package com.tcs.gosi.pojo;

import java.util.List;

public class output {

	public output() {
		// TODO Auto-generated constructor stub
	}
	
	List<DeploymentDatum> deploymentData;

	public List<DeploymentDatum> getDeploymentData() {
		return deploymentData;
	}

	public void setDeploymentData(List<DeploymentDatum> deploymentData) {
		this.deploymentData = deploymentData;
	}

}

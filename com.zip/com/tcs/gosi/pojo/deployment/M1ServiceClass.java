
package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "serviceClass",
    "bo",
    "description",
    "procedureTypes",
    "activityTypes",
    "version"
})
public class M1ServiceClass {

    @JsonProperty("serviceClass")
    private String serviceClass;
    @JsonProperty("bo")
    private String bo;
    @JsonProperty("description")
    private String description;
    @JsonProperty("procedureTypes")
    private ProcedureTypes procedureTypes;
    @JsonProperty("activityTypes")
    private List<ActivityType> activityTypes = null;
    @JsonProperty("version")
    private String version;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The serviceClass
     */
    @JsonProperty("serviceClass")
    public String getServiceClass() {
        return serviceClass;
    }

    /**
     * 
     * @param serviceClass
     *     The serviceClass
     */
    @JsonProperty("serviceClass")
    public void setServiceClass(String serviceClass) {
        this.serviceClass = serviceClass;
    }

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The procedureTypes
     */
    @JsonProperty("procedureTypes")
    public ProcedureTypes getProcedureTypes() {
        return procedureTypes;
    }

    /**
     * 
     * @param procedureTypes
     *     The procedureTypes
     */
    @JsonProperty("procedureTypes")
    public void setProcedureTypes(ProcedureTypes procedureTypes) {
        this.procedureTypes = procedureTypes;
    }

    /**
     * 
     * @return
     *     The activityTypes
     */
    @JsonProperty("activityTypes")
    public List<ActivityType> getActivityTypes() {
        return activityTypes;
    }

    /**
     * 
     * @param activityTypes
     *     The activityTypes
     */
    @JsonProperty("activityTypes")
    public void setActivityTypes(List<ActivityType> activityTypes) {
        this.activityTypes = activityTypes;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "serviceClass":
                if (value instanceof String) {
                    setServiceClass(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"serviceClass\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "procedureTypes":
                if (value instanceof ProcedureTypes) {
                    setProcedureTypes(((ProcedureTypes) value));
                } else {
                    throw new IllegalArgumentException(("property \"procedureTypes\" is of type \"com.tcs.gosi.pojo.deployment.ProcedureTypes\", but got "+ value.getClass().toString()));
                }
                return true;
            case "activityTypes":
                if (value instanceof List) {
                    setActivityTypes(((List<ActivityType> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"activityTypes\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ActivityType>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "serviceClass":
                return getServiceClass();
            case "bo":
                return getBo();
            case "description":
                return getDescription();
            case "procedureTypes":
                return getProcedureTypes();
            case "activityTypes":
                return getActivityTypes();
            case "version":
                return getVersion();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1ServiceClass.NOT_FOUND_VALUE);
        if (M1ServiceClass.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

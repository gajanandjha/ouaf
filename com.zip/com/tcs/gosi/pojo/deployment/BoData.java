
package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "boList"
})
public class BoData {

    @JsonProperty("boList")
    private List<BoList> boList = null;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The boList
     */
    @JsonProperty("boList")
    public List<BoList> getBoList() {
        return boList;
    }

    /**
     * 
     * @param boList
     *     The boList
     */
    @JsonProperty("boList")
    public void setBoList(List<BoList> boList) {
        this.boList = boList;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "boList":
                if (value instanceof List) {
                    setBoList(((List<BoList> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"boList\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.BoList>\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "boList":
                return getBoList();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, BoData.NOT_FOUND_VALUE);
        if (BoData.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

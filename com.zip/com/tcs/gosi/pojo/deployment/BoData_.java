
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "F1-COUNTRY",
    "M1-Excel",
    "M1-PDF",
    "M1-Word",
    "M1-CrewTimeUsageLookup",
    "M1-CustomerContactType",
    "M1-ExternalIdentifier",
    "M1-MCPCapabilityType",
    "M1-MCPIndicator",
    "M1-TimeSheetTimeType",
    "M1-GlobalConfigurations",
    "M1-StatusReason",
    "F1-BOStatusReason",
    "M1-RemarkType",
    "M1-ServiceClass",
    "M1-CrPTimesheetTyp",
    "M1-ResTimesheetTyp",
    "M1-BreakTaskType",
    "M1-ActivityType",
    "M1-ComplexActivityType",
    "M1-DepotRelatedActivityType",
    "M1-DepotTaskType",
    "M1-DepotBreakType",
    "M1-POUTaskType",
    "M1-NonPrdTaskType"
})
public class BoData_ {

    @JsonProperty("F1-COUNTRY")
    private F1COUNTRY f1COUNTRY;
    @JsonProperty("M1-Excel")
    private M1Excel m1Excel;
    @JsonProperty("M1-PDF")
    private M1PDF m1PDF;
    @JsonProperty("M1-Word")
    private M1Word m1Word;
    @JsonProperty("M1-CrewTimeUsageLookup")
    private M1CrewTimeUsageLookup m1CrewTimeUsageLookup;
    @JsonProperty("M1-CustomerContactType")
    private M1CustomerContactType m1CustomerContactType;
    @JsonProperty("M1-ExternalIdentifier")
    private M1ExternalIdentifier m1ExternalIdentifier;
    @JsonProperty("M1-MCPCapabilityType")
    private M1MCPCapabilityType m1MCPCapabilityType;
    @JsonProperty("M1-MCPIndicator")
    private M1MCPIndicator m1MCPIndicator;
    @JsonProperty("M1-TimeSheetTimeType")
    private M1TimeSheetTimeType m1TimeSheetTimeType;
    @JsonProperty("M1-GlobalConfigurations")
    private M1GlobalConfigurations m1GlobalConfigurations;
    @JsonProperty("M1-StatusReason")
    private M1StatusReason m1StatusReason;
    @JsonProperty("F1-BOStatusReason")
    private F1BOStatusReason f1BOStatusReason;
    @JsonProperty("M1-RemarkType")
    private M1RemarkType m1RemarkType;
    @JsonProperty("M1-ServiceClass")
    private M1ServiceClass m1ServiceClass;
    @JsonProperty("M1-CrPTimesheetTyp")
    private M1CrPTimesheetTyp m1CrPTimesheetTyp;
    @JsonProperty("M1-ResTimesheetTyp")
    private M1ResTimesheetTyp m1ResTimesheetTyp;
    @JsonProperty("M1-BreakTaskType")
    private M1BreakTaskType m1BreakTaskType;
    @JsonProperty("M1-ActivityType")
    private M1ActivityType m1ActivityType;
    @JsonProperty("M1-ComplexActivityType")
    private M1ComplexActivityType m1ComplexActivityType;
    @JsonProperty("M1-DepotRelatedActivityType")
    private M1DepotRelatedActivityType m1DepotRelatedActivityType;
    @JsonProperty("M1-DepotTaskType")
    private M1DepotTaskType m1DepotTaskType;
    @JsonProperty("M1-DepotBreakType")
    private M1DepotBreakType m1DepotBreakType;
    @JsonProperty("M1-POUTaskType")
    private M1POUTaskType m1POUTaskType;
    @JsonProperty("M1-NonPrdTaskType")
    private M1NonPrdTaskType m1NonPrdTaskType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The f1COUNTRY
     */
    @JsonProperty("F1-COUNTRY")
    public F1COUNTRY getF1COUNTRY() {
        return f1COUNTRY;
    }

    /**
     * 
     * @param f1COUNTRY
     *     The F1-COUNTRY
     */
    @JsonProperty("F1-COUNTRY")
    public void setF1COUNTRY(F1COUNTRY f1COUNTRY) {
        this.f1COUNTRY = f1COUNTRY;
    }

    /**
     * 
     * @return
     *     The m1Excel
     */
    @JsonProperty("M1-Excel")
    public M1Excel getM1Excel() {
        return m1Excel;
    }

    /**
     * 
     * @param m1Excel
     *     The M1-Excel
     */
    @JsonProperty("M1-Excel")
    public void setM1Excel(M1Excel m1Excel) {
        this.m1Excel = m1Excel;
    }

    /**
     * 
     * @return
     *     The m1PDF
     */
    @JsonProperty("M1-PDF")
    public M1PDF getM1PDF() {
        return m1PDF;
    }

    /**
     * 
     * @param m1PDF
     *     The M1-PDF
     */
    @JsonProperty("M1-PDF")
    public void setM1PDF(M1PDF m1PDF) {
        this.m1PDF = m1PDF;
    }

    /**
     * 
     * @return
     *     The m1Word
     */
    @JsonProperty("M1-Word")
    public M1Word getM1Word() {
        return m1Word;
    }

    /**
     * 
     * @param m1Word
     *     The M1-Word
     */
    @JsonProperty("M1-Word")
    public void setM1Word(M1Word m1Word) {
        this.m1Word = m1Word;
    }

    /**
     * 
     * @return
     *     The m1CrewTimeUsageLookup
     */
    @JsonProperty("M1-CrewTimeUsageLookup")
    public M1CrewTimeUsageLookup getM1CrewTimeUsageLookup() {
        return m1CrewTimeUsageLookup;
    }

    /**
     * 
     * @param m1CrewTimeUsageLookup
     *     The M1-CrewTimeUsageLookup
     */
    @JsonProperty("M1-CrewTimeUsageLookup")
    public void setM1CrewTimeUsageLookup(M1CrewTimeUsageLookup m1CrewTimeUsageLookup) {
        this.m1CrewTimeUsageLookup = m1CrewTimeUsageLookup;
    }

    /**
     * 
     * @return
     *     The m1CustomerContactType
     */
    @JsonProperty("M1-CustomerContactType")
    public M1CustomerContactType getM1CustomerContactType() {
        return m1CustomerContactType;
    }

    /**
     * 
     * @param m1CustomerContactType
     *     The M1-CustomerContactType
     */
    @JsonProperty("M1-CustomerContactType")
    public void setM1CustomerContactType(M1CustomerContactType m1CustomerContactType) {
        this.m1CustomerContactType = m1CustomerContactType;
    }

    /**
     * 
     * @return
     *     The m1ExternalIdentifier
     */
    @JsonProperty("M1-ExternalIdentifier")
    public M1ExternalIdentifier getM1ExternalIdentifier() {
        return m1ExternalIdentifier;
    }

    /**
     * 
     * @param m1ExternalIdentifier
     *     The M1-ExternalIdentifier
     */
    @JsonProperty("M1-ExternalIdentifier")
    public void setM1ExternalIdentifier(M1ExternalIdentifier m1ExternalIdentifier) {
        this.m1ExternalIdentifier = m1ExternalIdentifier;
    }

    /**
     * 
     * @return
     *     The m1MCPCapabilityType
     */
    @JsonProperty("M1-MCPCapabilityType")
    public M1MCPCapabilityType getM1MCPCapabilityType() {
        return m1MCPCapabilityType;
    }

    /**
     * 
     * @param m1MCPCapabilityType
     *     The M1-MCPCapabilityType
     */
    @JsonProperty("M1-MCPCapabilityType")
    public void setM1MCPCapabilityType(M1MCPCapabilityType m1MCPCapabilityType) {
        this.m1MCPCapabilityType = m1MCPCapabilityType;
    }

    /**
     * 
     * @return
     *     The m1MCPIndicator
     */
    @JsonProperty("M1-MCPIndicator")
    public M1MCPIndicator getM1MCPIndicator() {
        return m1MCPIndicator;
    }

    /**
     * 
     * @param m1MCPIndicator
     *     The M1-MCPIndicator
     */
    @JsonProperty("M1-MCPIndicator")
    public void setM1MCPIndicator(M1MCPIndicator m1MCPIndicator) {
        this.m1MCPIndicator = m1MCPIndicator;
    }

    /**
     * 
     * @return
     *     The m1TimeSheetTimeType
     */
    @JsonProperty("M1-TimeSheetTimeType")
    public M1TimeSheetTimeType getM1TimeSheetTimeType() {
        return m1TimeSheetTimeType;
    }

    /**
     * 
     * @param m1TimeSheetTimeType
     *     The M1-TimeSheetTimeType
     */
    @JsonProperty("M1-TimeSheetTimeType")
    public void setM1TimeSheetTimeType(M1TimeSheetTimeType m1TimeSheetTimeType) {
        this.m1TimeSheetTimeType = m1TimeSheetTimeType;
    }

    /**
     * 
     * @return
     *     The m1GlobalConfigurations
     */
    @JsonProperty("M1-GlobalConfigurations")
    public M1GlobalConfigurations getM1GlobalConfigurations() {
        return m1GlobalConfigurations;
    }

    /**
     * 
     * @param m1GlobalConfigurations
     *     The M1-GlobalConfigurations
     */
    @JsonProperty("M1-GlobalConfigurations")
    public void setM1GlobalConfigurations(M1GlobalConfigurations m1GlobalConfigurations) {
        this.m1GlobalConfigurations = m1GlobalConfigurations;
    }

    /**
     * 
     * @return
     *     The m1StatusReason
     */
    @JsonProperty("M1-StatusReason")
    public M1StatusReason getM1StatusReason() {
        return m1StatusReason;
    }

    /**
     * 
     * @param m1StatusReason
     *     The M1-StatusReason
     */
    @JsonProperty("M1-StatusReason")
    public void setM1StatusReason(M1StatusReason m1StatusReason) {
        this.m1StatusReason = m1StatusReason;
    }

    /**
     * 
     * @return
     *     The f1BOStatusReason
     */
    @JsonProperty("F1-BOStatusReason")
    public F1BOStatusReason getF1BOStatusReason() {
        return f1BOStatusReason;
    }

    /**
     * 
     * @param f1BOStatusReason
     *     The F1-BOStatusReason
     */
    @JsonProperty("F1-BOStatusReason")
    public void setF1BOStatusReason(F1BOStatusReason f1BOStatusReason) {
        this.f1BOStatusReason = f1BOStatusReason;
    }

    /**
     * 
     * @return
     *     The m1RemarkType
     */
    @JsonProperty("M1-RemarkType")
    public M1RemarkType getM1RemarkType() {
        return m1RemarkType;
    }

    /**
     * 
     * @param m1RemarkType
     *     The M1-RemarkType
     */
    @JsonProperty("M1-RemarkType")
    public void setM1RemarkType(M1RemarkType m1RemarkType) {
        this.m1RemarkType = m1RemarkType;
    }

    /**
     * 
     * @return
     *     The m1ServiceClass
     */
    @JsonProperty("M1-ServiceClass")
    public M1ServiceClass getM1ServiceClass() {
        return m1ServiceClass;
    }

    /**
     * 
     * @param m1ServiceClass
     *     The M1-ServiceClass
     */
    @JsonProperty("M1-ServiceClass")
    public void setM1ServiceClass(M1ServiceClass m1ServiceClass) {
        this.m1ServiceClass = m1ServiceClass;
    }

    /**
     * 
     * @return
     *     The m1CrPTimesheetTyp
     */
    @JsonProperty("M1-CrPTimesheetTyp")
    public M1CrPTimesheetTyp getM1CrPTimesheetTyp() {
        return m1CrPTimesheetTyp;
    }

    /**
     * 
     * @param m1CrPTimesheetTyp
     *     The M1-CrPTimesheetTyp
     */
    @JsonProperty("M1-CrPTimesheetTyp")
    public void setM1CrPTimesheetTyp(M1CrPTimesheetTyp m1CrPTimesheetTyp) {
        this.m1CrPTimesheetTyp = m1CrPTimesheetTyp;
    }

    /**
     * 
     * @return
     *     The m1ResTimesheetTyp
     */
    @JsonProperty("M1-ResTimesheetTyp")
    public M1ResTimesheetTyp getM1ResTimesheetTyp() {
        return m1ResTimesheetTyp;
    }

    /**
     * 
     * @param m1ResTimesheetTyp
     *     The M1-ResTimesheetTyp
     */
    @JsonProperty("M1-ResTimesheetTyp")
    public void setM1ResTimesheetTyp(M1ResTimesheetTyp m1ResTimesheetTyp) {
        this.m1ResTimesheetTyp = m1ResTimesheetTyp;
    }

    /**
     * 
     * @return
     *     The m1BreakTaskType
     */
    @JsonProperty("M1-BreakTaskType")
    public M1BreakTaskType getM1BreakTaskType() {
        return m1BreakTaskType;
    }

    /**
     * 
     * @param m1BreakTaskType
     *     The M1-BreakTaskType
     */
    @JsonProperty("M1-BreakTaskType")
    public void setM1BreakTaskType(M1BreakTaskType m1BreakTaskType) {
        this.m1BreakTaskType = m1BreakTaskType;
    }

    /**
     * 
     * @return
     *     The m1ActivityType
     */
    @JsonProperty("M1-ActivityType")
    public M1ActivityType getM1ActivityType() {
        return m1ActivityType;
    }

    /**
     * 
     * @param m1ActivityType
     *     The M1-ActivityType
     */
    @JsonProperty("M1-ActivityType")
    public void setM1ActivityType(M1ActivityType m1ActivityType) {
        this.m1ActivityType = m1ActivityType;
    }

    /**
     * 
     * @return
     *     The m1ComplexActivityType
     */
    @JsonProperty("M1-ComplexActivityType")
    public M1ComplexActivityType getM1ComplexActivityType() {
        return m1ComplexActivityType;
    }

    /**
     * 
     * @param m1ComplexActivityType
     *     The M1-ComplexActivityType
     */
    @JsonProperty("M1-ComplexActivityType")
    public void setM1ComplexActivityType(M1ComplexActivityType m1ComplexActivityType) {
        this.m1ComplexActivityType = m1ComplexActivityType;
    }

    /**
     * 
     * @return
     *     The m1DepotRelatedActivityType
     */
    @JsonProperty("M1-DepotRelatedActivityType")
    public M1DepotRelatedActivityType getM1DepotRelatedActivityType() {
        return m1DepotRelatedActivityType;
    }

    /**
     * 
     * @param m1DepotRelatedActivityType
     *     The M1-DepotRelatedActivityType
     */
    @JsonProperty("M1-DepotRelatedActivityType")
    public void setM1DepotRelatedActivityType(M1DepotRelatedActivityType m1DepotRelatedActivityType) {
        this.m1DepotRelatedActivityType = m1DepotRelatedActivityType;
    }

    /**
     * 
     * @return
     *     The m1DepotTaskType
     */
    @JsonProperty("M1-DepotTaskType")
    public M1DepotTaskType getM1DepotTaskType() {
        return m1DepotTaskType;
    }

    /**
     * 
     * @param m1DepotTaskType
     *     The M1-DepotTaskType
     */
    @JsonProperty("M1-DepotTaskType")
    public void setM1DepotTaskType(M1DepotTaskType m1DepotTaskType) {
        this.m1DepotTaskType = m1DepotTaskType;
    }

    /**
     * 
     * @return
     *     The m1DepotBreakType
     */
    @JsonProperty("M1-DepotBreakType")
    public M1DepotBreakType getM1DepotBreakType() {
        return m1DepotBreakType;
    }

    /**
     * 
     * @param m1DepotBreakType
     *     The M1-DepotBreakType
     */
    @JsonProperty("M1-DepotBreakType")
    public void setM1DepotBreakType(M1DepotBreakType m1DepotBreakType) {
        this.m1DepotBreakType = m1DepotBreakType;
    }

    /**
     * 
     * @return
     *     The m1POUTaskType
     */
    @JsonProperty("M1-POUTaskType")
    public M1POUTaskType getM1POUTaskType() {
        return m1POUTaskType;
    }

    /**
     * 
     * @param m1POUTaskType
     *     The M1-POUTaskType
     */
    @JsonProperty("M1-POUTaskType")
    public void setM1POUTaskType(M1POUTaskType m1POUTaskType) {
        this.m1POUTaskType = m1POUTaskType;
    }

    /**
     * 
     * @return
     *     The m1NonPrdTaskType
     */
    @JsonProperty("M1-NonPrdTaskType")
    public M1NonPrdTaskType getM1NonPrdTaskType() {
        return m1NonPrdTaskType;
    }

    /**
     * 
     * @param m1NonPrdTaskType
     *     The M1-NonPrdTaskType
     */
    @JsonProperty("M1-NonPrdTaskType")
    public void setM1NonPrdTaskType(M1NonPrdTaskType m1NonPrdTaskType) {
        this.m1NonPrdTaskType = m1NonPrdTaskType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "F1-COUNTRY":
                if (value instanceof F1COUNTRY) {
                    setF1COUNTRY(((F1COUNTRY) value));
                } else {
                    throw new IllegalArgumentException(("property \"F1-COUNTRY\" is of type \"com.tcs.gosi.pojo.deployment.F1COUNTRY\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-Excel":
                if (value instanceof M1Excel) {
                    setM1Excel(((M1Excel) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-Excel\" is of type \"com.tcs.gosi.pojo.deployment.M1Excel\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-PDF":
                if (value instanceof M1PDF) {
                    setM1PDF(((M1PDF) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-PDF\" is of type \"com.tcs.gosi.pojo.deployment.M1PDF\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-Word":
                if (value instanceof M1Word) {
                    setM1Word(((M1Word) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-Word\" is of type \"com.tcs.gosi.pojo.deployment.M1Word\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-CrewTimeUsageLookup":
                if (value instanceof M1CrewTimeUsageLookup) {
                    setM1CrewTimeUsageLookup(((M1CrewTimeUsageLookup) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-CrewTimeUsageLookup\" is of type \"com.tcs.gosi.pojo.deployment.M1CrewTimeUsageLookup\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-CustomerContactType":
                if (value instanceof M1CustomerContactType) {
                    setM1CustomerContactType(((M1CustomerContactType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-CustomerContactType\" is of type \"com.tcs.gosi.pojo.deployment.M1CustomerContactType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-ExternalIdentifier":
                if (value instanceof M1ExternalIdentifier) {
                    setM1ExternalIdentifier(((M1ExternalIdentifier) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-ExternalIdentifier\" is of type \"com.tcs.gosi.pojo.deployment.M1ExternalIdentifier\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-MCPCapabilityType":
                if (value instanceof M1MCPCapabilityType) {
                    setM1MCPCapabilityType(((M1MCPCapabilityType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-MCPCapabilityType\" is of type \"com.tcs.gosi.pojo.deployment.M1MCPCapabilityType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-MCPIndicator":
                if (value instanceof M1MCPIndicator) {
                    setM1MCPIndicator(((M1MCPIndicator) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-MCPIndicator\" is of type \"com.tcs.gosi.pojo.deployment.M1MCPIndicator\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-TimeSheetTimeType":
                if (value instanceof M1TimeSheetTimeType) {
                    setM1TimeSheetTimeType(((M1TimeSheetTimeType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-TimeSheetTimeType\" is of type \"com.tcs.gosi.pojo.deployment.M1TimeSheetTimeType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-GlobalConfigurations":
                if (value instanceof M1GlobalConfigurations) {
                    setM1GlobalConfigurations(((M1GlobalConfigurations) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-GlobalConfigurations\" is of type \"com.tcs.gosi.pojo.deployment.M1GlobalConfigurations\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-StatusReason":
                if (value instanceof M1StatusReason) {
                    setM1StatusReason(((M1StatusReason) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-StatusReason\" is of type \"com.tcs.gosi.pojo.deployment.M1StatusReason\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1-BOStatusReason":
                if (value instanceof F1BOStatusReason) {
                    setF1BOStatusReason(((F1BOStatusReason) value));
                } else {
                    throw new IllegalArgumentException(("property \"F1-BOStatusReason\" is of type \"com.tcs.gosi.pojo.deployment.F1BOStatusReason\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-RemarkType":
                if (value instanceof M1RemarkType) {
                    setM1RemarkType(((M1RemarkType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-RemarkType\" is of type \"com.tcs.gosi.pojo.deployment.M1RemarkType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-ServiceClass":
                if (value instanceof M1ServiceClass) {
                    setM1ServiceClass(((M1ServiceClass) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-ServiceClass\" is of type \"com.tcs.gosi.pojo.deployment.M1ServiceClass\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-CrPTimesheetTyp":
                if (value instanceof M1CrPTimesheetTyp) {
                    setM1CrPTimesheetTyp(((M1CrPTimesheetTyp) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-CrPTimesheetTyp\" is of type \"com.tcs.gosi.pojo.deployment.M1CrPTimesheetTyp\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-ResTimesheetTyp":
                if (value instanceof M1ResTimesheetTyp) {
                    setM1ResTimesheetTyp(((M1ResTimesheetTyp) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-ResTimesheetTyp\" is of type \"com.tcs.gosi.pojo.deployment.M1ResTimesheetTyp\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-BreakTaskType":
                if (value instanceof M1BreakTaskType) {
                    setM1BreakTaskType(((M1BreakTaskType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-BreakTaskType\" is of type \"com.tcs.gosi.pojo.deployment.M1BreakTaskType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-ActivityType":
                if (value instanceof M1ActivityType) {
                    setM1ActivityType(((M1ActivityType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-ActivityType\" is of type \"com.tcs.gosi.pojo.deployment.M1ActivityType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-ComplexActivityType":
                if (value instanceof M1ComplexActivityType) {
                    setM1ComplexActivityType(((M1ComplexActivityType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-ComplexActivityType\" is of type \"com.tcs.gosi.pojo.deployment.M1ComplexActivityType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-DepotRelatedActivityType":
                if (value instanceof M1DepotRelatedActivityType) {
                    setM1DepotRelatedActivityType(((M1DepotRelatedActivityType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-DepotRelatedActivityType\" is of type \"com.tcs.gosi.pojo.deployment.M1DepotRelatedActivityType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-DepotTaskType":
                if (value instanceof M1DepotTaskType) {
                    setM1DepotTaskType(((M1DepotTaskType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-DepotTaskType\" is of type \"com.tcs.gosi.pojo.deployment.M1DepotTaskType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-DepotBreakType":
                if (value instanceof M1DepotBreakType) {
                    setM1DepotBreakType(((M1DepotBreakType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-DepotBreakType\" is of type \"com.tcs.gosi.pojo.deployment.M1DepotBreakType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-POUTaskType":
                if (value instanceof M1POUTaskType) {
                    setM1POUTaskType(((M1POUTaskType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-POUTaskType\" is of type \"com.tcs.gosi.pojo.deployment.M1POUTaskType\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-NonPrdTaskType":
                if (value instanceof M1NonPrdTaskType) {
                    setM1NonPrdTaskType(((M1NonPrdTaskType) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-NonPrdTaskType\" is of type \"com.tcs.gosi.pojo.deployment.M1NonPrdTaskType\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "F1-COUNTRY":
                return getF1COUNTRY();
            case "M1-Excel":
                return getM1Excel();
            case "M1-PDF":
                return getM1PDF();
            case "M1-Word":
                return getM1Word();
            case "M1-CrewTimeUsageLookup":
                return getM1CrewTimeUsageLookup();
            case "M1-CustomerContactType":
                return getM1CustomerContactType();
            case "M1-ExternalIdentifier":
                return getM1ExternalIdentifier();
            case "M1-MCPCapabilityType":
                return getM1MCPCapabilityType();
            case "M1-MCPIndicator":
                return getM1MCPIndicator();
            case "M1-TimeSheetTimeType":
                return getM1TimeSheetTimeType();
            case "M1-GlobalConfigurations":
                return getM1GlobalConfigurations();
            case "M1-StatusReason":
                return getM1StatusReason();
            case "F1-BOStatusReason":
                return getF1BOStatusReason();
            case "M1-RemarkType":
                return getM1RemarkType();
            case "M1-ServiceClass":
                return getM1ServiceClass();
            case "M1-CrPTimesheetTyp":
                return getM1CrPTimesheetTyp();
            case "M1-ResTimesheetTyp":
                return getM1ResTimesheetTyp();
            case "M1-BreakTaskType":
                return getM1BreakTaskType();
            case "M1-ActivityType":
                return getM1ActivityType();
            case "M1-ComplexActivityType":
                return getM1ComplexActivityType();
            case "M1-DepotRelatedActivityType":
                return getM1DepotRelatedActivityType();
            case "M1-DepotTaskType":
                return getM1DepotTaskType();
            case "M1-DepotBreakType":
                return getM1DepotBreakType();
            case "M1-POUTaskType":
                return getM1POUTaskType();
            case "M1-NonPrdTaskType":
                return getM1NonPrdTaskType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, BoData_.NOT_FOUND_VALUE);
        if (BoData_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

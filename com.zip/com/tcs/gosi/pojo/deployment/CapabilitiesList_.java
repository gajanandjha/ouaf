
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "capabilityTypeUsage",
    "count",
    "taskType",
    "capabilityType"
})
public class CapabilitiesList_ {

    @JsonProperty("capabilityTypeUsage")
    private String capabilityTypeUsage;
    @JsonProperty("count")
    private String count;
    @JsonProperty("taskType")
    private String taskType;
    @JsonProperty("capabilityType")
    private String capabilityType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The capabilityTypeUsage
     */
    @JsonProperty("capabilityTypeUsage")
    public String getCapabilityTypeUsage() {
        return capabilityTypeUsage;
    }

    /**
     * 
     * @param capabilityTypeUsage
     *     The capabilityTypeUsage
     */
    @JsonProperty("capabilityTypeUsage")
    public void setCapabilityTypeUsage(String capabilityTypeUsage) {
        this.capabilityTypeUsage = capabilityTypeUsage;
    }

    /**
     * 
     * @return
     *     The count
     */
    @JsonProperty("count")
    public String getCount() {
        return count;
    }

    /**
     * 
     * @param count
     *     The count
     */
    @JsonProperty("count")
    public void setCount(String count) {
        this.count = count;
    }

    /**
     * 
     * @return
     *     The taskType
     */
    @JsonProperty("taskType")
    public String getTaskType() {
        return taskType;
    }

    /**
     * 
     * @param taskType
     *     The taskType
     */
    @JsonProperty("taskType")
    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    /**
     * 
     * @return
     *     The capabilityType
     */
    @JsonProperty("capabilityType")
    public String getCapabilityType() {
        return capabilityType;
    }

    /**
     * 
     * @param capabilityType
     *     The capabilityType
     */
    @JsonProperty("capabilityType")
    public void setCapabilityType(String capabilityType) {
        this.capabilityType = capabilityType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "capabilityTypeUsage":
                if (value instanceof String) {
                    setCapabilityTypeUsage(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"capabilityTypeUsage\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "count":
                if (value instanceof String) {
                    setCount(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"count\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskType":
                if (value instanceof String) {
                    setTaskType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "capabilityType":
                if (value instanceof String) {
                    setCapabilityType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"capabilityType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "capabilityTypeUsage":
                return getCapabilityTypeUsage();
            case "count":
                return getCount();
            case "taskType":
                return getTaskType();
            case "capabilityType":
                return getCapabilityType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, CapabilitiesList_.NOT_FOUND_VALUE);
        if (CapabilitiesList_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "fileSize",
    "creationDateTime",
    "creationUser",
    "bo",
    "uploadDTTM",
    "attachmentId",
    "description",
    "attachmentFileName",
    "sendToCrew",
    "mobileUse",
    "attachmentData",
    "version"
})
public class M1PDF {

    @JsonProperty("fileSize")
    private String fileSize;
    @JsonProperty("creationDateTime")
    private String creationDateTime;
    @JsonProperty("creationUser")
    private String creationUser;
    @JsonProperty("bo")
    private String bo;
    @JsonProperty("uploadDTTM")
    private String uploadDTTM;
    @JsonProperty("attachmentId")
    private String attachmentId;
    @JsonProperty("description")
    private String description;
    @JsonProperty("attachmentFileName")
    private String attachmentFileName;
    @JsonProperty("sendToCrew")
    private String sendToCrew;
    @JsonProperty("mobileUse")
    private MobileUse_ mobileUse;
    @JsonProperty("attachmentData")
    private String attachmentData;
    @JsonProperty("version")
    private String version;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The fileSize
     */
    @JsonProperty("fileSize")
    public String getFileSize() {
        return fileSize;
    }

    /**
     * 
     * @param fileSize
     *     The fileSize
     */
    @JsonProperty("fileSize")
    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    /**
     * 
     * @return
     *     The creationDateTime
     */
    @JsonProperty("creationDateTime")
    public String getCreationDateTime() {
        return creationDateTime;
    }

    /**
     * 
     * @param creationDateTime
     *     The creationDateTime
     */
    @JsonProperty("creationDateTime")
    public void setCreationDateTime(String creationDateTime) {
        this.creationDateTime = creationDateTime;
    }

    /**
     * 
     * @return
     *     The creationUser
     */
    @JsonProperty("creationUser")
    public String getCreationUser() {
        return creationUser;
    }

    /**
     * 
     * @param creationUser
     *     The creationUser
     */
    @JsonProperty("creationUser")
    public void setCreationUser(String creationUser) {
        this.creationUser = creationUser;
    }

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The uploadDTTM
     */
    @JsonProperty("uploadDTTM")
    public String getUploadDTTM() {
        return uploadDTTM;
    }

    /**
     * 
     * @param uploadDTTM
     *     The uploadDTTM
     */
    @JsonProperty("uploadDTTM")
    public void setUploadDTTM(String uploadDTTM) {
        this.uploadDTTM = uploadDTTM;
    }

    /**
     * 
     * @return
     *     The attachmentId
     */
    @JsonProperty("attachmentId")
    public String getAttachmentId() {
        return attachmentId;
    }

    /**
     * 
     * @param attachmentId
     *     The attachmentId
     */
    @JsonProperty("attachmentId")
    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The attachmentFileName
     */
    @JsonProperty("attachmentFileName")
    public String getAttachmentFileName() {
        return attachmentFileName;
    }

    /**
     * 
     * @param attachmentFileName
     *     The attachmentFileName
     */
    @JsonProperty("attachmentFileName")
    public void setAttachmentFileName(String attachmentFileName) {
        this.attachmentFileName = attachmentFileName;
    }

    /**
     * 
     * @return
     *     The sendToCrew
     */
    @JsonProperty("sendToCrew")
    public String getSendToCrew() {
        return sendToCrew;
    }

    /**
     * 
     * @param sendToCrew
     *     The sendToCrew
     */
    @JsonProperty("sendToCrew")
    public void setSendToCrew(String sendToCrew) {
        this.sendToCrew = sendToCrew;
    }

    /**
     * 
     * @return
     *     The mobileUse
     */
    @JsonProperty("mobileUse")
    public MobileUse_ getMobileUse() {
        return mobileUse;
    }

    /**
     * 
     * @param mobileUse
     *     The mobileUse
     */
    @JsonProperty("mobileUse")
    public void setMobileUse(MobileUse_ mobileUse) {
        this.mobileUse = mobileUse;
    }

    /**
     * 
     * @return
     *     The attachmentData
     */
    @JsonProperty("attachmentData")
    public String getAttachmentData() {
        return attachmentData;
    }

    /**
     * 
     * @param attachmentData
     *     The attachmentData
     */
    @JsonProperty("attachmentData")
    public void setAttachmentData(String attachmentData) {
        this.attachmentData = attachmentData;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "fileSize":
                if (value instanceof String) {
                    setFileSize(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"fileSize\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "creationDateTime":
                if (value instanceof String) {
                    setCreationDateTime(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"creationDateTime\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "creationUser":
                if (value instanceof String) {
                    setCreationUser(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"creationUser\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "uploadDTTM":
                if (value instanceof String) {
                    setUploadDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"uploadDTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "attachmentId":
                if (value instanceof String) {
                    setAttachmentId(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentId\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "attachmentFileName":
                if (value instanceof String) {
                    setAttachmentFileName(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentFileName\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "sendToCrew":
                if (value instanceof String) {
                    setSendToCrew(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"sendToCrew\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "mobileUse":
                if (value instanceof MobileUse_) {
                    setMobileUse(((MobileUse_) value));
                } else {
                    throw new IllegalArgumentException(("property \"mobileUse\" is of type \"com.tcs.gosi.pojo.deployment.MobileUse_\", but got "+ value.getClass().toString()));
                }
                return true;
            case "attachmentData":
                if (value instanceof String) {
                    setAttachmentData(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentData\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "fileSize":
                return getFileSize();
            case "creationDateTime":
                return getCreationDateTime();
            case "creationUser":
                return getCreationUser();
            case "bo":
                return getBo();
            case "uploadDTTM":
                return getUploadDTTM();
            case "attachmentId":
                return getAttachmentId();
            case "description":
                return getDescription();
            case "attachmentFileName":
                return getAttachmentFileName();
            case "sendToCrew":
                return getSendToCrew();
            case "mobileUse":
                return getMobileUse();
            case "attachmentData":
                return getAttachmentData();
            case "version":
                return getVersion();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1PDF.NOT_FOUND_VALUE);
        if (M1PDF.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

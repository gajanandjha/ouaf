
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bo",
    "boData",
    "mo",
    "key"
})
public class BoList {

    @JsonProperty("bo")
    private String bo;
    @JsonProperty("boData")
    private BoData_ boData;
    @JsonProperty("mo")
    private String mo;
    @JsonProperty("key")
    private String key;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The boData
     */
    @JsonProperty("boData")
    public BoData_ getBoData() {
        return boData;
    }

    /**
     * 
     * @param boData
     *     The boData
     */
    @JsonProperty("boData")
    public void setBoData(BoData_ boData) {
        this.boData = boData;
    }

    /**
     * 
     * @return
     *     The mo
     */
    @JsonProperty("mo")
    public String getMo() {
        return mo;
    }

    /**
     * 
     * @param mo
     *     The mo
     */
    @JsonProperty("mo")
    public void setMo(String mo) {
        this.mo = mo;
    }

    /**
     * 
     * @return
     *     The key
     */
    @JsonProperty("key")
    public String getKey() {
        return key;
    }

    /**
     * 
     * @param key
     *     The key
     */
    @JsonProperty("key")
    public void setKey(String key) {
        this.key = key;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "boData":
                if (value instanceof BoData_) {
                    setBoData(((BoData_) value));
                } else {
                    throw new IllegalArgumentException(("property \"boData\" is of type \"com.tcs.gosi.pojo.deployment.BoData_\", but got "+ value.getClass().toString()));
                }
                return true;
            case "mo":
                if (value instanceof String) {
                    setMo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"mo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "key":
                if (value instanceof String) {
                    setKey(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"key\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "bo":
                return getBo();
            case "boData":
                return getBoData();
            case "mo":
                return getMo();
            case "key":
                return getKey();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, BoList.NOT_FOUND_VALUE);
        if (BoList.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

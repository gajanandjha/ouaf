
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "timesheetType",
    "taskTypeForPOU",
    "timesheetCorrection",
    "timesheetProcessType"
})
public class ResourceManagement {

    @JsonProperty("timesheetType")
    private String timesheetType;
    @JsonProperty("taskTypeForPOU")
    private String taskTypeForPOU;
    @JsonProperty("timesheetCorrection")
    private String timesheetCorrection;
    @JsonProperty("timesheetProcessType")
    private String timesheetProcessType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The timesheetType
     */
    @JsonProperty("timesheetType")
    public String getTimesheetType() {
        return timesheetType;
    }

    /**
     * 
     * @param timesheetType
     *     The timesheetType
     */
    @JsonProperty("timesheetType")
    public void setTimesheetType(String timesheetType) {
        this.timesheetType = timesheetType;
    }

    /**
     * 
     * @return
     *     The taskTypeForPOU
     */
    @JsonProperty("taskTypeForPOU")
    public String getTaskTypeForPOU() {
        return taskTypeForPOU;
    }

    /**
     * 
     * @param taskTypeForPOU
     *     The taskTypeForPOU
     */
    @JsonProperty("taskTypeForPOU")
    public void setTaskTypeForPOU(String taskTypeForPOU) {
        this.taskTypeForPOU = taskTypeForPOU;
    }

    /**
     * 
     * @return
     *     The timesheetCorrection
     */
    @JsonProperty("timesheetCorrection")
    public String getTimesheetCorrection() {
        return timesheetCorrection;
    }

    /**
     * 
     * @param timesheetCorrection
     *     The timesheetCorrection
     */
    @JsonProperty("timesheetCorrection")
    public void setTimesheetCorrection(String timesheetCorrection) {
        this.timesheetCorrection = timesheetCorrection;
    }

    /**
     * 
     * @return
     *     The timesheetProcessType
     */
    @JsonProperty("timesheetProcessType")
    public String getTimesheetProcessType() {
        return timesheetProcessType;
    }

    /**
     * 
     * @param timesheetProcessType
     *     The timesheetProcessType
     */
    @JsonProperty("timesheetProcessType")
    public void setTimesheetProcessType(String timesheetProcessType) {
        this.timesheetProcessType = timesheetProcessType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "timesheetType":
                if (value instanceof String) {
                    setTimesheetType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"timesheetType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskTypeForPOU":
                if (value instanceof String) {
                    setTaskTypeForPOU(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskTypeForPOU\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "timesheetCorrection":
                if (value instanceof String) {
                    setTimesheetCorrection(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"timesheetCorrection\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "timesheetProcessType":
                if (value instanceof String) {
                    setTimesheetProcessType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"timesheetProcessType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "timesheetType":
                return getTimesheetType();
            case "taskTypeForPOU":
                return getTaskTypeForPOU();
            case "timesheetCorrection":
                return getTimesheetCorrection();
            case "timesheetProcessType":
                return getTimesheetProcessType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ResourceManagement.NOT_FOUND_VALUE);
        if (ResourceManagement.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

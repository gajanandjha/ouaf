
package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "M1-TimeSheetTimeType",
    "M1-CustomerContactType",
    "M1-MCPCapabilityType",
    "M1-CrewTimeUsageLookup",
    "M1-ExternalIdentifier",
    "M1-MCPIndicator"
})
public class ExtLookups {

    @JsonProperty("M1-TimeSheetTimeType")
    private List<M1TimeSheetTimeType_> m1TimeSheetTimeType = null;
    @JsonProperty("M1-CustomerContactType")
    private List<M1CustomerContactType_> m1CustomerContactType = null;
    @JsonProperty("M1-MCPCapabilityType")
    private List<M1MCPCapabilityType_> m1MCPCapabilityType = null;
    @JsonProperty("M1-CrewTimeUsageLookup")
    private List<M1CrewTimeUsageLookup_> m1CrewTimeUsageLookup = null;
    @JsonProperty("M1-ExternalIdentifier")
    private List<M1ExternalIdentifier_> m1ExternalIdentifier = null;
    @JsonProperty("M1-MCPIndicator")
    private List<M1MCPIndicator_> m1MCPIndicator = null;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The m1TimeSheetTimeType
     */
    @JsonProperty("M1-TimeSheetTimeType")
    public List<M1TimeSheetTimeType_> getM1TimeSheetTimeType() {
        return m1TimeSheetTimeType;
    }

    /**
     * 
     * @param m1TimeSheetTimeType
     *     The M1-TimeSheetTimeType
     */
    @JsonProperty("M1-TimeSheetTimeType")
    public void setM1TimeSheetTimeType(List<M1TimeSheetTimeType_> m1TimeSheetTimeType) {
        this.m1TimeSheetTimeType = m1TimeSheetTimeType;
    }

    /**
     * 
     * @return
     *     The m1CustomerContactType
     */
    @JsonProperty("M1-CustomerContactType")
    public List<M1CustomerContactType_> getM1CustomerContactType() {
        return m1CustomerContactType;
    }

    /**
     * 
     * @param m1CustomerContactType
     *     The M1-CustomerContactType
     */
    @JsonProperty("M1-CustomerContactType")
    public void setM1CustomerContactType(List<M1CustomerContactType_> m1CustomerContactType) {
        this.m1CustomerContactType = m1CustomerContactType;
    }

    /**
     * 
     * @return
     *     The m1MCPCapabilityType
     */
    @JsonProperty("M1-MCPCapabilityType")
    public List<M1MCPCapabilityType_> getM1MCPCapabilityType() {
        return m1MCPCapabilityType;
    }

    /**
     * 
     * @param m1MCPCapabilityType
     *     The M1-MCPCapabilityType
     */
    @JsonProperty("M1-MCPCapabilityType")
    public void setM1MCPCapabilityType(List<M1MCPCapabilityType_> m1MCPCapabilityType) {
        this.m1MCPCapabilityType = m1MCPCapabilityType;
    }

    /**
     * 
     * @return
     *     The m1CrewTimeUsageLookup
     */
    @JsonProperty("M1-CrewTimeUsageLookup")
    public List<M1CrewTimeUsageLookup_> getM1CrewTimeUsageLookup() {
        return m1CrewTimeUsageLookup;
    }

    /**
     * 
     * @param m1CrewTimeUsageLookup
     *     The M1-CrewTimeUsageLookup
     */
    @JsonProperty("M1-CrewTimeUsageLookup")
    public void setM1CrewTimeUsageLookup(List<M1CrewTimeUsageLookup_> m1CrewTimeUsageLookup) {
        this.m1CrewTimeUsageLookup = m1CrewTimeUsageLookup;
    }

    /**
     * 
     * @return
     *     The m1ExternalIdentifier
     */
    @JsonProperty("M1-ExternalIdentifier")
    public List<M1ExternalIdentifier_> getM1ExternalIdentifier() {
        return m1ExternalIdentifier;
    }

    /**
     * 
     * @param m1ExternalIdentifier
     *     The M1-ExternalIdentifier
     */
    @JsonProperty("M1-ExternalIdentifier")
    public void setM1ExternalIdentifier(List<M1ExternalIdentifier_> m1ExternalIdentifier) {
        this.m1ExternalIdentifier = m1ExternalIdentifier;
    }

    /**
     * 
     * @return
     *     The m1MCPIndicator
     */
    @JsonProperty("M1-MCPIndicator")
    public List<M1MCPIndicator_> getM1MCPIndicator() {
        return m1MCPIndicator;
    }

    /**
     * 
     * @param m1MCPIndicator
     *     The M1-MCPIndicator
     */
    @JsonProperty("M1-MCPIndicator")
    public void setM1MCPIndicator(List<M1MCPIndicator_> m1MCPIndicator) {
        this.m1MCPIndicator = m1MCPIndicator;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "M1-TimeSheetTimeType":
                if (value instanceof List) {
                    setM1TimeSheetTimeType(((List<M1TimeSheetTimeType_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-TimeSheetTimeType\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TimeSheetTimeType_>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-CustomerContactType":
                if (value instanceof List) {
                    setM1CustomerContactType(((List<M1CustomerContactType_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-CustomerContactType\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CustomerContactType_>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-MCPCapabilityType":
                if (value instanceof List) {
                    setM1MCPCapabilityType(((List<M1MCPCapabilityType_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-MCPCapabilityType\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MCPCapabilityType_>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-CrewTimeUsageLookup":
                if (value instanceof List) {
                    setM1CrewTimeUsageLookup(((List<M1CrewTimeUsageLookup_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-CrewTimeUsageLookup\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CrewTimeUsageLookup_>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-ExternalIdentifier":
                if (value instanceof List) {
                    setM1ExternalIdentifier(((List<M1ExternalIdentifier_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-ExternalIdentifier\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ExternalIdentifier_>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-MCPIndicator":
                if (value instanceof List) {
                    setM1MCPIndicator(((List<M1MCPIndicator_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-MCPIndicator\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MCPIndicator_>\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "M1-TimeSheetTimeType":
                return getM1TimeSheetTimeType();
            case "M1-CustomerContactType":
                return getM1CustomerContactType();
            case "M1-MCPCapabilityType":
                return getM1MCPCapabilityType();
            case "M1-CrewTimeUsageLookup":
                return getM1CrewTimeUsageLookup();
            case "M1-ExternalIdentifier":
                return getM1ExternalIdentifier();
            case "M1-MCPIndicator":
                return getM1MCPIndicator();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ExtLookups.NOT_FOUND_VALUE);
        if (ExtLookups.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

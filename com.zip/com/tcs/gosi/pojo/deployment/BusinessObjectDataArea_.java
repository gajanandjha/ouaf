
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "position",
    "indicatorImage"
})
public class BusinessObjectDataArea_ {

    @JsonProperty("position")
    private String position;
    @JsonProperty("indicatorImage")
    private String indicatorImage;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The position
     */
    @JsonProperty("position")
    public String getPosition() {
        return position;
    }

    /**
     * 
     * @param position
     *     The position
     */
    @JsonProperty("position")
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * 
     * @return
     *     The indicatorImage
     */
    @JsonProperty("indicatorImage")
    public String getIndicatorImage() {
        return indicatorImage;
    }

    /**
     * 
     * @param indicatorImage
     *     The indicatorImage
     */
    @JsonProperty("indicatorImage")
    public void setIndicatorImage(String indicatorImage) {
        this.indicatorImage = indicatorImage;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "position":
                if (value instanceof String) {
                    setPosition(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"position\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "indicatorImage":
                if (value instanceof String) {
                    setIndicatorImage(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"indicatorImage\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "position":
                return getPosition();
            case "indicatorImage":
                return getIndicatorImage();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, BusinessObjectDataArea_.NOT_FOUND_VALUE);
        if (BusinessObjectDataArea_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

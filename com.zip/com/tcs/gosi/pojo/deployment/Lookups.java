
package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "M1_AUTO_COMP_FLG",
    "M1_COMPLETE_OPTION_FLG",
    "M1_DELVR_NOW_FLG",
    "M1_DEFERMENT_REASON_FLG",
    "RESRC_CLASS_FLG",
    "OVERRIDE_CLEARANCE_FLG",
    "M1_WINDOW_MODE_FLG",
    "M1_YES_NO_FLAG",
    "YES_NO_ANSWER_FLG",
    "M1_ITEM_DELIVERY_FLG",
    "M1_DEPOT_ACT_CLASS_FLG",
    "M1_MDT_OWNED_FLG",
    "M1_STATUS_REASON_USAGE_FLG",
    "MSG_PARM_TYP_FLG",
    "RELATED_ENTITY_FLG",
    "SVC_AREA_USG_FLG",
    "M1_SVC_TYPE_FLG",
    "M1_REVW_ON_DEV_FLG",
    "M1_TMSHEET_CORR_FLG",
    "PROCEDURE_STATUS_FLG",
    "M1_UNDISPATCH_OPTION_FLG",
    "SVC_CLS_USG_FLG",
    "M1_CHANGE_SEQUENCE_FLG",
    "M1_ITEM_CUST_ACCEPTED_FLG",
    "M1_RESRV_CAPACITY_LEAD_OPT_FLG",
    "M1_ADV_DISPATCH_MODE_FLG",
    "M1_TIME_WINDOW_SOURCE_FLG",
    "EXT_SYS_TYP_FLG",
    "QUEUE_FLG",
    "M1_RT_DST_UNIT_FLG",
    "OVERRIDE_FAILURE_FLG",
    "M1_DEPOT_ITEM_LOAD_CHECK_FLG",
    "STEP_REQUIRED_FLG",
    "ALLOW_OVERRIDE_FLG",
    "APPOINTMENT_FLG",
    "TAKE_ATTENDANCE_FLG",
    "M1_ALLOW_EARNING_TIME_FLG",
    "M1_RESOURCE_OPTION_FLG",
    "M1_OR_TASK_CAPABILITY_FLG",
    "M1_ACTIVITY_CLASS_FLG",
    "M1_MLRD_STATUS_FLG",
    "M1_DAYS_OF_WEEK_FLG",
    "M1_LOC_OPT_FLG",
    "M1_DEPOT_CLASS_FLG",
    "M1_OFFLINE_FLG",
    "M1_PRDF_SNDTO_FLG",
    "M1_ALLOW_BREAKS_FLG",
    "M1_ALLOW_RELATED_ACTIVITIES",
    "M1_AUTO_ALLOCATION_FLG",
    "M1_REQ_BY_FLG",
    "M1_ELIGIBLE_ASSIST_FLG",
    "M1_CREATE_BY_CREW_FLG",
    "TIME_WINDOW_USAGE_FLG",
    "LOC_TYPE_FLG",
    "M1_TRANSFER_TYPE_FLG",
    "M1_PICKUP_STATUS_FLG",
    "M1_AUTO_EXTENSION",
    "M1_DATA_ENCRYPTION_GC_FLG",
    "M1_TRANSPORT_RESTRICTION_FLG",
    "GPS_DATA_ENABLED_FLG",
    "M1_RESTRICTION_TYPE_FLG",
    "M1_RESRV_CAPACITY_BY_FLG",
    "M1_ITEM_DELI_DCLN_RSN_FLG",
    "PROCEDURE_STATE_FLG",
    "STATUS_REASON_SELECT_FLG",
    "M1_TIMING_OPTION_FLG",
    "M1_RT_DST_UNIT_ABBR_FLG",
    "M1_ITEM_LOAD_STATUS_FLG",
    "LOG_ENTRY_TYPE_FLG",
    "M1_CAPACITY_PREFERRED_FLG",
    "ACKNOWLEDGEMENT_REQ_FLG",
    "STEP_STATE_FLG",
    "DRIP_MODE_FLG",
    "M1_DEPOT_TASK_LOAD_ORDER_FLG",
    "ATTENDED_PROCEDURE_FLG",
    "VARIABLE_SHIFT_FLG",
    "AUTO_DISPATCH_FLG",
    "M1_ACTIVITY_COMPLETE_FLG",
    "M1_ASIGN_CMPL_RECEIPT_OPT_FLG",
    "M1_ITEM_CUST_ACCEPT_REQ_FLG",
    "PROCEDURE_CLEARANCE_REQ_FLG",
    "M1_APPT_REQ_FLG",
    "M1_TASK_STATUS_FLG",
    "M1_SAME_CREW_FLG",
    "M1_DEPENDENCY_RSN_FLG",
    "M1_CAP_SYS_EVENT_FLG",
    "M1_ALLOW_CREW_TIME_FLG",
    "TASK_CLS_FLG",
    "M1_ELGB_CONTRACTING_FLG",
    "M1_FOLDER_FLG",
    "M1_MAX_CAPACITY_FLG",
    "M1_STRICT_TIME_FLG",
    "F1_EXT_LOOKUP_USAGE_FLG",
    "M1_MAX_NONCUM_CAPACITY_FLG",
    "M1_CREW_TM_USG_CLS_FLG",
    "SHFT_USAGE_FLG",
    "M1_SCHED_OPT_FLG",
    "M1_TMSHT_OVRD_FLG",
    "STATUS_FLG",
    "M1_AUTO_CANCEL",
    "M1_NONCUM_CAPACITY_FLG",
    "ROUND_START_TIME_OPT_FLG",
    "M1_CUMULATIVE_CAPACITY_FLG",
    "M1_MAIL_MSG_CLS_FLG",
    "M1_DEPOT_RUN_CLOSED_FLG",
    "M1_CLOSEDBY_ADV_DISP_FLG",
    "M1_SYSTEM_GEN_FLG",
    "M1_DEPENDENCY_TYPE_FLG",
    "M1_FORCE_LOGOFF_REASON_FLG",
    "ALLOCATION_RULE_FLG",
    "M1_OVRD_FLG",
    "M1_ITEM_LOAD_DCLN_RSN_FLG",
    "M1_IGNORE_SEQ_LOCK_FLG",
    "M1_OVRD_EXTENSION_LIMIT_FLG",
    "ANSWER_TYPE_FLG",
    "M1_ITEM_DELIVERY_STATUS_FLG",
    "M1_CAP_TYPE_USAGE_FLG",
    "M1_ACTIVITY_ATTRIB_USAGE_FLG",
    "OWNER_FLG",
    "RESRC_ID_TYPE_FLG",
    "OUTMSG_PRIOR_FLG"
})
public class Lookups {

    @JsonProperty("M1_AUTO_COMP_FLG")
    private List<M1AUTOCOMPFLG> m1AUTOCOMPFLG = null;
    @JsonProperty("M1_COMPLETE_OPTION_FLG")
    private List<M1COMPLETEOPTIONFLG> m1COMPLETEOPTIONFLG = null;
    @JsonProperty("M1_DELVR_NOW_FLG")
    private List<M1DELVRNOWFLG> m1DELVRNOWFLG = null;
    @JsonProperty("M1_DEFERMENT_REASON_FLG")
    private List<Object> m1DEFERMENTREASONFLG = null;
    @JsonProperty("RESRC_CLASS_FLG")
    private List<RESRCCLASSFLG> rESRCCLASSFLG = null;
    @JsonProperty("OVERRIDE_CLEARANCE_FLG")
    private List<OVERRIDECLEARANCEFLG> oVERRIDECLEARANCEFLG = null;
    @JsonProperty("M1_WINDOW_MODE_FLG")
    private List<M1WINDOWMODEFLG> m1WINDOWMODEFLG = null;
    @JsonProperty("M1_YES_NO_FLAG")
    private List<M1YESNOFLAG> m1YESNOFLAG = null;
    @JsonProperty("YES_NO_ANSWER_FLG")
    private List<YESNOANSWERFLG> yESNOANSWERFLG = null;
    @JsonProperty("M1_ITEM_DELIVERY_FLG")
    private List<M1ITEMDELIVERYFLG> m1ITEMDELIVERYFLG = null;
    @JsonProperty("M1_DEPOT_ACT_CLASS_FLG")
    private List<M1DEPOTACTCLASSFLG> m1DEPOTACTCLASSFLG = null;
    @JsonProperty("M1_MDT_OWNED_FLG")
    private List<M1MDTOWNEDFLG> m1MDTOWNEDFLG = null;
    @JsonProperty("M1_STATUS_REASON_USAGE_FLG")
    private List<M1STATUSREASONUSAGEFLG> m1STATUSREASONUSAGEFLG = null;
    @JsonProperty("MSG_PARM_TYP_FLG")
    private List<MSGPARMTYPFLG> mSGPARMTYPFLG = null;
    @JsonProperty("RELATED_ENTITY_FLG")
    private List<RELATEDENTITYFLG> rELATEDENTITYFLG = null;
    @JsonProperty("SVC_AREA_USG_FLG")
    private List<SVCAREAUSGFLG> sVCAREAUSGFLG = null;
    @JsonProperty("M1_SVC_TYPE_FLG")
    private List<Object> m1SVCTYPEFLG = null;
    @JsonProperty("M1_REVW_ON_DEV_FLG")
    private List<M1REVWONDEVFLG> m1REVWONDEVFLG = null;
    @JsonProperty("M1_TMSHEET_CORR_FLG")
    private List<M1TMSHEETCORRFLG> m1TMSHEETCORRFLG = null;
    @JsonProperty("PROCEDURE_STATUS_FLG")
    private List<PROCEDURESTATUSFLG> pROCEDURESTATUSFLG = null;
    @JsonProperty("M1_UNDISPATCH_OPTION_FLG")
    private List<M1UNDISPATCHOPTIONFLG> m1UNDISPATCHOPTIONFLG = null;
    @JsonProperty("SVC_CLS_USG_FLG")
    private List<SVCCLSUSGFLG> sVCCLSUSGFLG = null;
    @JsonProperty("M1_CHANGE_SEQUENCE_FLG")
    private List<M1CHANGESEQUENCEFLG> m1CHANGESEQUENCEFLG = null;
    @JsonProperty("M1_ITEM_CUST_ACCEPTED_FLG")
    private List<M1ITEMCUSTACCEPTEDFLG> m1ITEMCUSTACCEPTEDFLG = null;
    @JsonProperty("M1_RESRV_CAPACITY_LEAD_OPT_FLG")
    private List<M1RESRVCAPACITYLEADOPTFLG> m1RESRVCAPACITYLEADOPTFLG = null;
    @JsonProperty("M1_ADV_DISPATCH_MODE_FLG")
    private List<M1ADVDISPATCHMODEFLG> m1ADVDISPATCHMODEFLG = null;
    @JsonProperty("M1_TIME_WINDOW_SOURCE_FLG")
    private List<M1TIMEWINDOWSOURCEFLG> m1TIMEWINDOWSOURCEFLG = null;
    @JsonProperty("EXT_SYS_TYP_FLG")
    private List<EXTSYSTYPFLG> eXTSYSTYPFLG = null;
    @JsonProperty("QUEUE_FLG")
    private List<QUEUEFLG> qUEUEFLG = null;
    @JsonProperty("M1_RT_DST_UNIT_FLG")
    private List<M1RTDSTUNITFLG> m1RTDSTUNITFLG = null;
    @JsonProperty("OVERRIDE_FAILURE_FLG")
    private List<OVERRIDEFAILUREFLG> oVERRIDEFAILUREFLG = null;
    @JsonProperty("M1_DEPOT_ITEM_LOAD_CHECK_FLG")
    private List<M1DEPOTITEMLOADCHECKFLG> m1DEPOTITEMLOADCHECKFLG = null;
    @JsonProperty("STEP_REQUIRED_FLG")
    private List<STEPREQUIREDFLG> sTEPREQUIREDFLG = null;
    @JsonProperty("ALLOW_OVERRIDE_FLG")
    private List<ALLOWOVERRIDEFLG> aLLOWOVERRIDEFLG = null;
    @JsonProperty("APPOINTMENT_FLG")
    private List<APPOINTMENTFLG> aPPOINTMENTFLG = null;
    @JsonProperty("TAKE_ATTENDANCE_FLG")
    private List<TAKEATTENDANCEFLG> tAKEATTENDANCEFLG = null;
    @JsonProperty("M1_ALLOW_EARNING_TIME_FLG")
    private List<M1ALLOWEARNINGTIMEFLG> m1ALLOWEARNINGTIMEFLG = null;
    @JsonProperty("M1_RESOURCE_OPTION_FLG")
    private List<M1RESOURCEOPTIONFLG> m1RESOURCEOPTIONFLG = null;
    @JsonProperty("M1_OR_TASK_CAPABILITY_FLG")
    private List<M1ORTASKCAPABILITYFLG> m1ORTASKCAPABILITYFLG = null;
    @JsonProperty("M1_ACTIVITY_CLASS_FLG")
    private List<M1ACTIVITYCLASSFLG> m1ACTIVITYCLASSFLG = null;
    @JsonProperty("M1_MLRD_STATUS_FLG")
    private List<M1MLRDSTATUSFLG> m1MLRDSTATUSFLG = null;
    @JsonProperty("M1_DAYS_OF_WEEK_FLG")
    private List<M1DAYSOFWEEKFLG> m1DAYSOFWEEKFLG = null;
    @JsonProperty("M1_LOC_OPT_FLG")
    private List<M1LOCOPTFLG> m1LOCOPTFLG = null;
    @JsonProperty("M1_DEPOT_CLASS_FLG")
    private List<M1DEPOTCLASSFLG> m1DEPOTCLASSFLG = null;
    @JsonProperty("M1_OFFLINE_FLG")
    private List<M1OFFLINEFLG> m1OFFLINEFLG = null;
    @JsonProperty("M1_PRDF_SNDTO_FLG")
    private List<M1PRDFSNDTOFLG> m1PRDFSNDTOFLG = null;
    @JsonProperty("M1_ALLOW_BREAKS_FLG")
    private List<M1ALLOWBREAKSFLG> m1ALLOWBREAKSFLG = null;
    @JsonProperty("M1_ALLOW_RELATED_ACTIVITIES")
    private List<M1ALLOWRELATEDACTIVITy> m1ALLOWRELATEDACTIVITIES = null;
    @JsonProperty("M1_AUTO_ALLOCATION_FLG")
    private List<M1AUTOALLOCATIONFLG> m1AUTOALLOCATIONFLG = null;
    @JsonProperty("M1_REQ_BY_FLG")
    private List<M1REQBYFLG> m1REQBYFLG = null;
    @JsonProperty("M1_ELIGIBLE_ASSIST_FLG")
    private List<M1ELIGIBLEASSISTFLG> m1ELIGIBLEASSISTFLG = null;
    @JsonProperty("M1_CREATE_BY_CREW_FLG")
    private List<M1CREATEBYCREWFLG> m1CREATEBYCREWFLG = null;
    @JsonProperty("TIME_WINDOW_USAGE_FLG")
    private List<TIMEWINDOWUSAGEFLG> tIMEWINDOWUSAGEFLG = null;
    @JsonProperty("LOC_TYPE_FLG")
    private List<LOCTYPEFLG> lOCTYPEFLG = null;
    @JsonProperty("M1_TRANSFER_TYPE_FLG")
    private List<M1TRANSFERTYPEFLG> m1TRANSFERTYPEFLG = null;
    @JsonProperty("M1_PICKUP_STATUS_FLG")
    private List<M1PICKUPSTATUSFLG> m1PICKUPSTATUSFLG = null;
    @JsonProperty("M1_AUTO_EXTENSION")
    private List<M1AUTOEXTENSION> m1AUTOEXTENSION = null;
    @JsonProperty("M1_DATA_ENCRYPTION_GC_FLG")
    private List<M1DATAENCRYPTIONGCFLG> m1DATAENCRYPTIONGCFLG = null;
    @JsonProperty("M1_TRANSPORT_RESTRICTION_FLG")
    private List<M1TRANSPORTRESTRICTIONFLG> m1TRANSPORTRESTRICTIONFLG = null;
    @JsonProperty("GPS_DATA_ENABLED_FLG")
    private List<GPSDATAENABLEDFLG> gPSDATAENABLEDFLG = null;
    @JsonProperty("M1_RESTRICTION_TYPE_FLG")
    private List<M1RESTRICTIONTYPEFLG> m1RESTRICTIONTYPEFLG = null;
    @JsonProperty("M1_RESRV_CAPACITY_BY_FLG")
    private List<M1RESRVCAPACITYBYFLG> m1RESRVCAPACITYBYFLG = null;
    @JsonProperty("M1_ITEM_DELI_DCLN_RSN_FLG")
    private List<M1ITEMDELIDCLNRSNFLG> m1ITEMDELIDCLNRSNFLG = null;
    @JsonProperty("PROCEDURE_STATE_FLG")
    private List<PROCEDURESTATEFLG> pROCEDURESTATEFLG = null;
    @JsonProperty("STATUS_REASON_SELECT_FLG")
    private List<STATUSREASONSELECTFLG> sTATUSREASONSELECTFLG = null;
    @JsonProperty("M1_TIMING_OPTION_FLG")
    private List<M1TIMINGOPTIONFLG> m1TIMINGOPTIONFLG = null;
    @JsonProperty("M1_RT_DST_UNIT_ABBR_FLG")
    private List<M1RTDSTUNITABBRFLG> m1RTDSTUNITABBRFLG = null;
    @JsonProperty("M1_ITEM_LOAD_STATUS_FLG")
    private List<M1ITEMLOADSTATUSFLG> m1ITEMLOADSTATUSFLG = null;
    @JsonProperty("LOG_ENTRY_TYPE_FLG")
    private List<LOGENTRYTYPEFLG> lOGENTRYTYPEFLG = null;
    @JsonProperty("M1_CAPACITY_PREFERRED_FLG")
    private List<M1CAPACITYPREFERREDFLG> m1CAPACITYPREFERREDFLG = null;
    @JsonProperty("ACKNOWLEDGEMENT_REQ_FLG")
    private List<ACKNOWLEDGEMENTREQFLG> aCKNOWLEDGEMENTREQFLG = null;
    @JsonProperty("STEP_STATE_FLG")
    private List<STEPSTATEFLG> sTEPSTATEFLG = null;
    @JsonProperty("DRIP_MODE_FLG")
    private List<DRIPMODEFLG> dRIPMODEFLG = null;
    @JsonProperty("M1_DEPOT_TASK_LOAD_ORDER_FLG")
    private List<M1DEPOTTASKLOADORDERFLG> m1DEPOTTASKLOADORDERFLG = null;
    @JsonProperty("ATTENDED_PROCEDURE_FLG")
    private List<ATTENDEDPROCEDUREFLG> aTTENDEDPROCEDUREFLG = null;
    @JsonProperty("VARIABLE_SHIFT_FLG")
    private List<VARIABLESHIFTFLG> vARIABLESHIFTFLG = null;
    @JsonProperty("AUTO_DISPATCH_FLG")
    private List<AUTODISPATCHFLG> aUTODISPATCHFLG = null;
    @JsonProperty("M1_ACTIVITY_COMPLETE_FLG")
    private List<M1ACTIVITYCOMPLETEFLG> m1ACTIVITYCOMPLETEFLG = null;
    @JsonProperty("M1_ASIGN_CMPL_RECEIPT_OPT_FLG")
    private List<Object> m1ASIGNCMPLRECEIPTOPTFLG = null;
    @JsonProperty("M1_ITEM_CUST_ACCEPT_REQ_FLG")
    private List<M1ITEMCUSTACCEPTREQFLG> m1ITEMCUSTACCEPTREQFLG = null;
    @JsonProperty("PROCEDURE_CLEARANCE_REQ_FLG")
    private List<PROCEDURECLEARANCEREQFLG> pROCEDURECLEARANCEREQFLG = null;
    @JsonProperty("M1_APPT_REQ_FLG")
    private List<M1APPTREQFLG> m1APPTREQFLG = null;
    @JsonProperty("M1_TASK_STATUS_FLG")
    private List<M1TASKSTATUSFLG> m1TASKSTATUSFLG = null;
    @JsonProperty("M1_SAME_CREW_FLG")
    private List<M1SAMECREWFLG> m1SAMECREWFLG = null;
    @JsonProperty("M1_DEPENDENCY_RSN_FLG")
    private List<M1DEPENDENCYRSNFLG> m1DEPENDENCYRSNFLG = null;
    @JsonProperty("M1_CAP_SYS_EVENT_FLG")
    private List<M1CAPSYSEVENTFLG> m1CAPSYSEVENTFLG = null;
    @JsonProperty("M1_ALLOW_CREW_TIME_FLG")
    private List<M1ALLOWCREWTIMEFLG> m1ALLOWCREWTIMEFLG = null;
    @JsonProperty("TASK_CLS_FLG")
    private List<TASKCLSFLG> tASKCLSFLG = null;
    @JsonProperty("M1_ELGB_CONTRACTING_FLG")
    private List<M1ELGBCONTRACTINGFLG> m1ELGBCONTRACTINGFLG = null;
    @JsonProperty("M1_FOLDER_FLG")
    private List<M1FOLDERFLG> m1FOLDERFLG = null;
    @JsonProperty("M1_MAX_CAPACITY_FLG")
    private List<M1MAXCAPACITYFLG> m1MAXCAPACITYFLG = null;
    @JsonProperty("M1_STRICT_TIME_FLG")
    private List<M1STRICTTIMEFLG> m1STRICTTIMEFLG = null;
    @JsonProperty("F1_EXT_LOOKUP_USAGE_FLG")
    private List<F1EXTLOOKUPUSAGEFLG> f1EXTLOOKUPUSAGEFLG = null;
    @JsonProperty("M1_MAX_NONCUM_CAPACITY_FLG")
    private List<M1MAXNONCUMCAPACITYFLG> m1MAXNONCUMCAPACITYFLG = null;
    @JsonProperty("M1_CREW_TM_USG_CLS_FLG")
    private List<M1CREWTMUSGCLSFLG> m1CREWTMUSGCLSFLG = null;
    @JsonProperty("SHFT_USAGE_FLG")
    private List<SHFTUSAGEFLG> sHFTUSAGEFLG = null;
    @JsonProperty("M1_SCHED_OPT_FLG")
    private List<M1SCHEDOPTFLG> m1SCHEDOPTFLG = null;
    @JsonProperty("M1_TMSHT_OVRD_FLG")
    private List<M1TMSHTOVRDFLG> m1TMSHTOVRDFLG = null;
    @JsonProperty("STATUS_FLG")
    private List<STATUSFLG> sTATUSFLG = null;
    @JsonProperty("M1_AUTO_CANCEL")
    private List<M1AUTOCANCEL> m1AUTOCANCEL = null;
    @JsonProperty("M1_NONCUM_CAPACITY_FLG")
    private List<M1NONCUMCAPACITYFLG> m1NONCUMCAPACITYFLG = null;
    @JsonProperty("ROUND_START_TIME_OPT_FLG")
    private List<ROUNDSTARTTIMEOPTFLG> rOUNDSTARTTIMEOPTFLG = null;
    @JsonProperty("M1_CUMULATIVE_CAPACITY_FLG")
    private List<M1CUMULATIVECAPACITYFLG> m1CUMULATIVECAPACITYFLG = null;
    @JsonProperty("M1_MAIL_MSG_CLS_FLG")
    private List<M1MAILMSGCLSFLG> m1MAILMSGCLSFLG = null;
    @JsonProperty("M1_DEPOT_RUN_CLOSED_FLG")
    private List<M1DEPOTRUNCLOSEDFLG> m1DEPOTRUNCLOSEDFLG = null;
    @JsonProperty("M1_CLOSEDBY_ADV_DISP_FLG")
    private List<M1CLOSEDBYADVDISPFLG> m1CLOSEDBYADVDISPFLG = null;
    @JsonProperty("M1_SYSTEM_GEN_FLG")
    private List<M1SYSTEMGENFLG> m1SYSTEMGENFLG = null;
    @JsonProperty("M1_DEPENDENCY_TYPE_FLG")
    private List<M1DEPENDENCYTYPEFLG> m1DEPENDENCYTYPEFLG = null;
    @JsonProperty("M1_FORCE_LOGOFF_REASON_FLG")
    private List<M1FORCELOGOFFREASONFLG> m1FORCELOGOFFREASONFLG = null;
    @JsonProperty("ALLOCATION_RULE_FLG")
    private List<ALLOCATIONRULEFLG> aLLOCATIONRULEFLG = null;
    @JsonProperty("M1_OVRD_FLG")
    private List<M1OVRDFLG> m1OVRDFLG = null;
    @JsonProperty("M1_ITEM_LOAD_DCLN_RSN_FLG")
    private List<Object> m1ITEMLOADDCLNRSNFLG = null;
    @JsonProperty("M1_IGNORE_SEQ_LOCK_FLG")
    private List<M1IGNORESEQLOCKFLG> m1IGNORESEQLOCKFLG = null;
    @JsonProperty("M1_OVRD_EXTENSION_LIMIT_FLG")
    private List<M1OVRDEXTENSIONLIMITFLG> m1OVRDEXTENSIONLIMITFLG = null;
    @JsonProperty("ANSWER_TYPE_FLG")
    private List<ANSWERTYPEFLG> aNSWERTYPEFLG = null;
    @JsonProperty("M1_ITEM_DELIVERY_STATUS_FLG")
    private List<M1ITEMDELIVERYSTATUSFLG> m1ITEMDELIVERYSTATUSFLG = null;
    @JsonProperty("M1_CAP_TYPE_USAGE_FLG")
    private List<M1CAPTYPEUSAGEFLG> m1CAPTYPEUSAGEFLG = null;
    @JsonProperty("M1_ACTIVITY_ATTRIB_USAGE_FLG")
    private List<M1ACTIVITYATTRIBUSAGEFLG> m1ACTIVITYATTRIBUSAGEFLG = null;
    @JsonProperty("OWNER_FLG")
    private List<OWNERFLG> oWNERFLG = null;
    @JsonProperty("RESRC_ID_TYPE_FLG")
    private List<RESRCIDTYPEFLG> rESRCIDTYPEFLG = null;
    @JsonProperty("OUTMSG_PRIOR_FLG")
    private List<OUTMSGPRIORFLG> oUTMSGPRIORFLG = null;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The m1AUTOCOMPFLG
     */
    @JsonProperty("M1_AUTO_COMP_FLG")
    public List<M1AUTOCOMPFLG> getM1AUTOCOMPFLG() {
        return m1AUTOCOMPFLG;
    }

    /**
     * 
     * @param m1AUTOCOMPFLG
     *     The M1_AUTO_COMP_FLG
     */
    @JsonProperty("M1_AUTO_COMP_FLG")
    public void setM1AUTOCOMPFLG(List<M1AUTOCOMPFLG> m1AUTOCOMPFLG) {
        this.m1AUTOCOMPFLG = m1AUTOCOMPFLG;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEOPTIONFLG
     */
    @JsonProperty("M1_COMPLETE_OPTION_FLG")
    public List<M1COMPLETEOPTIONFLG> getM1COMPLETEOPTIONFLG() {
        return m1COMPLETEOPTIONFLG;
    }

    /**
     * 
     * @param m1COMPLETEOPTIONFLG
     *     The M1_COMPLETE_OPTION_FLG
     */
    @JsonProperty("M1_COMPLETE_OPTION_FLG")
    public void setM1COMPLETEOPTIONFLG(List<M1COMPLETEOPTIONFLG> m1COMPLETEOPTIONFLG) {
        this.m1COMPLETEOPTIONFLG = m1COMPLETEOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1DELVRNOWFLG
     */
    @JsonProperty("M1_DELVR_NOW_FLG")
    public List<M1DELVRNOWFLG> getM1DELVRNOWFLG() {
        return m1DELVRNOWFLG;
    }

    /**
     * 
     * @param m1DELVRNOWFLG
     *     The M1_DELVR_NOW_FLG
     */
    @JsonProperty("M1_DELVR_NOW_FLG")
    public void setM1DELVRNOWFLG(List<M1DELVRNOWFLG> m1DELVRNOWFLG) {
        this.m1DELVRNOWFLG = m1DELVRNOWFLG;
    }

    /**
     * 
     * @return
     *     The m1DEFERMENTREASONFLG
     */
    @JsonProperty("M1_DEFERMENT_REASON_FLG")
    public List<Object> getM1DEFERMENTREASONFLG() {
        return m1DEFERMENTREASONFLG;
    }

    /**
     * 
     * @param m1DEFERMENTREASONFLG
     *     The M1_DEFERMENT_REASON_FLG
     */
    @JsonProperty("M1_DEFERMENT_REASON_FLG")
    public void setM1DEFERMENTREASONFLG(List<Object> m1DEFERMENTREASONFLG) {
        this.m1DEFERMENTREASONFLG = m1DEFERMENTREASONFLG;
    }

    /**
     * 
     * @return
     *     The rESRCCLASSFLG
     */
    @JsonProperty("RESRC_CLASS_FLG")
    public List<RESRCCLASSFLG> getRESRCCLASSFLG() {
        return rESRCCLASSFLG;
    }

    /**
     * 
     * @param rESRCCLASSFLG
     *     The RESRC_CLASS_FLG
     */
    @JsonProperty("RESRC_CLASS_FLG")
    public void setRESRCCLASSFLG(List<RESRCCLASSFLG> rESRCCLASSFLG) {
        this.rESRCCLASSFLG = rESRCCLASSFLG;
    }

    /**
     * 
     * @return
     *     The oVERRIDECLEARANCEFLG
     */
    @JsonProperty("OVERRIDE_CLEARANCE_FLG")
    public List<OVERRIDECLEARANCEFLG> getOVERRIDECLEARANCEFLG() {
        return oVERRIDECLEARANCEFLG;
    }

    /**
     * 
     * @param oVERRIDECLEARANCEFLG
     *     The OVERRIDE_CLEARANCE_FLG
     */
    @JsonProperty("OVERRIDE_CLEARANCE_FLG")
    public void setOVERRIDECLEARANCEFLG(List<OVERRIDECLEARANCEFLG> oVERRIDECLEARANCEFLG) {
        this.oVERRIDECLEARANCEFLG = oVERRIDECLEARANCEFLG;
    }

    /**
     * 
     * @return
     *     The m1WINDOWMODEFLG
     */
    @JsonProperty("M1_WINDOW_MODE_FLG")
    public List<M1WINDOWMODEFLG> getM1WINDOWMODEFLG() {
        return m1WINDOWMODEFLG;
    }

    /**
     * 
     * @param m1WINDOWMODEFLG
     *     The M1_WINDOW_MODE_FLG
     */
    @JsonProperty("M1_WINDOW_MODE_FLG")
    public void setM1WINDOWMODEFLG(List<M1WINDOWMODEFLG> m1WINDOWMODEFLG) {
        this.m1WINDOWMODEFLG = m1WINDOWMODEFLG;
    }

    /**
     * 
     * @return
     *     The m1YESNOFLAG
     */
    @JsonProperty("M1_YES_NO_FLAG")
    public List<M1YESNOFLAG> getM1YESNOFLAG() {
        return m1YESNOFLAG;
    }

    /**
     * 
     * @param m1YESNOFLAG
     *     The M1_YES_NO_FLAG
     */
    @JsonProperty("M1_YES_NO_FLAG")
    public void setM1YESNOFLAG(List<M1YESNOFLAG> m1YESNOFLAG) {
        this.m1YESNOFLAG = m1YESNOFLAG;
    }

    /**
     * 
     * @return
     *     The yESNOANSWERFLG
     */
    @JsonProperty("YES_NO_ANSWER_FLG")
    public List<YESNOANSWERFLG> getYESNOANSWERFLG() {
        return yESNOANSWERFLG;
    }

    /**
     * 
     * @param yESNOANSWERFLG
     *     The YES_NO_ANSWER_FLG
     */
    @JsonProperty("YES_NO_ANSWER_FLG")
    public void setYESNOANSWERFLG(List<YESNOANSWERFLG> yESNOANSWERFLG) {
        this.yESNOANSWERFLG = yESNOANSWERFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMDELIVERYFLG
     */
    @JsonProperty("M1_ITEM_DELIVERY_FLG")
    public List<M1ITEMDELIVERYFLG> getM1ITEMDELIVERYFLG() {
        return m1ITEMDELIVERYFLG;
    }

    /**
     * 
     * @param m1ITEMDELIVERYFLG
     *     The M1_ITEM_DELIVERY_FLG
     */
    @JsonProperty("M1_ITEM_DELIVERY_FLG")
    public void setM1ITEMDELIVERYFLG(List<M1ITEMDELIVERYFLG> m1ITEMDELIVERYFLG) {
        this.m1ITEMDELIVERYFLG = m1ITEMDELIVERYFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPOTACTCLASSFLG
     */
    @JsonProperty("M1_DEPOT_ACT_CLASS_FLG")
    public List<M1DEPOTACTCLASSFLG> getM1DEPOTACTCLASSFLG() {
        return m1DEPOTACTCLASSFLG;
    }

    /**
     * 
     * @param m1DEPOTACTCLASSFLG
     *     The M1_DEPOT_ACT_CLASS_FLG
     */
    @JsonProperty("M1_DEPOT_ACT_CLASS_FLG")
    public void setM1DEPOTACTCLASSFLG(List<M1DEPOTACTCLASSFLG> m1DEPOTACTCLASSFLG) {
        this.m1DEPOTACTCLASSFLG = m1DEPOTACTCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1MDTOWNEDFLG
     */
    @JsonProperty("M1_MDT_OWNED_FLG")
    public List<M1MDTOWNEDFLG> getM1MDTOWNEDFLG() {
        return m1MDTOWNEDFLG;
    }

    /**
     * 
     * @param m1MDTOWNEDFLG
     *     The M1_MDT_OWNED_FLG
     */
    @JsonProperty("M1_MDT_OWNED_FLG")
    public void setM1MDTOWNEDFLG(List<M1MDTOWNEDFLG> m1MDTOWNEDFLG) {
        this.m1MDTOWNEDFLG = m1MDTOWNEDFLG;
    }

    /**
     * 
     * @return
     *     The m1STATUSREASONUSAGEFLG
     */
    @JsonProperty("M1_STATUS_REASON_USAGE_FLG")
    public List<M1STATUSREASONUSAGEFLG> getM1STATUSREASONUSAGEFLG() {
        return m1STATUSREASONUSAGEFLG;
    }

    /**
     * 
     * @param m1STATUSREASONUSAGEFLG
     *     The M1_STATUS_REASON_USAGE_FLG
     */
    @JsonProperty("M1_STATUS_REASON_USAGE_FLG")
    public void setM1STATUSREASONUSAGEFLG(List<M1STATUSREASONUSAGEFLG> m1STATUSREASONUSAGEFLG) {
        this.m1STATUSREASONUSAGEFLG = m1STATUSREASONUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The mSGPARMTYPFLG
     */
    @JsonProperty("MSG_PARM_TYP_FLG")
    public List<MSGPARMTYPFLG> getMSGPARMTYPFLG() {
        return mSGPARMTYPFLG;
    }

    /**
     * 
     * @param mSGPARMTYPFLG
     *     The MSG_PARM_TYP_FLG
     */
    @JsonProperty("MSG_PARM_TYP_FLG")
    public void setMSGPARMTYPFLG(List<MSGPARMTYPFLG> mSGPARMTYPFLG) {
        this.mSGPARMTYPFLG = mSGPARMTYPFLG;
    }

    /**
     * 
     * @return
     *     The rELATEDENTITYFLG
     */
    @JsonProperty("RELATED_ENTITY_FLG")
    public List<RELATEDENTITYFLG> getRELATEDENTITYFLG() {
        return rELATEDENTITYFLG;
    }

    /**
     * 
     * @param rELATEDENTITYFLG
     *     The RELATED_ENTITY_FLG
     */
    @JsonProperty("RELATED_ENTITY_FLG")
    public void setRELATEDENTITYFLG(List<RELATEDENTITYFLG> rELATEDENTITYFLG) {
        this.rELATEDENTITYFLG = rELATEDENTITYFLG;
    }

    /**
     * 
     * @return
     *     The sVCAREAUSGFLG
     */
    @JsonProperty("SVC_AREA_USG_FLG")
    public List<SVCAREAUSGFLG> getSVCAREAUSGFLG() {
        return sVCAREAUSGFLG;
    }

    /**
     * 
     * @param sVCAREAUSGFLG
     *     The SVC_AREA_USG_FLG
     */
    @JsonProperty("SVC_AREA_USG_FLG")
    public void setSVCAREAUSGFLG(List<SVCAREAUSGFLG> sVCAREAUSGFLG) {
        this.sVCAREAUSGFLG = sVCAREAUSGFLG;
    }

    /**
     * 
     * @return
     *     The m1SVCTYPEFLG
     */
    @JsonProperty("M1_SVC_TYPE_FLG")
    public List<Object> getM1SVCTYPEFLG() {
        return m1SVCTYPEFLG;
    }

    /**
     * 
     * @param m1SVCTYPEFLG
     *     The M1_SVC_TYPE_FLG
     */
    @JsonProperty("M1_SVC_TYPE_FLG")
    public void setM1SVCTYPEFLG(List<Object> m1SVCTYPEFLG) {
        this.m1SVCTYPEFLG = m1SVCTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1REVWONDEVFLG
     */
    @JsonProperty("M1_REVW_ON_DEV_FLG")
    public List<M1REVWONDEVFLG> getM1REVWONDEVFLG() {
        return m1REVWONDEVFLG;
    }

    /**
     * 
     * @param m1REVWONDEVFLG
     *     The M1_REVW_ON_DEV_FLG
     */
    @JsonProperty("M1_REVW_ON_DEV_FLG")
    public void setM1REVWONDEVFLG(List<M1REVWONDEVFLG> m1REVWONDEVFLG) {
        this.m1REVWONDEVFLG = m1REVWONDEVFLG;
    }

    /**
     * 
     * @return
     *     The m1TMSHEETCORRFLG
     */
    @JsonProperty("M1_TMSHEET_CORR_FLG")
    public List<M1TMSHEETCORRFLG> getM1TMSHEETCORRFLG() {
        return m1TMSHEETCORRFLG;
    }

    /**
     * 
     * @param m1TMSHEETCORRFLG
     *     The M1_TMSHEET_CORR_FLG
     */
    @JsonProperty("M1_TMSHEET_CORR_FLG")
    public void setM1TMSHEETCORRFLG(List<M1TMSHEETCORRFLG> m1TMSHEETCORRFLG) {
        this.m1TMSHEETCORRFLG = m1TMSHEETCORRFLG;
    }

    /**
     * 
     * @return
     *     The pROCEDURESTATUSFLG
     */
    @JsonProperty("PROCEDURE_STATUS_FLG")
    public List<PROCEDURESTATUSFLG> getPROCEDURESTATUSFLG() {
        return pROCEDURESTATUSFLG;
    }

    /**
     * 
     * @param pROCEDURESTATUSFLG
     *     The PROCEDURE_STATUS_FLG
     */
    @JsonProperty("PROCEDURE_STATUS_FLG")
    public void setPROCEDURESTATUSFLG(List<PROCEDURESTATUSFLG> pROCEDURESTATUSFLG) {
        this.pROCEDURESTATUSFLG = pROCEDURESTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1UNDISPATCHOPTIONFLG
     */
    @JsonProperty("M1_UNDISPATCH_OPTION_FLG")
    public List<M1UNDISPATCHOPTIONFLG> getM1UNDISPATCHOPTIONFLG() {
        return m1UNDISPATCHOPTIONFLG;
    }

    /**
     * 
     * @param m1UNDISPATCHOPTIONFLG
     *     The M1_UNDISPATCH_OPTION_FLG
     */
    @JsonProperty("M1_UNDISPATCH_OPTION_FLG")
    public void setM1UNDISPATCHOPTIONFLG(List<M1UNDISPATCHOPTIONFLG> m1UNDISPATCHOPTIONFLG) {
        this.m1UNDISPATCHOPTIONFLG = m1UNDISPATCHOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The sVCCLSUSGFLG
     */
    @JsonProperty("SVC_CLS_USG_FLG")
    public List<SVCCLSUSGFLG> getSVCCLSUSGFLG() {
        return sVCCLSUSGFLG;
    }

    /**
     * 
     * @param sVCCLSUSGFLG
     *     The SVC_CLS_USG_FLG
     */
    @JsonProperty("SVC_CLS_USG_FLG")
    public void setSVCCLSUSGFLG(List<SVCCLSUSGFLG> sVCCLSUSGFLG) {
        this.sVCCLSUSGFLG = sVCCLSUSGFLG;
    }

    /**
     * 
     * @return
     *     The m1CHANGESEQUENCEFLG
     */
    @JsonProperty("M1_CHANGE_SEQUENCE_FLG")
    public List<M1CHANGESEQUENCEFLG> getM1CHANGESEQUENCEFLG() {
        return m1CHANGESEQUENCEFLG;
    }

    /**
     * 
     * @param m1CHANGESEQUENCEFLG
     *     The M1_CHANGE_SEQUENCE_FLG
     */
    @JsonProperty("M1_CHANGE_SEQUENCE_FLG")
    public void setM1CHANGESEQUENCEFLG(List<M1CHANGESEQUENCEFLG> m1CHANGESEQUENCEFLG) {
        this.m1CHANGESEQUENCEFLG = m1CHANGESEQUENCEFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMCUSTACCEPTEDFLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPTED_FLG")
    public List<M1ITEMCUSTACCEPTEDFLG> getM1ITEMCUSTACCEPTEDFLG() {
        return m1ITEMCUSTACCEPTEDFLG;
    }

    /**
     * 
     * @param m1ITEMCUSTACCEPTEDFLG
     *     The M1_ITEM_CUST_ACCEPTED_FLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPTED_FLG")
    public void setM1ITEMCUSTACCEPTEDFLG(List<M1ITEMCUSTACCEPTEDFLG> m1ITEMCUSTACCEPTEDFLG) {
        this.m1ITEMCUSTACCEPTEDFLG = m1ITEMCUSTACCEPTEDFLG;
    }

    /**
     * 
     * @return
     *     The m1RESRVCAPACITYLEADOPTFLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_LEAD_OPT_FLG")
    public List<M1RESRVCAPACITYLEADOPTFLG> getM1RESRVCAPACITYLEADOPTFLG() {
        return m1RESRVCAPACITYLEADOPTFLG;
    }

    /**
     * 
     * @param m1RESRVCAPACITYLEADOPTFLG
     *     The M1_RESRV_CAPACITY_LEAD_OPT_FLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_LEAD_OPT_FLG")
    public void setM1RESRVCAPACITYLEADOPTFLG(List<M1RESRVCAPACITYLEADOPTFLG> m1RESRVCAPACITYLEADOPTFLG) {
        this.m1RESRVCAPACITYLEADOPTFLG = m1RESRVCAPACITYLEADOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1ADVDISPATCHMODEFLG
     */
    @JsonProperty("M1_ADV_DISPATCH_MODE_FLG")
    public List<M1ADVDISPATCHMODEFLG> getM1ADVDISPATCHMODEFLG() {
        return m1ADVDISPATCHMODEFLG;
    }

    /**
     * 
     * @param m1ADVDISPATCHMODEFLG
     *     The M1_ADV_DISPATCH_MODE_FLG
     */
    @JsonProperty("M1_ADV_DISPATCH_MODE_FLG")
    public void setM1ADVDISPATCHMODEFLG(List<M1ADVDISPATCHMODEFLG> m1ADVDISPATCHMODEFLG) {
        this.m1ADVDISPATCHMODEFLG = m1ADVDISPATCHMODEFLG;
    }

    /**
     * 
     * @return
     *     The m1TIMEWINDOWSOURCEFLG
     */
    @JsonProperty("M1_TIME_WINDOW_SOURCE_FLG")
    public List<M1TIMEWINDOWSOURCEFLG> getM1TIMEWINDOWSOURCEFLG() {
        return m1TIMEWINDOWSOURCEFLG;
    }

    /**
     * 
     * @param m1TIMEWINDOWSOURCEFLG
     *     The M1_TIME_WINDOW_SOURCE_FLG
     */
    @JsonProperty("M1_TIME_WINDOW_SOURCE_FLG")
    public void setM1TIMEWINDOWSOURCEFLG(List<M1TIMEWINDOWSOURCEFLG> m1TIMEWINDOWSOURCEFLG) {
        this.m1TIMEWINDOWSOURCEFLG = m1TIMEWINDOWSOURCEFLG;
    }

    /**
     * 
     * @return
     *     The eXTSYSTYPFLG
     */
    @JsonProperty("EXT_SYS_TYP_FLG")
    public List<EXTSYSTYPFLG> getEXTSYSTYPFLG() {
        return eXTSYSTYPFLG;
    }

    /**
     * 
     * @param eXTSYSTYPFLG
     *     The EXT_SYS_TYP_FLG
     */
    @JsonProperty("EXT_SYS_TYP_FLG")
    public void setEXTSYSTYPFLG(List<EXTSYSTYPFLG> eXTSYSTYPFLG) {
        this.eXTSYSTYPFLG = eXTSYSTYPFLG;
    }

    /**
     * 
     * @return
     *     The qUEUEFLG
     */
    @JsonProperty("QUEUE_FLG")
    public List<QUEUEFLG> getQUEUEFLG() {
        return qUEUEFLG;
    }

    /**
     * 
     * @param qUEUEFLG
     *     The QUEUE_FLG
     */
    @JsonProperty("QUEUE_FLG")
    public void setQUEUEFLG(List<QUEUEFLG> qUEUEFLG) {
        this.qUEUEFLG = qUEUEFLG;
    }

    /**
     * 
     * @return
     *     The m1RTDSTUNITFLG
     */
    @JsonProperty("M1_RT_DST_UNIT_FLG")
    public List<M1RTDSTUNITFLG> getM1RTDSTUNITFLG() {
        return m1RTDSTUNITFLG;
    }

    /**
     * 
     * @param m1RTDSTUNITFLG
     *     The M1_RT_DST_UNIT_FLG
     */
    @JsonProperty("M1_RT_DST_UNIT_FLG")
    public void setM1RTDSTUNITFLG(List<M1RTDSTUNITFLG> m1RTDSTUNITFLG) {
        this.m1RTDSTUNITFLG = m1RTDSTUNITFLG;
    }

    /**
     * 
     * @return
     *     The oVERRIDEFAILUREFLG
     */
    @JsonProperty("OVERRIDE_FAILURE_FLG")
    public List<OVERRIDEFAILUREFLG> getOVERRIDEFAILUREFLG() {
        return oVERRIDEFAILUREFLG;
    }

    /**
     * 
     * @param oVERRIDEFAILUREFLG
     *     The OVERRIDE_FAILURE_FLG
     */
    @JsonProperty("OVERRIDE_FAILURE_FLG")
    public void setOVERRIDEFAILUREFLG(List<OVERRIDEFAILUREFLG> oVERRIDEFAILUREFLG) {
        this.oVERRIDEFAILUREFLG = oVERRIDEFAILUREFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPOTITEMLOADCHECKFLG
     */
    @JsonProperty("M1_DEPOT_ITEM_LOAD_CHECK_FLG")
    public List<M1DEPOTITEMLOADCHECKFLG> getM1DEPOTITEMLOADCHECKFLG() {
        return m1DEPOTITEMLOADCHECKFLG;
    }

    /**
     * 
     * @param m1DEPOTITEMLOADCHECKFLG
     *     The M1_DEPOT_ITEM_LOAD_CHECK_FLG
     */
    @JsonProperty("M1_DEPOT_ITEM_LOAD_CHECK_FLG")
    public void setM1DEPOTITEMLOADCHECKFLG(List<M1DEPOTITEMLOADCHECKFLG> m1DEPOTITEMLOADCHECKFLG) {
        this.m1DEPOTITEMLOADCHECKFLG = m1DEPOTITEMLOADCHECKFLG;
    }

    /**
     * 
     * @return
     *     The sTEPREQUIREDFLG
     */
    @JsonProperty("STEP_REQUIRED_FLG")
    public List<STEPREQUIREDFLG> getSTEPREQUIREDFLG() {
        return sTEPREQUIREDFLG;
    }

    /**
     * 
     * @param sTEPREQUIREDFLG
     *     The STEP_REQUIRED_FLG
     */
    @JsonProperty("STEP_REQUIRED_FLG")
    public void setSTEPREQUIREDFLG(List<STEPREQUIREDFLG> sTEPREQUIREDFLG) {
        this.sTEPREQUIREDFLG = sTEPREQUIREDFLG;
    }

    /**
     * 
     * @return
     *     The aLLOWOVERRIDEFLG
     */
    @JsonProperty("ALLOW_OVERRIDE_FLG")
    public List<ALLOWOVERRIDEFLG> getALLOWOVERRIDEFLG() {
        return aLLOWOVERRIDEFLG;
    }

    /**
     * 
     * @param aLLOWOVERRIDEFLG
     *     The ALLOW_OVERRIDE_FLG
     */
    @JsonProperty("ALLOW_OVERRIDE_FLG")
    public void setALLOWOVERRIDEFLG(List<ALLOWOVERRIDEFLG> aLLOWOVERRIDEFLG) {
        this.aLLOWOVERRIDEFLG = aLLOWOVERRIDEFLG;
    }

    /**
     * 
     * @return
     *     The aPPOINTMENTFLG
     */
    @JsonProperty("APPOINTMENT_FLG")
    public List<APPOINTMENTFLG> getAPPOINTMENTFLG() {
        return aPPOINTMENTFLG;
    }

    /**
     * 
     * @param aPPOINTMENTFLG
     *     The APPOINTMENT_FLG
     */
    @JsonProperty("APPOINTMENT_FLG")
    public void setAPPOINTMENTFLG(List<APPOINTMENTFLG> aPPOINTMENTFLG) {
        this.aPPOINTMENTFLG = aPPOINTMENTFLG;
    }

    /**
     * 
     * @return
     *     The tAKEATTENDANCEFLG
     */
    @JsonProperty("TAKE_ATTENDANCE_FLG")
    public List<TAKEATTENDANCEFLG> getTAKEATTENDANCEFLG() {
        return tAKEATTENDANCEFLG;
    }

    /**
     * 
     * @param tAKEATTENDANCEFLG
     *     The TAKE_ATTENDANCE_FLG
     */
    @JsonProperty("TAKE_ATTENDANCE_FLG")
    public void setTAKEATTENDANCEFLG(List<TAKEATTENDANCEFLG> tAKEATTENDANCEFLG) {
        this.tAKEATTENDANCEFLG = tAKEATTENDANCEFLG;
    }

    /**
     * 
     * @return
     *     The m1ALLOWEARNINGTIMEFLG
     */
    @JsonProperty("M1_ALLOW_EARNING_TIME_FLG")
    public List<M1ALLOWEARNINGTIMEFLG> getM1ALLOWEARNINGTIMEFLG() {
        return m1ALLOWEARNINGTIMEFLG;
    }

    /**
     * 
     * @param m1ALLOWEARNINGTIMEFLG
     *     The M1_ALLOW_EARNING_TIME_FLG
     */
    @JsonProperty("M1_ALLOW_EARNING_TIME_FLG")
    public void setM1ALLOWEARNINGTIMEFLG(List<M1ALLOWEARNINGTIMEFLG> m1ALLOWEARNINGTIMEFLG) {
        this.m1ALLOWEARNINGTIMEFLG = m1ALLOWEARNINGTIMEFLG;
    }

    /**
     * 
     * @return
     *     The m1RESOURCEOPTIONFLG
     */
    @JsonProperty("M1_RESOURCE_OPTION_FLG")
    public List<M1RESOURCEOPTIONFLG> getM1RESOURCEOPTIONFLG() {
        return m1RESOURCEOPTIONFLG;
    }

    /**
     * 
     * @param m1RESOURCEOPTIONFLG
     *     The M1_RESOURCE_OPTION_FLG
     */
    @JsonProperty("M1_RESOURCE_OPTION_FLG")
    public void setM1RESOURCEOPTIONFLG(List<M1RESOURCEOPTIONFLG> m1RESOURCEOPTIONFLG) {
        this.m1RESOURCEOPTIONFLG = m1RESOURCEOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1ORTASKCAPABILITYFLG
     */
    @JsonProperty("M1_OR_TASK_CAPABILITY_FLG")
    public List<M1ORTASKCAPABILITYFLG> getM1ORTASKCAPABILITYFLG() {
        return m1ORTASKCAPABILITYFLG;
    }

    /**
     * 
     * @param m1ORTASKCAPABILITYFLG
     *     The M1_OR_TASK_CAPABILITY_FLG
     */
    @JsonProperty("M1_OR_TASK_CAPABILITY_FLG")
    public void setM1ORTASKCAPABILITYFLG(List<M1ORTASKCAPABILITYFLG> m1ORTASKCAPABILITYFLG) {
        this.m1ORTASKCAPABILITYFLG = m1ORTASKCAPABILITYFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYCLASSFLG
     */
    @JsonProperty("M1_ACTIVITY_CLASS_FLG")
    public List<M1ACTIVITYCLASSFLG> getM1ACTIVITYCLASSFLG() {
        return m1ACTIVITYCLASSFLG;
    }

    /**
     * 
     * @param m1ACTIVITYCLASSFLG
     *     The M1_ACTIVITY_CLASS_FLG
     */
    @JsonProperty("M1_ACTIVITY_CLASS_FLG")
    public void setM1ACTIVITYCLASSFLG(List<M1ACTIVITYCLASSFLG> m1ACTIVITYCLASSFLG) {
        this.m1ACTIVITYCLASSFLG = m1ACTIVITYCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1MLRDSTATUSFLG
     */
    @JsonProperty("M1_MLRD_STATUS_FLG")
    public List<M1MLRDSTATUSFLG> getM1MLRDSTATUSFLG() {
        return m1MLRDSTATUSFLG;
    }

    /**
     * 
     * @param m1MLRDSTATUSFLG
     *     The M1_MLRD_STATUS_FLG
     */
    @JsonProperty("M1_MLRD_STATUS_FLG")
    public void setM1MLRDSTATUSFLG(List<M1MLRDSTATUSFLG> m1MLRDSTATUSFLG) {
        this.m1MLRDSTATUSFLG = m1MLRDSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1DAYSOFWEEKFLG
     */
    @JsonProperty("M1_DAYS_OF_WEEK_FLG")
    public List<M1DAYSOFWEEKFLG> getM1DAYSOFWEEKFLG() {
        return m1DAYSOFWEEKFLG;
    }

    /**
     * 
     * @param m1DAYSOFWEEKFLG
     *     The M1_DAYS_OF_WEEK_FLG
     */
    @JsonProperty("M1_DAYS_OF_WEEK_FLG")
    public void setM1DAYSOFWEEKFLG(List<M1DAYSOFWEEKFLG> m1DAYSOFWEEKFLG) {
        this.m1DAYSOFWEEKFLG = m1DAYSOFWEEKFLG;
    }

    /**
     * 
     * @return
     *     The m1LOCOPTFLG
     */
    @JsonProperty("M1_LOC_OPT_FLG")
    public List<M1LOCOPTFLG> getM1LOCOPTFLG() {
        return m1LOCOPTFLG;
    }

    /**
     * 
     * @param m1LOCOPTFLG
     *     The M1_LOC_OPT_FLG
     */
    @JsonProperty("M1_LOC_OPT_FLG")
    public void setM1LOCOPTFLG(List<M1LOCOPTFLG> m1LOCOPTFLG) {
        this.m1LOCOPTFLG = m1LOCOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPOTCLASSFLG
     */
    @JsonProperty("M1_DEPOT_CLASS_FLG")
    public List<M1DEPOTCLASSFLG> getM1DEPOTCLASSFLG() {
        return m1DEPOTCLASSFLG;
    }

    /**
     * 
     * @param m1DEPOTCLASSFLG
     *     The M1_DEPOT_CLASS_FLG
     */
    @JsonProperty("M1_DEPOT_CLASS_FLG")
    public void setM1DEPOTCLASSFLG(List<M1DEPOTCLASSFLG> m1DEPOTCLASSFLG) {
        this.m1DEPOTCLASSFLG = m1DEPOTCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1OFFLINEFLG
     */
    @JsonProperty("M1_OFFLINE_FLG")
    public List<M1OFFLINEFLG> getM1OFFLINEFLG() {
        return m1OFFLINEFLG;
    }

    /**
     * 
     * @param m1OFFLINEFLG
     *     The M1_OFFLINE_FLG
     */
    @JsonProperty("M1_OFFLINE_FLG")
    public void setM1OFFLINEFLG(List<M1OFFLINEFLG> m1OFFLINEFLG) {
        this.m1OFFLINEFLG = m1OFFLINEFLG;
    }

    /**
     * 
     * @return
     *     The m1PRDFSNDTOFLG
     */
    @JsonProperty("M1_PRDF_SNDTO_FLG")
    public List<M1PRDFSNDTOFLG> getM1PRDFSNDTOFLG() {
        return m1PRDFSNDTOFLG;
    }

    /**
     * 
     * @param m1PRDFSNDTOFLG
     *     The M1_PRDF_SNDTO_FLG
     */
    @JsonProperty("M1_PRDF_SNDTO_FLG")
    public void setM1PRDFSNDTOFLG(List<M1PRDFSNDTOFLG> m1PRDFSNDTOFLG) {
        this.m1PRDFSNDTOFLG = m1PRDFSNDTOFLG;
    }

    /**
     * 
     * @return
     *     The m1ALLOWBREAKSFLG
     */
    @JsonProperty("M1_ALLOW_BREAKS_FLG")
    public List<M1ALLOWBREAKSFLG> getM1ALLOWBREAKSFLG() {
        return m1ALLOWBREAKSFLG;
    }

    /**
     * 
     * @param m1ALLOWBREAKSFLG
     *     The M1_ALLOW_BREAKS_FLG
     */
    @JsonProperty("M1_ALLOW_BREAKS_FLG")
    public void setM1ALLOWBREAKSFLG(List<M1ALLOWBREAKSFLG> m1ALLOWBREAKSFLG) {
        this.m1ALLOWBREAKSFLG = m1ALLOWBREAKSFLG;
    }

    /**
     * 
     * @return
     *     The m1ALLOWRELATEDACTIVITIES
     */
    @JsonProperty("M1_ALLOW_RELATED_ACTIVITIES")
    public List<M1ALLOWRELATEDACTIVITy> getM1ALLOWRELATEDACTIVITIES() {
        return m1ALLOWRELATEDACTIVITIES;
    }

    /**
     * 
     * @param m1ALLOWRELATEDACTIVITIES
     *     The M1_ALLOW_RELATED_ACTIVITIES
     */
    @JsonProperty("M1_ALLOW_RELATED_ACTIVITIES")
    public void setM1ALLOWRELATEDACTIVITIES(List<M1ALLOWRELATEDACTIVITy> m1ALLOWRELATEDACTIVITIES) {
        this.m1ALLOWRELATEDACTIVITIES = m1ALLOWRELATEDACTIVITIES;
    }

    /**
     * 
     * @return
     *     The m1AUTOALLOCATIONFLG
     */
    @JsonProperty("M1_AUTO_ALLOCATION_FLG")
    public List<M1AUTOALLOCATIONFLG> getM1AUTOALLOCATIONFLG() {
        return m1AUTOALLOCATIONFLG;
    }

    /**
     * 
     * @param m1AUTOALLOCATIONFLG
     *     The M1_AUTO_ALLOCATION_FLG
     */
    @JsonProperty("M1_AUTO_ALLOCATION_FLG")
    public void setM1AUTOALLOCATIONFLG(List<M1AUTOALLOCATIONFLG> m1AUTOALLOCATIONFLG) {
        this.m1AUTOALLOCATIONFLG = m1AUTOALLOCATIONFLG;
    }

    /**
     * 
     * @return
     *     The m1REQBYFLG
     */
    @JsonProperty("M1_REQ_BY_FLG")
    public List<M1REQBYFLG> getM1REQBYFLG() {
        return m1REQBYFLG;
    }

    /**
     * 
     * @param m1REQBYFLG
     *     The M1_REQ_BY_FLG
     */
    @JsonProperty("M1_REQ_BY_FLG")
    public void setM1REQBYFLG(List<M1REQBYFLG> m1REQBYFLG) {
        this.m1REQBYFLG = m1REQBYFLG;
    }

    /**
     * 
     * @return
     *     The m1ELIGIBLEASSISTFLG
     */
    @JsonProperty("M1_ELIGIBLE_ASSIST_FLG")
    public List<M1ELIGIBLEASSISTFLG> getM1ELIGIBLEASSISTFLG() {
        return m1ELIGIBLEASSISTFLG;
    }

    /**
     * 
     * @param m1ELIGIBLEASSISTFLG
     *     The M1_ELIGIBLE_ASSIST_FLG
     */
    @JsonProperty("M1_ELIGIBLE_ASSIST_FLG")
    public void setM1ELIGIBLEASSISTFLG(List<M1ELIGIBLEASSISTFLG> m1ELIGIBLEASSISTFLG) {
        this.m1ELIGIBLEASSISTFLG = m1ELIGIBLEASSISTFLG;
    }

    /**
     * 
     * @return
     *     The m1CREATEBYCREWFLG
     */
    @JsonProperty("M1_CREATE_BY_CREW_FLG")
    public List<M1CREATEBYCREWFLG> getM1CREATEBYCREWFLG() {
        return m1CREATEBYCREWFLG;
    }

    /**
     * 
     * @param m1CREATEBYCREWFLG
     *     The M1_CREATE_BY_CREW_FLG
     */
    @JsonProperty("M1_CREATE_BY_CREW_FLG")
    public void setM1CREATEBYCREWFLG(List<M1CREATEBYCREWFLG> m1CREATEBYCREWFLG) {
        this.m1CREATEBYCREWFLG = m1CREATEBYCREWFLG;
    }

    /**
     * 
     * @return
     *     The tIMEWINDOWUSAGEFLG
     */
    @JsonProperty("TIME_WINDOW_USAGE_FLG")
    public List<TIMEWINDOWUSAGEFLG> getTIMEWINDOWUSAGEFLG() {
        return tIMEWINDOWUSAGEFLG;
    }

    /**
     * 
     * @param tIMEWINDOWUSAGEFLG
     *     The TIME_WINDOW_USAGE_FLG
     */
    @JsonProperty("TIME_WINDOW_USAGE_FLG")
    public void setTIMEWINDOWUSAGEFLG(List<TIMEWINDOWUSAGEFLG> tIMEWINDOWUSAGEFLG) {
        this.tIMEWINDOWUSAGEFLG = tIMEWINDOWUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The lOCTYPEFLG
     */
    @JsonProperty("LOC_TYPE_FLG")
    public List<LOCTYPEFLG> getLOCTYPEFLG() {
        return lOCTYPEFLG;
    }

    /**
     * 
     * @param lOCTYPEFLG
     *     The LOC_TYPE_FLG
     */
    @JsonProperty("LOC_TYPE_FLG")
    public void setLOCTYPEFLG(List<LOCTYPEFLG> lOCTYPEFLG) {
        this.lOCTYPEFLG = lOCTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1TRANSFERTYPEFLG
     */
    @JsonProperty("M1_TRANSFER_TYPE_FLG")
    public List<M1TRANSFERTYPEFLG> getM1TRANSFERTYPEFLG() {
        return m1TRANSFERTYPEFLG;
    }

    /**
     * 
     * @param m1TRANSFERTYPEFLG
     *     The M1_TRANSFER_TYPE_FLG
     */
    @JsonProperty("M1_TRANSFER_TYPE_FLG")
    public void setM1TRANSFERTYPEFLG(List<M1TRANSFERTYPEFLG> m1TRANSFERTYPEFLG) {
        this.m1TRANSFERTYPEFLG = m1TRANSFERTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1PICKUPSTATUSFLG
     */
    @JsonProperty("M1_PICKUP_STATUS_FLG")
    public List<M1PICKUPSTATUSFLG> getM1PICKUPSTATUSFLG() {
        return m1PICKUPSTATUSFLG;
    }

    /**
     * 
     * @param m1PICKUPSTATUSFLG
     *     The M1_PICKUP_STATUS_FLG
     */
    @JsonProperty("M1_PICKUP_STATUS_FLG")
    public void setM1PICKUPSTATUSFLG(List<M1PICKUPSTATUSFLG> m1PICKUPSTATUSFLG) {
        this.m1PICKUPSTATUSFLG = m1PICKUPSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1AUTOEXTENSION
     */
    @JsonProperty("M1_AUTO_EXTENSION")
    public List<M1AUTOEXTENSION> getM1AUTOEXTENSION() {
        return m1AUTOEXTENSION;
    }

    /**
     * 
     * @param m1AUTOEXTENSION
     *     The M1_AUTO_EXTENSION
     */
    @JsonProperty("M1_AUTO_EXTENSION")
    public void setM1AUTOEXTENSION(List<M1AUTOEXTENSION> m1AUTOEXTENSION) {
        this.m1AUTOEXTENSION = m1AUTOEXTENSION;
    }

    /**
     * 
     * @return
     *     The m1DATAENCRYPTIONGCFLG
     */
    @JsonProperty("M1_DATA_ENCRYPTION_GC_FLG")
    public List<M1DATAENCRYPTIONGCFLG> getM1DATAENCRYPTIONGCFLG() {
        return m1DATAENCRYPTIONGCFLG;
    }

    /**
     * 
     * @param m1DATAENCRYPTIONGCFLG
     *     The M1_DATA_ENCRYPTION_GC_FLG
     */
    @JsonProperty("M1_DATA_ENCRYPTION_GC_FLG")
    public void setM1DATAENCRYPTIONGCFLG(List<M1DATAENCRYPTIONGCFLG> m1DATAENCRYPTIONGCFLG) {
        this.m1DATAENCRYPTIONGCFLG = m1DATAENCRYPTIONGCFLG;
    }

    /**
     * 
     * @return
     *     The m1TRANSPORTRESTRICTIONFLG
     */
    @JsonProperty("M1_TRANSPORT_RESTRICTION_FLG")
    public List<M1TRANSPORTRESTRICTIONFLG> getM1TRANSPORTRESTRICTIONFLG() {
        return m1TRANSPORTRESTRICTIONFLG;
    }

    /**
     * 
     * @param m1TRANSPORTRESTRICTIONFLG
     *     The M1_TRANSPORT_RESTRICTION_FLG
     */
    @JsonProperty("M1_TRANSPORT_RESTRICTION_FLG")
    public void setM1TRANSPORTRESTRICTIONFLG(List<M1TRANSPORTRESTRICTIONFLG> m1TRANSPORTRESTRICTIONFLG) {
        this.m1TRANSPORTRESTRICTIONFLG = m1TRANSPORTRESTRICTIONFLG;
    }

    /**
     * 
     * @return
     *     The gPSDATAENABLEDFLG
     */
    @JsonProperty("GPS_DATA_ENABLED_FLG")
    public List<GPSDATAENABLEDFLG> getGPSDATAENABLEDFLG() {
        return gPSDATAENABLEDFLG;
    }

    /**
     * 
     * @param gPSDATAENABLEDFLG
     *     The GPS_DATA_ENABLED_FLG
     */
    @JsonProperty("GPS_DATA_ENABLED_FLG")
    public void setGPSDATAENABLEDFLG(List<GPSDATAENABLEDFLG> gPSDATAENABLEDFLG) {
        this.gPSDATAENABLEDFLG = gPSDATAENABLEDFLG;
    }

    /**
     * 
     * @return
     *     The m1RESTRICTIONTYPEFLG
     */
    @JsonProperty("M1_RESTRICTION_TYPE_FLG")
    public List<M1RESTRICTIONTYPEFLG> getM1RESTRICTIONTYPEFLG() {
        return m1RESTRICTIONTYPEFLG;
    }

    /**
     * 
     * @param m1RESTRICTIONTYPEFLG
     *     The M1_RESTRICTION_TYPE_FLG
     */
    @JsonProperty("M1_RESTRICTION_TYPE_FLG")
    public void setM1RESTRICTIONTYPEFLG(List<M1RESTRICTIONTYPEFLG> m1RESTRICTIONTYPEFLG) {
        this.m1RESTRICTIONTYPEFLG = m1RESTRICTIONTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1RESRVCAPACITYBYFLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_BY_FLG")
    public List<M1RESRVCAPACITYBYFLG> getM1RESRVCAPACITYBYFLG() {
        return m1RESRVCAPACITYBYFLG;
    }

    /**
     * 
     * @param m1RESRVCAPACITYBYFLG
     *     The M1_RESRV_CAPACITY_BY_FLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_BY_FLG")
    public void setM1RESRVCAPACITYBYFLG(List<M1RESRVCAPACITYBYFLG> m1RESRVCAPACITYBYFLG) {
        this.m1RESRVCAPACITYBYFLG = m1RESRVCAPACITYBYFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMDELIDCLNRSNFLG
     */
    @JsonProperty("M1_ITEM_DELI_DCLN_RSN_FLG")
    public List<M1ITEMDELIDCLNRSNFLG> getM1ITEMDELIDCLNRSNFLG() {
        return m1ITEMDELIDCLNRSNFLG;
    }

    /**
     * 
     * @param m1ITEMDELIDCLNRSNFLG
     *     The M1_ITEM_DELI_DCLN_RSN_FLG
     */
    @JsonProperty("M1_ITEM_DELI_DCLN_RSN_FLG")
    public void setM1ITEMDELIDCLNRSNFLG(List<M1ITEMDELIDCLNRSNFLG> m1ITEMDELIDCLNRSNFLG) {
        this.m1ITEMDELIDCLNRSNFLG = m1ITEMDELIDCLNRSNFLG;
    }

    /**
     * 
     * @return
     *     The pROCEDURESTATEFLG
     */
    @JsonProperty("PROCEDURE_STATE_FLG")
    public List<PROCEDURESTATEFLG> getPROCEDURESTATEFLG() {
        return pROCEDURESTATEFLG;
    }

    /**
     * 
     * @param pROCEDURESTATEFLG
     *     The PROCEDURE_STATE_FLG
     */
    @JsonProperty("PROCEDURE_STATE_FLG")
    public void setPROCEDURESTATEFLG(List<PROCEDURESTATEFLG> pROCEDURESTATEFLG) {
        this.pROCEDURESTATEFLG = pROCEDURESTATEFLG;
    }

    /**
     * 
     * @return
     *     The sTATUSREASONSELECTFLG
     */
    @JsonProperty("STATUS_REASON_SELECT_FLG")
    public List<STATUSREASONSELECTFLG> getSTATUSREASONSELECTFLG() {
        return sTATUSREASONSELECTFLG;
    }

    /**
     * 
     * @param sTATUSREASONSELECTFLG
     *     The STATUS_REASON_SELECT_FLG
     */
    @JsonProperty("STATUS_REASON_SELECT_FLG")
    public void setSTATUSREASONSELECTFLG(List<STATUSREASONSELECTFLG> sTATUSREASONSELECTFLG) {
        this.sTATUSREASONSELECTFLG = sTATUSREASONSELECTFLG;
    }

    /**
     * 
     * @return
     *     The m1TIMINGOPTIONFLG
     */
    @JsonProperty("M1_TIMING_OPTION_FLG")
    public List<M1TIMINGOPTIONFLG> getM1TIMINGOPTIONFLG() {
        return m1TIMINGOPTIONFLG;
    }

    /**
     * 
     * @param m1TIMINGOPTIONFLG
     *     The M1_TIMING_OPTION_FLG
     */
    @JsonProperty("M1_TIMING_OPTION_FLG")
    public void setM1TIMINGOPTIONFLG(List<M1TIMINGOPTIONFLG> m1TIMINGOPTIONFLG) {
        this.m1TIMINGOPTIONFLG = m1TIMINGOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1RTDSTUNITABBRFLG
     */
    @JsonProperty("M1_RT_DST_UNIT_ABBR_FLG")
    public List<M1RTDSTUNITABBRFLG> getM1RTDSTUNITABBRFLG() {
        return m1RTDSTUNITABBRFLG;
    }

    /**
     * 
     * @param m1RTDSTUNITABBRFLG
     *     The M1_RT_DST_UNIT_ABBR_FLG
     */
    @JsonProperty("M1_RT_DST_UNIT_ABBR_FLG")
    public void setM1RTDSTUNITABBRFLG(List<M1RTDSTUNITABBRFLG> m1RTDSTUNITABBRFLG) {
        this.m1RTDSTUNITABBRFLG = m1RTDSTUNITABBRFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMLOADSTATUSFLG
     */
    @JsonProperty("M1_ITEM_LOAD_STATUS_FLG")
    public List<M1ITEMLOADSTATUSFLG> getM1ITEMLOADSTATUSFLG() {
        return m1ITEMLOADSTATUSFLG;
    }

    /**
     * 
     * @param m1ITEMLOADSTATUSFLG
     *     The M1_ITEM_LOAD_STATUS_FLG
     */
    @JsonProperty("M1_ITEM_LOAD_STATUS_FLG")
    public void setM1ITEMLOADSTATUSFLG(List<M1ITEMLOADSTATUSFLG> m1ITEMLOADSTATUSFLG) {
        this.m1ITEMLOADSTATUSFLG = m1ITEMLOADSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The lOGENTRYTYPEFLG
     */
    @JsonProperty("LOG_ENTRY_TYPE_FLG")
    public List<LOGENTRYTYPEFLG> getLOGENTRYTYPEFLG() {
        return lOGENTRYTYPEFLG;
    }

    /**
     * 
     * @param lOGENTRYTYPEFLG
     *     The LOG_ENTRY_TYPE_FLG
     */
    @JsonProperty("LOG_ENTRY_TYPE_FLG")
    public void setLOGENTRYTYPEFLG(List<LOGENTRYTYPEFLG> lOGENTRYTYPEFLG) {
        this.lOGENTRYTYPEFLG = lOGENTRYTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1CAPACITYPREFERREDFLG
     */
    @JsonProperty("M1_CAPACITY_PREFERRED_FLG")
    public List<M1CAPACITYPREFERREDFLG> getM1CAPACITYPREFERREDFLG() {
        return m1CAPACITYPREFERREDFLG;
    }

    /**
     * 
     * @param m1CAPACITYPREFERREDFLG
     *     The M1_CAPACITY_PREFERRED_FLG
     */
    @JsonProperty("M1_CAPACITY_PREFERRED_FLG")
    public void setM1CAPACITYPREFERREDFLG(List<M1CAPACITYPREFERREDFLG> m1CAPACITYPREFERREDFLG) {
        this.m1CAPACITYPREFERREDFLG = m1CAPACITYPREFERREDFLG;
    }

    /**
     * 
     * @return
     *     The aCKNOWLEDGEMENTREQFLG
     */
    @JsonProperty("ACKNOWLEDGEMENT_REQ_FLG")
    public List<ACKNOWLEDGEMENTREQFLG> getACKNOWLEDGEMENTREQFLG() {
        return aCKNOWLEDGEMENTREQFLG;
    }

    /**
     * 
     * @param aCKNOWLEDGEMENTREQFLG
     *     The ACKNOWLEDGEMENT_REQ_FLG
     */
    @JsonProperty("ACKNOWLEDGEMENT_REQ_FLG")
    public void setACKNOWLEDGEMENTREQFLG(List<ACKNOWLEDGEMENTREQFLG> aCKNOWLEDGEMENTREQFLG) {
        this.aCKNOWLEDGEMENTREQFLG = aCKNOWLEDGEMENTREQFLG;
    }

    /**
     * 
     * @return
     *     The sTEPSTATEFLG
     */
    @JsonProperty("STEP_STATE_FLG")
    public List<STEPSTATEFLG> getSTEPSTATEFLG() {
        return sTEPSTATEFLG;
    }

    /**
     * 
     * @param sTEPSTATEFLG
     *     The STEP_STATE_FLG
     */
    @JsonProperty("STEP_STATE_FLG")
    public void setSTEPSTATEFLG(List<STEPSTATEFLG> sTEPSTATEFLG) {
        this.sTEPSTATEFLG = sTEPSTATEFLG;
    }

    /**
     * 
     * @return
     *     The dRIPMODEFLG
     */
    @JsonProperty("DRIP_MODE_FLG")
    public List<DRIPMODEFLG> getDRIPMODEFLG() {
        return dRIPMODEFLG;
    }

    /**
     * 
     * @param dRIPMODEFLG
     *     The DRIP_MODE_FLG
     */
    @JsonProperty("DRIP_MODE_FLG")
    public void setDRIPMODEFLG(List<DRIPMODEFLG> dRIPMODEFLG) {
        this.dRIPMODEFLG = dRIPMODEFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKLOADORDERFLG
     */
    @JsonProperty("M1_DEPOT_TASK_LOAD_ORDER_FLG")
    public List<M1DEPOTTASKLOADORDERFLG> getM1DEPOTTASKLOADORDERFLG() {
        return m1DEPOTTASKLOADORDERFLG;
    }

    /**
     * 
     * @param m1DEPOTTASKLOADORDERFLG
     *     The M1_DEPOT_TASK_LOAD_ORDER_FLG
     */
    @JsonProperty("M1_DEPOT_TASK_LOAD_ORDER_FLG")
    public void setM1DEPOTTASKLOADORDERFLG(List<M1DEPOTTASKLOADORDERFLG> m1DEPOTTASKLOADORDERFLG) {
        this.m1DEPOTTASKLOADORDERFLG = m1DEPOTTASKLOADORDERFLG;
    }

    /**
     * 
     * @return
     *     The aTTENDEDPROCEDUREFLG
     */
    @JsonProperty("ATTENDED_PROCEDURE_FLG")
    public List<ATTENDEDPROCEDUREFLG> getATTENDEDPROCEDUREFLG() {
        return aTTENDEDPROCEDUREFLG;
    }

    /**
     * 
     * @param aTTENDEDPROCEDUREFLG
     *     The ATTENDED_PROCEDURE_FLG
     */
    @JsonProperty("ATTENDED_PROCEDURE_FLG")
    public void setATTENDEDPROCEDUREFLG(List<ATTENDEDPROCEDUREFLG> aTTENDEDPROCEDUREFLG) {
        this.aTTENDEDPROCEDUREFLG = aTTENDEDPROCEDUREFLG;
    }

    /**
     * 
     * @return
     *     The vARIABLESHIFTFLG
     */
    @JsonProperty("VARIABLE_SHIFT_FLG")
    public List<VARIABLESHIFTFLG> getVARIABLESHIFTFLG() {
        return vARIABLESHIFTFLG;
    }

    /**
     * 
     * @param vARIABLESHIFTFLG
     *     The VARIABLE_SHIFT_FLG
     */
    @JsonProperty("VARIABLE_SHIFT_FLG")
    public void setVARIABLESHIFTFLG(List<VARIABLESHIFTFLG> vARIABLESHIFTFLG) {
        this.vARIABLESHIFTFLG = vARIABLESHIFTFLG;
    }

    /**
     * 
     * @return
     *     The aUTODISPATCHFLG
     */
    @JsonProperty("AUTO_DISPATCH_FLG")
    public List<AUTODISPATCHFLG> getAUTODISPATCHFLG() {
        return aUTODISPATCHFLG;
    }

    /**
     * 
     * @param aUTODISPATCHFLG
     *     The AUTO_DISPATCH_FLG
     */
    @JsonProperty("AUTO_DISPATCH_FLG")
    public void setAUTODISPATCHFLG(List<AUTODISPATCHFLG> aUTODISPATCHFLG) {
        this.aUTODISPATCHFLG = aUTODISPATCHFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYCOMPLETEFLG
     */
    @JsonProperty("M1_ACTIVITY_COMPLETE_FLG")
    public List<M1ACTIVITYCOMPLETEFLG> getM1ACTIVITYCOMPLETEFLG() {
        return m1ACTIVITYCOMPLETEFLG;
    }

    /**
     * 
     * @param m1ACTIVITYCOMPLETEFLG
     *     The M1_ACTIVITY_COMPLETE_FLG
     */
    @JsonProperty("M1_ACTIVITY_COMPLETE_FLG")
    public void setM1ACTIVITYCOMPLETEFLG(List<M1ACTIVITYCOMPLETEFLG> m1ACTIVITYCOMPLETEFLG) {
        this.m1ACTIVITYCOMPLETEFLG = m1ACTIVITYCOMPLETEFLG;
    }

    /**
     * 
     * @return
     *     The m1ASIGNCMPLRECEIPTOPTFLG
     */
    @JsonProperty("M1_ASIGN_CMPL_RECEIPT_OPT_FLG")
    public List<Object> getM1ASIGNCMPLRECEIPTOPTFLG() {
        return m1ASIGNCMPLRECEIPTOPTFLG;
    }

    /**
     * 
     * @param m1ASIGNCMPLRECEIPTOPTFLG
     *     The M1_ASIGN_CMPL_RECEIPT_OPT_FLG
     */
    @JsonProperty("M1_ASIGN_CMPL_RECEIPT_OPT_FLG")
    public void setM1ASIGNCMPLRECEIPTOPTFLG(List<Object> m1ASIGNCMPLRECEIPTOPTFLG) {
        this.m1ASIGNCMPLRECEIPTOPTFLG = m1ASIGNCMPLRECEIPTOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMCUSTACCEPTREQFLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPT_REQ_FLG")
    public List<M1ITEMCUSTACCEPTREQFLG> getM1ITEMCUSTACCEPTREQFLG() {
        return m1ITEMCUSTACCEPTREQFLG;
    }

    /**
     * 
     * @param m1ITEMCUSTACCEPTREQFLG
     *     The M1_ITEM_CUST_ACCEPT_REQ_FLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPT_REQ_FLG")
    public void setM1ITEMCUSTACCEPTREQFLG(List<M1ITEMCUSTACCEPTREQFLG> m1ITEMCUSTACCEPTREQFLG) {
        this.m1ITEMCUSTACCEPTREQFLG = m1ITEMCUSTACCEPTREQFLG;
    }

    /**
     * 
     * @return
     *     The pROCEDURECLEARANCEREQFLG
     */
    @JsonProperty("PROCEDURE_CLEARANCE_REQ_FLG")
    public List<PROCEDURECLEARANCEREQFLG> getPROCEDURECLEARANCEREQFLG() {
        return pROCEDURECLEARANCEREQFLG;
    }

    /**
     * 
     * @param pROCEDURECLEARANCEREQFLG
     *     The PROCEDURE_CLEARANCE_REQ_FLG
     */
    @JsonProperty("PROCEDURE_CLEARANCE_REQ_FLG")
    public void setPROCEDURECLEARANCEREQFLG(List<PROCEDURECLEARANCEREQFLG> pROCEDURECLEARANCEREQFLG) {
        this.pROCEDURECLEARANCEREQFLG = pROCEDURECLEARANCEREQFLG;
    }

    /**
     * 
     * @return
     *     The m1APPTREQFLG
     */
    @JsonProperty("M1_APPT_REQ_FLG")
    public List<M1APPTREQFLG> getM1APPTREQFLG() {
        return m1APPTREQFLG;
    }

    /**
     * 
     * @param m1APPTREQFLG
     *     The M1_APPT_REQ_FLG
     */
    @JsonProperty("M1_APPT_REQ_FLG")
    public void setM1APPTREQFLG(List<M1APPTREQFLG> m1APPTREQFLG) {
        this.m1APPTREQFLG = m1APPTREQFLG;
    }

    /**
     * 
     * @return
     *     The m1TASKSTATUSFLG
     */
    @JsonProperty("M1_TASK_STATUS_FLG")
    public List<M1TASKSTATUSFLG> getM1TASKSTATUSFLG() {
        return m1TASKSTATUSFLG;
    }

    /**
     * 
     * @param m1TASKSTATUSFLG
     *     The M1_TASK_STATUS_FLG
     */
    @JsonProperty("M1_TASK_STATUS_FLG")
    public void setM1TASKSTATUSFLG(List<M1TASKSTATUSFLG> m1TASKSTATUSFLG) {
        this.m1TASKSTATUSFLG = m1TASKSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1SAMECREWFLG
     */
    @JsonProperty("M1_SAME_CREW_FLG")
    public List<M1SAMECREWFLG> getM1SAMECREWFLG() {
        return m1SAMECREWFLG;
    }

    /**
     * 
     * @param m1SAMECREWFLG
     *     The M1_SAME_CREW_FLG
     */
    @JsonProperty("M1_SAME_CREW_FLG")
    public void setM1SAMECREWFLG(List<M1SAMECREWFLG> m1SAMECREWFLG) {
        this.m1SAMECREWFLG = m1SAMECREWFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPENDENCYRSNFLG
     */
    @JsonProperty("M1_DEPENDENCY_RSN_FLG")
    public List<M1DEPENDENCYRSNFLG> getM1DEPENDENCYRSNFLG() {
        return m1DEPENDENCYRSNFLG;
    }

    /**
     * 
     * @param m1DEPENDENCYRSNFLG
     *     The M1_DEPENDENCY_RSN_FLG
     */
    @JsonProperty("M1_DEPENDENCY_RSN_FLG")
    public void setM1DEPENDENCYRSNFLG(List<M1DEPENDENCYRSNFLG> m1DEPENDENCYRSNFLG) {
        this.m1DEPENDENCYRSNFLG = m1DEPENDENCYRSNFLG;
    }

    /**
     * 
     * @return
     *     The m1CAPSYSEVENTFLG
     */
    @JsonProperty("M1_CAP_SYS_EVENT_FLG")
    public List<M1CAPSYSEVENTFLG> getM1CAPSYSEVENTFLG() {
        return m1CAPSYSEVENTFLG;
    }

    /**
     * 
     * @param m1CAPSYSEVENTFLG
     *     The M1_CAP_SYS_EVENT_FLG
     */
    @JsonProperty("M1_CAP_SYS_EVENT_FLG")
    public void setM1CAPSYSEVENTFLG(List<M1CAPSYSEVENTFLG> m1CAPSYSEVENTFLG) {
        this.m1CAPSYSEVENTFLG = m1CAPSYSEVENTFLG;
    }

    /**
     * 
     * @return
     *     The m1ALLOWCREWTIMEFLG
     */
    @JsonProperty("M1_ALLOW_CREW_TIME_FLG")
    public List<M1ALLOWCREWTIMEFLG> getM1ALLOWCREWTIMEFLG() {
        return m1ALLOWCREWTIMEFLG;
    }

    /**
     * 
     * @param m1ALLOWCREWTIMEFLG
     *     The M1_ALLOW_CREW_TIME_FLG
     */
    @JsonProperty("M1_ALLOW_CREW_TIME_FLG")
    public void setM1ALLOWCREWTIMEFLG(List<M1ALLOWCREWTIMEFLG> m1ALLOWCREWTIMEFLG) {
        this.m1ALLOWCREWTIMEFLG = m1ALLOWCREWTIMEFLG;
    }

    /**
     * 
     * @return
     *     The tASKCLSFLG
     */
    @JsonProperty("TASK_CLS_FLG")
    public List<TASKCLSFLG> getTASKCLSFLG() {
        return tASKCLSFLG;
    }

    /**
     * 
     * @param tASKCLSFLG
     *     The TASK_CLS_FLG
     */
    @JsonProperty("TASK_CLS_FLG")
    public void setTASKCLSFLG(List<TASKCLSFLG> tASKCLSFLG) {
        this.tASKCLSFLG = tASKCLSFLG;
    }

    /**
     * 
     * @return
     *     The m1ELGBCONTRACTINGFLG
     */
    @JsonProperty("M1_ELGB_CONTRACTING_FLG")
    public List<M1ELGBCONTRACTINGFLG> getM1ELGBCONTRACTINGFLG() {
        return m1ELGBCONTRACTINGFLG;
    }

    /**
     * 
     * @param m1ELGBCONTRACTINGFLG
     *     The M1_ELGB_CONTRACTING_FLG
     */
    @JsonProperty("M1_ELGB_CONTRACTING_FLG")
    public void setM1ELGBCONTRACTINGFLG(List<M1ELGBCONTRACTINGFLG> m1ELGBCONTRACTINGFLG) {
        this.m1ELGBCONTRACTINGFLG = m1ELGBCONTRACTINGFLG;
    }

    /**
     * 
     * @return
     *     The m1FOLDERFLG
     */
    @JsonProperty("M1_FOLDER_FLG")
    public List<M1FOLDERFLG> getM1FOLDERFLG() {
        return m1FOLDERFLG;
    }

    /**
     * 
     * @param m1FOLDERFLG
     *     The M1_FOLDER_FLG
     */
    @JsonProperty("M1_FOLDER_FLG")
    public void setM1FOLDERFLG(List<M1FOLDERFLG> m1FOLDERFLG) {
        this.m1FOLDERFLG = m1FOLDERFLG;
    }

    /**
     * 
     * @return
     *     The m1MAXCAPACITYFLG
     */
    @JsonProperty("M1_MAX_CAPACITY_FLG")
    public List<M1MAXCAPACITYFLG> getM1MAXCAPACITYFLG() {
        return m1MAXCAPACITYFLG;
    }

    /**
     * 
     * @param m1MAXCAPACITYFLG
     *     The M1_MAX_CAPACITY_FLG
     */
    @JsonProperty("M1_MAX_CAPACITY_FLG")
    public void setM1MAXCAPACITYFLG(List<M1MAXCAPACITYFLG> m1MAXCAPACITYFLG) {
        this.m1MAXCAPACITYFLG = m1MAXCAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1STRICTTIMEFLG
     */
    @JsonProperty("M1_STRICT_TIME_FLG")
    public List<M1STRICTTIMEFLG> getM1STRICTTIMEFLG() {
        return m1STRICTTIMEFLG;
    }

    /**
     * 
     * @param m1STRICTTIMEFLG
     *     The M1_STRICT_TIME_FLG
     */
    @JsonProperty("M1_STRICT_TIME_FLG")
    public void setM1STRICTTIMEFLG(List<M1STRICTTIMEFLG> m1STRICTTIMEFLG) {
        this.m1STRICTTIMEFLG = m1STRICTTIMEFLG;
    }

    /**
     * 
     * @return
     *     The f1EXTLOOKUPUSAGEFLG
     */
    @JsonProperty("F1_EXT_LOOKUP_USAGE_FLG")
    public List<F1EXTLOOKUPUSAGEFLG> getF1EXTLOOKUPUSAGEFLG() {
        return f1EXTLOOKUPUSAGEFLG;
    }

    /**
     * 
     * @param f1EXTLOOKUPUSAGEFLG
     *     The F1_EXT_LOOKUP_USAGE_FLG
     */
    @JsonProperty("F1_EXT_LOOKUP_USAGE_FLG")
    public void setF1EXTLOOKUPUSAGEFLG(List<F1EXTLOOKUPUSAGEFLG> f1EXTLOOKUPUSAGEFLG) {
        this.f1EXTLOOKUPUSAGEFLG = f1EXTLOOKUPUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The m1MAXNONCUMCAPACITYFLG
     */
    @JsonProperty("M1_MAX_NONCUM_CAPACITY_FLG")
    public List<M1MAXNONCUMCAPACITYFLG> getM1MAXNONCUMCAPACITYFLG() {
        return m1MAXNONCUMCAPACITYFLG;
    }

    /**
     * 
     * @param m1MAXNONCUMCAPACITYFLG
     *     The M1_MAX_NONCUM_CAPACITY_FLG
     */
    @JsonProperty("M1_MAX_NONCUM_CAPACITY_FLG")
    public void setM1MAXNONCUMCAPACITYFLG(List<M1MAXNONCUMCAPACITYFLG> m1MAXNONCUMCAPACITYFLG) {
        this.m1MAXNONCUMCAPACITYFLG = m1MAXNONCUMCAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1CREWTMUSGCLSFLG
     */
    @JsonProperty("M1_CREW_TM_USG_CLS_FLG")
    public List<M1CREWTMUSGCLSFLG> getM1CREWTMUSGCLSFLG() {
        return m1CREWTMUSGCLSFLG;
    }

    /**
     * 
     * @param m1CREWTMUSGCLSFLG
     *     The M1_CREW_TM_USG_CLS_FLG
     */
    @JsonProperty("M1_CREW_TM_USG_CLS_FLG")
    public void setM1CREWTMUSGCLSFLG(List<M1CREWTMUSGCLSFLG> m1CREWTMUSGCLSFLG) {
        this.m1CREWTMUSGCLSFLG = m1CREWTMUSGCLSFLG;
    }

    /**
     * 
     * @return
     *     The sHFTUSAGEFLG
     */
    @JsonProperty("SHFT_USAGE_FLG")
    public List<SHFTUSAGEFLG> getSHFTUSAGEFLG() {
        return sHFTUSAGEFLG;
    }

    /**
     * 
     * @param sHFTUSAGEFLG
     *     The SHFT_USAGE_FLG
     */
    @JsonProperty("SHFT_USAGE_FLG")
    public void setSHFTUSAGEFLG(List<SHFTUSAGEFLG> sHFTUSAGEFLG) {
        this.sHFTUSAGEFLG = sHFTUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The m1SCHEDOPTFLG
     */
    @JsonProperty("M1_SCHED_OPT_FLG")
    public List<M1SCHEDOPTFLG> getM1SCHEDOPTFLG() {
        return m1SCHEDOPTFLG;
    }

    /**
     * 
     * @param m1SCHEDOPTFLG
     *     The M1_SCHED_OPT_FLG
     */
    @JsonProperty("M1_SCHED_OPT_FLG")
    public void setM1SCHEDOPTFLG(List<M1SCHEDOPTFLG> m1SCHEDOPTFLG) {
        this.m1SCHEDOPTFLG = m1SCHEDOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1TMSHTOVRDFLG
     */
    @JsonProperty("M1_TMSHT_OVRD_FLG")
    public List<M1TMSHTOVRDFLG> getM1TMSHTOVRDFLG() {
        return m1TMSHTOVRDFLG;
    }

    /**
     * 
     * @param m1TMSHTOVRDFLG
     *     The M1_TMSHT_OVRD_FLG
     */
    @JsonProperty("M1_TMSHT_OVRD_FLG")
    public void setM1TMSHTOVRDFLG(List<M1TMSHTOVRDFLG> m1TMSHTOVRDFLG) {
        this.m1TMSHTOVRDFLG = m1TMSHTOVRDFLG;
    }

    /**
     * 
     * @return
     *     The sTATUSFLG
     */
    @JsonProperty("STATUS_FLG")
    public List<STATUSFLG> getSTATUSFLG() {
        return sTATUSFLG;
    }

    /**
     * 
     * @param sTATUSFLG
     *     The STATUS_FLG
     */
    @JsonProperty("STATUS_FLG")
    public void setSTATUSFLG(List<STATUSFLG> sTATUSFLG) {
        this.sTATUSFLG = sTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1AUTOCANCEL
     */
    @JsonProperty("M1_AUTO_CANCEL")
    public List<M1AUTOCANCEL> getM1AUTOCANCEL() {
        return m1AUTOCANCEL;
    }

    /**
     * 
     * @param m1AUTOCANCEL
     *     The M1_AUTO_CANCEL
     */
    @JsonProperty("M1_AUTO_CANCEL")
    public void setM1AUTOCANCEL(List<M1AUTOCANCEL> m1AUTOCANCEL) {
        this.m1AUTOCANCEL = m1AUTOCANCEL;
    }

    /**
     * 
     * @return
     *     The m1NONCUMCAPACITYFLG
     */
    @JsonProperty("M1_NONCUM_CAPACITY_FLG")
    public List<M1NONCUMCAPACITYFLG> getM1NONCUMCAPACITYFLG() {
        return m1NONCUMCAPACITYFLG;
    }

    /**
     * 
     * @param m1NONCUMCAPACITYFLG
     *     The M1_NONCUM_CAPACITY_FLG
     */
    @JsonProperty("M1_NONCUM_CAPACITY_FLG")
    public void setM1NONCUMCAPACITYFLG(List<M1NONCUMCAPACITYFLG> m1NONCUMCAPACITYFLG) {
        this.m1NONCUMCAPACITYFLG = m1NONCUMCAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The rOUNDSTARTTIMEOPTFLG
     */
    @JsonProperty("ROUND_START_TIME_OPT_FLG")
    public List<ROUNDSTARTTIMEOPTFLG> getROUNDSTARTTIMEOPTFLG() {
        return rOUNDSTARTTIMEOPTFLG;
    }

    /**
     * 
     * @param rOUNDSTARTTIMEOPTFLG
     *     The ROUND_START_TIME_OPT_FLG
     */
    @JsonProperty("ROUND_START_TIME_OPT_FLG")
    public void setROUNDSTARTTIMEOPTFLG(List<ROUNDSTARTTIMEOPTFLG> rOUNDSTARTTIMEOPTFLG) {
        this.rOUNDSTARTTIMEOPTFLG = rOUNDSTARTTIMEOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1CUMULATIVECAPACITYFLG
     */
    @JsonProperty("M1_CUMULATIVE_CAPACITY_FLG")
    public List<M1CUMULATIVECAPACITYFLG> getM1CUMULATIVECAPACITYFLG() {
        return m1CUMULATIVECAPACITYFLG;
    }

    /**
     * 
     * @param m1CUMULATIVECAPACITYFLG
     *     The M1_CUMULATIVE_CAPACITY_FLG
     */
    @JsonProperty("M1_CUMULATIVE_CAPACITY_FLG")
    public void setM1CUMULATIVECAPACITYFLG(List<M1CUMULATIVECAPACITYFLG> m1CUMULATIVECAPACITYFLG) {
        this.m1CUMULATIVECAPACITYFLG = m1CUMULATIVECAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1MAILMSGCLSFLG
     */
    @JsonProperty("M1_MAIL_MSG_CLS_FLG")
    public List<M1MAILMSGCLSFLG> getM1MAILMSGCLSFLG() {
        return m1MAILMSGCLSFLG;
    }

    /**
     * 
     * @param m1MAILMSGCLSFLG
     *     The M1_MAIL_MSG_CLS_FLG
     */
    @JsonProperty("M1_MAIL_MSG_CLS_FLG")
    public void setM1MAILMSGCLSFLG(List<M1MAILMSGCLSFLG> m1MAILMSGCLSFLG) {
        this.m1MAILMSGCLSFLG = m1MAILMSGCLSFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPOTRUNCLOSEDFLG
     */
    @JsonProperty("M1_DEPOT_RUN_CLOSED_FLG")
    public List<M1DEPOTRUNCLOSEDFLG> getM1DEPOTRUNCLOSEDFLG() {
        return m1DEPOTRUNCLOSEDFLG;
    }

    /**
     * 
     * @param m1DEPOTRUNCLOSEDFLG
     *     The M1_DEPOT_RUN_CLOSED_FLG
     */
    @JsonProperty("M1_DEPOT_RUN_CLOSED_FLG")
    public void setM1DEPOTRUNCLOSEDFLG(List<M1DEPOTRUNCLOSEDFLG> m1DEPOTRUNCLOSEDFLG) {
        this.m1DEPOTRUNCLOSEDFLG = m1DEPOTRUNCLOSEDFLG;
    }

    /**
     * 
     * @return
     *     The m1CLOSEDBYADVDISPFLG
     */
    @JsonProperty("M1_CLOSEDBY_ADV_DISP_FLG")
    public List<M1CLOSEDBYADVDISPFLG> getM1CLOSEDBYADVDISPFLG() {
        return m1CLOSEDBYADVDISPFLG;
    }

    /**
     * 
     * @param m1CLOSEDBYADVDISPFLG
     *     The M1_CLOSEDBY_ADV_DISP_FLG
     */
    @JsonProperty("M1_CLOSEDBY_ADV_DISP_FLG")
    public void setM1CLOSEDBYADVDISPFLG(List<M1CLOSEDBYADVDISPFLG> m1CLOSEDBYADVDISPFLG) {
        this.m1CLOSEDBYADVDISPFLG = m1CLOSEDBYADVDISPFLG;
    }

    /**
     * 
     * @return
     *     The m1SYSTEMGENFLG
     */
    @JsonProperty("M1_SYSTEM_GEN_FLG")
    public List<M1SYSTEMGENFLG> getM1SYSTEMGENFLG() {
        return m1SYSTEMGENFLG;
    }

    /**
     * 
     * @param m1SYSTEMGENFLG
     *     The M1_SYSTEM_GEN_FLG
     */
    @JsonProperty("M1_SYSTEM_GEN_FLG")
    public void setM1SYSTEMGENFLG(List<M1SYSTEMGENFLG> m1SYSTEMGENFLG) {
        this.m1SYSTEMGENFLG = m1SYSTEMGENFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPENDENCYTYPEFLG
     */
    @JsonProperty("M1_DEPENDENCY_TYPE_FLG")
    public List<M1DEPENDENCYTYPEFLG> getM1DEPENDENCYTYPEFLG() {
        return m1DEPENDENCYTYPEFLG;
    }

    /**
     * 
     * @param m1DEPENDENCYTYPEFLG
     *     The M1_DEPENDENCY_TYPE_FLG
     */
    @JsonProperty("M1_DEPENDENCY_TYPE_FLG")
    public void setM1DEPENDENCYTYPEFLG(List<M1DEPENDENCYTYPEFLG> m1DEPENDENCYTYPEFLG) {
        this.m1DEPENDENCYTYPEFLG = m1DEPENDENCYTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1FORCELOGOFFREASONFLG
     */
    @JsonProperty("M1_FORCE_LOGOFF_REASON_FLG")
    public List<M1FORCELOGOFFREASONFLG> getM1FORCELOGOFFREASONFLG() {
        return m1FORCELOGOFFREASONFLG;
    }

    /**
     * 
     * @param m1FORCELOGOFFREASONFLG
     *     The M1_FORCE_LOGOFF_REASON_FLG
     */
    @JsonProperty("M1_FORCE_LOGOFF_REASON_FLG")
    public void setM1FORCELOGOFFREASONFLG(List<M1FORCELOGOFFREASONFLG> m1FORCELOGOFFREASONFLG) {
        this.m1FORCELOGOFFREASONFLG = m1FORCELOGOFFREASONFLG;
    }

    /**
     * 
     * @return
     *     The aLLOCATIONRULEFLG
     */
    @JsonProperty("ALLOCATION_RULE_FLG")
    public List<ALLOCATIONRULEFLG> getALLOCATIONRULEFLG() {
        return aLLOCATIONRULEFLG;
    }

    /**
     * 
     * @param aLLOCATIONRULEFLG
     *     The ALLOCATION_RULE_FLG
     */
    @JsonProperty("ALLOCATION_RULE_FLG")
    public void setALLOCATIONRULEFLG(List<ALLOCATIONRULEFLG> aLLOCATIONRULEFLG) {
        this.aLLOCATIONRULEFLG = aLLOCATIONRULEFLG;
    }

    /**
     * 
     * @return
     *     The m1OVRDFLG
     */
    @JsonProperty("M1_OVRD_FLG")
    public List<M1OVRDFLG> getM1OVRDFLG() {
        return m1OVRDFLG;
    }

    /**
     * 
     * @param m1OVRDFLG
     *     The M1_OVRD_FLG
     */
    @JsonProperty("M1_OVRD_FLG")
    public void setM1OVRDFLG(List<M1OVRDFLG> m1OVRDFLG) {
        this.m1OVRDFLG = m1OVRDFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMLOADDCLNRSNFLG
     */
    @JsonProperty("M1_ITEM_LOAD_DCLN_RSN_FLG")
    public List<Object> getM1ITEMLOADDCLNRSNFLG() {
        return m1ITEMLOADDCLNRSNFLG;
    }

    /**
     * 
     * @param m1ITEMLOADDCLNRSNFLG
     *     The M1_ITEM_LOAD_DCLN_RSN_FLG
     */
    @JsonProperty("M1_ITEM_LOAD_DCLN_RSN_FLG")
    public void setM1ITEMLOADDCLNRSNFLG(List<Object> m1ITEMLOADDCLNRSNFLG) {
        this.m1ITEMLOADDCLNRSNFLG = m1ITEMLOADDCLNRSNFLG;
    }

    /**
     * 
     * @return
     *     The m1IGNORESEQLOCKFLG
     */
    @JsonProperty("M1_IGNORE_SEQ_LOCK_FLG")
    public List<M1IGNORESEQLOCKFLG> getM1IGNORESEQLOCKFLG() {
        return m1IGNORESEQLOCKFLG;
    }

    /**
     * 
     * @param m1IGNORESEQLOCKFLG
     *     The M1_IGNORE_SEQ_LOCK_FLG
     */
    @JsonProperty("M1_IGNORE_SEQ_LOCK_FLG")
    public void setM1IGNORESEQLOCKFLG(List<M1IGNORESEQLOCKFLG> m1IGNORESEQLOCKFLG) {
        this.m1IGNORESEQLOCKFLG = m1IGNORESEQLOCKFLG;
    }

    /**
     * 
     * @return
     *     The m1OVRDEXTENSIONLIMITFLG
     */
    @JsonProperty("M1_OVRD_EXTENSION_LIMIT_FLG")
    public List<M1OVRDEXTENSIONLIMITFLG> getM1OVRDEXTENSIONLIMITFLG() {
        return m1OVRDEXTENSIONLIMITFLG;
    }

    /**
     * 
     * @param m1OVRDEXTENSIONLIMITFLG
     *     The M1_OVRD_EXTENSION_LIMIT_FLG
     */
    @JsonProperty("M1_OVRD_EXTENSION_LIMIT_FLG")
    public void setM1OVRDEXTENSIONLIMITFLG(List<M1OVRDEXTENSIONLIMITFLG> m1OVRDEXTENSIONLIMITFLG) {
        this.m1OVRDEXTENSIONLIMITFLG = m1OVRDEXTENSIONLIMITFLG;
    }

    /**
     * 
     * @return
     *     The aNSWERTYPEFLG
     */
    @JsonProperty("ANSWER_TYPE_FLG")
    public List<ANSWERTYPEFLG> getANSWERTYPEFLG() {
        return aNSWERTYPEFLG;
    }

    /**
     * 
     * @param aNSWERTYPEFLG
     *     The ANSWER_TYPE_FLG
     */
    @JsonProperty("ANSWER_TYPE_FLG")
    public void setANSWERTYPEFLG(List<ANSWERTYPEFLG> aNSWERTYPEFLG) {
        this.aNSWERTYPEFLG = aNSWERTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMDELIVERYSTATUSFLG
     */
    @JsonProperty("M1_ITEM_DELIVERY_STATUS_FLG")
    public List<M1ITEMDELIVERYSTATUSFLG> getM1ITEMDELIVERYSTATUSFLG() {
        return m1ITEMDELIVERYSTATUSFLG;
    }

    /**
     * 
     * @param m1ITEMDELIVERYSTATUSFLG
     *     The M1_ITEM_DELIVERY_STATUS_FLG
     */
    @JsonProperty("M1_ITEM_DELIVERY_STATUS_FLG")
    public void setM1ITEMDELIVERYSTATUSFLG(List<M1ITEMDELIVERYSTATUSFLG> m1ITEMDELIVERYSTATUSFLG) {
        this.m1ITEMDELIVERYSTATUSFLG = m1ITEMDELIVERYSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1CAPTYPEUSAGEFLG
     */
    @JsonProperty("M1_CAP_TYPE_USAGE_FLG")
    public List<M1CAPTYPEUSAGEFLG> getM1CAPTYPEUSAGEFLG() {
        return m1CAPTYPEUSAGEFLG;
    }

    /**
     * 
     * @param m1CAPTYPEUSAGEFLG
     *     The M1_CAP_TYPE_USAGE_FLG
     */
    @JsonProperty("M1_CAP_TYPE_USAGE_FLG")
    public void setM1CAPTYPEUSAGEFLG(List<M1CAPTYPEUSAGEFLG> m1CAPTYPEUSAGEFLG) {
        this.m1CAPTYPEUSAGEFLG = m1CAPTYPEUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYATTRIBUSAGEFLG
     */
    @JsonProperty("M1_ACTIVITY_ATTRIB_USAGE_FLG")
    public List<M1ACTIVITYATTRIBUSAGEFLG> getM1ACTIVITYATTRIBUSAGEFLG() {
        return m1ACTIVITYATTRIBUSAGEFLG;
    }

    /**
     * 
     * @param m1ACTIVITYATTRIBUSAGEFLG
     *     The M1_ACTIVITY_ATTRIB_USAGE_FLG
     */
    @JsonProperty("M1_ACTIVITY_ATTRIB_USAGE_FLG")
    public void setM1ACTIVITYATTRIBUSAGEFLG(List<M1ACTIVITYATTRIBUSAGEFLG> m1ACTIVITYATTRIBUSAGEFLG) {
        this.m1ACTIVITYATTRIBUSAGEFLG = m1ACTIVITYATTRIBUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The oWNERFLG
     */
    @JsonProperty("OWNER_FLG")
    public List<OWNERFLG> getOWNERFLG() {
        return oWNERFLG;
    }

    /**
     * 
     * @param oWNERFLG
     *     The OWNER_FLG
     */
    @JsonProperty("OWNER_FLG")
    public void setOWNERFLG(List<OWNERFLG> oWNERFLG) {
        this.oWNERFLG = oWNERFLG;
    }

    /**
     * 
     * @return
     *     The rESRCIDTYPEFLG
     */
    @JsonProperty("RESRC_ID_TYPE_FLG")
    public List<RESRCIDTYPEFLG> getRESRCIDTYPEFLG() {
        return rESRCIDTYPEFLG;
    }

    /**
     * 
     * @param rESRCIDTYPEFLG
     *     The RESRC_ID_TYPE_FLG
     */
    @JsonProperty("RESRC_ID_TYPE_FLG")
    public void setRESRCIDTYPEFLG(List<RESRCIDTYPEFLG> rESRCIDTYPEFLG) {
        this.rESRCIDTYPEFLG = rESRCIDTYPEFLG;
    }

    /**
     * 
     * @return
     *     The oUTMSGPRIORFLG
     */
    @JsonProperty("OUTMSG_PRIOR_FLG")
    public List<OUTMSGPRIORFLG> getOUTMSGPRIORFLG() {
        return oUTMSGPRIORFLG;
    }

    /**
     * 
     * @param oUTMSGPRIORFLG
     *     The OUTMSG_PRIOR_FLG
     */
    @JsonProperty("OUTMSG_PRIOR_FLG")
    public void setOUTMSGPRIORFLG(List<OUTMSGPRIORFLG> oUTMSGPRIORFLG) {
        this.oUTMSGPRIORFLG = oUTMSGPRIORFLG;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "M1_AUTO_COMP_FLG":
                if (value instanceof List) {
                    setM1AUTOCOMPFLG(((List<M1AUTOCOMPFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_AUTO_COMP_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1AUTOCOMPFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETE_OPTION_FLG":
                if (value instanceof List) {
                    setM1COMPLETEOPTIONFLG(((List<M1COMPLETEOPTIONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_COMPLETE_OPTION_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1COMPLETEOPTIONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DELVR_NOW_FLG":
                if (value instanceof List) {
                    setM1DELVRNOWFLG(((List<M1DELVRNOWFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DELVR_NOW_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DELVRNOWFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEFERMENT_REASON_FLG":
                if (value instanceof List) {
                    setM1DEFERMENTREASONFLG(((List<Object> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEFERMENT_REASON_FLG\" is of type \"java.util.List<java.lang.Object>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RESRC_CLASS_FLG":
                if (value instanceof List) {
                    setRESRCCLASSFLG(((List<RESRCCLASSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"RESRC_CLASS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.RESRCCLASSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OVERRIDE_CLEARANCE_FLG":
                if (value instanceof List) {
                    setOVERRIDECLEARANCEFLG(((List<OVERRIDECLEARANCEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"OVERRIDE_CLEARANCE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.OVERRIDECLEARANCEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WINDOW_MODE_FLG":
                if (value instanceof List) {
                    setM1WINDOWMODEFLG(((List<M1WINDOWMODEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_WINDOW_MODE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1WINDOWMODEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_YES_NO_FLAG":
                if (value instanceof List) {
                    setM1YESNOFLAG(((List<M1YESNOFLAG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_YES_NO_FLAG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1YESNOFLAG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "YES_NO_ANSWER_FLG":
                if (value instanceof List) {
                    setYESNOANSWERFLG(((List<YESNOANSWERFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"YES_NO_ANSWER_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.YESNOANSWERFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_DELIVERY_FLG":
                if (value instanceof List) {
                    setM1ITEMDELIVERYFLG(((List<M1ITEMDELIVERYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_DELIVERY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ITEMDELIVERYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_ACT_CLASS_FLG":
                if (value instanceof List) {
                    setM1DEPOTACTCLASSFLG(((List<M1DEPOTACTCLASSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPOT_ACT_CLASS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPOTACTCLASSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_OWNED_FLG":
                if (value instanceof List) {
                    setM1MDTOWNEDFLG(((List<M1MDTOWNEDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_MDT_OWNED_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MDTOWNEDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STATUS_REASON_USAGE_FLG":
                if (value instanceof List) {
                    setM1STATUSREASONUSAGEFLG(((List<M1STATUSREASONUSAGEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_STATUS_REASON_USAGE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1STATUSREASONUSAGEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MSG_PARM_TYP_FLG":
                if (value instanceof List) {
                    setMSGPARMTYPFLG(((List<MSGPARMTYPFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"MSG_PARM_TYP_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.MSGPARMTYPFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RELATED_ENTITY_FLG":
                if (value instanceof List) {
                    setRELATEDENTITYFLG(((List<RELATEDENTITYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"RELATED_ENTITY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.RELATEDENTITYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SVC_AREA_USG_FLG":
                if (value instanceof List) {
                    setSVCAREAUSGFLG(((List<SVCAREAUSGFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"SVC_AREA_USG_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.SVCAREAUSGFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SVC_TYPE_FLG":
                if (value instanceof List) {
                    setM1SVCTYPEFLG(((List<Object> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_SVC_TYPE_FLG\" is of type \"java.util.List<java.lang.Object>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REVW_ON_DEV_FLG":
                if (value instanceof List) {
                    setM1REVWONDEVFLG(((List<M1REVWONDEVFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_REVW_ON_DEV_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1REVWONDEVFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TMSHEET_CORR_FLG":
                if (value instanceof List) {
                    setM1TMSHEETCORRFLG(((List<M1TMSHEETCORRFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TMSHEET_CORR_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TMSHEETCORRFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_STATUS_FLG":
                if (value instanceof List) {
                    setPROCEDURESTATUSFLG(((List<PROCEDURESTATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"PROCEDURE_STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.PROCEDURESTATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UNDISPATCH_OPTION_FLG":
                if (value instanceof List) {
                    setM1UNDISPATCHOPTIONFLG(((List<M1UNDISPATCHOPTIONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_UNDISPATCH_OPTION_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1UNDISPATCHOPTIONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SVC_CLS_USG_FLG":
                if (value instanceof List) {
                    setSVCCLSUSGFLG(((List<SVCCLSUSGFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"SVC_CLS_USG_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.SVCCLSUSGFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CHANGE_SEQUENCE_FLG":
                if (value instanceof List) {
                    setM1CHANGESEQUENCEFLG(((List<M1CHANGESEQUENCEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CHANGE_SEQUENCE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CHANGESEQUENCEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_CUST_ACCEPTED_FLG":
                if (value instanceof List) {
                    setM1ITEMCUSTACCEPTEDFLG(((List<M1ITEMCUSTACCEPTEDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_CUST_ACCEPTED_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ITEMCUSTACCEPTEDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESRV_CAPACITY_LEAD_OPT_FLG":
                if (value instanceof List) {
                    setM1RESRVCAPACITYLEADOPTFLG(((List<M1RESRVCAPACITYLEADOPTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_RESRV_CAPACITY_LEAD_OPT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RESRVCAPACITYLEADOPTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADV_DISPATCH_MODE_FLG":
                if (value instanceof List) {
                    setM1ADVDISPATCHMODEFLG(((List<M1ADVDISPATCHMODEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ADV_DISPATCH_MODE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ADVDISPATCHMODEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIME_WINDOW_SOURCE_FLG":
                if (value instanceof List) {
                    setM1TIMEWINDOWSOURCEFLG(((List<M1TIMEWINDOWSOURCEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TIME_WINDOW_SOURCE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TIMEWINDOWSOURCEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "EXT_SYS_TYP_FLG":
                if (value instanceof List) {
                    setEXTSYSTYPFLG(((List<EXTSYSTYPFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"EXT_SYS_TYP_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.EXTSYSTYPFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "QUEUE_FLG":
                if (value instanceof List) {
                    setQUEUEFLG(((List<QUEUEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"QUEUE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.QUEUEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RT_DST_UNIT_FLG":
                if (value instanceof List) {
                    setM1RTDSTUNITFLG(((List<M1RTDSTUNITFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_RT_DST_UNIT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RTDSTUNITFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OVERRIDE_FAILURE_FLG":
                if (value instanceof List) {
                    setOVERRIDEFAILUREFLG(((List<OVERRIDEFAILUREFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"OVERRIDE_FAILURE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.OVERRIDEFAILUREFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_ITEM_LOAD_CHECK_FLG":
                if (value instanceof List) {
                    setM1DEPOTITEMLOADCHECKFLG(((List<M1DEPOTITEMLOADCHECKFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPOT_ITEM_LOAD_CHECK_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPOTITEMLOADCHECKFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_REQUIRED_FLG":
                if (value instanceof List) {
                    setSTEPREQUIREDFLG(((List<STEPREQUIREDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"STEP_REQUIRED_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.STEPREQUIREDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ALLOW_OVERRIDE_FLG":
                if (value instanceof List) {
                    setALLOWOVERRIDEFLG(((List<ALLOWOVERRIDEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"ALLOW_OVERRIDE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ALLOWOVERRIDEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "APPOINTMENT_FLG":
                if (value instanceof List) {
                    setAPPOINTMENTFLG(((List<APPOINTMENTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"APPOINTMENT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.APPOINTMENTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TAKE_ATTENDANCE_FLG":
                if (value instanceof List) {
                    setTAKEATTENDANCEFLG(((List<TAKEATTENDANCEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"TAKE_ATTENDANCE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.TAKEATTENDANCEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_EARNING_TIME_FLG":
                if (value instanceof List) {
                    setM1ALLOWEARNINGTIMEFLG(((List<M1ALLOWEARNINGTIMEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ALLOW_EARNING_TIME_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ALLOWEARNINGTIMEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESOURCE_OPTION_FLG":
                if (value instanceof List) {
                    setM1RESOURCEOPTIONFLG(((List<M1RESOURCEOPTIONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_RESOURCE_OPTION_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RESOURCEOPTIONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OR_TASK_CAPABILITY_FLG":
                if (value instanceof List) {
                    setM1ORTASKCAPABILITYFLG(((List<M1ORTASKCAPABILITYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_OR_TASK_CAPABILITY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ORTASKCAPABILITYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_CLASS_FLG":
                if (value instanceof List) {
                    setM1ACTIVITYCLASSFLG(((List<M1ACTIVITYCLASSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ACTIVITY_CLASS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ACTIVITYCLASSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MLRD_STATUS_FLG":
                if (value instanceof List) {
                    setM1MLRDSTATUSFLG(((List<M1MLRDSTATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_MLRD_STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MLRDSTATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DAYS_OF_WEEK_FLG":
                if (value instanceof List) {
                    setM1DAYSOFWEEKFLG(((List<M1DAYSOFWEEKFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DAYS_OF_WEEK_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DAYSOFWEEKFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOC_OPT_FLG":
                if (value instanceof List) {
                    setM1LOCOPTFLG(((List<M1LOCOPTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_LOC_OPT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1LOCOPTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_CLASS_FLG":
                if (value instanceof List) {
                    setM1DEPOTCLASSFLG(((List<M1DEPOTCLASSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPOT_CLASS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPOTCLASSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OFFLINE_FLG":
                if (value instanceof List) {
                    setM1OFFLINEFLG(((List<M1OFFLINEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_OFFLINE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1OFFLINEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PRDF_SNDTO_FLG":
                if (value instanceof List) {
                    setM1PRDFSNDTOFLG(((List<M1PRDFSNDTOFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_PRDF_SNDTO_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1PRDFSNDTOFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_BREAKS_FLG":
                if (value instanceof List) {
                    setM1ALLOWBREAKSFLG(((List<M1ALLOWBREAKSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ALLOW_BREAKS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ALLOWBREAKSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_RELATED_ACTIVITIES":
                if (value instanceof List) {
                    setM1ALLOWRELATEDACTIVITIES(((List<M1ALLOWRELATEDACTIVITy> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ALLOW_RELATED_ACTIVITIES\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ALLOWRELATEDACTIVITy>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_ALLOCATION_FLG":
                if (value instanceof List) {
                    setM1AUTOALLOCATIONFLG(((List<M1AUTOALLOCATIONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_AUTO_ALLOCATION_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1AUTOALLOCATIONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REQ_BY_FLG":
                if (value instanceof List) {
                    setM1REQBYFLG(((List<M1REQBYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_REQ_BY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1REQBYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ELIGIBLE_ASSIST_FLG":
                if (value instanceof List) {
                    setM1ELIGIBLEASSISTFLG(((List<M1ELIGIBLEASSISTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ELIGIBLE_ASSIST_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ELIGIBLEASSISTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREATE_BY_CREW_FLG":
                if (value instanceof List) {
                    setM1CREATEBYCREWFLG(((List<M1CREATEBYCREWFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CREATE_BY_CREW_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CREATEBYCREWFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIME_WINDOW_USAGE_FLG":
                if (value instanceof List) {
                    setTIMEWINDOWUSAGEFLG(((List<TIMEWINDOWUSAGEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"TIME_WINDOW_USAGE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.TIMEWINDOWUSAGEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "LOC_TYPE_FLG":
                if (value instanceof List) {
                    setLOCTYPEFLG(((List<LOCTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"LOC_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.LOCTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TRANSFER_TYPE_FLG":
                if (value instanceof List) {
                    setM1TRANSFERTYPEFLG(((List<M1TRANSFERTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TRANSFER_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TRANSFERTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PICKUP_STATUS_FLG":
                if (value instanceof List) {
                    setM1PICKUPSTATUSFLG(((List<M1PICKUPSTATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_PICKUP_STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1PICKUPSTATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_EXTENSION":
                if (value instanceof List) {
                    setM1AUTOEXTENSION(((List<M1AUTOEXTENSION> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_AUTO_EXTENSION\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1AUTOEXTENSION>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DATA_ENCRYPTION_GC_FLG":
                if (value instanceof List) {
                    setM1DATAENCRYPTIONGCFLG(((List<M1DATAENCRYPTIONGCFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DATA_ENCRYPTION_GC_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DATAENCRYPTIONGCFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TRANSPORT_RESTRICTION_FLG":
                if (value instanceof List) {
                    setM1TRANSPORTRESTRICTIONFLG(((List<M1TRANSPORTRESTRICTIONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TRANSPORT_RESTRICTION_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TRANSPORTRESTRICTIONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "GPS_DATA_ENABLED_FLG":
                if (value instanceof List) {
                    setGPSDATAENABLEDFLG(((List<GPSDATAENABLEDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"GPS_DATA_ENABLED_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.GPSDATAENABLEDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESTRICTION_TYPE_FLG":
                if (value instanceof List) {
                    setM1RESTRICTIONTYPEFLG(((List<M1RESTRICTIONTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_RESTRICTION_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RESTRICTIONTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESRV_CAPACITY_BY_FLG":
                if (value instanceof List) {
                    setM1RESRVCAPACITYBYFLG(((List<M1RESRVCAPACITYBYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_RESRV_CAPACITY_BY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RESRVCAPACITYBYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_DELI_DCLN_RSN_FLG":
                if (value instanceof List) {
                    setM1ITEMDELIDCLNRSNFLG(((List<M1ITEMDELIDCLNRSNFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_DELI_DCLN_RSN_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ITEMDELIDCLNRSNFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_STATE_FLG":
                if (value instanceof List) {
                    setPROCEDURESTATEFLG(((List<PROCEDURESTATEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"PROCEDURE_STATE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.PROCEDURESTATEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATUS_REASON_SELECT_FLG":
                if (value instanceof List) {
                    setSTATUSREASONSELECTFLG(((List<STATUSREASONSELECTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"STATUS_REASON_SELECT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.STATUSREASONSELECTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIMING_OPTION_FLG":
                if (value instanceof List) {
                    setM1TIMINGOPTIONFLG(((List<M1TIMINGOPTIONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TIMING_OPTION_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TIMINGOPTIONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RT_DST_UNIT_ABBR_FLG":
                if (value instanceof List) {
                    setM1RTDSTUNITABBRFLG(((List<M1RTDSTUNITABBRFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_RT_DST_UNIT_ABBR_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RTDSTUNITABBRFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_LOAD_STATUS_FLG":
                if (value instanceof List) {
                    setM1ITEMLOADSTATUSFLG(((List<M1ITEMLOADSTATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_LOAD_STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ITEMLOADSTATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "LOG_ENTRY_TYPE_FLG":
                if (value instanceof List) {
                    setLOGENTRYTYPEFLG(((List<LOGENTRYTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"LOG_ENTRY_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.LOGENTRYTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAPACITY_PREFERRED_FLG":
                if (value instanceof List) {
                    setM1CAPACITYPREFERREDFLG(((List<M1CAPACITYPREFERREDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CAPACITY_PREFERRED_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CAPACITYPREFERREDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ACKNOWLEDGEMENT_REQ_FLG":
                if (value instanceof List) {
                    setACKNOWLEDGEMENTREQFLG(((List<ACKNOWLEDGEMENTREQFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"ACKNOWLEDGEMENT_REQ_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ACKNOWLEDGEMENTREQFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_STATE_FLG":
                if (value instanceof List) {
                    setSTEPSTATEFLG(((List<STEPSTATEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"STEP_STATE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.STEPSTATEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DRIP_MODE_FLG":
                if (value instanceof List) {
                    setDRIPMODEFLG(((List<DRIPMODEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"DRIP_MODE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.DRIPMODEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_LOAD_ORDER_FLG":
                if (value instanceof List) {
                    setM1DEPOTTASKLOADORDERFLG(((List<M1DEPOTTASKLOADORDERFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_LOAD_ORDER_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPOTTASKLOADORDERFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTENDED_PROCEDURE_FLG":
                if (value instanceof List) {
                    setATTENDEDPROCEDUREFLG(((List<ATTENDEDPROCEDUREFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"ATTENDED_PROCEDURE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ATTENDEDPROCEDUREFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "VARIABLE_SHIFT_FLG":
                if (value instanceof List) {
                    setVARIABLESHIFTFLG(((List<VARIABLESHIFTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"VARIABLE_SHIFT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.VARIABLESHIFTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "AUTO_DISPATCH_FLG":
                if (value instanceof List) {
                    setAUTODISPATCHFLG(((List<AUTODISPATCHFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"AUTO_DISPATCH_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.AUTODISPATCHFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_COMPLETE_FLG":
                if (value instanceof List) {
                    setM1ACTIVITYCOMPLETEFLG(((List<M1ACTIVITYCOMPLETEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ACTIVITY_COMPLETE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ACTIVITYCOMPLETEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ASIGN_CMPL_RECEIPT_OPT_FLG":
                if (value instanceof List) {
                    setM1ASIGNCMPLRECEIPTOPTFLG(((List<Object> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ASIGN_CMPL_RECEIPT_OPT_FLG\" is of type \"java.util.List<java.lang.Object>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_CUST_ACCEPT_REQ_FLG":
                if (value instanceof List) {
                    setM1ITEMCUSTACCEPTREQFLG(((List<M1ITEMCUSTACCEPTREQFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_CUST_ACCEPT_REQ_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ITEMCUSTACCEPTREQFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_CLEARANCE_REQ_FLG":
                if (value instanceof List) {
                    setPROCEDURECLEARANCEREQFLG(((List<PROCEDURECLEARANCEREQFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"PROCEDURE_CLEARANCE_REQ_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.PROCEDURECLEARANCEREQFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPT_REQ_FLG":
                if (value instanceof List) {
                    setM1APPTREQFLG(((List<M1APPTREQFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_APPT_REQ_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1APPTREQFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TASK_STATUS_FLG":
                if (value instanceof List) {
                    setM1TASKSTATUSFLG(((List<M1TASKSTATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TASK_STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TASKSTATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SAME_CREW_FLG":
                if (value instanceof List) {
                    setM1SAMECREWFLG(((List<M1SAMECREWFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_SAME_CREW_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1SAMECREWFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPENDENCY_RSN_FLG":
                if (value instanceof List) {
                    setM1DEPENDENCYRSNFLG(((List<M1DEPENDENCYRSNFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPENDENCY_RSN_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPENDENCYRSNFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAP_SYS_EVENT_FLG":
                if (value instanceof List) {
                    setM1CAPSYSEVENTFLG(((List<M1CAPSYSEVENTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CAP_SYS_EVENT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CAPSYSEVENTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_CREW_TIME_FLG":
                if (value instanceof List) {
                    setM1ALLOWCREWTIMEFLG(((List<M1ALLOWCREWTIMEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ALLOW_CREW_TIME_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ALLOWCREWTIMEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TASK_CLS_FLG":
                if (value instanceof List) {
                    setTASKCLSFLG(((List<TASKCLSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"TASK_CLS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.TASKCLSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ELGB_CONTRACTING_FLG":
                if (value instanceof List) {
                    setM1ELGBCONTRACTINGFLG(((List<M1ELGBCONTRACTINGFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ELGB_CONTRACTING_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ELGBCONTRACTINGFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FOLDER_FLG":
                if (value instanceof List) {
                    setM1FOLDERFLG(((List<M1FOLDERFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_FOLDER_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1FOLDERFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_CAPACITY_FLG":
                if (value instanceof List) {
                    setM1MAXCAPACITYFLG(((List<M1MAXCAPACITYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_MAX_CAPACITY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MAXCAPACITYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STRICT_TIME_FLG":
                if (value instanceof List) {
                    setM1STRICTTIMEFLG(((List<M1STRICTTIMEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_STRICT_TIME_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1STRICTTIMEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_EXT_LOOKUP_USAGE_FLG":
                if (value instanceof List) {
                    setF1EXTLOOKUPUSAGEFLG(((List<F1EXTLOOKUPUSAGEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"F1_EXT_LOOKUP_USAGE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.F1EXTLOOKUPUSAGEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_NONCUM_CAPACITY_FLG":
                if (value instanceof List) {
                    setM1MAXNONCUMCAPACITYFLG(((List<M1MAXNONCUMCAPACITYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_MAX_NONCUM_CAPACITY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MAXNONCUMCAPACITYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_TM_USG_CLS_FLG":
                if (value instanceof List) {
                    setM1CREWTMUSGCLSFLG(((List<M1CREWTMUSGCLSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CREW_TM_USG_CLS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CREWTMUSGCLSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SHFT_USAGE_FLG":
                if (value instanceof List) {
                    setSHFTUSAGEFLG(((List<SHFTUSAGEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"SHFT_USAGE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.SHFTUSAGEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCHED_OPT_FLG":
                if (value instanceof List) {
                    setM1SCHEDOPTFLG(((List<M1SCHEDOPTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_SCHED_OPT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1SCHEDOPTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TMSHT_OVRD_FLG":
                if (value instanceof List) {
                    setM1TMSHTOVRDFLG(((List<M1TMSHTOVRDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_TMSHT_OVRD_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TMSHTOVRDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATUS_FLG":
                if (value instanceof List) {
                    setSTATUSFLG(((List<STATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.STATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_CANCEL":
                if (value instanceof List) {
                    setM1AUTOCANCEL(((List<M1AUTOCANCEL> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_AUTO_CANCEL\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1AUTOCANCEL>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NONCUM_CAPACITY_FLG":
                if (value instanceof List) {
                    setM1NONCUMCAPACITYFLG(((List<M1NONCUMCAPACITYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_NONCUM_CAPACITY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1NONCUMCAPACITYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ROUND_START_TIME_OPT_FLG":
                if (value instanceof List) {
                    setROUNDSTARTTIMEOPTFLG(((List<ROUNDSTARTTIMEOPTFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"ROUND_START_TIME_OPT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ROUNDSTARTTIMEOPTFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUMULATIVE_CAPACITY_FLG":
                if (value instanceof List) {
                    setM1CUMULATIVECAPACITYFLG(((List<M1CUMULATIVECAPACITYFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CUMULATIVE_CAPACITY_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CUMULATIVECAPACITYFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAIL_MSG_CLS_FLG":
                if (value instanceof List) {
                    setM1MAILMSGCLSFLG(((List<M1MAILMSGCLSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_MAIL_MSG_CLS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1MAILMSGCLSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_RUN_CLOSED_FLG":
                if (value instanceof List) {
                    setM1DEPOTRUNCLOSEDFLG(((List<M1DEPOTRUNCLOSEDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPOT_RUN_CLOSED_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPOTRUNCLOSEDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CLOSEDBY_ADV_DISP_FLG":
                if (value instanceof List) {
                    setM1CLOSEDBYADVDISPFLG(((List<M1CLOSEDBYADVDISPFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CLOSEDBY_ADV_DISP_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CLOSEDBYADVDISPFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SYSTEM_GEN_FLG":
                if (value instanceof List) {
                    setM1SYSTEMGENFLG(((List<M1SYSTEMGENFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_SYSTEM_GEN_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1SYSTEMGENFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPENDENCY_TYPE_FLG":
                if (value instanceof List) {
                    setM1DEPENDENCYTYPEFLG(((List<M1DEPENDENCYTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_DEPENDENCY_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1DEPENDENCYTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FORCE_LOGOFF_REASON_FLG":
                if (value instanceof List) {
                    setM1FORCELOGOFFREASONFLG(((List<M1FORCELOGOFFREASONFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_FORCE_LOGOFF_REASON_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1FORCELOGOFFREASONFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ALLOCATION_RULE_FLG":
                if (value instanceof List) {
                    setALLOCATIONRULEFLG(((List<ALLOCATIONRULEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"ALLOCATION_RULE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ALLOCATIONRULEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVRD_FLG":
                if (value instanceof List) {
                    setM1OVRDFLG(((List<M1OVRDFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_OVRD_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1OVRDFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_LOAD_DCLN_RSN_FLG":
                if (value instanceof List) {
                    setM1ITEMLOADDCLNRSNFLG(((List<Object> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_LOAD_DCLN_RSN_FLG\" is of type \"java.util.List<java.lang.Object>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_IGNORE_SEQ_LOCK_FLG":
                if (value instanceof List) {
                    setM1IGNORESEQLOCKFLG(((List<M1IGNORESEQLOCKFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_IGNORE_SEQ_LOCK_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1IGNORESEQLOCKFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVRD_EXTENSION_LIMIT_FLG":
                if (value instanceof List) {
                    setM1OVRDEXTENSIONLIMITFLG(((List<M1OVRDEXTENSIONLIMITFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_OVRD_EXTENSION_LIMIT_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1OVRDEXTENSIONLIMITFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ANSWER_TYPE_FLG":
                if (value instanceof List) {
                    setANSWERTYPEFLG(((List<ANSWERTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"ANSWER_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.ANSWERTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_DELIVERY_STATUS_FLG":
                if (value instanceof List) {
                    setM1ITEMDELIVERYSTATUSFLG(((List<M1ITEMDELIVERYSTATUSFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ITEM_DELIVERY_STATUS_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ITEMDELIVERYSTATUSFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAP_TYPE_USAGE_FLG":
                if (value instanceof List) {
                    setM1CAPTYPEUSAGEFLG(((List<M1CAPTYPEUSAGEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_CAP_TYPE_USAGE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1CAPTYPEUSAGEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_ATTRIB_USAGE_FLG":
                if (value instanceof List) {
                    setM1ACTIVITYATTRIBUSAGEFLG(((List<M1ACTIVITYATTRIBUSAGEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1_ACTIVITY_ATTRIB_USAGE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1ACTIVITYATTRIBUSAGEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OWNER_FLG":
                if (value instanceof List) {
                    setOWNERFLG(((List<OWNERFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"OWNER_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.OWNERFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RESRC_ID_TYPE_FLG":
                if (value instanceof List) {
                    setRESRCIDTYPEFLG(((List<RESRCIDTYPEFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"RESRC_ID_TYPE_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.RESRCIDTYPEFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OUTMSG_PRIOR_FLG":
                if (value instanceof List) {
                    setOUTMSGPRIORFLG(((List<OUTMSGPRIORFLG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"OUTMSG_PRIOR_FLG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.OUTMSGPRIORFLG>\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "M1_AUTO_COMP_FLG":
                return getM1AUTOCOMPFLG();
            case "M1_COMPLETE_OPTION_FLG":
                return getM1COMPLETEOPTIONFLG();
            case "M1_DELVR_NOW_FLG":
                return getM1DELVRNOWFLG();
            case "M1_DEFERMENT_REASON_FLG":
                return getM1DEFERMENTREASONFLG();
            case "RESRC_CLASS_FLG":
                return getRESRCCLASSFLG();
            case "OVERRIDE_CLEARANCE_FLG":
                return getOVERRIDECLEARANCEFLG();
            case "M1_WINDOW_MODE_FLG":
                return getM1WINDOWMODEFLG();
            case "M1_YES_NO_FLAG":
                return getM1YESNOFLAG();
            case "YES_NO_ANSWER_FLG":
                return getYESNOANSWERFLG();
            case "M1_ITEM_DELIVERY_FLG":
                return getM1ITEMDELIVERYFLG();
            case "M1_DEPOT_ACT_CLASS_FLG":
                return getM1DEPOTACTCLASSFLG();
            case "M1_MDT_OWNED_FLG":
                return getM1MDTOWNEDFLG();
            case "M1_STATUS_REASON_USAGE_FLG":
                return getM1STATUSREASONUSAGEFLG();
            case "MSG_PARM_TYP_FLG":
                return getMSGPARMTYPFLG();
            case "RELATED_ENTITY_FLG":
                return getRELATEDENTITYFLG();
            case "SVC_AREA_USG_FLG":
                return getSVCAREAUSGFLG();
            case "M1_SVC_TYPE_FLG":
                return getM1SVCTYPEFLG();
            case "M1_REVW_ON_DEV_FLG":
                return getM1REVWONDEVFLG();
            case "M1_TMSHEET_CORR_FLG":
                return getM1TMSHEETCORRFLG();
            case "PROCEDURE_STATUS_FLG":
                return getPROCEDURESTATUSFLG();
            case "M1_UNDISPATCH_OPTION_FLG":
                return getM1UNDISPATCHOPTIONFLG();
            case "SVC_CLS_USG_FLG":
                return getSVCCLSUSGFLG();
            case "M1_CHANGE_SEQUENCE_FLG":
                return getM1CHANGESEQUENCEFLG();
            case "M1_ITEM_CUST_ACCEPTED_FLG":
                return getM1ITEMCUSTACCEPTEDFLG();
            case "M1_RESRV_CAPACITY_LEAD_OPT_FLG":
                return getM1RESRVCAPACITYLEADOPTFLG();
            case "M1_ADV_DISPATCH_MODE_FLG":
                return getM1ADVDISPATCHMODEFLG();
            case "M1_TIME_WINDOW_SOURCE_FLG":
                return getM1TIMEWINDOWSOURCEFLG();
            case "EXT_SYS_TYP_FLG":
                return getEXTSYSTYPFLG();
            case "QUEUE_FLG":
                return getQUEUEFLG();
            case "M1_RT_DST_UNIT_FLG":
                return getM1RTDSTUNITFLG();
            case "OVERRIDE_FAILURE_FLG":
                return getOVERRIDEFAILUREFLG();
            case "M1_DEPOT_ITEM_LOAD_CHECK_FLG":
                return getM1DEPOTITEMLOADCHECKFLG();
            case "STEP_REQUIRED_FLG":
                return getSTEPREQUIREDFLG();
            case "ALLOW_OVERRIDE_FLG":
                return getALLOWOVERRIDEFLG();
            case "APPOINTMENT_FLG":
                return getAPPOINTMENTFLG();
            case "TAKE_ATTENDANCE_FLG":
                return getTAKEATTENDANCEFLG();
            case "M1_ALLOW_EARNING_TIME_FLG":
                return getM1ALLOWEARNINGTIMEFLG();
            case "M1_RESOURCE_OPTION_FLG":
                return getM1RESOURCEOPTIONFLG();
            case "M1_OR_TASK_CAPABILITY_FLG":
                return getM1ORTASKCAPABILITYFLG();
            case "M1_ACTIVITY_CLASS_FLG":
                return getM1ACTIVITYCLASSFLG();
            case "M1_MLRD_STATUS_FLG":
                return getM1MLRDSTATUSFLG();
            case "M1_DAYS_OF_WEEK_FLG":
                return getM1DAYSOFWEEKFLG();
            case "M1_LOC_OPT_FLG":
                return getM1LOCOPTFLG();
            case "M1_DEPOT_CLASS_FLG":
                return getM1DEPOTCLASSFLG();
            case "M1_OFFLINE_FLG":
                return getM1OFFLINEFLG();
            case "M1_PRDF_SNDTO_FLG":
                return getM1PRDFSNDTOFLG();
            case "M1_ALLOW_BREAKS_FLG":
                return getM1ALLOWBREAKSFLG();
            case "M1_ALLOW_RELATED_ACTIVITIES":
                return getM1ALLOWRELATEDACTIVITIES();
            case "M1_AUTO_ALLOCATION_FLG":
                return getM1AUTOALLOCATIONFLG();
            case "M1_REQ_BY_FLG":
                return getM1REQBYFLG();
            case "M1_ELIGIBLE_ASSIST_FLG":
                return getM1ELIGIBLEASSISTFLG();
            case "M1_CREATE_BY_CREW_FLG":
                return getM1CREATEBYCREWFLG();
            case "TIME_WINDOW_USAGE_FLG":
                return getTIMEWINDOWUSAGEFLG();
            case "LOC_TYPE_FLG":
                return getLOCTYPEFLG();
            case "M1_TRANSFER_TYPE_FLG":
                return getM1TRANSFERTYPEFLG();
            case "M1_PICKUP_STATUS_FLG":
                return getM1PICKUPSTATUSFLG();
            case "M1_AUTO_EXTENSION":
                return getM1AUTOEXTENSION();
            case "M1_DATA_ENCRYPTION_GC_FLG":
                return getM1DATAENCRYPTIONGCFLG();
            case "M1_TRANSPORT_RESTRICTION_FLG":
                return getM1TRANSPORTRESTRICTIONFLG();
            case "GPS_DATA_ENABLED_FLG":
                return getGPSDATAENABLEDFLG();
            case "M1_RESTRICTION_TYPE_FLG":
                return getM1RESTRICTIONTYPEFLG();
            case "M1_RESRV_CAPACITY_BY_FLG":
                return getM1RESRVCAPACITYBYFLG();
            case "M1_ITEM_DELI_DCLN_RSN_FLG":
                return getM1ITEMDELIDCLNRSNFLG();
            case "PROCEDURE_STATE_FLG":
                return getPROCEDURESTATEFLG();
            case "STATUS_REASON_SELECT_FLG":
                return getSTATUSREASONSELECTFLG();
            case "M1_TIMING_OPTION_FLG":
                return getM1TIMINGOPTIONFLG();
            case "M1_RT_DST_UNIT_ABBR_FLG":
                return getM1RTDSTUNITABBRFLG();
            case "M1_ITEM_LOAD_STATUS_FLG":
                return getM1ITEMLOADSTATUSFLG();
            case "LOG_ENTRY_TYPE_FLG":
                return getLOGENTRYTYPEFLG();
            case "M1_CAPACITY_PREFERRED_FLG":
                return getM1CAPACITYPREFERREDFLG();
            case "ACKNOWLEDGEMENT_REQ_FLG":
                return getACKNOWLEDGEMENTREQFLG();
            case "STEP_STATE_FLG":
                return getSTEPSTATEFLG();
            case "DRIP_MODE_FLG":
                return getDRIPMODEFLG();
            case "M1_DEPOT_TASK_LOAD_ORDER_FLG":
                return getM1DEPOTTASKLOADORDERFLG();
            case "ATTENDED_PROCEDURE_FLG":
                return getATTENDEDPROCEDUREFLG();
            case "VARIABLE_SHIFT_FLG":
                return getVARIABLESHIFTFLG();
            case "AUTO_DISPATCH_FLG":
                return getAUTODISPATCHFLG();
            case "M1_ACTIVITY_COMPLETE_FLG":
                return getM1ACTIVITYCOMPLETEFLG();
            case "M1_ASIGN_CMPL_RECEIPT_OPT_FLG":
                return getM1ASIGNCMPLRECEIPTOPTFLG();
            case "M1_ITEM_CUST_ACCEPT_REQ_FLG":
                return getM1ITEMCUSTACCEPTREQFLG();
            case "PROCEDURE_CLEARANCE_REQ_FLG":
                return getPROCEDURECLEARANCEREQFLG();
            case "M1_APPT_REQ_FLG":
                return getM1APPTREQFLG();
            case "M1_TASK_STATUS_FLG":
                return getM1TASKSTATUSFLG();
            case "M1_SAME_CREW_FLG":
                return getM1SAMECREWFLG();
            case "M1_DEPENDENCY_RSN_FLG":
                return getM1DEPENDENCYRSNFLG();
            case "M1_CAP_SYS_EVENT_FLG":
                return getM1CAPSYSEVENTFLG();
            case "M1_ALLOW_CREW_TIME_FLG":
                return getM1ALLOWCREWTIMEFLG();
            case "TASK_CLS_FLG":
                return getTASKCLSFLG();
            case "M1_ELGB_CONTRACTING_FLG":
                return getM1ELGBCONTRACTINGFLG();
            case "M1_FOLDER_FLG":
                return getM1FOLDERFLG();
            case "M1_MAX_CAPACITY_FLG":
                return getM1MAXCAPACITYFLG();
            case "M1_STRICT_TIME_FLG":
                return getM1STRICTTIMEFLG();
            case "F1_EXT_LOOKUP_USAGE_FLG":
                return getF1EXTLOOKUPUSAGEFLG();
            case "M1_MAX_NONCUM_CAPACITY_FLG":
                return getM1MAXNONCUMCAPACITYFLG();
            case "M1_CREW_TM_USG_CLS_FLG":
                return getM1CREWTMUSGCLSFLG();
            case "SHFT_USAGE_FLG":
                return getSHFTUSAGEFLG();
            case "M1_SCHED_OPT_FLG":
                return getM1SCHEDOPTFLG();
            case "M1_TMSHT_OVRD_FLG":
                return getM1TMSHTOVRDFLG();
            case "STATUS_FLG":
                return getSTATUSFLG();
            case "M1_AUTO_CANCEL":
                return getM1AUTOCANCEL();
            case "M1_NONCUM_CAPACITY_FLG":
                return getM1NONCUMCAPACITYFLG();
            case "ROUND_START_TIME_OPT_FLG":
                return getROUNDSTARTTIMEOPTFLG();
            case "M1_CUMULATIVE_CAPACITY_FLG":
                return getM1CUMULATIVECAPACITYFLG();
            case "M1_MAIL_MSG_CLS_FLG":
                return getM1MAILMSGCLSFLG();
            case "M1_DEPOT_RUN_CLOSED_FLG":
                return getM1DEPOTRUNCLOSEDFLG();
            case "M1_CLOSEDBY_ADV_DISP_FLG":
                return getM1CLOSEDBYADVDISPFLG();
            case "M1_SYSTEM_GEN_FLG":
                return getM1SYSTEMGENFLG();
            case "M1_DEPENDENCY_TYPE_FLG":
                return getM1DEPENDENCYTYPEFLG();
            case "M1_FORCE_LOGOFF_REASON_FLG":
                return getM1FORCELOGOFFREASONFLG();
            case "ALLOCATION_RULE_FLG":
                return getALLOCATIONRULEFLG();
            case "M1_OVRD_FLG":
                return getM1OVRDFLG();
            case "M1_ITEM_LOAD_DCLN_RSN_FLG":
                return getM1ITEMLOADDCLNRSNFLG();
            case "M1_IGNORE_SEQ_LOCK_FLG":
                return getM1IGNORESEQLOCKFLG();
            case "M1_OVRD_EXTENSION_LIMIT_FLG":
                return getM1OVRDEXTENSIONLIMITFLG();
            case "ANSWER_TYPE_FLG":
                return getANSWERTYPEFLG();
            case "M1_ITEM_DELIVERY_STATUS_FLG":
                return getM1ITEMDELIVERYSTATUSFLG();
            case "M1_CAP_TYPE_USAGE_FLG":
                return getM1CAPTYPEUSAGEFLG();
            case "M1_ACTIVITY_ATTRIB_USAGE_FLG":
                return getM1ACTIVITYATTRIBUSAGEFLG();
            case "OWNER_FLG":
                return getOWNERFLG();
            case "RESRC_ID_TYPE_FLG":
                return getRESRCIDTYPEFLG();
            case "OUTMSG_PRIOR_FLG":
                return getOUTMSGPRIORFLG();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, Lookups.NOT_FOUND_VALUE);
        if (Lookups.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

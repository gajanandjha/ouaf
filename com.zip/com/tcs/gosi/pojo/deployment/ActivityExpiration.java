
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "autoExtension",
    "autoCancel"
})
public class ActivityExpiration {

    @JsonProperty("autoExtension")
    private String autoExtension;
    @JsonProperty("autoCancel")
    private String autoCancel;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The autoExtension
     */
    @JsonProperty("autoExtension")
    public String getAutoExtension() {
        return autoExtension;
    }

    /**
     * 
     * @param autoExtension
     *     The autoExtension
     */
    @JsonProperty("autoExtension")
    public void setAutoExtension(String autoExtension) {
        this.autoExtension = autoExtension;
    }

    /**
     * 
     * @return
     *     The autoCancel
     */
    @JsonProperty("autoCancel")
    public String getAutoCancel() {
        return autoCancel;
    }

    /**
     * 
     * @param autoCancel
     *     The autoCancel
     */
    @JsonProperty("autoCancel")
    public void setAutoCancel(String autoCancel) {
        this.autoCancel = autoCancel;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "autoExtension":
                if (value instanceof String) {
                    setAutoExtension(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"autoExtension\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "autoCancel":
                if (value instanceof String) {
                    setAutoCancel(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"autoCancel\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "autoExtension":
                return getAutoExtension();
            case "autoCancel":
                return getAutoCancel();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ActivityExpiration.NOT_FOUND_VALUE);
        if (ActivityExpiration.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

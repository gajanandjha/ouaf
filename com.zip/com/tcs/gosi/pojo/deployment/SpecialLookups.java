
package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "M1-SEVCLS",
    "F1-STSREASON",
    "M1-TIMESHTYP",
    "F1-MSTCFG",
    "COUNTRY",
    "M1-TSKTYP",
    "M1-RMKTYP"
})
public class SpecialLookups {

    @JsonProperty("M1-SEVCLS")
    private List<M1SEVCL> m1SEVCLS = null;
    @JsonProperty("F1-STSREASON")
    private List<F1STSREASON> f1STSREASON = null;
    @JsonProperty("M1-TIMESHTYP")
    private List<M1TIMESHTYP> m1TIMESHTYP = null;
    @JsonProperty("F1-MSTCFG")
    private List<F1MSTCFG> f1MSTCFG = null;
    @JsonProperty("COUNTRY")
    private List<COUNTRY> cOUNTRY = null;
    @JsonProperty("M1-TSKTYP")
    private List<M1TSKTYP> m1TSKTYP = null;
    @JsonProperty("M1-RMKTYP")
    private List<M1RMKTYP> m1RMKTYP = null;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The m1SEVCLS
     */
    @JsonProperty("M1-SEVCLS")
    public List<M1SEVCL> getM1SEVCLS() {
        return m1SEVCLS;
    }

    /**
     * 
     * @param m1SEVCLS
     *     The M1-SEVCLS
     */
    @JsonProperty("M1-SEVCLS")
    public void setM1SEVCLS(List<M1SEVCL> m1SEVCLS) {
        this.m1SEVCLS = m1SEVCLS;
    }

    /**
     * 
     * @return
     *     The f1STSREASON
     */
    @JsonProperty("F1-STSREASON")
    public List<F1STSREASON> getF1STSREASON() {
        return f1STSREASON;
    }

    /**
     * 
     * @param f1STSREASON
     *     The F1-STSREASON
     */
    @JsonProperty("F1-STSREASON")
    public void setF1STSREASON(List<F1STSREASON> f1STSREASON) {
        this.f1STSREASON = f1STSREASON;
    }

    /**
     * 
     * @return
     *     The m1TIMESHTYP
     */
    @JsonProperty("M1-TIMESHTYP")
    public List<M1TIMESHTYP> getM1TIMESHTYP() {
        return m1TIMESHTYP;
    }

    /**
     * 
     * @param m1TIMESHTYP
     *     The M1-TIMESHTYP
     */
    @JsonProperty("M1-TIMESHTYP")
    public void setM1TIMESHTYP(List<M1TIMESHTYP> m1TIMESHTYP) {
        this.m1TIMESHTYP = m1TIMESHTYP;
    }

    /**
     * 
     * @return
     *     The f1MSTCFG
     */
    @JsonProperty("F1-MSTCFG")
    public List<F1MSTCFG> getF1MSTCFG() {
        return f1MSTCFG;
    }

    /**
     * 
     * @param f1MSTCFG
     *     The F1-MSTCFG
     */
    @JsonProperty("F1-MSTCFG")
    public void setF1MSTCFG(List<F1MSTCFG> f1MSTCFG) {
        this.f1MSTCFG = f1MSTCFG;
    }

    /**
     * 
     * @return
     *     The cOUNTRY
     */
    @JsonProperty("COUNTRY")
    public List<COUNTRY> getCOUNTRY() {
        return cOUNTRY;
    }

    /**
     * 
     * @param cOUNTRY
     *     The COUNTRY
     */
    @JsonProperty("COUNTRY")
    public void setCOUNTRY(List<COUNTRY> cOUNTRY) {
        this.cOUNTRY = cOUNTRY;
    }

    /**
     * 
     * @return
     *     The m1TSKTYP
     */
    @JsonProperty("M1-TSKTYP")
    public List<M1TSKTYP> getM1TSKTYP() {
        return m1TSKTYP;
    }

    /**
     * 
     * @param m1TSKTYP
     *     The M1-TSKTYP
     */
    @JsonProperty("M1-TSKTYP")
    public void setM1TSKTYP(List<M1TSKTYP> m1TSKTYP) {
        this.m1TSKTYP = m1TSKTYP;
    }

    /**
     * 
     * @return
     *     The m1RMKTYP
     */
    @JsonProperty("M1-RMKTYP")
    public List<M1RMKTYP> getM1RMKTYP() {
        return m1RMKTYP;
    }

    /**
     * 
     * @param m1RMKTYP
     *     The M1-RMKTYP
     */
    @JsonProperty("M1-RMKTYP")
    public void setM1RMKTYP(List<M1RMKTYP> m1RMKTYP) {
        this.m1RMKTYP = m1RMKTYP;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "M1-SEVCLS":
                if (value instanceof List) {
                    setM1SEVCLS(((List<M1SEVCL> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-SEVCLS\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1SEVCL>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1-STSREASON":
                if (value instanceof List) {
                    setF1STSREASON(((List<F1STSREASON> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"F1-STSREASON\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.F1STSREASON>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-TIMESHTYP":
                if (value instanceof List) {
                    setM1TIMESHTYP(((List<M1TIMESHTYP> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-TIMESHTYP\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TIMESHTYP>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1-MSTCFG":
                if (value instanceof List) {
                    setF1MSTCFG(((List<F1MSTCFG> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"F1-MSTCFG\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.F1MSTCFG>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "COUNTRY":
                if (value instanceof List) {
                    setCOUNTRY(((List<COUNTRY> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"COUNTRY\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.COUNTRY>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-TSKTYP":
                if (value instanceof List) {
                    setM1TSKTYP(((List<M1TSKTYP> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-TSKTYP\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1TSKTYP>\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-RMKTYP":
                if (value instanceof List) {
                    setM1RMKTYP(((List<M1RMKTYP> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"M1-RMKTYP\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.M1RMKTYP>\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "M1-SEVCLS":
                return getM1SEVCLS();
            case "F1-STSREASON":
                return getF1STSREASON();
            case "M1-TIMESHTYP":
                return getM1TIMESHTYP();
            case "F1-MSTCFG":
                return getF1MSTCFG();
            case "COUNTRY":
                return getCOUNTRY();
            case "M1-TSKTYP":
                return getM1TSKTYP();
            case "M1-RMKTYP":
                return getM1RMKTYP();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, SpecialLookups.NOT_FOUND_VALUE);
        if (SpecialLookups.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

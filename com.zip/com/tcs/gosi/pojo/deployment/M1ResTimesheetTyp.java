
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "percentageDeviation",
    "bo",
    "timesheetType",
    "description",
    "version",
    "timesheetBo"
})
public class M1ResTimesheetTyp {

    @JsonProperty("percentageDeviation")
    private String percentageDeviation;
    @JsonProperty("bo")
    private String bo;
    @JsonProperty("timesheetType")
    private String timesheetType;
    @JsonProperty("description")
    private String description;
    @JsonProperty("version")
    private String version;
    @JsonProperty("timesheetBo")
    private String timesheetBo;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The percentageDeviation
     */
    @JsonProperty("percentageDeviation")
    public String getPercentageDeviation() {
        return percentageDeviation;
    }

    /**
     * 
     * @param percentageDeviation
     *     The percentageDeviation
     */
    @JsonProperty("percentageDeviation")
    public void setPercentageDeviation(String percentageDeviation) {
        this.percentageDeviation = percentageDeviation;
    }

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The timesheetType
     */
    @JsonProperty("timesheetType")
    public String getTimesheetType() {
        return timesheetType;
    }

    /**
     * 
     * @param timesheetType
     *     The timesheetType
     */
    @JsonProperty("timesheetType")
    public void setTimesheetType(String timesheetType) {
        this.timesheetType = timesheetType;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * 
     * @return
     *     The timesheetBo
     */
    @JsonProperty("timesheetBo")
    public String getTimesheetBo() {
        return timesheetBo;
    }

    /**
     * 
     * @param timesheetBo
     *     The timesheetBo
     */
    @JsonProperty("timesheetBo")
    public void setTimesheetBo(String timesheetBo) {
        this.timesheetBo = timesheetBo;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "percentageDeviation":
                if (value instanceof String) {
                    setPercentageDeviation(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"percentageDeviation\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "timesheetType":
                if (value instanceof String) {
                    setTimesheetType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"timesheetType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "timesheetBo":
                if (value instanceof String) {
                    setTimesheetBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"timesheetBo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "percentageDeviation":
                return getPercentageDeviation();
            case "bo":
                return getBo();
            case "timesheetType":
                return getTimesheetType();
            case "description":
                return getDescription();
            case "version":
                return getVersion();
            case "timesheetBo":
                return getTimesheetBo();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1ResTimesheetTyp.NOT_FOUND_VALUE);
        if (M1ResTimesheetTyp.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

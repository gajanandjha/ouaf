
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "statesList"
})
public class States {

    @JsonProperty("statesList")
    private StatesList statesList;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The statesList
     */
    @JsonProperty("statesList")
    public StatesList getStatesList() {
        return statesList;
    }

    /**
     * 
     * @param statesList
     *     The statesList
     */
    @JsonProperty("statesList")
    public void setStatesList(StatesList statesList) {
        this.statesList = statesList;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "statesList":
                if (value instanceof StatesList) {
                    setStatesList(((StatesList) value));
                } else {
                    throw new IllegalArgumentException(("property \"statesList\" is of type \"com.tcs.gosi.pojo.deployment.StatesList\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "statesList":
                return getStatesList();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, States.NOT_FOUND_VALUE);
        if (States.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

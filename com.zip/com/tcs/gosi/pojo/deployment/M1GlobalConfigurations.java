
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bo",
    "geographicRoutingParameters",
    "alerts",
    "depot",
    "resourceManagement",
    "mobileApplication",
    "general",
    "version"
})
public class M1GlobalConfigurations {

    @JsonProperty("bo")
    private String bo;
    @JsonProperty("geographicRoutingParameters")
    private GeographicRoutingParameters geographicRoutingParameters;
    @JsonProperty("alerts")
    private Alerts alerts;
    @JsonProperty("depot")
    private Depot depot;
    @JsonProperty("resourceManagement")
    private ResourceManagement resourceManagement;
    @JsonProperty("mobileApplication")
    private MobileApplication mobileApplication;
    @JsonProperty("general")
    private General general;
    @JsonProperty("version")
    private String version;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The geographicRoutingParameters
     */
    @JsonProperty("geographicRoutingParameters")
    public GeographicRoutingParameters getGeographicRoutingParameters() {
        return geographicRoutingParameters;
    }

    /**
     * 
     * @param geographicRoutingParameters
     *     The geographicRoutingParameters
     */
    @JsonProperty("geographicRoutingParameters")
    public void setGeographicRoutingParameters(GeographicRoutingParameters geographicRoutingParameters) {
        this.geographicRoutingParameters = geographicRoutingParameters;
    }

    /**
     * 
     * @return
     *     The alerts
     */
    @JsonProperty("alerts")
    public Alerts getAlerts() {
        return alerts;
    }

    /**
     * 
     * @param alerts
     *     The alerts
     */
    @JsonProperty("alerts")
    public void setAlerts(Alerts alerts) {
        this.alerts = alerts;
    }

    /**
     * 
     * @return
     *     The depot
     */
    @JsonProperty("depot")
    public Depot getDepot() {
        return depot;
    }

    /**
     * 
     * @param depot
     *     The depot
     */
    @JsonProperty("depot")
    public void setDepot(Depot depot) {
        this.depot = depot;
    }

    /**
     * 
     * @return
     *     The resourceManagement
     */
    @JsonProperty("resourceManagement")
    public ResourceManagement getResourceManagement() {
        return resourceManagement;
    }

    /**
     * 
     * @param resourceManagement
     *     The resourceManagement
     */
    @JsonProperty("resourceManagement")
    public void setResourceManagement(ResourceManagement resourceManagement) {
        this.resourceManagement = resourceManagement;
    }

    /**
     * 
     * @return
     *     The mobileApplication
     */
    @JsonProperty("mobileApplication")
    public MobileApplication getMobileApplication() {
        return mobileApplication;
    }

    /**
     * 
     * @param mobileApplication
     *     The mobileApplication
     */
    @JsonProperty("mobileApplication")
    public void setMobileApplication(MobileApplication mobileApplication) {
        this.mobileApplication = mobileApplication;
    }

    /**
     * 
     * @return
     *     The general
     */
    @JsonProperty("general")
    public General getGeneral() {
        return general;
    }

    /**
     * 
     * @param general
     *     The general
     */
    @JsonProperty("general")
    public void setGeneral(General general) {
        this.general = general;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "geographicRoutingParameters":
                if (value instanceof GeographicRoutingParameters) {
                    setGeographicRoutingParameters(((GeographicRoutingParameters) value));
                } else {
                    throw new IllegalArgumentException(("property \"geographicRoutingParameters\" is of type \"com.tcs.gosi.pojo.deployment.GeographicRoutingParameters\", but got "+ value.getClass().toString()));
                }
                return true;
            case "alerts":
                if (value instanceof Alerts) {
                    setAlerts(((Alerts) value));
                } else {
                    throw new IllegalArgumentException(("property \"alerts\" is of type \"com.tcs.gosi.pojo.deployment.Alerts\", but got "+ value.getClass().toString()));
                }
                return true;
            case "depot":
                if (value instanceof Depot) {
                    setDepot(((Depot) value));
                } else {
                    throw new IllegalArgumentException(("property \"depot\" is of type \"com.tcs.gosi.pojo.deployment.Depot\", but got "+ value.getClass().toString()));
                }
                return true;
            case "resourceManagement":
                if (value instanceof ResourceManagement) {
                    setResourceManagement(((ResourceManagement) value));
                } else {
                    throw new IllegalArgumentException(("property \"resourceManagement\" is of type \"com.tcs.gosi.pojo.deployment.ResourceManagement\", but got "+ value.getClass().toString()));
                }
                return true;
            case "mobileApplication":
                if (value instanceof MobileApplication) {
                    setMobileApplication(((MobileApplication) value));
                } else {
                    throw new IllegalArgumentException(("property \"mobileApplication\" is of type \"com.tcs.gosi.pojo.deployment.MobileApplication\", but got "+ value.getClass().toString()));
                }
                return true;
            case "general":
                if (value instanceof General) {
                    setGeneral(((General) value));
                } else {
                    throw new IllegalArgumentException(("property \"general\" is of type \"com.tcs.gosi.pojo.deployment.General\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "bo":
                return getBo();
            case "geographicRoutingParameters":
                return getGeographicRoutingParameters();
            case "alerts":
                return getAlerts();
            case "depot":
                return getDepot();
            case "resourceManagement":
                return getResourceManagement();
            case "mobileApplication":
                return getMobileApplication();
            case "general":
                return getGeneral();
            case "version":
                return getVersion();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1GlobalConfigurations.NOT_FOUND_VALUE);
        if (M1GlobalConfigurations.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

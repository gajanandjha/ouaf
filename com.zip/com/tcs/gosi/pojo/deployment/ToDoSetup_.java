
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "collisionDetectedToDoRole",
    "collisionDetectedToDoType",
    "expirationToDoRole",
    "expirationToDoType",
    "issuesDetectedToDoRole",
    "issuesDetectedToDoType"
})
public class ToDoSetup_ {

    @JsonProperty("collisionDetectedToDoRole")
    private String collisionDetectedToDoRole;
    @JsonProperty("collisionDetectedToDoType")
    private String collisionDetectedToDoType;
    @JsonProperty("expirationToDoRole")
    private String expirationToDoRole;
    @JsonProperty("expirationToDoType")
    private String expirationToDoType;
    @JsonProperty("issuesDetectedToDoRole")
    private String issuesDetectedToDoRole;
    @JsonProperty("issuesDetectedToDoType")
    private String issuesDetectedToDoType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The collisionDetectedToDoRole
     */
    @JsonProperty("collisionDetectedToDoRole")
    public String getCollisionDetectedToDoRole() {
        return collisionDetectedToDoRole;
    }

    /**
     * 
     * @param collisionDetectedToDoRole
     *     The collisionDetectedToDoRole
     */
    @JsonProperty("collisionDetectedToDoRole")
    public void setCollisionDetectedToDoRole(String collisionDetectedToDoRole) {
        this.collisionDetectedToDoRole = collisionDetectedToDoRole;
    }

    /**
     * 
     * @return
     *     The collisionDetectedToDoType
     */
    @JsonProperty("collisionDetectedToDoType")
    public String getCollisionDetectedToDoType() {
        return collisionDetectedToDoType;
    }

    /**
     * 
     * @param collisionDetectedToDoType
     *     The collisionDetectedToDoType
     */
    @JsonProperty("collisionDetectedToDoType")
    public void setCollisionDetectedToDoType(String collisionDetectedToDoType) {
        this.collisionDetectedToDoType = collisionDetectedToDoType;
    }

    /**
     * 
     * @return
     *     The expirationToDoRole
     */
    @JsonProperty("expirationToDoRole")
    public String getExpirationToDoRole() {
        return expirationToDoRole;
    }

    /**
     * 
     * @param expirationToDoRole
     *     The expirationToDoRole
     */
    @JsonProperty("expirationToDoRole")
    public void setExpirationToDoRole(String expirationToDoRole) {
        this.expirationToDoRole = expirationToDoRole;
    }

    /**
     * 
     * @return
     *     The expirationToDoType
     */
    @JsonProperty("expirationToDoType")
    public String getExpirationToDoType() {
        return expirationToDoType;
    }

    /**
     * 
     * @param expirationToDoType
     *     The expirationToDoType
     */
    @JsonProperty("expirationToDoType")
    public void setExpirationToDoType(String expirationToDoType) {
        this.expirationToDoType = expirationToDoType;
    }

    /**
     * 
     * @return
     *     The issuesDetectedToDoRole
     */
    @JsonProperty("issuesDetectedToDoRole")
    public String getIssuesDetectedToDoRole() {
        return issuesDetectedToDoRole;
    }

    /**
     * 
     * @param issuesDetectedToDoRole
     *     The issuesDetectedToDoRole
     */
    @JsonProperty("issuesDetectedToDoRole")
    public void setIssuesDetectedToDoRole(String issuesDetectedToDoRole) {
        this.issuesDetectedToDoRole = issuesDetectedToDoRole;
    }

    /**
     * 
     * @return
     *     The issuesDetectedToDoType
     */
    @JsonProperty("issuesDetectedToDoType")
    public String getIssuesDetectedToDoType() {
        return issuesDetectedToDoType;
    }

    /**
     * 
     * @param issuesDetectedToDoType
     *     The issuesDetectedToDoType
     */
    @JsonProperty("issuesDetectedToDoType")
    public void setIssuesDetectedToDoType(String issuesDetectedToDoType) {
        this.issuesDetectedToDoType = issuesDetectedToDoType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "collisionDetectedToDoRole":
                if (value instanceof String) {
                    setCollisionDetectedToDoRole(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"collisionDetectedToDoRole\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "collisionDetectedToDoType":
                if (value instanceof String) {
                    setCollisionDetectedToDoType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"collisionDetectedToDoType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "expirationToDoRole":
                if (value instanceof String) {
                    setExpirationToDoRole(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"expirationToDoRole\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "expirationToDoType":
                if (value instanceof String) {
                    setExpirationToDoType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"expirationToDoType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "issuesDetectedToDoRole":
                if (value instanceof String) {
                    setIssuesDetectedToDoRole(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"issuesDetectedToDoRole\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "issuesDetectedToDoType":
                if (value instanceof String) {
                    setIssuesDetectedToDoType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"issuesDetectedToDoType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "collisionDetectedToDoRole":
                return getCollisionDetectedToDoRole();
            case "collisionDetectedToDoType":
                return getCollisionDetectedToDoType();
            case "expirationToDoRole":
                return getExpirationToDoRole();
            case "expirationToDoType":
                return getExpirationToDoType();
            case "issuesDetectedToDoRole":
                return getIssuesDetectedToDoRole();
            case "issuesDetectedToDoType":
                return getIssuesDetectedToDoType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ToDoSetup_.NOT_FOUND_VALUE);
        if (ToDoSetup_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

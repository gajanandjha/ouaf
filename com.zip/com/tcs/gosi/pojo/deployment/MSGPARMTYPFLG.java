
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "description",
    "lookupValue"
})
public class MSGPARMTYPFLG {

    @JsonProperty("description")
    private String description;
    @JsonProperty("lookupValue")
    private String lookupValue;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The lookupValue
     */
    @JsonProperty("lookupValue")
    public String getLookupValue() {
        return lookupValue;
    }

    /**
     * 
     * @param lookupValue
     *     The lookupValue
     */
    @JsonProperty("lookupValue")
    public void setLookupValue(String lookupValue) {
        this.lookupValue = lookupValue;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "lookupValue":
                if (value instanceof String) {
                    setLookupValue(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"lookupValue\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "description":
                return getDescription();
            case "lookupValue":
                return getLookupValue();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, MSGPARMTYPFLG.NOT_FOUND_VALUE);
        if (MSGPARMTYPFLG.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

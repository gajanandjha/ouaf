
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "boData",
    "extLookups",
    "characteristicTypes",
    "lookups",
    "labels",
    "attachmentList",
    "specialLookups"
})
public class Content {

    @JsonProperty("boData")
    private BoData boData;
    @JsonProperty("extLookups")
    private ExtLookups extLookups;
    @JsonProperty("characteristicTypes")
    private CharacteristicTypes characteristicTypes;
    @JsonProperty("lookups")
    private Lookups lookups;
    @JsonProperty("labels")
    private Labels labels;
    @JsonProperty("attachmentList")
    private AttachmentList attachmentList;
    @JsonProperty("specialLookups")
    private SpecialLookups specialLookups;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The boData
     */
    @JsonProperty("boData")
    public BoData getBoData() {
        return boData;
    }

    /**
     * 
     * @param boData
     *     The boData
     */
    @JsonProperty("boData")
    public void setBoData(BoData boData) {
        this.boData = boData;
    }

    /**
     * 
     * @return
     *     The extLookups
     */
    @JsonProperty("extLookups")
    public ExtLookups getExtLookups() {
        return extLookups;
    }

    /**
     * 
     * @param extLookups
     *     The extLookups
     */
    @JsonProperty("extLookups")
    public void setExtLookups(ExtLookups extLookups) {
        this.extLookups = extLookups;
    }

    /**
     * 
     * @return
     *     The characteristicTypes
     */
    @JsonProperty("characteristicTypes")
    public CharacteristicTypes getCharacteristicTypes() {
        return characteristicTypes;
    }

    /**
     * 
     * @param characteristicTypes
     *     The characteristicTypes
     */
    @JsonProperty("characteristicTypes")
    public void setCharacteristicTypes(CharacteristicTypes characteristicTypes) {
        this.characteristicTypes = characteristicTypes;
    }

    /**
     * 
     * @return
     *     The lookups
     */
    @JsonProperty("lookups")
    public Lookups getLookups() {
        return lookups;
    }

    /**
     * 
     * @param lookups
     *     The lookups
     */
    @JsonProperty("lookups")
    public void setLookups(Lookups lookups) {
        this.lookups = lookups;
    }

    /**
     * 
     * @return
     *     The labels
     */
    @JsonProperty("labels")
    public Labels getLabels() {
        return labels;
    }

    /**
     * 
     * @param labels
     *     The labels
     */
    @JsonProperty("labels")
    public void setLabels(Labels labels) {
        this.labels = labels;
    }

    /**
     * 
     * @return
     *     The attachmentList
     */
    @JsonProperty("attachmentList")
    public AttachmentList getAttachmentList() {
        return attachmentList;
    }

    /**
     * 
     * @param attachmentList
     *     The attachmentList
     */
    @JsonProperty("attachmentList")
    public void setAttachmentList(AttachmentList attachmentList) {
        this.attachmentList = attachmentList;
    }

    /**
     * 
     * @return
     *     The specialLookups
     */
    @JsonProperty("specialLookups")
    public SpecialLookups getSpecialLookups() {
        return specialLookups;
    }

    /**
     * 
     * @param specialLookups
     *     The specialLookups
     */
    @JsonProperty("specialLookups")
    public void setSpecialLookups(SpecialLookups specialLookups) {
        this.specialLookups = specialLookups;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "boData":
                if (value instanceof BoData) {
                    setBoData(((BoData) value));
                } else {
                    throw new IllegalArgumentException(("property \"boData\" is of type \"com.tcs.gosi.pojo.deployment.BoData\", but got "+ value.getClass().toString()));
                }
                return true;
            case "extLookups":
                if (value instanceof ExtLookups) {
                    setExtLookups(((ExtLookups) value));
                } else {
                    throw new IllegalArgumentException(("property \"extLookups\" is of type \"com.tcs.gosi.pojo.deployment.ExtLookups\", but got "+ value.getClass().toString()));
                }
                return true;
            case "characteristicTypes":
                if (value instanceof CharacteristicTypes) {
                    setCharacteristicTypes(((CharacteristicTypes) value));
                } else {
                    throw new IllegalArgumentException(("property \"characteristicTypes\" is of type \"com.tcs.gosi.pojo.deployment.CharacteristicTypes\", but got "+ value.getClass().toString()));
                }
                return true;
            case "lookups":
                if (value instanceof Lookups) {
                    setLookups(((Lookups) value));
                } else {
                    throw new IllegalArgumentException(("property \"lookups\" is of type \"com.tcs.gosi.pojo.deployment.Lookups\", but got "+ value.getClass().toString()));
                }
                return true;
            case "labels":
                if (value instanceof Labels) {
                    setLabels(((Labels) value));
                } else {
                    throw new IllegalArgumentException(("property \"labels\" is of type \"com.tcs.gosi.pojo.deployment.Labels\", but got "+ value.getClass().toString()));
                }
                return true;
            case "attachmentList":
                if (value instanceof AttachmentList) {
                    setAttachmentList(((AttachmentList) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentList\" is of type \"com.tcs.gosi.pojo.deployment.AttachmentList\", but got "+ value.getClass().toString()));
                }
                return true;
            case "specialLookups":
                if (value instanceof SpecialLookups) {
                    setSpecialLookups(((SpecialLookups) value));
                } else {
                    throw new IllegalArgumentException(("property \"specialLookups\" is of type \"com.tcs.gosi.pojo.deployment.SpecialLookups\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "boData":
                return getBoData();
            case "extLookups":
                return getExtLookups();
            case "characteristicTypes":
                return getCharacteristicTypes();
            case "lookups":
                return getLookups();
            case "labels":
                return getLabels();
            case "attachmentList":
                return getAttachmentList();
            case "specialLookups":
                return getSpecialLookups();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, Content.NOT_FOUND_VALUE);
        if (Content.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "capabilityImage",
    "attachmentBO",
    "capabilitySystemEvent"
})
public class BusinessObjectDataArea {

    @JsonProperty("capabilityImage")
    private String capabilityImage;
    @JsonProperty("attachmentBO")
    private String attachmentBO;
    @JsonProperty("capabilitySystemEvent")
    private String capabilitySystemEvent;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The capabilityImage
     */
    @JsonProperty("capabilityImage")
    public String getCapabilityImage() {
        return capabilityImage;
    }

    /**
     * 
     * @param capabilityImage
     *     The capabilityImage
     */
    @JsonProperty("capabilityImage")
    public void setCapabilityImage(String capabilityImage) {
        this.capabilityImage = capabilityImage;
    }

    /**
     * 
     * @return
     *     The attachmentBO
     */
    @JsonProperty("attachmentBO")
    public String getAttachmentBO() {
        return attachmentBO;
    }

    /**
     * 
     * @param attachmentBO
     *     The attachmentBO
     */
    @JsonProperty("attachmentBO")
    public void setAttachmentBO(String attachmentBO) {
        this.attachmentBO = attachmentBO;
    }

    /**
     * 
     * @return
     *     The capabilitySystemEvent
     */
    @JsonProperty("capabilitySystemEvent")
    public String getCapabilitySystemEvent() {
        return capabilitySystemEvent;
    }

    /**
     * 
     * @param capabilitySystemEvent
     *     The capabilitySystemEvent
     */
    @JsonProperty("capabilitySystemEvent")
    public void setCapabilitySystemEvent(String capabilitySystemEvent) {
        this.capabilitySystemEvent = capabilitySystemEvent;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "capabilityImage":
                if (value instanceof String) {
                    setCapabilityImage(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"capabilityImage\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "attachmentBO":
                if (value instanceof String) {
                    setAttachmentBO(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentBO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "capabilitySystemEvent":
                if (value instanceof String) {
                    setCapabilitySystemEvent(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"capabilitySystemEvent\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "capabilityImage":
                return getCapabilityImage();
            case "attachmentBO":
                return getAttachmentBO();
            case "capabilitySystemEvent":
                return getCapabilitySystemEvent();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, BusinessObjectDataArea.NOT_FOUND_VALUE);
        if (BusinessObjectDataArea.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

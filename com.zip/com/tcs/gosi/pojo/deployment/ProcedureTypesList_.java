
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "seqNum",
    "charType",
    "procedureType"
})
public class ProcedureTypesList_ {

    @JsonProperty("seqNum")
    private String seqNum;
    @JsonProperty("charType")
    private String charType;
    @JsonProperty("procedureType")
    private String procedureType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The seqNum
     */
    @JsonProperty("seqNum")
    public String getSeqNum() {
        return seqNum;
    }

    /**
     * 
     * @param seqNum
     *     The seqNum
     */
    @JsonProperty("seqNum")
    public void setSeqNum(String seqNum) {
        this.seqNum = seqNum;
    }

    /**
     * 
     * @return
     *     The charType
     */
    @JsonProperty("charType")
    public String getCharType() {
        return charType;
    }

    /**
     * 
     * @param charType
     *     The charType
     */
    @JsonProperty("charType")
    public void setCharType(String charType) {
        this.charType = charType;
    }

    /**
     * 
     * @return
     *     The procedureType
     */
    @JsonProperty("procedureType")
    public String getProcedureType() {
        return procedureType;
    }

    /**
     * 
     * @param procedureType
     *     The procedureType
     */
    @JsonProperty("procedureType")
    public void setProcedureType(String procedureType) {
        this.procedureType = procedureType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "seqNum":
                if (value instanceof String) {
                    setSeqNum(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"seqNum\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "charType":
                if (value instanceof String) {
                    setCharType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"charType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "procedureType":
                if (value instanceof String) {
                    setProcedureType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"procedureType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "seqNum":
                return getSeqNum();
            case "charType":
                return getCharType();
            case "procedureType":
                return getProcedureType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ProcedureTypesList_.NOT_FOUND_VALUE);
        if (ProcedureTypesList_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

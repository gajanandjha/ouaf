
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "NUM2_LBL",
    "M1_RELATED_ENTITY_LBL",
    "M1_COMPLETE_OPTION_FLG",
    "M1_PERF_LBL",
    "M1_ATTACHMENT",
    "M1_MAX_STRT_TRVL",
    "TASK_ID",
    "M1_VALID_REMARK_TYPES",
    "ATTACH_LBL",
    "OVERRIDE_CLEARANCE_FLG",
    "ADDRESS2",
    "M1_LOGOFF_LOCATION_TYPE",
    "ADDRESS3",
    "ADDRESS1",
    "M1_WINDOW_MODE_FLG",
    "M1_REVIEWED_LBL",
    "EXT_CAP_TYPE_CD",
    "M1_POUABB_LBL",
    "M1_NUM_OF_EXTENSIONS",
    "M1_STATUS_REASON_USAGE_FLG",
    "M1_COMMON_ATTACHMENT",
    "M1_RESPONSE_TIME_SLA",
    "ADDRESS4",
    "M1_RESRC_NAME",
    "M1_CITY",
    "M1_RESERVE_CAP_PERCENT",
    "M1_POSTPONE_TIME",
    "M1_CRSHT_ROUTE_LBL",
    "M1_TIME_LIMIT",
    "EXT_SYS_TYP_FLG",
    "M1_SCAN_ANY_LBL",
    "M1_RETURNED_LBL",
    "M1_MAX_OFFSET",
    "CHAR_VAL",
    "M1_POSTAL",
    "M1_UPTO_BUS_PRI_VAL",
    "M1_PREVIEW_TASK_LIST_LBL",
    "M1_ALLOW_EARNING_TIME_FLG",
    "ERROR_MSG",
    "SHFT_COPRF_CD",
    "M1_SORT_SEQUENCE",
    "M1_ACTIVITY_COMMENTS",
    "ENROUTE_DTTM",
    "M1_AUTO_ALLOCATION_FLG",
    "TIME_WINDOW_USAGE_FLG",
    "M1_LOGON_LOCATION",
    "M1_MDT_SOUND_DURATION",
    "BUS_OBJ_CD",
    "M1_REMOVE_FROM_SHIFT_LBL",
    "M1_TIMING_OPTION_FLG",
    "M1_COUNTY",
    "ARRD_DTTM",
    "M1_COMPLETION_TM",
    "M1_SEQ_NUM_WRK",
    "M1_STATUSCLASS_AND_SHIFTID",
    "M1_DEPOT_TASK_LOAD_ORDER_FLG",
    "M1_STARTEND_ODOMETER_LBL",
    "STEP_PASS_VALUE",
    "M1_SCHED_PRIORITY",
    "AUTO_DISPATCH_FLG",
    "MESSAGE_NBR",
    "M1_INQUIRY_HISTORY_LBL",
    "M1_SENT_LBL",
    "M1_ACTUAL_COM_DTTM",
    "M1_APPT_REQ_FLG",
    "M1_SOUND_PAUSE",
    "M1_RELATED_PICKUPS_EXIST_SW",
    "M1_AFTER_DURATION",
    "M1_MARK_ALL_AS_LOADED_LBL",
    "M1_NOT_LOADED_LBL",
    "M1_MAX_CAPACITY_FLG",
    "M1_ALERT_SENT_LBL",
    "MDT_CAPABILITY_IMAGE",
    "INSTR",
    "F1_EXT_LOOKUP_USAGE_FLG",
    "COUNTY",
    "M1_POU_TASK_BO",
    "M1_WIND_ST_DTTM",
    "M1_OVERRIDDEN_FLIPSW_LBL",
    "MAIL_ID",
    "M1_PARENT_ASSIGNMENT_ID",
    "M1_FILTER_ITEMS_LBL",
    "ROUND_START_TIME_OPT_FLG",
    "M1_VIEW_ACT_PRCDR_LBL",
    "M1_SAVE_BTN_LBL",
    "M1_FILE_APPENDER_LBL",
    "M1_SITE_INSTRUCTIONS",
    "M1_BRK_WINDOW_DUR",
    "STARTED_DTTM",
    "M1_ACTIVITIES_FOR_DEPOT_LBL",
    "M1_FINALIZED_DTTM",
    "M1_DEPENDENCY_TYPE_FLG",
    "M1_ITEM_COMPLETION_COMMENTS",
    "M1_PANIC_ALERT_COUNT_DOWN",
    "M1_SLA_FLEXIBILITY",
    "M1_SERVER_PROXY_PORT",
    "M1_HIGH_CORR_LIMIT",
    "M1_NO_LBL",
    "M1_IGNORE_SEQ_LOCK_FLG",
    "M1_OVRD_EXTENSION_LIMIT_FLG",
    "M1_GANTT_DISPLAY_ICON_LBL",
    "M1_VEHICLE_TAG",
    "M1_STATE",
    "OWNER_FLG",
    "M1_STOP_BTN_LBL",
    "START_TM",
    "M1_ASSIGNMENT_REMKSEC_LBL",
    "M1_NON_FINAL_SHIFT_WARN_LBL",
    "M1_VEHICLES_LBL",
    "M1_ITEM_PACKAGE_ITEMS",
    "RESRC_CLASS_FLG",
    "M1_NATIVE_MAPS_LBL",
    "M1_NON_PROD_TASK_LBL",
    "M1_RESTRICTION_VALUE",
    "M1_TAKEN_BY",
    "CALENDAR_CD",
    "M1DEPTSK_AN_LBL",
    "ADHOC_CHAR_VAL",
    "M1_DATA_SRC_IND",
    "M1_DEPOT_ACT_CLASS_FLG",
    "M1_ENDS_LBL",
    "M1_LOGGING_LBL",
    "M1_IS_DECLINE_ALLOWED_SW",
    "M1_REVIEW_LBL",
    "M1_MDT_ATTCH_ID",
    "END_DTTM",
    "M1_CREATED_BY_ASSIGNMENT_ID",
    "TIME_ZONE_CD",
    "M1_BRK_CRE_DTTM",
    "CHAR_VAL_FK2",
    "M1_MOBILE_PHONE_NUMBER",
    "CHAR_VAL_FK3",
    "CREW_SHFT_TYPE_CD",
    "CHAR_VAL_FK1",
    "CHAR_VAL_FK4",
    "CHAR_VAL_FK5",
    "M1_APPOINTMENT_WINDOW_LBL",
    "M1_PENDING_DISPATCH_APPROVAL",
    "M1_CAPACITY_CNT_CMPL_LBL",
    "M1_ACTIVITY_TYPE_WORK_CALENDAR",
    "M1_MCP_LAYERS",
    "M1_RT_DST_UNIT_FLG",
    "SHFT_TMPL_ID",
    "SHIFT_DURATION",
    "M1_EFF_DUR_IMPACT",
    "PROCEDURE_STEP_TEXT",
    "M1_PICKUP_SEQUENCE_NUMBER",
    "SVC_AREA_CD",
    "M1_EXTENSION_LIMIT",
    "PROCEDURE_TYPE_CD",
    "M1_REF_DELPOY_LBL",
    "M1_RESOURCE_OPTION_FLG",
    "M1_EXTENSION_DURATION",
    "M1_ADD_BTN_LBL",
    "M1_SEND_MAIL_LBL",
    "M1_OFFLINE_FLG",
    "M1_PRDF_SNDTO_FLG",
    "M1_ACT_CHG_SHFST_LBL",
    "ADDR4_AVAIL",
    "M1_CANCEL_OFFLINE_LBL",
    "ATTACHMENT_NAME_LBL",
    "M1_WARNING_LBL",
    "M1_CREW_TM_USG_CD",
    "M1_CHOOSE_AN_ACTION_LBL",
    "STATUS_RSN_USAGE",
    "M1_REQ_BY_FLG",
    "M1_ADVANCED_DISPATCH_TASKS",
    "M1_EARNING_TIME_CMPL_LBL",
    "FIXED_CREW",
    "M1_TRANSFER_TYPE_FLG",
    "M1_LOGOFF_LOCATION",
    "M1_NOTIFY_HOST_COMPLETION_ONLY",
    "M1_MDT_DEBUG_LBL",
    "M1_BUS_PRI_NBR",
    "DELETE_BTN",
    "M1_ENROUTE_TO_LBL",
    "TIMESHEET_PROCESS_TYPE_CD",
    "M1_TBD_LBL",
    "GPS_DATA_ENABLED_FLG",
    "M1_SMS_CURRENT_TASK_ID",
    "M1_REQUEST_HELP_LBL",
    "M1_ACTIVITY_INFO_LBL",
    "PROCEDURE_STEP_SEQ_NO",
    "M1_WINDOW_COST",
    "M1_RT_PARMS_LBL",
    "M1_TAG",
    "ENTITY_INFORMATION",
    "M1_ADDRESS_CITY",
    "ATTENDED_PROCEDURE_FLG",
    "M1_MAX_FINSH_TRVL",
    "M1_PARENT_TASK_ID",
    "M1_AT_DEPOT_LBL",
    "CUST_NAME",
    "GEO_LONG",
    "STATE_AVAIL",
    "CREATED_BY_LBL",
    "M1_CAC_EXTENSION_HIGH_LIMIT",
    "M1_SAME_CREW_FLG",
    "M1_CAP_SYS_EVENT_FLG",
    "M1_SVC_STATE_LBL",
    "M1_SEND_NOW_LBL",
    "M1_BRK_TYPE",
    "M1_STRICT_TIME_FLG",
    "M1_CAPACITY_VAL",
    "M1_MAP_LBL",
    "M1_CREW_SIZE",
    "M1_TIME_REMAINING",
    "M1_SCHED_OPT_FLG",
    "M1_SHIFT_PROCEDURES_LBL",
    "M1_ORGJB_LBL",
    "M1_PLAN_START_TIME",
    "M1_CALC_TRVL_DIST",
    "M1_LOGON_USER",
    "M1_LOGOFF_DELAY",
    "M1_THEME_D_LBL",
    "M1_FORCED_LOG_OFF_SW",
    "ADJ_DURATION",
    "ATTACHMENT_DATA",
    "M1_WINDOW_DURATION",
    "M1_PROCEDURES_LBL",
    "M1_CAP_TYPE_USAGE_FLG",
    "CITY_AVAIL",
    "SVC_CLS_CD",
    "M1_RESRC_MNGT_LBL",
    "M1_NOTIFY_HOST_OF_DISPATCH",
    "M1_BREAK_TYPE",
    "M1_EMPLOYEE_ID",
    "M1_ELEM_XPATH",
    "M1_OPEN_LBL",
    "NUM1_AVAIL",
    "M1_DURATION_LBL",
    "F1_CONFIRM_DEL_LBL",
    "M1_ALERT_MESSAGE",
    "MDT_CAPABILITY_TYPE",
    "M1_ARR_TM",
    "KEY_LBL",
    "M1_ATTACHMENT_DETAILS_LBL",
    "TRAVEL_TIMESHEET_TYPE",
    "DESCR_OVRD",
    "RELATED_ENTITY_FLG",
    "M1_TASK_LIST_LBL",
    "EXP_DTTM",
    "ATTACHMENT_ID",
    "M1_AUTO_ALLOCATION_DUR",
    "M1_SCHEDULING_INFO_LBL",
    "M1_POU_TYPE",
    "M1_DELIVER_ALL_ITEMS_LBL",
    "M1_ADD_VEHICLE_LBL",
    "DESCRLONG",
    "M1_GPS_RESRC_ID",
    "M1_ML_POU_TASK_LBL",
    "PLAN_END_DTTM",
    "AVG_DUR",
    "M1_RESRV_CAPACITY_LEAD_OPT_FLG",
    "M1_ADV_DISPATCH_MODE_FLG",
    "M1_OFFLINE_BTN_LBL",
    "M1_THEME_B_LBL",
    "M1_RESERVE_CAP_LEAD_TM",
    "M1_COUNTRY",
    "M1_SIGNATURE_LBL",
    "M1_DESC_LBL",
    "M1_DOWNLOAD",
    "BUS_STATUS_DTTM",
    "ALLOW_OVERRIDE_FLG",
    "M1_SENT_MAIL_LBL",
    "M1_START_ODOMTR_LBL",
    "M1_TO_LBL",
    "M1_MDT",
    "DEPOT_TIMESHEET_TYPE",
    "M1_MIN_OFFSET",
    "M1_DEPOT_CLASS_FLG",
    "M1_SHF_DTL_LBL",
    "M1_DEPOT_CD",
    "M1_CALC_TRVL_TM",
    "M1_CREWINQUIRY_LBL",
    "M1_ADD_ANOTHER_BTN_LBL",
    "M1_ITEM_DETAILS_LBL",
    "M1_POSTPONE_DTTM",
    "M1_NETWORK_COMMUNICATION_LBL",
    "M1_FATAL_LBL",
    "M1_APPT_END_DTTM",
    "MOB_LOG_DTTM",
    "M1_CALCADJ_DURATION_LBL",
    "MST_CONFIG_DATA",
    "M1_TARGET_TASK_TYPE",
    "M1_ACTIVITY_TYPE",
    "M1_ADDRESS_4",
    "M1_ADDRESS_2",
    "M1_ADDRESS_3",
    "PROCEDURE_STATE_FLG",
    "M1_ADDRESS_1",
    "EFF_DTTM",
    "M1_USER_ID",
    "F1_FILE_UPLOAD_DTTM",
    "M1_CANCEL_ALERT_ACT_TYPE",
    "M1_TASK_TYPE_FOR_POU",
    "M1_DISCONNECT_THRESHOLD",
    "PROCEDURE_ID",
    "M1_OK_BTN_LBL",
    "M1_TIMED_EVENT_ALERT_LBL",
    "M1_WORK_DURATION",
    "LOCATION_CD",
    "M1_KEY_ID",
    "M1_ASIGN_CMPL_RECEIPT_OPT_FLG",
    "M1_ITEM_PROVIDED_QUANTITY",
    "M1_ADDRESS_LBL",
    "M1_TASK_STATUS_FLG",
    "M1_ALLOW_CREW_TIME_FLG",
    "HOUSE_TYPE_AVAIL",
    "M1_ACT_AFRA_LBL",
    "ADDR1_LBL",
    "SHFT_USAGE_FLG",
    "M1_SYNC_ALERT_THRESHOLD",
    "STATUS_FLG",
    "M1_YES_LBL",
    "M1_NOTIFY_HOST_OF_STATUS",
    "IN_CITY_LIM_LBL",
    "MAN_ALLOC_TO_SHIFT",
    "PARENT_TASK_ALT_ID",
    "DRIP_HORIZON",
    "M1_BACK_BTN_LBL",
    "M1_DEPOT_TASK_ITEM_ID",
    "TSK_TM_WIND_END_DTTM",
    "M1_PLAN_HORIZON",
    "GEO_CODE_LBL",
    "M1_DEPOT_RUN_CLOSED_FLG",
    "M1_FORCE_LOGOFF_REASON_FLG",
    "M1_SCAN_ALL_ITEMS_LBL",
    "CREATE_USER_LBL",
    "ANSWER_TYPE_FLG",
    "MDT_INDICATOR_IMAGE",
    "RESRC_ID",
    "M1_THEME_LBL",
    "M1_SITE_DELAY",
    "M1_SCAN_LBL",
    "M1_ALERT_SOUND",
    "M1_SERVICE_ADDRESS",
    "M1_EARNING_TYPE",
    "M1_CUTOFF_DTTM",
    "FIRST_NAME",
    "ADDR2_AVAIL",
    "PROCEDURE_EXP_DT",
    "M1_VEH_END_ODO_MTR",
    "F1_ATTACHMENT_FILE_SIZE",
    "M1_RANK",
    "CANCEL_LBL",
    "M1_SEND_TO_HOST",
    "ORIG_PLANNED_START_DTTM",
    "M1_ONLINE_LBL",
    "M1_TMSHEET_CORR_FLG",
    "M1_ITEM_QUANTITY",
    "GEO_CODE_AVAIL",
    "M1_SHIFT_ID",
    "M1_STATUS_RSN_LBL",
    "CAP_TYPE_CD",
    "M1_EXPIRATION_TD_TYPE",
    "OVERRIDE_FAILURE_FLG",
    "M1_UPDATE_LBL",
    "STATUS_UPD_DTTM",
    "M1_SENT_FROM_CREW_SHFT",
    "HOST_SYSTEM_CD",
    "ESTIMATED_DURATION",
    "M1_LOC_OPT_FLG",
    "TIMESHEET_TYPE_CD",
    "M1_ACT_CPF_LBL",
    "NUMBER_ANSWER",
    "M1_SVC_CATEGORY_CD",
    "M1_MESSAGES_LBL",
    "F1-ATTACHIDLBL",
    "M1_PREVIEW_BTN_LBL",
    "M1_ELIGIBLE_ASSIST_FLG",
    "START_DTTM",
    "STEP_UPPER_LIMIT",
    "LOGON_MOBILE_PHONE",
    "M1_RESOURCE_LBL",
    "M1_AUTO_EXTENSION",
    "COUNTY_AVAIL",
    "M1_DATA_ENCRYPTION_GC_FLG",
    "M1_CAMERA_LBL",
    "M1_REMOTE_APPENDER_LBL",
    "M1_BREAK_TASK_LBL",
    "BO_STATUS_CD",
    "EXT_OPT_TYPE",
    "M1_SUBURB",
    "M1_ITEM_LOAD_STATUS_FLG",
    "PROCEDURE_COMMENTS",
    "M1_SHIFT_ACTIONS_LBL",
    "M1_CONTACT_NAME",
    "M1_GALLERY_LBL",
    "M1_SYNC_ALERT_TYPE",
    "M1_SCHED_PRIORITY_VAL",
    "M1_LEFT_AT_LBL",
    "M1_LATE_COST",
    "M1_POU_SHIFT_ID",
    "M1_SERVERSYNC",
    "M1_ELGB_CONTRACTING_FLG",
    "BO_DATA_AREA",
    "M1_ACTIVITY_ALTERNATE_ID",
    "WFM_MSG_CD",
    "M1_INBOX_LBL",
    "M1_INFO_LBL",
    "M1_LOADED_LBL",
    "M1_HOST_CHAIN_EXT_ID",
    "M1_CONTR_ELIG_VERSION",
    "M1_MDTOWNED",
    "M1_OVERRIDE_FLIPSW_LBL",
    "M1_PLAN_END_TIME",
    "M1_PRIMARY_FUNCTION",
    "M1_PERSON_ID",
    "M1_MAIL_LBL",
    "CHAR_TYPE_CD",
    "M1_ADVANCED_DISPATCH_OFFSET",
    "ERROR_LBL",
    "M1_CRW_LBL",
    "PK_VALUE2",
    "PK_VALUE1",
    "PK_VALUE4",
    "PK_VALUE3",
    "M1_LOGON_LOCATION_TYPE",
    "PK_VALUE5",
    "M1_VIEW_SHF_PRCDR_LBL",
    "M1_SYSTEM_GEN_FLG",
    "M1_GEOCODE_LATITUDE",
    "M1_ELEM_INDEX",
    "M1_ITEM_DELIVERY_STATUS_FLG",
    "M1_ACTIVITY_LBL",
    "M1_DEPOT_REL_ASSIGNMENT_LBL",
    "M1_DEFERMENT_COMMENTS",
    "M1_CREW_NAME",
    "M1_ACTIVITY_PROCEDURES_LBL",
    "OUTMSG_PRIOR_FLG",
    "M1_AUTO_COMP_FLG",
    "M1_DOWNLOAD_ALL",
    "M1_COLLISION_DETECTED_TODO_TYP",
    "M1_GUAR_DEL_LBL",
    "M1_ADDRESS_COUNTY",
    "M1_DEFERMENT_REASON_FLG",
    "M1_SUBJECT",
    "M1_PANIC_HEADER_LBL",
    "TASK_ALT_ID",
    "SEQ_NUM",
    "M1_LOAD_ALL_ITEMS_LBL",
    "M1_SHOW_MORE_LBL",
    "M1_UPDATED_ETA",
    "M1_RESET_SIGNATURE_LBL",
    "M1_DELIVERED_LBL",
    "M1_REMARK_TYPE",
    "M1_LOCKED_TO_DEPOT_TASK_ID",
    "M1_DEPOT_TASK_BO",
    "M1_SVC_TYPE_FLG",
    "M1_MBL_WKR_LBL",
    "M1_REACH_DEST_LBL",
    "WFM_MSG_CAT_FLG",
    "M1_SENT_BY_MAIL_ID",
    "M1_LOGOFF_BTN_LBL",
    "M1_CHANGE_SEQUENCE_FLG",
    "TSK_TM_WIND_START_DTTM",
    "M1_DEPOT_TASK_TYPE",
    "MDT_INDICATOR_POSITION",
    "M1_RTN_TO_SVC_LBL",
    "M1_OVERTIME_TYPE_EXT_ID",
    "M1_NEW_FUNCTION_LBL",
    "M1_CORRECT_LBL",
    "M1_BREAK_TIME",
    "M1_RTN_SVC_PRPT",
    "M1_MCP_CAPABILITY_TYP_MAIN_LBL",
    "M1_CREWINQUIRY_TYPE",
    "ADDR1_AVAIL",
    "M1_SCAN_NEXT_LBL",
    "OVERRIDE_ALLOCATION_RULE",
    "M1_SECONDS_LBL",
    "MDT_INDICATOR_CODE",
    "M1_ACTIVITY_CLASS_FLG",
    "M1_DURATION",
    "M1_SS_LBL",
    "M1_PROCEDURE_MESSAGE_NBR",
    "M1_ACTUAL_COMPLETION_TIME",
    "F1_EXT_LOOKUP_VALUE",
    "M1_DECLINE_ALL_ITEMS_LBL",
    "M1_POUTASK_ID",
    "M1_ONLINE_BTN_LBL",
    "BO_STATUS_REASON_CD",
    "M1_ACTIVITY_ID",
    "LOC_TYPE_FLG",
    "M1_PICKUP_STATUS_FLG",
    "M1_WARN_LBL",
    "M1_ISSUE_DETECTED_TODO_TYPE",
    "M1_COMPLETED_LBL",
    "M1_HOST_JOB_EXTERNAL_ID",
    "M1_MARK_ALL_AS_UNLOADED_LBL",
    "TOTAL_LBL",
    "BREAK_TIMESHEET_TYPE",
    "M1_PREV_CUTOFF_DTTM",
    "M1_SENDTOCREW",
    "M1_CELL_PHONE",
    "M1_CAPTURE_SIGNATURE_LBL",
    "VERSION",
    "M1_MCP_MARKERS",
    "M1_RVE_TM_WAIT_LBL",
    "M1_ERROR_LBL",
    "M1_COMPLETED_BY_ASSIGNMENT_ID",
    "WFM_OPT_VAL",
    "M1_CAPACITY_PREFERRED_FLG",
    "PARENT_TASK_ID",
    "M1_PRE_TIME_FAC",
    "M1_COMPLEX_ACT_CMPL_LBL",
    "M1_THEME_A_LBL",
    "M1_ATTACHMENT_FILE_NAME",
    "NUM2_AVAIL",
    "GEO_LAT",
    "M1_DOWNLOAD_IN_PROGRESS_LBL",
    "M1_POSTPONE_DTTM_NO_DEFAULT_SW",
    "M1_SND_TO_LBL",
    "M1_HAS_ATTACHMENTS_SW",
    "M1_LEGEND_LBL",
    "M1_TASK_DETAILS_LBL",
    "M1_HH_LBL",
    "M1_COMPOSE_MAIL_LBL",
    "M1_MOBILE_WORKER",
    "TASK_CLS_FLG",
    "PROCEDURE_BUS_OBJ_CD",
    "CALC_DURATION",
    "M1_PANIC_ALERT_TYPE",
    "M1_MDT_SOUND_PAUSE",
    "M1_CUST_CONTACT_TYPE_MAIN_LBL",
    "M1_MAX_NONCUM_CAPACITY_FLG",
    "M1_CREW_TM_USG_CLS_FLG",
    "M1_CAC_EXTENSION_LOW_LIMIT",
    "WFM_NAME",
    "PLAN_START_DTTM",
    "M1_EST_REMAINING_DURATION",
    "M1_TMSHT_OVRD_FLG",
    "M1_INQUIRY_HISTORY",
    "M1_CALC_DURATION",
    "PROCEDURE_EFF_DT",
    "M1_UPLOADED_IMAGES_LBL",
    "M1_ADD_WORKER_LBL",
    "M1_SITE_ID",
    "STATE_LBL",
    "USER_ID",
    "M1_ASSIGNED_ENGINEER",
    "TMSHEET_BO_CD",
    "M1_ACT_CAL_LBL",
    "M1_TIME_REMAINING_AS_OF_DTTM",
    "M1_POSTPONE_UNTIL_LBL",
    "M1_SOUND_DURATION",
    "M1_MDT_TASKLIST_LINE",
    "POSTAL",
    "ADDR2_LBL",
    "M1_CREW_TIME_USAGE_CMPL_LBL",
    "M1_ACTIVITY_TYPE_LBL",
    "M1_MCPME_SCHEDULING_INFO_LBL",
    "M1_LOW_CORR_LIMIT",
    "M1_ARRIVED_ASSIGNMENT_LBL",
    "M1_MM_LBL",
    "M1_DEPOT_ADDRESS",
    "M1_ASSIGNMENT_ID",
    "M1_TIMED_EVENT_EXP_DTTM",
    "M1_QUESTIONNAIRE_LBL",
    "M1_COMMENTS",
    "M1_RESERVE_CAP_MAX_PERCENT",
    "M1_DUR_EXTENSION_LIMIT",
    "YES_NO_ANSWER_FLG",
    "M1_DEPLOYMENT_ID_LBL",
    "M1_SCAN_BARCODE_LBL",
    "TIMESHEET_ID",
    "M1_SYNC_LOG_FILES_LBL",
    "M1_LOAD_INSTR",
    "M1_SUMMARY_LBL",
    "M1_DECLINE_COMMENTS",
    "PK_VAL5",
    "M1_APPROVAL_DTTM_LBL",
    "M1_MAX_LATE",
    "M1_TASKS_LBL",
    "PK_VAL1",
    "PK_VAL2",
    "M1_PENDING_LBL",
    "PK_VAL3",
    "M1_ITEM_CUST_ACCEPTED_FLG",
    "PK_VAL4",
    "CROSS_STREET",
    "M1_OVERRIDE_PRCDR_CLEAR_LBL",
    "POU_ID",
    "M1_CREW_SHFT_LBL",
    "M1_RE_LBL",
    "M1_ACTIVITY_EXP_LBL",
    "M1_FROM_LBL",
    "M1_JOB_ID",
    "CITY_LBL",
    "APPOINTMENT_FLG",
    "M1_ACTIVITY_ATTRIBUTE",
    "M1_LOAD_TASK_BUTTON_LBL",
    "M1_SELECT_THEME_LBL",
    "M1_MORE_ELLIPSIS_LBL",
    "M1_WORK_SEQ_LBL",
    "M1_ACTUAL_START_TIME",
    "M1_SETTINGS_LBL",
    "M1_EXTENSION_DAYS",
    "HOST_TASK_ID",
    "M1_ALLOW_BREAKS_FLG",
    "M1_MCP_INDICATOR_MAIN_LBL",
    "M1_COLLISION_DETECTED_TODO_ROL",
    "M1_CREATE_BY_CREW_FLG",
    "M1_SVC_AREA_USAGE",
    "M1_USED_UNTIL_LBL",
    "M1_CROSS_STREET",
    "M1_ETA_LBL",
    "M1_SERVICE_INSTRUCTIONS",
    "M1_RESTRICTION_TYPE_FLG",
    "M1_SCHEDULING_ORDER",
    "M1_TEMPLATE_SHIFT",
    "STATUS_REASON_SELECT_FLG",
    "M1_AFTER_DAYS",
    "DIRECTIONS_LBL",
    "M1_CUSTOMER_INFO_LBL",
    "DESCR",
    "CREW_SHFT_ID",
    "M1_SEL_PRI_FUNCTION_LBL",
    "M1_ADJUSTED_DURATION",
    "M1_CALC_ERROR_SW",
    "M1_AT_LBL",
    "M1_APPT_ST_DTTM",
    "M1_LOAD_TASK_COMPLETE_LBL",
    "M1_EXT_ENTITY_NAME",
    "M1_DOWNLOADED",
    "M1_DEPOT_INFORMATION_LBL",
    "M1_FOLDER_FLG",
    "POSTAL_AVAIL",
    "M1_MAIL_ID",
    "M1_BRK_DUR",
    "M1_ITEM_BARCODE_TYPE",
    "M1_NPT_LBL",
    "M1_SELECT_ONE_LBL",
    "M1_ITEM_BARCODE",
    "M1_UNACKN_EMERG_ALERT_TYPE",
    "M1-MCPMEPOSTPONED",
    "M1_ITEM_ADDITIONAL_DETAILS",
    "ACCEPT_LBL",
    "WORK_TIMESHEET_TYPE",
    "M1_RECEIVED_LBL",
    "M1_RETURN_ALL_ITEMS_LBL",
    "M1_CUMULATIVE_CAPACITY_FLG",
    "M1_MAIN_PHONE",
    "M1_MAILING_LIST_CD",
    "M1_EARNING_TYPE_EXT_ID",
    "M1_FINAL_DTTM",
    "M1_DEPOT_TASK_ID",
    "M1_POSTPONE_DATE",
    "M1_ACTIVITY_ATTRIB_USAGE_FLG",
    "SEND_BTN_LBL",
    "M1_GEOCODE_LONGITUDE",
    "RESRC_ID_TYPE_FLG",
    "SEQNO",
    "M1_CREATION_DTTM",
    "M1_START_BTN_LBL",
    "M1_NON_PROD_TASK_ID",
    "M1_THEME_C_LBL",
    "M1_ON_SITE_DATE",
    "M1_ALERTS_LBL",
    "M1_REQUIRED_FIELDS_LBL",
    "M1_MIN_VISIT_DURATION",
    "M1_ACTIVITY_TYPE_TODO",
    "M1_NAME",
    "M1_ACCOUNT_ID",
    "ATTACHMENT_FILE_NAME",
    "M1_EXT_ENTITY_VALUE",
    "SVC_AREA_USG_FLG",
    "POU_TIMESHEET_TYPE",
    "PRI_PROF_CD",
    "M1_REVW_ON_DEV_FLG",
    "PROCEDURE_STATUS_FLG",
    "M1_AUTO_ALLOCATION_DAYS",
    "SVC_CLS_USG_FLG",
    "M1_TRAVEL_DISTANCE",
    "M1_CAC_REMAINING_DURATION",
    "M1_COMPLETE_BTN_LBL",
    "M1_GROUP_LBL",
    "STEP_REQUIRED_FLG",
    "M1_CUSTOMER_CONTACT_TYPE_CD",
    "MDT_CAPABILITY_ATTACHMENT_BO",
    "M1_PERCENTAGE_DEVIATION",
    "M1_OR_TASK_CAPABILITY_FLG",
    "M1_ITEM_ATTR_NAME",
    "M1_MLRD_STATUS_FLG",
    "M1_RELATED_ACTIVITY_TYPES",
    "M1_AVG_VISIT_DURATION",
    "M1_CONTRACTOR_ID",
    "M1_GO_OUT_SVC_LBL",
    "M1_DECLINED_LBL",
    "NPT_TIMESHEET_TYPE",
    "M1_ALLOW_RELATED_ACTIVITIES",
    "M1_WINDOW_APPENDER_LBL",
    "DFL_APPT_BOOK_GRP",
    "M1_ISSUE_DETECTED_TODO_ROLE",
    "M1_END_TM",
    "M1_REVIEW_RQD_LBL",
    "M1_ITEM_INFORMATION_LBL",
    "CAP_DTTM",
    "M1_TRANSPORT_RESTRICTION_FLG",
    "MAINT_OBJ_CD",
    "M1_TIMED_EVENT_ALERT_TYPE",
    "POSTAL_LBL",
    "M1_RESRV_CAPACITY_BY_FLG",
    "M1_ITEM_DELI_DCLN_RSN_FLG",
    "M1_START_DAY_OF_WEEK",
    "M1_RT_DST_UNIT_ABBR_FLG",
    "M1_REAL_GPS_THRESHOLD",
    "RESET_LBL",
    "ADDR3_LBL",
    "ACKNOWLEDGEMENT_REQ_FLG",
    "M1_FILE_DESC",
    "M1_COMPLETE_ACT_LBL",
    "M1_RESERVE_CAP_TYPE",
    "BO_STATUS_BO_CD",
    "M1_HOST_PARENT_EXT_ID",
    "M1_RVW_TM_SH_LBL",
    "M1_ITEM_CUST_ACCEPT_REQ_FLG",
    "M1_MDT_LOG_LOC",
    "M1_DEPENDENT_ON",
    "CITY",
    "M1_LOCATION",
    "MESSAGE_CAT_NBR",
    "M1_DECLINE_ACT_LBL",
    "M1_MCPME_CUSTOMER_INFO_LBL",
    "STATE",
    "M1_CREW_ID",
    "M1_ACT_EOS_LBL",
    "M1_ACTUAL_ST_DTTM",
    "M1_DISPATCH_DTTM",
    "M1_TAKEN_DATE",
    "M1_AUTO_CANCEL",
    "M1_EST_OUT_OF_SVC_DUR",
    "M1_MDT_MAP_HOVER_TEXT",
    "MESSAGE_PARM_CNT",
    "M1_BELONGS_TO_PKG_LBL",
    "M1_THEME_ORACLE_LBL",
    "M1_PENDING_CANCEL_SW",
    "TASK_BUS_OBJ_CD",
    "M1_SHIFT_LBL",
    "M1_AVG_DUR",
    "M1_OVERRIDE_DURATION",
    "M1_DEPOT_TASK_ASSIGNMENT_LBL",
    "M1_EMBEDDEDVIEWER",
    "M1_SENT_FROM_USER",
    "ALLOCATION_RULE_FLG",
    "M1_CONSOLE_APPENDER_LBL",
    "M1_LOG_APPENDER_LBL",
    "M1_SEND_NOW_UPDATE_SW",
    "M1_OVRD_FLG",
    "ADDR3_AVAIL",
    "M1_VEH_STRT_ODO_MTR",
    "TEXT_ANSWER",
    "ORIG_PLANNED_END_DTTM",
    "SUBSCRIPTION_ID",
    "M1_COMMENT",
    "M1_DELVR_NOW_FLG",
    "CALC_TRVL_DIST",
    "M1_POU_TASK_TYPE",
    "M1_ASSIGNED_TO_CAPACITY_SW",
    "M1_GENERAL_LBL",
    "M1_REPLY_LBL",
    "M1_CLOSE_BTN_LBL",
    "M1_SERVER_PROXY_HOST",
    "TASK_TYPE_CD",
    "M1_ACTIVITY_BO",
    "TIMESHEET_TM_TYPE_CD",
    "M1_COMPLETE_WITHIN_DAYS",
    "M1_TO_DO_MESSAGE",
    "M1_WORK_PROFILE_CD",
    "MSG_PARM_TYP_FLG",
    "M1_SITE_ADDRESS",
    "MDT_ID",
    "M1_MCPME_ACTIVITY_INFO_LBL",
    "M1_UNDISPATCH_OPTION_FLG",
    "M1_PACKAGE_ITEMS_LBL",
    "M1_WORK_SEQ",
    "HOST_REF_CD",
    "M1_DEPOT_DELAY",
    "M1_TIME_WINDOW_SOURCE_FLG",
    "M1_PREVIEW_SHFT_LBL",
    "M1_MSG_TEXT",
    "QUEUE_FLG",
    "M1_SELECT_LOGLEVEL_LBL",
    "M1_EXPIRATION_TD_ROLE",
    "M1_NUMBER_ACTIVITIES",
    "M1_DEBUG_LBL",
    "M1_SELECT_PICKUP_ACTTYPE_LBL",
    "IN_CITY_LIM_AVAIL",
    "OUTMSG_TYPE_CD",
    "COUNTY_LBL",
    "M1_BREAK_ID",
    "TAKE_ATTENDANCE_FLG",
    "F1_MSG_PARM_VLONG",
    "M1_WORK_BY_DATE",
    "M1_ESTIMATED_DURATION",
    "COUNTRY",
    "STEP_LOWER_LIMIT",
    "M1_CUSTOMER_CONTACT_COMMENTS",
    "M1_OFFLINE_LBL",
    "M1_CONCURRENT_TASK_ID",
    "M1_LOGON_DELAY",
    "M1_MOB_APP_LBL",
    "M1_CONTRACTOR_LBL",
    "M1_ITEM_ATTR_VALUE",
    "M1_NON_PRD_TASK_BO",
    "M1_DELIVERY_COMPLETE",
    "M1_TIMESHEET_LBL",
    "M1_APPENDERS_LBL",
    "M1_BREAK_BO",
    "M1_COMMON_COMPLETION_LBL",
    "M1_CREW_TIM_UGG_DIM_MAIN_LBL",
    "NUM1_LBL",
    "M1_ACT_STE_LBL",
    "M1_TRAVELTIME_DURATION",
    "M1_COMPLETE_WITHIN_TIME",
    "LOG_ENTRY_TYPE_FLG",
    "M1_ATTENDANCE_LBL",
    "ADDR4_LBL",
    "F1_ATTACHMENT_RECORD",
    "M1_DEPOT_TASK_DECLINE_REASON",
    "M1_THEME_E_LBL",
    "DRIP_MODE_FLG",
    "STEP_STATE_FLG",
    "M1_ADD_NEW_LBL",
    "CRE_DTTM",
    "VARIABLE_SHIFT_FLG",
    "M1_ACTIVITY_COMPLETE_FLG",
    "ALL_LBL",
    "M1_UNDELIVERED_LBL",
    "M1_STRT_SHIFT_LBL",
    "M1_ADD_REMARK_TYP_LBL",
    "PROCEDURE_CLEARANCE_REQ_FLG",
    "HOST_EXTERNAL_ID",
    "M1_LIST_LBL",
    "M1_DEPENDENCY_RSN_FLG",
    "SUBURB",
    "M1_DEPOT_LBL",
    "DESCR100",
    "M1_COUNT",
    "M1_LOG_LEVEL_LBL",
    "M1_LIFE_SPAN",
    "M1_CREATED_BY_CREW_SW",
    "M1_NONCUM_CAPACITY_FLG",
    "M1_ACTUAL_ARR_DTTM",
    "M1_CANCEL_CHGS_BTN_LBL",
    "M1_DATA_SENT_AT_DTTM",
    "M1_MAIL_MSG_CLS_FLG",
    "PARM_SEQ",
    "M1_CLOSEDBY_ADV_DISP_FLG",
    "HOUSE_TYPE_LBL",
    "RMK_TYPE_CD",
    "M1_PICKUP_ACTIVITY_LBL",
    "M1_ITEM_LOAD_DCLN_RSN_FLG",
    "M1_RESEND_MAIL_LBL",
    "M1_CONTR_ELIG_ID",
    "M1_END_SHIFT_LBL",
    "M1_RVW_TMSH_DEV_LBL",
    "M1_CUSTOMER_ACCEPTANCE_LBL",
    "M1_KEEP_WITH_CREW_LBL",
    "M1_MEETING_INFORMATION_LBL"
})
public class Labels {

    @JsonProperty("NUM2_LBL")
    private String nUM2LBL;
    @JsonProperty("M1_RELATED_ENTITY_LBL")
    private String m1RELATEDENTITYLBL;
    @JsonProperty("M1_COMPLETE_OPTION_FLG")
    private String m1COMPLETEOPTIONFLG;
    @JsonProperty("M1_PERF_LBL")
    private String m1PERFLBL;
    @JsonProperty("M1_ATTACHMENT")
    private String m1ATTACHMENT;
    @JsonProperty("M1_MAX_STRT_TRVL")
    private String m1MAXSTRTTRVL;
    @JsonProperty("TASK_ID")
    private String tASKID;
    @JsonProperty("M1_VALID_REMARK_TYPES")
    private String m1VALIDREMARKTYPES;
    @JsonProperty("ATTACH_LBL")
    private String aTTACHLBL;
    @JsonProperty("OVERRIDE_CLEARANCE_FLG")
    private String oVERRIDECLEARANCEFLG;
    @JsonProperty("ADDRESS2")
    private String aDDRESS2;
    @JsonProperty("M1_LOGOFF_LOCATION_TYPE")
    private String m1LOGOFFLOCATIONTYPE;
    @JsonProperty("ADDRESS3")
    private String aDDRESS3;
    @JsonProperty("ADDRESS1")
    private String aDDRESS1;
    @JsonProperty("M1_WINDOW_MODE_FLG")
    private String m1WINDOWMODEFLG;
    @JsonProperty("M1_REVIEWED_LBL")
    private String m1REVIEWEDLBL;
    @JsonProperty("EXT_CAP_TYPE_CD")
    private String eXTCAPTYPECD;
    @JsonProperty("M1_POUABB_LBL")
    private String m1POUABBLBL;
    @JsonProperty("M1_NUM_OF_EXTENSIONS")
    private String m1NUMOFEXTENSIONS;
    @JsonProperty("M1_STATUS_REASON_USAGE_FLG")
    private String m1STATUSREASONUSAGEFLG;
    @JsonProperty("M1_COMMON_ATTACHMENT")
    private String m1COMMONATTACHMENT;
    @JsonProperty("M1_RESPONSE_TIME_SLA")
    private String m1RESPONSETIMESLA;
    @JsonProperty("ADDRESS4")
    private String aDDRESS4;
    @JsonProperty("M1_RESRC_NAME")
    private String m1RESRCNAME;
    @JsonProperty("M1_CITY")
    private String m1CITY;
    @JsonProperty("M1_RESERVE_CAP_PERCENT")
    private String m1RESERVECAPPERCENT;
    @JsonProperty("M1_POSTPONE_TIME")
    private String m1POSTPONETIME;
    @JsonProperty("M1_CRSHT_ROUTE_LBL")
    private String m1CRSHTROUTELBL;
    @JsonProperty("M1_TIME_LIMIT")
    private String m1TIMELIMIT;
    @JsonProperty("EXT_SYS_TYP_FLG")
    private String eXTSYSTYPFLG;
    @JsonProperty("M1_SCAN_ANY_LBL")
    private String m1SCANANYLBL;
    @JsonProperty("M1_RETURNED_LBL")
    private String m1RETURNEDLBL;
    @JsonProperty("M1_MAX_OFFSET")
    private String m1MAXOFFSET;
    @JsonProperty("CHAR_VAL")
    private String cHARVAL;
    @JsonProperty("M1_POSTAL")
    private String m1POSTAL;
    @JsonProperty("M1_UPTO_BUS_PRI_VAL")
    private String m1UPTOBUSPRIVAL;
    @JsonProperty("M1_PREVIEW_TASK_LIST_LBL")
    private String m1PREVIEWTASKLISTLBL;
    @JsonProperty("M1_ALLOW_EARNING_TIME_FLG")
    private String m1ALLOWEARNINGTIMEFLG;
    @JsonProperty("ERROR_MSG")
    private String eRRORMSG;
    @JsonProperty("SHFT_COPRF_CD")
    private String sHFTCOPRFCD;
    @JsonProperty("M1_SORT_SEQUENCE")
    private String m1SORTSEQUENCE;
    @JsonProperty("M1_ACTIVITY_COMMENTS")
    private String m1ACTIVITYCOMMENTS;
    @JsonProperty("ENROUTE_DTTM")
    private String eNROUTEDTTM;
    @JsonProperty("M1_AUTO_ALLOCATION_FLG")
    private String m1AUTOALLOCATIONFLG;
    @JsonProperty("TIME_WINDOW_USAGE_FLG")
    private String tIMEWINDOWUSAGEFLG;
    @JsonProperty("M1_LOGON_LOCATION")
    private String m1LOGONLOCATION;
    @JsonProperty("M1_MDT_SOUND_DURATION")
    private String m1MDTSOUNDDURATION;
    @JsonProperty("BUS_OBJ_CD")
    private String bUSOBJCD;
    @JsonProperty("M1_REMOVE_FROM_SHIFT_LBL")
    private String m1REMOVEFROMSHIFTLBL;
    @JsonProperty("M1_TIMING_OPTION_FLG")
    private String m1TIMINGOPTIONFLG;
    @JsonProperty("M1_COUNTY")
    private String m1COUNTY;
    @JsonProperty("ARRD_DTTM")
    private String aRRDDTTM;
    @JsonProperty("M1_COMPLETION_TM")
    private String m1COMPLETIONTM;
    @JsonProperty("M1_SEQ_NUM_WRK")
    private String m1SEQNUMWRK;
    @JsonProperty("M1_STATUSCLASS_AND_SHIFTID")
    private String m1STATUSCLASSANDSHIFTID;
    @JsonProperty("M1_DEPOT_TASK_LOAD_ORDER_FLG")
    private String m1DEPOTTASKLOADORDERFLG;
    @JsonProperty("M1_STARTEND_ODOMETER_LBL")
    private String m1STARTENDODOMETERLBL;
    @JsonProperty("STEP_PASS_VALUE")
    private String sTEPPASSVALUE;
    @JsonProperty("M1_SCHED_PRIORITY")
    private String m1SCHEDPRIORITY;
    @JsonProperty("AUTO_DISPATCH_FLG")
    private String aUTODISPATCHFLG;
    @JsonProperty("MESSAGE_NBR")
    private String mESSAGENBR;
    @JsonProperty("M1_INQUIRY_HISTORY_LBL")
    private String m1INQUIRYHISTORYLBL;
    @JsonProperty("M1_SENT_LBL")
    private String m1SENTLBL;
    @JsonProperty("M1_ACTUAL_COM_DTTM")
    private String m1ACTUALCOMDTTM;
    @JsonProperty("M1_APPT_REQ_FLG")
    private String m1APPTREQFLG;
    @JsonProperty("M1_SOUND_PAUSE")
    private String m1SOUNDPAUSE;
    @JsonProperty("M1_RELATED_PICKUPS_EXIST_SW")
    private String m1RELATEDPICKUPSEXISTSW;
    @JsonProperty("M1_AFTER_DURATION")
    private String m1AFTERDURATION;
    @JsonProperty("M1_MARK_ALL_AS_LOADED_LBL")
    private String m1MARKALLASLOADEDLBL;
    @JsonProperty("M1_NOT_LOADED_LBL")
    private String m1NOTLOADEDLBL;
    @JsonProperty("M1_MAX_CAPACITY_FLG")
    private String m1MAXCAPACITYFLG;
    @JsonProperty("M1_ALERT_SENT_LBL")
    private String m1ALERTSENTLBL;
    @JsonProperty("MDT_CAPABILITY_IMAGE")
    private String mDTCAPABILITYIMAGE;
    @JsonProperty("INSTR")
    private String iNSTR;
    @JsonProperty("F1_EXT_LOOKUP_USAGE_FLG")
    private String f1EXTLOOKUPUSAGEFLG;
    @JsonProperty("COUNTY")
    private String cOUNTY;
    @JsonProperty("M1_POU_TASK_BO")
    private String m1POUTASKBO;
    @JsonProperty("M1_WIND_ST_DTTM")
    private String m1WINDSTDTTM;
    @JsonProperty("M1_OVERRIDDEN_FLIPSW_LBL")
    private String m1OVERRIDDENFLIPSWLBL;
    @JsonProperty("MAIL_ID")
    private String mAILID;
    @JsonProperty("M1_PARENT_ASSIGNMENT_ID")
    private String m1PARENTASSIGNMENTID;
    @JsonProperty("M1_FILTER_ITEMS_LBL")
    private String m1FILTERITEMSLBL;
    @JsonProperty("ROUND_START_TIME_OPT_FLG")
    private String rOUNDSTARTTIMEOPTFLG;
    @JsonProperty("M1_VIEW_ACT_PRCDR_LBL")
    private String m1VIEWACTPRCDRLBL;
    @JsonProperty("M1_SAVE_BTN_LBL")
    private String m1SAVEBTNLBL;
    @JsonProperty("M1_FILE_APPENDER_LBL")
    private String m1FILEAPPENDERLBL;
    @JsonProperty("M1_SITE_INSTRUCTIONS")
    private String m1SITEINSTRUCTIONS;
    @JsonProperty("M1_BRK_WINDOW_DUR")
    private String m1BRKWINDOWDUR;
    @JsonProperty("STARTED_DTTM")
    private String sTARTEDDTTM;
    @JsonProperty("M1_ACTIVITIES_FOR_DEPOT_LBL")
    private String m1ACTIVITIESFORDEPOTLBL;
    @JsonProperty("M1_FINALIZED_DTTM")
    private String m1FINALIZEDDTTM;
    @JsonProperty("M1_DEPENDENCY_TYPE_FLG")
    private String m1DEPENDENCYTYPEFLG;
    @JsonProperty("M1_ITEM_COMPLETION_COMMENTS")
    private String m1ITEMCOMPLETIONCOMMENTS;
    @JsonProperty("M1_PANIC_ALERT_COUNT_DOWN")
    private String m1PANICALERTCOUNTDOWN;
    @JsonProperty("M1_SLA_FLEXIBILITY")
    private String m1SLAFLEXIBILITY;
    @JsonProperty("M1_SERVER_PROXY_PORT")
    private String m1SERVERPROXYPORT;
    @JsonProperty("M1_HIGH_CORR_LIMIT")
    private String m1HIGHCORRLIMIT;
    @JsonProperty("M1_NO_LBL")
    private String m1NOLBL;
    @JsonProperty("M1_IGNORE_SEQ_LOCK_FLG")
    private String m1IGNORESEQLOCKFLG;
    @JsonProperty("M1_OVRD_EXTENSION_LIMIT_FLG")
    private String m1OVRDEXTENSIONLIMITFLG;
    @JsonProperty("M1_GANTT_DISPLAY_ICON_LBL")
    private String m1GANTTDISPLAYICONLBL;
    @JsonProperty("M1_VEHICLE_TAG")
    private String m1VEHICLETAG;
    @JsonProperty("M1_STATE")
    private String m1STATE;
    @JsonProperty("OWNER_FLG")
    private String oWNERFLG;
    @JsonProperty("M1_STOP_BTN_LBL")
    private String m1STOPBTNLBL;
    @JsonProperty("START_TM")
    private String sTARTTM;
    @JsonProperty("M1_ASSIGNMENT_REMKSEC_LBL")
    private String m1ASSIGNMENTREMKSECLBL;
    @JsonProperty("M1_NON_FINAL_SHIFT_WARN_LBL")
    private String m1NONFINALSHIFTWARNLBL;
    @JsonProperty("M1_VEHICLES_LBL")
    private String m1VEHICLESLBL;
    @JsonProperty("M1_ITEM_PACKAGE_ITEMS")
    private String m1ITEMPACKAGEITEMS;
    @JsonProperty("RESRC_CLASS_FLG")
    private String rESRCCLASSFLG;
    @JsonProperty("M1_NATIVE_MAPS_LBL")
    private String m1NATIVEMAPSLBL;
    @JsonProperty("M1_NON_PROD_TASK_LBL")
    private String m1NONPRODTASKLBL;
    @JsonProperty("M1_RESTRICTION_VALUE")
    private String m1RESTRICTIONVALUE;
    @JsonProperty("M1_TAKEN_BY")
    private String m1TAKENBY;
    @JsonProperty("CALENDAR_CD")
    private String cALENDARCD;
    @JsonProperty("M1DEPTSK_AN_LBL")
    private String m1DEPTSKANLBL;
    @JsonProperty("ADHOC_CHAR_VAL")
    private String aDHOCCHARVAL;
    @JsonProperty("M1_DATA_SRC_IND")
    private String m1DATASRCIND;
    @JsonProperty("M1_DEPOT_ACT_CLASS_FLG")
    private String m1DEPOTACTCLASSFLG;
    @JsonProperty("M1_ENDS_LBL")
    private String m1ENDSLBL;
    @JsonProperty("M1_LOGGING_LBL")
    private String m1LOGGINGLBL;
    @JsonProperty("M1_IS_DECLINE_ALLOWED_SW")
    private String m1ISDECLINEALLOWEDSW;
    @JsonProperty("M1_REVIEW_LBL")
    private String m1REVIEWLBL;
    @JsonProperty("M1_MDT_ATTCH_ID")
    private String m1MDTATTCHID;
    @JsonProperty("END_DTTM")
    private String eNDDTTM;
    @JsonProperty("M1_CREATED_BY_ASSIGNMENT_ID")
    private String m1CREATEDBYASSIGNMENTID;
    @JsonProperty("TIME_ZONE_CD")
    private String tIMEZONECD;
    @JsonProperty("M1_BRK_CRE_DTTM")
    private String m1BRKCREDTTM;
    @JsonProperty("CHAR_VAL_FK2")
    private String cHARVALFK2;
    @JsonProperty("M1_MOBILE_PHONE_NUMBER")
    private String m1MOBILEPHONENUMBER;
    @JsonProperty("CHAR_VAL_FK3")
    private String cHARVALFK3;
    @JsonProperty("CREW_SHFT_TYPE_CD")
    private String cREWSHFTTYPECD;
    @JsonProperty("CHAR_VAL_FK1")
    private String cHARVALFK1;
    @JsonProperty("CHAR_VAL_FK4")
    private String cHARVALFK4;
    @JsonProperty("CHAR_VAL_FK5")
    private String cHARVALFK5;
    @JsonProperty("M1_APPOINTMENT_WINDOW_LBL")
    private String m1APPOINTMENTWINDOWLBL;
    @JsonProperty("M1_PENDING_DISPATCH_APPROVAL")
    private String m1PENDINGDISPATCHAPPROVAL;
    @JsonProperty("M1_CAPACITY_CNT_CMPL_LBL")
    private String m1CAPACITYCNTCMPLLBL;
    @JsonProperty("M1_ACTIVITY_TYPE_WORK_CALENDAR")
    private String m1ACTIVITYTYPEWORKCALENDAR;
    @JsonProperty("M1_MCP_LAYERS")
    private String m1MCPLAYERS;
    @JsonProperty("M1_RT_DST_UNIT_FLG")
    private String m1RTDSTUNITFLG;
    @JsonProperty("SHFT_TMPL_ID")
    private String sHFTTMPLID;
    @JsonProperty("SHIFT_DURATION")
    private String sHIFTDURATION;
    @JsonProperty("M1_EFF_DUR_IMPACT")
    private String m1EFFDURIMPACT;
    @JsonProperty("PROCEDURE_STEP_TEXT")
    private String pROCEDURESTEPTEXT;
    @JsonProperty("M1_PICKUP_SEQUENCE_NUMBER")
    private String m1PICKUPSEQUENCENUMBER;
    @JsonProperty("SVC_AREA_CD")
    private String sVCAREACD;
    @JsonProperty("M1_EXTENSION_LIMIT")
    private String m1EXTENSIONLIMIT;
    @JsonProperty("PROCEDURE_TYPE_CD")
    private String pROCEDURETYPECD;
    @JsonProperty("M1_REF_DELPOY_LBL")
    private String m1REFDELPOYLBL;
    @JsonProperty("M1_RESOURCE_OPTION_FLG")
    private String m1RESOURCEOPTIONFLG;
    @JsonProperty("M1_EXTENSION_DURATION")
    private String m1EXTENSIONDURATION;
    @JsonProperty("M1_ADD_BTN_LBL")
    private String m1ADDBTNLBL;
    @JsonProperty("M1_SEND_MAIL_LBL")
    private String m1SENDMAILLBL;
    @JsonProperty("M1_OFFLINE_FLG")
    private String m1OFFLINEFLG;
    @JsonProperty("M1_PRDF_SNDTO_FLG")
    private String m1PRDFSNDTOFLG;
    @JsonProperty("M1_ACT_CHG_SHFST_LBL")
    private String m1ACTCHGSHFSTLBL;
    @JsonProperty("ADDR4_AVAIL")
    private String aDDR4AVAIL;
    @JsonProperty("M1_CANCEL_OFFLINE_LBL")
    private String m1CANCELOFFLINELBL;
    @JsonProperty("ATTACHMENT_NAME_LBL")
    private String aTTACHMENTNAMELBL;
    @JsonProperty("M1_WARNING_LBL")
    private String m1WARNINGLBL;
    @JsonProperty("M1_CREW_TM_USG_CD")
    private String m1CREWTMUSGCD;
    @JsonProperty("M1_CHOOSE_AN_ACTION_LBL")
    private String m1CHOOSEANACTIONLBL;
    @JsonProperty("STATUS_RSN_USAGE")
    private String sTATUSRSNUSAGE;
    @JsonProperty("M1_REQ_BY_FLG")
    private String m1REQBYFLG;
    @JsonProperty("M1_ADVANCED_DISPATCH_TASKS")
    private String m1ADVANCEDDISPATCHTASKS;
    @JsonProperty("M1_EARNING_TIME_CMPL_LBL")
    private String m1EARNINGTIMECMPLLBL;
    @JsonProperty("FIXED_CREW")
    private String fIXEDCREW;
    @JsonProperty("M1_TRANSFER_TYPE_FLG")
    private String m1TRANSFERTYPEFLG;
    @JsonProperty("M1_LOGOFF_LOCATION")
    private String m1LOGOFFLOCATION;
    @JsonProperty("M1_NOTIFY_HOST_COMPLETION_ONLY")
    private String m1NOTIFYHOSTCOMPLETIONONLY;
    @JsonProperty("M1_MDT_DEBUG_LBL")
    private String m1MDTDEBUGLBL;
    @JsonProperty("M1_BUS_PRI_NBR")
    private String m1BUSPRINBR;
    @JsonProperty("DELETE_BTN")
    private String dELETEBTN;
    @JsonProperty("M1_ENROUTE_TO_LBL")
    private String m1ENROUTETOLBL;
    @JsonProperty("TIMESHEET_PROCESS_TYPE_CD")
    private String tIMESHEETPROCESSTYPECD;
    @JsonProperty("M1_TBD_LBL")
    private String m1TBDLBL;
    @JsonProperty("GPS_DATA_ENABLED_FLG")
    private String gPSDATAENABLEDFLG;
    @JsonProperty("M1_SMS_CURRENT_TASK_ID")
    private String m1SMSCURRENTTASKID;
    @JsonProperty("M1_REQUEST_HELP_LBL")
    private String m1REQUESTHELPLBL;
    @JsonProperty("M1_ACTIVITY_INFO_LBL")
    private String m1ACTIVITYINFOLBL;
    @JsonProperty("PROCEDURE_STEP_SEQ_NO")
    private String pROCEDURESTEPSEQNO;
    @JsonProperty("M1_WINDOW_COST")
    private String m1WINDOWCOST;
    @JsonProperty("M1_RT_PARMS_LBL")
    private String m1RTPARMSLBL;
    @JsonProperty("M1_TAG")
    private String m1TAG;
    @JsonProperty("ENTITY_INFORMATION")
    private String eNTITYINFORMATION;
    @JsonProperty("M1_ADDRESS_CITY")
    private String m1ADDRESSCITY;
    @JsonProperty("ATTENDED_PROCEDURE_FLG")
    private String aTTENDEDPROCEDUREFLG;
    @JsonProperty("M1_MAX_FINSH_TRVL")
    private String m1MAXFINSHTRVL;
    @JsonProperty("M1_PARENT_TASK_ID")
    private String m1PARENTTASKID;
    @JsonProperty("M1_AT_DEPOT_LBL")
    private String m1ATDEPOTLBL;
    @JsonProperty("CUST_NAME")
    private String cUSTNAME;
    @JsonProperty("GEO_LONG")
    private String gEOLONG;
    @JsonProperty("STATE_AVAIL")
    private String sTATEAVAIL;
    @JsonProperty("CREATED_BY_LBL")
    private String cREATEDBYLBL;
    @JsonProperty("M1_CAC_EXTENSION_HIGH_LIMIT")
    private String m1CACEXTENSIONHIGHLIMIT;
    @JsonProperty("M1_SAME_CREW_FLG")
    private String m1SAMECREWFLG;
    @JsonProperty("M1_CAP_SYS_EVENT_FLG")
    private String m1CAPSYSEVENTFLG;
    @JsonProperty("M1_SVC_STATE_LBL")
    private String m1SVCSTATELBL;
    @JsonProperty("M1_SEND_NOW_LBL")
    private String m1SENDNOWLBL;
    @JsonProperty("M1_BRK_TYPE")
    private String m1BRKTYPE;
    @JsonProperty("M1_STRICT_TIME_FLG")
    private String m1STRICTTIMEFLG;
    @JsonProperty("M1_CAPACITY_VAL")
    private String m1CAPACITYVAL;
    @JsonProperty("M1_MAP_LBL")
    private String m1MAPLBL;
    @JsonProperty("M1_CREW_SIZE")
    private String m1CREWSIZE;
    @JsonProperty("M1_TIME_REMAINING")
    private String m1TIMEREMAINING;
    @JsonProperty("M1_SCHED_OPT_FLG")
    private String m1SCHEDOPTFLG;
    @JsonProperty("M1_SHIFT_PROCEDURES_LBL")
    private String m1SHIFTPROCEDURESLBL;
    @JsonProperty("M1_ORGJB_LBL")
    private String m1ORGJBLBL;
    @JsonProperty("M1_PLAN_START_TIME")
    private String m1PLANSTARTTIME;
    @JsonProperty("M1_CALC_TRVL_DIST")
    private String m1CALCTRVLDIST;
    @JsonProperty("M1_LOGON_USER")
    private String m1LOGONUSER;
    @JsonProperty("M1_LOGOFF_DELAY")
    private String m1LOGOFFDELAY;
    @JsonProperty("M1_THEME_D_LBL")
    private String m1THEMEDLBL;
    @JsonProperty("M1_FORCED_LOG_OFF_SW")
    private String m1FORCEDLOGOFFSW;
    @JsonProperty("ADJ_DURATION")
    private String aDJDURATION;
    @JsonProperty("ATTACHMENT_DATA")
    private String aTTACHMENTDATA;
    @JsonProperty("M1_WINDOW_DURATION")
    private String m1WINDOWDURATION;
    @JsonProperty("M1_PROCEDURES_LBL")
    private String m1PROCEDURESLBL;
    @JsonProperty("M1_CAP_TYPE_USAGE_FLG")
    private String m1CAPTYPEUSAGEFLG;
    @JsonProperty("CITY_AVAIL")
    private String cITYAVAIL;
    @JsonProperty("SVC_CLS_CD")
    private String sVCCLSCD;
    @JsonProperty("M1_RESRC_MNGT_LBL")
    private String m1RESRCMNGTLBL;
    @JsonProperty("M1_NOTIFY_HOST_OF_DISPATCH")
    private String m1NOTIFYHOSTOFDISPATCH;
    @JsonProperty("M1_BREAK_TYPE")
    private String m1BREAKTYPE;
    @JsonProperty("M1_EMPLOYEE_ID")
    private String m1EMPLOYEEID;
    @JsonProperty("M1_ELEM_XPATH")
    private String m1ELEMXPATH;
    @JsonProperty("M1_OPEN_LBL")
    private String m1OPENLBL;
    @JsonProperty("NUM1_AVAIL")
    private String nUM1AVAIL;
    @JsonProperty("M1_DURATION_LBL")
    private String m1DURATIONLBL;
    @JsonProperty("F1_CONFIRM_DEL_LBL")
    private String f1CONFIRMDELLBL;
    @JsonProperty("M1_ALERT_MESSAGE")
    private String m1ALERTMESSAGE;
    @JsonProperty("MDT_CAPABILITY_TYPE")
    private String mDTCAPABILITYTYPE;
    @JsonProperty("M1_ARR_TM")
    private String m1ARRTM;
    @JsonProperty("KEY_LBL")
    private String kEYLBL;
    @JsonProperty("M1_ATTACHMENT_DETAILS_LBL")
    private String m1ATTACHMENTDETAILSLBL;
    @JsonProperty("TRAVEL_TIMESHEET_TYPE")
    private String tRAVELTIMESHEETTYPE;
    @JsonProperty("DESCR_OVRD")
    private String dESCROVRD;
    @JsonProperty("RELATED_ENTITY_FLG")
    private String rELATEDENTITYFLG;
    @JsonProperty("M1_TASK_LIST_LBL")
    private String m1TASKLISTLBL;
    @JsonProperty("EXP_DTTM")
    private String eXPDTTM;
    @JsonProperty("ATTACHMENT_ID")
    private String aTTACHMENTID;
    @JsonProperty("M1_AUTO_ALLOCATION_DUR")
    private String m1AUTOALLOCATIONDUR;
    @JsonProperty("M1_SCHEDULING_INFO_LBL")
    private String m1SCHEDULINGINFOLBL;
    @JsonProperty("M1_POU_TYPE")
    private String m1POUTYPE;
    @JsonProperty("M1_DELIVER_ALL_ITEMS_LBL")
    private String m1DELIVERALLITEMSLBL;
    @JsonProperty("M1_ADD_VEHICLE_LBL")
    private String m1ADDVEHICLELBL;
    @JsonProperty("DESCRLONG")
    private String dESCRLONG;
    @JsonProperty("M1_GPS_RESRC_ID")
    private String m1GPSRESRCID;
    @JsonProperty("M1_ML_POU_TASK_LBL")
    private String m1MLPOUTASKLBL;
    @JsonProperty("PLAN_END_DTTM")
    private String pLANENDDTTM;
    @JsonProperty("AVG_DUR")
    private String aVGDUR;
    @JsonProperty("M1_RESRV_CAPACITY_LEAD_OPT_FLG")
    private String m1RESRVCAPACITYLEADOPTFLG;
    @JsonProperty("M1_ADV_DISPATCH_MODE_FLG")
    private String m1ADVDISPATCHMODEFLG;
    @JsonProperty("M1_OFFLINE_BTN_LBL")
    private String m1OFFLINEBTNLBL;
    @JsonProperty("M1_THEME_B_LBL")
    private String m1THEMEBLBL;
    @JsonProperty("M1_RESERVE_CAP_LEAD_TM")
    private String m1RESERVECAPLEADTM;
    @JsonProperty("M1_COUNTRY")
    private String m1COUNTRY;
    @JsonProperty("M1_SIGNATURE_LBL")
    private String m1SIGNATURELBL;
    @JsonProperty("M1_DESC_LBL")
    private String m1DESCLBL;
    @JsonProperty("M1_DOWNLOAD")
    private String m1DOWNLOAD;
    @JsonProperty("BUS_STATUS_DTTM")
    private String bUSSTATUSDTTM;
    @JsonProperty("ALLOW_OVERRIDE_FLG")
    private String aLLOWOVERRIDEFLG;
    @JsonProperty("M1_SENT_MAIL_LBL")
    private String m1SENTMAILLBL;
    @JsonProperty("M1_START_ODOMTR_LBL")
    private String m1STARTODOMTRLBL;
    @JsonProperty("M1_TO_LBL")
    private String m1TOLBL;
    @JsonProperty("M1_MDT")
    private String m1MDT;
    @JsonProperty("DEPOT_TIMESHEET_TYPE")
    private String dEPOTTIMESHEETTYPE;
    @JsonProperty("M1_MIN_OFFSET")
    private String m1MINOFFSET;
    @JsonProperty("M1_DEPOT_CLASS_FLG")
    private String m1DEPOTCLASSFLG;
    @JsonProperty("M1_SHF_DTL_LBL")
    private String m1SHFDTLLBL;
    @JsonProperty("M1_DEPOT_CD")
    private String m1DEPOTCD;
    @JsonProperty("M1_CALC_TRVL_TM")
    private String m1CALCTRVLTM;
    @JsonProperty("M1_CREWINQUIRY_LBL")
    private String m1CREWINQUIRYLBL;
    @JsonProperty("M1_ADD_ANOTHER_BTN_LBL")
    private String m1ADDANOTHERBTNLBL;
    @JsonProperty("M1_ITEM_DETAILS_LBL")
    private String m1ITEMDETAILSLBL;
    @JsonProperty("M1_POSTPONE_DTTM")
    private String m1POSTPONEDTTM;
    @JsonProperty("M1_NETWORK_COMMUNICATION_LBL")
    private String m1NETWORKCOMMUNICATIONLBL;
    @JsonProperty("M1_FATAL_LBL")
    private String m1FATALLBL;
    @JsonProperty("M1_APPT_END_DTTM")
    private String m1APPTENDDTTM;
    @JsonProperty("MOB_LOG_DTTM")
    private String mOBLOGDTTM;
    @JsonProperty("M1_CALCADJ_DURATION_LBL")
    private String m1CALCADJDURATIONLBL;
    @JsonProperty("MST_CONFIG_DATA")
    private String mSTCONFIGDATA;
    @JsonProperty("M1_TARGET_TASK_TYPE")
    private String m1TARGETTASKTYPE;
    @JsonProperty("M1_ACTIVITY_TYPE")
    private String m1ACTIVITYTYPE;
    @JsonProperty("M1_ADDRESS_4")
    private String m1ADDRESS4;
    @JsonProperty("M1_ADDRESS_2")
    private String m1ADDRESS2;
    @JsonProperty("M1_ADDRESS_3")
    private String m1ADDRESS3;
    @JsonProperty("PROCEDURE_STATE_FLG")
    private String pROCEDURESTATEFLG;
    @JsonProperty("M1_ADDRESS_1")
    private String m1ADDRESS1;
    @JsonProperty("EFF_DTTM")
    private String eFFDTTM;
    @JsonProperty("M1_USER_ID")
    private String m1USERID;
    @JsonProperty("F1_FILE_UPLOAD_DTTM")
    private String f1FILEUPLOADDTTM;
    @JsonProperty("M1_CANCEL_ALERT_ACT_TYPE")
    private String m1CANCELALERTACTTYPE;
    @JsonProperty("M1_TASK_TYPE_FOR_POU")
    private String m1TASKTYPEFORPOU;
    @JsonProperty("M1_DISCONNECT_THRESHOLD")
    private String m1DISCONNECTTHRESHOLD;
    @JsonProperty("PROCEDURE_ID")
    private String pROCEDUREID;
    @JsonProperty("M1_OK_BTN_LBL")
    private String m1OKBTNLBL;
    @JsonProperty("M1_TIMED_EVENT_ALERT_LBL")
    private String m1TIMEDEVENTALERTLBL;
    @JsonProperty("M1_WORK_DURATION")
    private String m1WORKDURATION;
    @JsonProperty("LOCATION_CD")
    private String lOCATIONCD;
    @JsonProperty("M1_KEY_ID")
    private String m1KEYID;
    @JsonProperty("M1_ASIGN_CMPL_RECEIPT_OPT_FLG")
    private String m1ASIGNCMPLRECEIPTOPTFLG;
    @JsonProperty("M1_ITEM_PROVIDED_QUANTITY")
    private String m1ITEMPROVIDEDQUANTITY;
    @JsonProperty("M1_ADDRESS_LBL")
    private String m1ADDRESSLBL;
    @JsonProperty("M1_TASK_STATUS_FLG")
    private String m1TASKSTATUSFLG;
    @JsonProperty("M1_ALLOW_CREW_TIME_FLG")
    private String m1ALLOWCREWTIMEFLG;
    @JsonProperty("HOUSE_TYPE_AVAIL")
    private String hOUSETYPEAVAIL;
    @JsonProperty("M1_ACT_AFRA_LBL")
    private String m1ACTAFRALBL;
    @JsonProperty("ADDR1_LBL")
    private String aDDR1LBL;
    @JsonProperty("SHFT_USAGE_FLG")
    private String sHFTUSAGEFLG;
    @JsonProperty("M1_SYNC_ALERT_THRESHOLD")
    private String m1SYNCALERTTHRESHOLD;
    @JsonProperty("STATUS_FLG")
    private String sTATUSFLG;
    @JsonProperty("M1_YES_LBL")
    private String m1YESLBL;
    @JsonProperty("M1_NOTIFY_HOST_OF_STATUS")
    private String m1NOTIFYHOSTOFSTATUS;
    @JsonProperty("IN_CITY_LIM_LBL")
    private String iNCITYLIMLBL;
    @JsonProperty("MAN_ALLOC_TO_SHIFT")
    private String mANALLOCTOSHIFT;
    @JsonProperty("PARENT_TASK_ALT_ID")
    private String pARENTTASKALTID;
    @JsonProperty("DRIP_HORIZON")
    private String dRIPHORIZON;
    @JsonProperty("M1_BACK_BTN_LBL")
    private String m1BACKBTNLBL;
    @JsonProperty("M1_DEPOT_TASK_ITEM_ID")
    private String m1DEPOTTASKITEMID;
    @JsonProperty("TSK_TM_WIND_END_DTTM")
    private String tSKTMWINDENDDTTM;
    @JsonProperty("M1_PLAN_HORIZON")
    private String m1PLANHORIZON;
    @JsonProperty("GEO_CODE_LBL")
    private String gEOCODELBL;
    @JsonProperty("M1_DEPOT_RUN_CLOSED_FLG")
    private String m1DEPOTRUNCLOSEDFLG;
    @JsonProperty("M1_FORCE_LOGOFF_REASON_FLG")
    private String m1FORCELOGOFFREASONFLG;
    @JsonProperty("M1_SCAN_ALL_ITEMS_LBL")
    private String m1SCANALLITEMSLBL;
    @JsonProperty("CREATE_USER_LBL")
    private String cREATEUSERLBL;
    @JsonProperty("ANSWER_TYPE_FLG")
    private String aNSWERTYPEFLG;
    @JsonProperty("MDT_INDICATOR_IMAGE")
    private String mDTINDICATORIMAGE;
    @JsonProperty("RESRC_ID")
    private String rESRCID;
    @JsonProperty("M1_THEME_LBL")
    private String m1THEMELBL;
    @JsonProperty("M1_SITE_DELAY")
    private String m1SITEDELAY;
    @JsonProperty("M1_SCAN_LBL")
    private String m1SCANLBL;
    @JsonProperty("M1_ALERT_SOUND")
    private String m1ALERTSOUND;
    @JsonProperty("M1_SERVICE_ADDRESS")
    private String m1SERVICEADDRESS;
    @JsonProperty("M1_EARNING_TYPE")
    private String m1EARNINGTYPE;
    @JsonProperty("M1_CUTOFF_DTTM")
    private String m1CUTOFFDTTM;
    @JsonProperty("FIRST_NAME")
    private String fIRSTNAME;
    @JsonProperty("ADDR2_AVAIL")
    private String aDDR2AVAIL;
    @JsonProperty("PROCEDURE_EXP_DT")
    private String pROCEDUREEXPDT;
    @JsonProperty("M1_VEH_END_ODO_MTR")
    private String m1VEHENDODOMTR;
    @JsonProperty("F1_ATTACHMENT_FILE_SIZE")
    private String f1ATTACHMENTFILESIZE;
    @JsonProperty("M1_RANK")
    private String m1RANK;
    @JsonProperty("CANCEL_LBL")
    private String cANCELLBL;
    @JsonProperty("M1_SEND_TO_HOST")
    private String m1SENDTOHOST;
    @JsonProperty("ORIG_PLANNED_START_DTTM")
    private String oRIGPLANNEDSTARTDTTM;
    @JsonProperty("M1_ONLINE_LBL")
    private String m1ONLINELBL;
    @JsonProperty("M1_TMSHEET_CORR_FLG")
    private String m1TMSHEETCORRFLG;
    @JsonProperty("M1_ITEM_QUANTITY")
    private String m1ITEMQUANTITY;
    @JsonProperty("GEO_CODE_AVAIL")
    private String gEOCODEAVAIL;
    @JsonProperty("M1_SHIFT_ID")
    private String m1SHIFTID;
    @JsonProperty("M1_STATUS_RSN_LBL")
    private String m1STATUSRSNLBL;
    @JsonProperty("CAP_TYPE_CD")
    private String cAPTYPECD;
    @JsonProperty("M1_EXPIRATION_TD_TYPE")
    private String m1EXPIRATIONTDTYPE;
    @JsonProperty("OVERRIDE_FAILURE_FLG")
    private String oVERRIDEFAILUREFLG;
    @JsonProperty("M1_UPDATE_LBL")
    private String m1UPDATELBL;
    @JsonProperty("STATUS_UPD_DTTM")
    private String sTATUSUPDDTTM;
    @JsonProperty("M1_SENT_FROM_CREW_SHFT")
    private String m1SENTFROMCREWSHFT;
    @JsonProperty("HOST_SYSTEM_CD")
    private String hOSTSYSTEMCD;
    @JsonProperty("ESTIMATED_DURATION")
    private String eSTIMATEDDURATION;
    @JsonProperty("M1_LOC_OPT_FLG")
    private String m1LOCOPTFLG;
    @JsonProperty("TIMESHEET_TYPE_CD")
    private String tIMESHEETTYPECD;
    @JsonProperty("M1_ACT_CPF_LBL")
    private String m1ACTCPFLBL;
    @JsonProperty("NUMBER_ANSWER")
    private String nUMBERANSWER;
    @JsonProperty("M1_SVC_CATEGORY_CD")
    private String m1SVCCATEGORYCD;
    @JsonProperty("M1_MESSAGES_LBL")
    private String m1MESSAGESLBL;
    @JsonProperty("F1-ATTACHIDLBL")
    private String f1ATTACHIDLBL;
    @JsonProperty("M1_PREVIEW_BTN_LBL")
    private String m1PREVIEWBTNLBL;
    @JsonProperty("M1_ELIGIBLE_ASSIST_FLG")
    private String m1ELIGIBLEASSISTFLG;
    @JsonProperty("START_DTTM")
    private String sTARTDTTM;
    @JsonProperty("STEP_UPPER_LIMIT")
    private String sTEPUPPERLIMIT;
    @JsonProperty("LOGON_MOBILE_PHONE")
    private String lOGONMOBILEPHONE;
    @JsonProperty("M1_RESOURCE_LBL")
    private String m1RESOURCELBL;
    @JsonProperty("M1_AUTO_EXTENSION")
    private String m1AUTOEXTENSION;
    @JsonProperty("COUNTY_AVAIL")
    private String cOUNTYAVAIL;
    @JsonProperty("M1_DATA_ENCRYPTION_GC_FLG")
    private String m1DATAENCRYPTIONGCFLG;
    @JsonProperty("M1_CAMERA_LBL")
    private String m1CAMERALBL;
    @JsonProperty("M1_REMOTE_APPENDER_LBL")
    private String m1REMOTEAPPENDERLBL;
    @JsonProperty("M1_BREAK_TASK_LBL")
    private String m1BREAKTASKLBL;
    @JsonProperty("BO_STATUS_CD")
    private String bOSTATUSCD;
    @JsonProperty("EXT_OPT_TYPE")
    private String eXTOPTTYPE;
    @JsonProperty("M1_SUBURB")
    private String m1SUBURB;
    @JsonProperty("M1_ITEM_LOAD_STATUS_FLG")
    private String m1ITEMLOADSTATUSFLG;
    @JsonProperty("PROCEDURE_COMMENTS")
    private String pROCEDURECOMMENTS;
    @JsonProperty("M1_SHIFT_ACTIONS_LBL")
    private String m1SHIFTACTIONSLBL;
    @JsonProperty("M1_CONTACT_NAME")
    private String m1CONTACTNAME;
    @JsonProperty("M1_GALLERY_LBL")
    private String m1GALLERYLBL;
    @JsonProperty("M1_SYNC_ALERT_TYPE")
    private String m1SYNCALERTTYPE;
    @JsonProperty("M1_SCHED_PRIORITY_VAL")
    private String m1SCHEDPRIORITYVAL;
    @JsonProperty("M1_LEFT_AT_LBL")
    private String m1LEFTATLBL;
    @JsonProperty("M1_LATE_COST")
    private String m1LATECOST;
    @JsonProperty("M1_POU_SHIFT_ID")
    private String m1POUSHIFTID;
    @JsonProperty("M1_SERVERSYNC")
    private String m1SERVERSYNC;
    @JsonProperty("M1_ELGB_CONTRACTING_FLG")
    private String m1ELGBCONTRACTINGFLG;
    @JsonProperty("BO_DATA_AREA")
    private String bODATAAREA;
    @JsonProperty("M1_ACTIVITY_ALTERNATE_ID")
    private String m1ACTIVITYALTERNATEID;
    @JsonProperty("WFM_MSG_CD")
    private String wFMMSGCD;
    @JsonProperty("M1_INBOX_LBL")
    private String m1INBOXLBL;
    @JsonProperty("M1_INFO_LBL")
    private String m1INFOLBL;
    @JsonProperty("M1_LOADED_LBL")
    private String m1LOADEDLBL;
    @JsonProperty("M1_HOST_CHAIN_EXT_ID")
    private String m1HOSTCHAINEXTID;
    @JsonProperty("M1_CONTR_ELIG_VERSION")
    private String m1CONTRELIGVERSION;
    @JsonProperty("M1_MDTOWNED")
    private String m1MDTOWNED;
    @JsonProperty("M1_OVERRIDE_FLIPSW_LBL")
    private String m1OVERRIDEFLIPSWLBL;
    @JsonProperty("M1_PLAN_END_TIME")
    private String m1PLANENDTIME;
    @JsonProperty("M1_PRIMARY_FUNCTION")
    private String m1PRIMARYFUNCTION;
    @JsonProperty("M1_PERSON_ID")
    private String m1PERSONID;
    @JsonProperty("M1_MAIL_LBL")
    private String m1MAILLBL;
    @JsonProperty("CHAR_TYPE_CD")
    private String cHARTYPECD;
    @JsonProperty("M1_ADVANCED_DISPATCH_OFFSET")
    private String m1ADVANCEDDISPATCHOFFSET;
    @JsonProperty("ERROR_LBL")
    private String eRRORLBL;
    @JsonProperty("M1_CRW_LBL")
    private String m1CRWLBL;
    @JsonProperty("PK_VALUE2")
    private String pKVALUE2;
    @JsonProperty("PK_VALUE1")
    private String pKVALUE1;
    @JsonProperty("PK_VALUE4")
    private String pKVALUE4;
    @JsonProperty("PK_VALUE3")
    private String pKVALUE3;
    @JsonProperty("M1_LOGON_LOCATION_TYPE")
    private String m1LOGONLOCATIONTYPE;
    @JsonProperty("PK_VALUE5")
    private String pKVALUE5;
    @JsonProperty("M1_VIEW_SHF_PRCDR_LBL")
    private String m1VIEWSHFPRCDRLBL;
    @JsonProperty("M1_SYSTEM_GEN_FLG")
    private String m1SYSTEMGENFLG;
    @JsonProperty("M1_GEOCODE_LATITUDE")
    private String m1GEOCODELATITUDE;
    @JsonProperty("M1_ELEM_INDEX")
    private String m1ELEMINDEX;
    @JsonProperty("M1_ITEM_DELIVERY_STATUS_FLG")
    private String m1ITEMDELIVERYSTATUSFLG;
    @JsonProperty("M1_ACTIVITY_LBL")
    private String m1ACTIVITYLBL;
    @JsonProperty("M1_DEPOT_REL_ASSIGNMENT_LBL")
    private String m1DEPOTRELASSIGNMENTLBL;
    @JsonProperty("M1_DEFERMENT_COMMENTS")
    private String m1DEFERMENTCOMMENTS;
    @JsonProperty("M1_CREW_NAME")
    private String m1CREWNAME;
    @JsonProperty("M1_ACTIVITY_PROCEDURES_LBL")
    private String m1ACTIVITYPROCEDURESLBL;
    @JsonProperty("OUTMSG_PRIOR_FLG")
    private String oUTMSGPRIORFLG;
    @JsonProperty("M1_AUTO_COMP_FLG")
    private String m1AUTOCOMPFLG;
    @JsonProperty("M1_DOWNLOAD_ALL")
    private String m1DOWNLOADALL;
    @JsonProperty("M1_COLLISION_DETECTED_TODO_TYP")
    private String m1COLLISIONDETECTEDTODOTYP;
    @JsonProperty("M1_GUAR_DEL_LBL")
    private String m1GUARDELLBL;
    @JsonProperty("M1_ADDRESS_COUNTY")
    private String m1ADDRESSCOUNTY;
    @JsonProperty("M1_DEFERMENT_REASON_FLG")
    private String m1DEFERMENTREASONFLG;
    @JsonProperty("M1_SUBJECT")
    private String m1SUBJECT;
    @JsonProperty("M1_PANIC_HEADER_LBL")
    private String m1PANICHEADERLBL;
    @JsonProperty("TASK_ALT_ID")
    private String tASKALTID;
    @JsonProperty("SEQ_NUM")
    private String sEQNUM;
    @JsonProperty("M1_LOAD_ALL_ITEMS_LBL")
    private String m1LOADALLITEMSLBL;
    @JsonProperty("M1_SHOW_MORE_LBL")
    private String m1SHOWMORELBL;
    @JsonProperty("M1_UPDATED_ETA")
    private String m1UPDATEDETA;
    @JsonProperty("M1_RESET_SIGNATURE_LBL")
    private String m1RESETSIGNATURELBL;
    @JsonProperty("M1_DELIVERED_LBL")
    private String m1DELIVEREDLBL;
    @JsonProperty("M1_REMARK_TYPE")
    private String m1REMARKTYPE;
    @JsonProperty("M1_LOCKED_TO_DEPOT_TASK_ID")
    private String m1LOCKEDTODEPOTTASKID;
    @JsonProperty("M1_DEPOT_TASK_BO")
    private String m1DEPOTTASKBO;
    @JsonProperty("M1_SVC_TYPE_FLG")
    private String m1SVCTYPEFLG;
    @JsonProperty("M1_MBL_WKR_LBL")
    private String m1MBLWKRLBL;
    @JsonProperty("M1_REACH_DEST_LBL")
    private String m1REACHDESTLBL;
    @JsonProperty("WFM_MSG_CAT_FLG")
    private String wFMMSGCATFLG;
    @JsonProperty("M1_SENT_BY_MAIL_ID")
    private String m1SENTBYMAILID;
    @JsonProperty("M1_LOGOFF_BTN_LBL")
    private String m1LOGOFFBTNLBL;
    @JsonProperty("M1_CHANGE_SEQUENCE_FLG")
    private String m1CHANGESEQUENCEFLG;
    @JsonProperty("TSK_TM_WIND_START_DTTM")
    private String tSKTMWINDSTARTDTTM;
    @JsonProperty("M1_DEPOT_TASK_TYPE")
    private String m1DEPOTTASKTYPE;
    @JsonProperty("MDT_INDICATOR_POSITION")
    private String mDTINDICATORPOSITION;
    @JsonProperty("M1_RTN_TO_SVC_LBL")
    private String m1RTNTOSVCLBL;
    @JsonProperty("M1_OVERTIME_TYPE_EXT_ID")
    private String m1OVERTIMETYPEEXTID;
    @JsonProperty("M1_NEW_FUNCTION_LBL")
    private String m1NEWFUNCTIONLBL;
    @JsonProperty("M1_CORRECT_LBL")
    private String m1CORRECTLBL;
    @JsonProperty("M1_BREAK_TIME")
    private String m1BREAKTIME;
    @JsonProperty("M1_RTN_SVC_PRPT")
    private String m1RTNSVCPRPT;
    @JsonProperty("M1_MCP_CAPABILITY_TYP_MAIN_LBL")
    private String m1MCPCAPABILITYTYPMAINLBL;
    @JsonProperty("M1_CREWINQUIRY_TYPE")
    private String m1CREWINQUIRYTYPE;
    @JsonProperty("ADDR1_AVAIL")
    private String aDDR1AVAIL;
    @JsonProperty("M1_SCAN_NEXT_LBL")
    private String m1SCANNEXTLBL;
    @JsonProperty("OVERRIDE_ALLOCATION_RULE")
    private String oVERRIDEALLOCATIONRULE;
    @JsonProperty("M1_SECONDS_LBL")
    private String m1SECONDSLBL;
    @JsonProperty("MDT_INDICATOR_CODE")
    private String mDTINDICATORCODE;
    @JsonProperty("M1_ACTIVITY_CLASS_FLG")
    private String m1ACTIVITYCLASSFLG;
    @JsonProperty("M1_DURATION")
    private String m1DURATION;
    @JsonProperty("M1_SS_LBL")
    private String m1SSLBL;
    @JsonProperty("M1_PROCEDURE_MESSAGE_NBR")
    private String m1PROCEDUREMESSAGENBR;
    @JsonProperty("M1_ACTUAL_COMPLETION_TIME")
    private String m1ACTUALCOMPLETIONTIME;
    @JsonProperty("F1_EXT_LOOKUP_VALUE")
    private String f1EXTLOOKUPVALUE;
    @JsonProperty("M1_DECLINE_ALL_ITEMS_LBL")
    private String m1DECLINEALLITEMSLBL;
    @JsonProperty("M1_POUTASK_ID")
    private String m1POUTASKID;
    @JsonProperty("M1_ONLINE_BTN_LBL")
    private String m1ONLINEBTNLBL;
    @JsonProperty("BO_STATUS_REASON_CD")
    private String bOSTATUSREASONCD;
    @JsonProperty("M1_ACTIVITY_ID")
    private String m1ACTIVITYID;
    @JsonProperty("LOC_TYPE_FLG")
    private String lOCTYPEFLG;
    @JsonProperty("M1_PICKUP_STATUS_FLG")
    private String m1PICKUPSTATUSFLG;
    @JsonProperty("M1_WARN_LBL")
    private String m1WARNLBL;
    @JsonProperty("M1_ISSUE_DETECTED_TODO_TYPE")
    private String m1ISSUEDETECTEDTODOTYPE;
    @JsonProperty("M1_COMPLETED_LBL")
    private String m1COMPLETEDLBL;
    @JsonProperty("M1_HOST_JOB_EXTERNAL_ID")
    private String m1HOSTJOBEXTERNALID;
    @JsonProperty("M1_MARK_ALL_AS_UNLOADED_LBL")
    private String m1MARKALLASUNLOADEDLBL;
    @JsonProperty("TOTAL_LBL")
    private String tOTALLBL;
    @JsonProperty("BREAK_TIMESHEET_TYPE")
    private String bREAKTIMESHEETTYPE;
    @JsonProperty("M1_PREV_CUTOFF_DTTM")
    private String m1PREVCUTOFFDTTM;
    @JsonProperty("M1_SENDTOCREW")
    private String m1SENDTOCREW;
    @JsonProperty("M1_CELL_PHONE")
    private String m1CELLPHONE;
    @JsonProperty("M1_CAPTURE_SIGNATURE_LBL")
    private String m1CAPTURESIGNATURELBL;
    @JsonProperty("VERSION")
    private String vERSION;
    @JsonProperty("M1_MCP_MARKERS")
    private String m1MCPMARKERS;
    @JsonProperty("M1_RVE_TM_WAIT_LBL")
    private String m1RVETMWAITLBL;
    @JsonProperty("M1_ERROR_LBL")
    private String m1ERRORLBL;
    @JsonProperty("M1_COMPLETED_BY_ASSIGNMENT_ID")
    private String m1COMPLETEDBYASSIGNMENTID;
    @JsonProperty("WFM_OPT_VAL")
    private String wFMOPTVAL;
    @JsonProperty("M1_CAPACITY_PREFERRED_FLG")
    private String m1CAPACITYPREFERREDFLG;
    @JsonProperty("PARENT_TASK_ID")
    private String pARENTTASKID;
    @JsonProperty("M1_PRE_TIME_FAC")
    private String m1PRETIMEFAC;
    @JsonProperty("M1_COMPLEX_ACT_CMPL_LBL")
    private String m1COMPLEXACTCMPLLBL;
    @JsonProperty("M1_THEME_A_LBL")
    private String m1THEMEALBL;
    @JsonProperty("M1_ATTACHMENT_FILE_NAME")
    private String m1ATTACHMENTFILENAME;
    @JsonProperty("NUM2_AVAIL")
    private String nUM2AVAIL;
    @JsonProperty("GEO_LAT")
    private String gEOLAT;
    @JsonProperty("M1_DOWNLOAD_IN_PROGRESS_LBL")
    private String m1DOWNLOADINPROGRESSLBL;
    @JsonProperty("M1_POSTPONE_DTTM_NO_DEFAULT_SW")
    private String m1POSTPONEDTTMNODEFAULTSW;
    @JsonProperty("M1_SND_TO_LBL")
    private String m1SNDTOLBL;
    @JsonProperty("M1_HAS_ATTACHMENTS_SW")
    private String m1HASATTACHMENTSSW;
    @JsonProperty("M1_LEGEND_LBL")
    private String m1LEGENDLBL;
    @JsonProperty("M1_TASK_DETAILS_LBL")
    private String m1TASKDETAILSLBL;
    @JsonProperty("M1_HH_LBL")
    private String m1HHLBL;
    @JsonProperty("M1_COMPOSE_MAIL_LBL")
    private String m1COMPOSEMAILLBL;
    @JsonProperty("M1_MOBILE_WORKER")
    private String m1MOBILEWORKER;
    @JsonProperty("TASK_CLS_FLG")
    private String tASKCLSFLG;
    @JsonProperty("PROCEDURE_BUS_OBJ_CD")
    private String pROCEDUREBUSOBJCD;
    @JsonProperty("CALC_DURATION")
    private String cALCDURATION;
    @JsonProperty("M1_PANIC_ALERT_TYPE")
    private String m1PANICALERTTYPE;
    @JsonProperty("M1_MDT_SOUND_PAUSE")
    private String m1MDTSOUNDPAUSE;
    @JsonProperty("M1_CUST_CONTACT_TYPE_MAIN_LBL")
    private String m1CUSTCONTACTTYPEMAINLBL;
    @JsonProperty("M1_MAX_NONCUM_CAPACITY_FLG")
    private String m1MAXNONCUMCAPACITYFLG;
    @JsonProperty("M1_CREW_TM_USG_CLS_FLG")
    private String m1CREWTMUSGCLSFLG;
    @JsonProperty("M1_CAC_EXTENSION_LOW_LIMIT")
    private String m1CACEXTENSIONLOWLIMIT;
    @JsonProperty("WFM_NAME")
    private String wFMNAME;
    @JsonProperty("PLAN_START_DTTM")
    private String pLANSTARTDTTM;
    @JsonProperty("M1_EST_REMAINING_DURATION")
    private String m1ESTREMAININGDURATION;
    @JsonProperty("M1_TMSHT_OVRD_FLG")
    private String m1TMSHTOVRDFLG;
    @JsonProperty("M1_INQUIRY_HISTORY")
    private String m1INQUIRYHISTORY;
    @JsonProperty("M1_CALC_DURATION")
    private String m1CALCDURATION;
    @JsonProperty("PROCEDURE_EFF_DT")
    private String pROCEDUREEFFDT;
    @JsonProperty("M1_UPLOADED_IMAGES_LBL")
    private String m1UPLOADEDIMAGESLBL;
    @JsonProperty("M1_ADD_WORKER_LBL")
    private String m1ADDWORKERLBL;
    @JsonProperty("M1_SITE_ID")
    private String m1SITEID;
    @JsonProperty("STATE_LBL")
    private String sTATELBL;
    @JsonProperty("USER_ID")
    private String uSERID;
    @JsonProperty("M1_ASSIGNED_ENGINEER")
    private String m1ASSIGNEDENGINEER;
    @JsonProperty("TMSHEET_BO_CD")
    private String tMSHEETBOCD;
    @JsonProperty("M1_ACT_CAL_LBL")
    private String m1ACTCALLBL;
    @JsonProperty("M1_TIME_REMAINING_AS_OF_DTTM")
    private String m1TIMEREMAININGASOFDTTM;
    @JsonProperty("M1_POSTPONE_UNTIL_LBL")
    private String m1POSTPONEUNTILLBL;
    @JsonProperty("M1_SOUND_DURATION")
    private String m1SOUNDDURATION;
    @JsonProperty("M1_MDT_TASKLIST_LINE")
    private String m1MDTTASKLISTLINE;
    @JsonProperty("POSTAL")
    private String pOSTAL;
    @JsonProperty("ADDR2_LBL")
    private String aDDR2LBL;
    @JsonProperty("M1_CREW_TIME_USAGE_CMPL_LBL")
    private String m1CREWTIMEUSAGECMPLLBL;
    @JsonProperty("M1_ACTIVITY_TYPE_LBL")
    private String m1ACTIVITYTYPELBL;
    @JsonProperty("M1_MCPME_SCHEDULING_INFO_LBL")
    private String m1MCPMESCHEDULINGINFOLBL;
    @JsonProperty("M1_LOW_CORR_LIMIT")
    private String m1LOWCORRLIMIT;
    @JsonProperty("M1_ARRIVED_ASSIGNMENT_LBL")
    private String m1ARRIVEDASSIGNMENTLBL;
    @JsonProperty("M1_MM_LBL")
    private String m1MMLBL;
    @JsonProperty("M1_DEPOT_ADDRESS")
    private String m1DEPOTADDRESS;
    @JsonProperty("M1_ASSIGNMENT_ID")
    private String m1ASSIGNMENTID;
    @JsonProperty("M1_TIMED_EVENT_EXP_DTTM")
    private String m1TIMEDEVENTEXPDTTM;
    @JsonProperty("M1_QUESTIONNAIRE_LBL")
    private String m1QUESTIONNAIRELBL;
    @JsonProperty("M1_COMMENTS")
    private String m1COMMENTS;
    @JsonProperty("M1_RESERVE_CAP_MAX_PERCENT")
    private String m1RESERVECAPMAXPERCENT;
    @JsonProperty("M1_DUR_EXTENSION_LIMIT")
    private String m1DUREXTENSIONLIMIT;
    @JsonProperty("YES_NO_ANSWER_FLG")
    private String yESNOANSWERFLG;
    @JsonProperty("M1_DEPLOYMENT_ID_LBL")
    private String m1DEPLOYMENTIDLBL;
    @JsonProperty("M1_SCAN_BARCODE_LBL")
    private String m1SCANBARCODELBL;
    @JsonProperty("TIMESHEET_ID")
    private String tIMESHEETID;
    @JsonProperty("M1_SYNC_LOG_FILES_LBL")
    private String m1SYNCLOGFILESLBL;
    @JsonProperty("M1_LOAD_INSTR")
    private String m1LOADINSTR;
    @JsonProperty("M1_SUMMARY_LBL")
    private String m1SUMMARYLBL;
    @JsonProperty("M1_DECLINE_COMMENTS")
    private String m1DECLINECOMMENTS;
    @JsonProperty("PK_VAL5")
    private String pKVAL5;
    @JsonProperty("M1_APPROVAL_DTTM_LBL")
    private String m1APPROVALDTTMLBL;
    @JsonProperty("M1_MAX_LATE")
    private String m1MAXLATE;
    @JsonProperty("M1_TASKS_LBL")
    private String m1TASKSLBL;
    @JsonProperty("PK_VAL1")
    private String pKVAL1;
    @JsonProperty("PK_VAL2")
    private String pKVAL2;
    @JsonProperty("M1_PENDING_LBL")
    private String m1PENDINGLBL;
    @JsonProperty("PK_VAL3")
    private String pKVAL3;
    @JsonProperty("M1_ITEM_CUST_ACCEPTED_FLG")
    private String m1ITEMCUSTACCEPTEDFLG;
    @JsonProperty("PK_VAL4")
    private String pKVAL4;
    @JsonProperty("CROSS_STREET")
    private String cROSSSTREET;
    @JsonProperty("M1_OVERRIDE_PRCDR_CLEAR_LBL")
    private String m1OVERRIDEPRCDRCLEARLBL;
    @JsonProperty("POU_ID")
    private String pOUID;
    @JsonProperty("M1_CREW_SHFT_LBL")
    private String m1CREWSHFTLBL;
    @JsonProperty("M1_RE_LBL")
    private String m1RELBL;
    @JsonProperty("M1_ACTIVITY_EXP_LBL")
    private String m1ACTIVITYEXPLBL;
    @JsonProperty("M1_FROM_LBL")
    private String m1FROMLBL;
    @JsonProperty("M1_JOB_ID")
    private String m1JOBID;
    @JsonProperty("CITY_LBL")
    private String cITYLBL;
    @JsonProperty("APPOINTMENT_FLG")
    private String aPPOINTMENTFLG;
    @JsonProperty("M1_ACTIVITY_ATTRIBUTE")
    private String m1ACTIVITYATTRIBUTE;
    @JsonProperty("M1_LOAD_TASK_BUTTON_LBL")
    private String m1LOADTASKBUTTONLBL;
    @JsonProperty("M1_SELECT_THEME_LBL")
    private String m1SELECTTHEMELBL;
    @JsonProperty("M1_MORE_ELLIPSIS_LBL")
    private String m1MOREELLIPSISLBL;
    @JsonProperty("M1_WORK_SEQ_LBL")
    private String m1WORKSEQLBL;
    @JsonProperty("M1_ACTUAL_START_TIME")
    private String m1ACTUALSTARTTIME;
    @JsonProperty("M1_SETTINGS_LBL")
    private String m1SETTINGSLBL;
    @JsonProperty("M1_EXTENSION_DAYS")
    private String m1EXTENSIONDAYS;
    @JsonProperty("HOST_TASK_ID")
    private String hOSTTASKID;
    @JsonProperty("M1_ALLOW_BREAKS_FLG")
    private String m1ALLOWBREAKSFLG;
    @JsonProperty("M1_MCP_INDICATOR_MAIN_LBL")
    private String m1MCPINDICATORMAINLBL;
    @JsonProperty("M1_COLLISION_DETECTED_TODO_ROL")
    private String m1COLLISIONDETECTEDTODOROL;
    @JsonProperty("M1_CREATE_BY_CREW_FLG")
    private String m1CREATEBYCREWFLG;
    @JsonProperty("M1_SVC_AREA_USAGE")
    private String m1SVCAREAUSAGE;
    @JsonProperty("M1_USED_UNTIL_LBL")
    private String m1USEDUNTILLBL;
    @JsonProperty("M1_CROSS_STREET")
    private String m1CROSSSTREET;
    @JsonProperty("M1_ETA_LBL")
    private String m1ETALBL;
    @JsonProperty("M1_SERVICE_INSTRUCTIONS")
    private String m1SERVICEINSTRUCTIONS;
    @JsonProperty("M1_RESTRICTION_TYPE_FLG")
    private String m1RESTRICTIONTYPEFLG;
    @JsonProperty("M1_SCHEDULING_ORDER")
    private String m1SCHEDULINGORDER;
    @JsonProperty("M1_TEMPLATE_SHIFT")
    private String m1TEMPLATESHIFT;
    @JsonProperty("STATUS_REASON_SELECT_FLG")
    private String sTATUSREASONSELECTFLG;
    @JsonProperty("M1_AFTER_DAYS")
    private String m1AFTERDAYS;
    @JsonProperty("DIRECTIONS_LBL")
    private String dIRECTIONSLBL;
    @JsonProperty("M1_CUSTOMER_INFO_LBL")
    private String m1CUSTOMERINFOLBL;
    @JsonProperty("DESCR")
    private String dESCR;
    @JsonProperty("CREW_SHFT_ID")
    private String cREWSHFTID;
    @JsonProperty("M1_SEL_PRI_FUNCTION_LBL")
    private String m1SELPRIFUNCTIONLBL;
    @JsonProperty("M1_ADJUSTED_DURATION")
    private String m1ADJUSTEDDURATION;
    @JsonProperty("M1_CALC_ERROR_SW")
    private String m1CALCERRORSW;
    @JsonProperty("M1_AT_LBL")
    private String m1ATLBL;
    @JsonProperty("M1_APPT_ST_DTTM")
    private String m1APPTSTDTTM;
    @JsonProperty("M1_LOAD_TASK_COMPLETE_LBL")
    private String m1LOADTASKCOMPLETELBL;
    @JsonProperty("M1_EXT_ENTITY_NAME")
    private String m1EXTENTITYNAME;
    @JsonProperty("M1_DOWNLOADED")
    private String m1DOWNLOADED;
    @JsonProperty("M1_DEPOT_INFORMATION_LBL")
    private String m1DEPOTINFORMATIONLBL;
    @JsonProperty("M1_FOLDER_FLG")
    private String m1FOLDERFLG;
    @JsonProperty("POSTAL_AVAIL")
    private String pOSTALAVAIL;
    @JsonProperty("M1_MAIL_ID")
    private String m1MAILID;
    @JsonProperty("M1_BRK_DUR")
    private String m1BRKDUR;
    @JsonProperty("M1_ITEM_BARCODE_TYPE")
    private String m1ITEMBARCODETYPE;
    @JsonProperty("M1_NPT_LBL")
    private String m1NPTLBL;
    @JsonProperty("M1_SELECT_ONE_LBL")
    private String m1SELECTONELBL;
    @JsonProperty("M1_ITEM_BARCODE")
    private String m1ITEMBARCODE;
    @JsonProperty("M1_UNACKN_EMERG_ALERT_TYPE")
    private String m1UNACKNEMERGALERTTYPE;
    @JsonProperty("M1-MCPMEPOSTPONED")
    private String m1MCPMEPOSTPONED;
    @JsonProperty("M1_ITEM_ADDITIONAL_DETAILS")
    private String m1ITEMADDITIONALDETAILS;
    @JsonProperty("ACCEPT_LBL")
    private String aCCEPTLBL;
    @JsonProperty("WORK_TIMESHEET_TYPE")
    private String wORKTIMESHEETTYPE;
    @JsonProperty("M1_RECEIVED_LBL")
    private String m1RECEIVEDLBL;
    @JsonProperty("M1_RETURN_ALL_ITEMS_LBL")
    private String m1RETURNALLITEMSLBL;
    @JsonProperty("M1_CUMULATIVE_CAPACITY_FLG")
    private String m1CUMULATIVECAPACITYFLG;
    @JsonProperty("M1_MAIN_PHONE")
    private String m1MAINPHONE;
    @JsonProperty("M1_MAILING_LIST_CD")
    private String m1MAILINGLISTCD;
    @JsonProperty("M1_EARNING_TYPE_EXT_ID")
    private String m1EARNINGTYPEEXTID;
    @JsonProperty("M1_FINAL_DTTM")
    private String m1FINALDTTM;
    @JsonProperty("M1_DEPOT_TASK_ID")
    private String m1DEPOTTASKID;
    @JsonProperty("M1_POSTPONE_DATE")
    private String m1POSTPONEDATE;
    @JsonProperty("M1_ACTIVITY_ATTRIB_USAGE_FLG")
    private String m1ACTIVITYATTRIBUSAGEFLG;
    @JsonProperty("SEND_BTN_LBL")
    private String sENDBTNLBL;
    @JsonProperty("M1_GEOCODE_LONGITUDE")
    private String m1GEOCODELONGITUDE;
    @JsonProperty("RESRC_ID_TYPE_FLG")
    private String rESRCIDTYPEFLG;
    @JsonProperty("SEQNO")
    private String sEQNO;
    @JsonProperty("M1_CREATION_DTTM")
    private String m1CREATIONDTTM;
    @JsonProperty("M1_START_BTN_LBL")
    private String m1STARTBTNLBL;
    @JsonProperty("M1_NON_PROD_TASK_ID")
    private String m1NONPRODTASKID;
    @JsonProperty("M1_THEME_C_LBL")
    private String m1THEMECLBL;
    @JsonProperty("M1_ON_SITE_DATE")
    private String m1ONSITEDATE;
    @JsonProperty("M1_ALERTS_LBL")
    private String m1ALERTSLBL;
    @JsonProperty("M1_REQUIRED_FIELDS_LBL")
    private String m1REQUIREDFIELDSLBL;
    @JsonProperty("M1_MIN_VISIT_DURATION")
    private String m1MINVISITDURATION;
    @JsonProperty("M1_ACTIVITY_TYPE_TODO")
    private String m1ACTIVITYTYPETODO;
    @JsonProperty("M1_NAME")
    private String m1NAME;
    @JsonProperty("M1_ACCOUNT_ID")
    private String m1ACCOUNTID;
    @JsonProperty("ATTACHMENT_FILE_NAME")
    private String aTTACHMENTFILENAME;
    @JsonProperty("M1_EXT_ENTITY_VALUE")
    private String m1EXTENTITYVALUE;
    @JsonProperty("SVC_AREA_USG_FLG")
    private String sVCAREAUSGFLG;
    @JsonProperty("POU_TIMESHEET_TYPE")
    private String pOUTIMESHEETTYPE;
    @JsonProperty("PRI_PROF_CD")
    private String pRIPROFCD;
    @JsonProperty("M1_REVW_ON_DEV_FLG")
    private String m1REVWONDEVFLG;
    @JsonProperty("PROCEDURE_STATUS_FLG")
    private String pROCEDURESTATUSFLG;
    @JsonProperty("M1_AUTO_ALLOCATION_DAYS")
    private String m1AUTOALLOCATIONDAYS;
    @JsonProperty("SVC_CLS_USG_FLG")
    private String sVCCLSUSGFLG;
    @JsonProperty("M1_TRAVEL_DISTANCE")
    private String m1TRAVELDISTANCE;
    @JsonProperty("M1_CAC_REMAINING_DURATION")
    private String m1CACREMAININGDURATION;
    @JsonProperty("M1_COMPLETE_BTN_LBL")
    private String m1COMPLETEBTNLBL;
    @JsonProperty("M1_GROUP_LBL")
    private String m1GROUPLBL;
    @JsonProperty("STEP_REQUIRED_FLG")
    private String sTEPREQUIREDFLG;
    @JsonProperty("M1_CUSTOMER_CONTACT_TYPE_CD")
    private String m1CUSTOMERCONTACTTYPECD;
    @JsonProperty("MDT_CAPABILITY_ATTACHMENT_BO")
    private String mDTCAPABILITYATTACHMENTBO;
    @JsonProperty("M1_PERCENTAGE_DEVIATION")
    private String m1PERCENTAGEDEVIATION;
    @JsonProperty("M1_OR_TASK_CAPABILITY_FLG")
    private String m1ORTASKCAPABILITYFLG;
    @JsonProperty("M1_ITEM_ATTR_NAME")
    private String m1ITEMATTRNAME;
    @JsonProperty("M1_MLRD_STATUS_FLG")
    private String m1MLRDSTATUSFLG;
    @JsonProperty("M1_RELATED_ACTIVITY_TYPES")
    private String m1RELATEDACTIVITYTYPES;
    @JsonProperty("M1_AVG_VISIT_DURATION")
    private String m1AVGVISITDURATION;
    @JsonProperty("M1_CONTRACTOR_ID")
    private String m1CONTRACTORID;
    @JsonProperty("M1_GO_OUT_SVC_LBL")
    private String m1GOOUTSVCLBL;
    @JsonProperty("M1_DECLINED_LBL")
    private String m1DECLINEDLBL;
    @JsonProperty("NPT_TIMESHEET_TYPE")
    private String nPTTIMESHEETTYPE;
    @JsonProperty("M1_ALLOW_RELATED_ACTIVITIES")
    private String m1ALLOWRELATEDACTIVITIES;
    @JsonProperty("M1_WINDOW_APPENDER_LBL")
    private String m1WINDOWAPPENDERLBL;
    @JsonProperty("DFL_APPT_BOOK_GRP")
    private String dFLAPPTBOOKGRP;
    @JsonProperty("M1_ISSUE_DETECTED_TODO_ROLE")
    private String m1ISSUEDETECTEDTODOROLE;
    @JsonProperty("M1_END_TM")
    private String m1ENDTM;
    @JsonProperty("M1_REVIEW_RQD_LBL")
    private String m1REVIEWRQDLBL;
    @JsonProperty("M1_ITEM_INFORMATION_LBL")
    private String m1ITEMINFORMATIONLBL;
    @JsonProperty("CAP_DTTM")
    private String cAPDTTM;
    @JsonProperty("M1_TRANSPORT_RESTRICTION_FLG")
    private String m1TRANSPORTRESTRICTIONFLG;
    @JsonProperty("MAINT_OBJ_CD")
    private String mAINTOBJCD;
    @JsonProperty("M1_TIMED_EVENT_ALERT_TYPE")
    private String m1TIMEDEVENTALERTTYPE;
    @JsonProperty("POSTAL_LBL")
    private String pOSTALLBL;
    @JsonProperty("M1_RESRV_CAPACITY_BY_FLG")
    private String m1RESRVCAPACITYBYFLG;
    @JsonProperty("M1_ITEM_DELI_DCLN_RSN_FLG")
    private String m1ITEMDELIDCLNRSNFLG;
    @JsonProperty("M1_START_DAY_OF_WEEK")
    private String m1STARTDAYOFWEEK;
    @JsonProperty("M1_RT_DST_UNIT_ABBR_FLG")
    private String m1RTDSTUNITABBRFLG;
    @JsonProperty("M1_REAL_GPS_THRESHOLD")
    private String m1REALGPSTHRESHOLD;
    @JsonProperty("RESET_LBL")
    private String rESETLBL;
    @JsonProperty("ADDR3_LBL")
    private String aDDR3LBL;
    @JsonProperty("ACKNOWLEDGEMENT_REQ_FLG")
    private String aCKNOWLEDGEMENTREQFLG;
    @JsonProperty("M1_FILE_DESC")
    private String m1FILEDESC;
    @JsonProperty("M1_COMPLETE_ACT_LBL")
    private String m1COMPLETEACTLBL;
    @JsonProperty("M1_RESERVE_CAP_TYPE")
    private String m1RESERVECAPTYPE;
    @JsonProperty("BO_STATUS_BO_CD")
    private String bOSTATUSBOCD;
    @JsonProperty("M1_HOST_PARENT_EXT_ID")
    private String m1HOSTPARENTEXTID;
    @JsonProperty("M1_RVW_TM_SH_LBL")
    private String m1RVWTMSHLBL;
    @JsonProperty("M1_ITEM_CUST_ACCEPT_REQ_FLG")
    private String m1ITEMCUSTACCEPTREQFLG;
    @JsonProperty("M1_MDT_LOG_LOC")
    private String m1MDTLOGLOC;
    @JsonProperty("M1_DEPENDENT_ON")
    private String m1DEPENDENTON;
    @JsonProperty("CITY")
    private String cITY;
    @JsonProperty("M1_LOCATION")
    private String m1LOCATION;
    @JsonProperty("MESSAGE_CAT_NBR")
    private String mESSAGECATNBR;
    @JsonProperty("M1_DECLINE_ACT_LBL")
    private String m1DECLINEACTLBL;
    @JsonProperty("M1_MCPME_CUSTOMER_INFO_LBL")
    private String m1MCPMECUSTOMERINFOLBL;
    @JsonProperty("STATE")
    private String sTATE;
    @JsonProperty("M1_CREW_ID")
    private String m1CREWID;
    @JsonProperty("M1_ACT_EOS_LBL")
    private String m1ACTEOSLBL;
    @JsonProperty("M1_ACTUAL_ST_DTTM")
    private String m1ACTUALSTDTTM;
    @JsonProperty("M1_DISPATCH_DTTM")
    private String m1DISPATCHDTTM;
    @JsonProperty("M1_TAKEN_DATE")
    private String m1TAKENDATE;
    @JsonProperty("M1_AUTO_CANCEL")
    private String m1AUTOCANCEL;
    @JsonProperty("M1_EST_OUT_OF_SVC_DUR")
    private String m1ESTOUTOFSVCDUR;
    @JsonProperty("M1_MDT_MAP_HOVER_TEXT")
    private String m1MDTMAPHOVERTEXT;
    @JsonProperty("MESSAGE_PARM_CNT")
    private String mESSAGEPARMCNT;
    @JsonProperty("M1_BELONGS_TO_PKG_LBL")
    private String m1BELONGSTOPKGLBL;
    @JsonProperty("M1_THEME_ORACLE_LBL")
    private String m1THEMEORACLELBL;
    @JsonProperty("M1_PENDING_CANCEL_SW")
    private String m1PENDINGCANCELSW;
    @JsonProperty("TASK_BUS_OBJ_CD")
    private String tASKBUSOBJCD;
    @JsonProperty("M1_SHIFT_LBL")
    private String m1SHIFTLBL;
    @JsonProperty("M1_AVG_DUR")
    private String m1AVGDUR;
    @JsonProperty("M1_OVERRIDE_DURATION")
    private String m1OVERRIDEDURATION;
    @JsonProperty("M1_DEPOT_TASK_ASSIGNMENT_LBL")
    private String m1DEPOTTASKASSIGNMENTLBL;
    @JsonProperty("M1_EMBEDDEDVIEWER")
    private String m1EMBEDDEDVIEWER;
    @JsonProperty("M1_SENT_FROM_USER")
    private String m1SENTFROMUSER;
    @JsonProperty("ALLOCATION_RULE_FLG")
    private String aLLOCATIONRULEFLG;
    @JsonProperty("M1_CONSOLE_APPENDER_LBL")
    private String m1CONSOLEAPPENDERLBL;
    @JsonProperty("M1_LOG_APPENDER_LBL")
    private String m1LOGAPPENDERLBL;
    @JsonProperty("M1_SEND_NOW_UPDATE_SW")
    private String m1SENDNOWUPDATESW;
    @JsonProperty("M1_OVRD_FLG")
    private String m1OVRDFLG;
    @JsonProperty("ADDR3_AVAIL")
    private String aDDR3AVAIL;
    @JsonProperty("M1_VEH_STRT_ODO_MTR")
    private String m1VEHSTRTODOMTR;
    @JsonProperty("TEXT_ANSWER")
    private String tEXTANSWER;
    @JsonProperty("ORIG_PLANNED_END_DTTM")
    private String oRIGPLANNEDENDDTTM;
    @JsonProperty("SUBSCRIPTION_ID")
    private String sUBSCRIPTIONID;
    @JsonProperty("M1_COMMENT")
    private String m1COMMENT;
    @JsonProperty("M1_DELVR_NOW_FLG")
    private String m1DELVRNOWFLG;
    @JsonProperty("CALC_TRVL_DIST")
    private String cALCTRVLDIST;
    @JsonProperty("M1_POU_TASK_TYPE")
    private String m1POUTASKTYPE;
    @JsonProperty("M1_ASSIGNED_TO_CAPACITY_SW")
    private String m1ASSIGNEDTOCAPACITYSW;
    @JsonProperty("M1_GENERAL_LBL")
    private String m1GENERALLBL;
    @JsonProperty("M1_REPLY_LBL")
    private String m1REPLYLBL;
    @JsonProperty("M1_CLOSE_BTN_LBL")
    private String m1CLOSEBTNLBL;
    @JsonProperty("M1_SERVER_PROXY_HOST")
    private String m1SERVERPROXYHOST;
    @JsonProperty("TASK_TYPE_CD")
    private String tASKTYPECD;
    @JsonProperty("M1_ACTIVITY_BO")
    private String m1ACTIVITYBO;
    @JsonProperty("TIMESHEET_TM_TYPE_CD")
    private String tIMESHEETTMTYPECD;
    @JsonProperty("M1_COMPLETE_WITHIN_DAYS")
    private String m1COMPLETEWITHINDAYS;
    @JsonProperty("M1_TO_DO_MESSAGE")
    private String m1TODOMESSAGE;
    @JsonProperty("M1_WORK_PROFILE_CD")
    private String m1WORKPROFILECD;
    @JsonProperty("MSG_PARM_TYP_FLG")
    private String mSGPARMTYPFLG;
    @JsonProperty("M1_SITE_ADDRESS")
    private String m1SITEADDRESS;
    @JsonProperty("MDT_ID")
    private String mDTID;
    @JsonProperty("M1_MCPME_ACTIVITY_INFO_LBL")
    private String m1MCPMEACTIVITYINFOLBL;
    @JsonProperty("M1_UNDISPATCH_OPTION_FLG")
    private String m1UNDISPATCHOPTIONFLG;
    @JsonProperty("M1_PACKAGE_ITEMS_LBL")
    private String m1PACKAGEITEMSLBL;
    @JsonProperty("M1_WORK_SEQ")
    private String m1WORKSEQ;
    @JsonProperty("HOST_REF_CD")
    private String hOSTREFCD;
    @JsonProperty("M1_DEPOT_DELAY")
    private String m1DEPOTDELAY;
    @JsonProperty("M1_TIME_WINDOW_SOURCE_FLG")
    private String m1TIMEWINDOWSOURCEFLG;
    @JsonProperty("M1_PREVIEW_SHFT_LBL")
    private String m1PREVIEWSHFTLBL;
    @JsonProperty("M1_MSG_TEXT")
    private String m1MSGTEXT;
    @JsonProperty("QUEUE_FLG")
    private String qUEUEFLG;
    @JsonProperty("M1_SELECT_LOGLEVEL_LBL")
    private String m1SELECTLOGLEVELLBL;
    @JsonProperty("M1_EXPIRATION_TD_ROLE")
    private String m1EXPIRATIONTDROLE;
    @JsonProperty("M1_NUMBER_ACTIVITIES")
    private String m1NUMBERACTIVITIES;
    @JsonProperty("M1_DEBUG_LBL")
    private String m1DEBUGLBL;
    @JsonProperty("M1_SELECT_PICKUP_ACTTYPE_LBL")
    private String m1SELECTPICKUPACTTYPELBL;
    @JsonProperty("IN_CITY_LIM_AVAIL")
    private String iNCITYLIMAVAIL;
    @JsonProperty("OUTMSG_TYPE_CD")
    private String oUTMSGTYPECD;
    @JsonProperty("COUNTY_LBL")
    private String cOUNTYLBL;
    @JsonProperty("M1_BREAK_ID")
    private String m1BREAKID;
    @JsonProperty("TAKE_ATTENDANCE_FLG")
    private String tAKEATTENDANCEFLG;
    @JsonProperty("F1_MSG_PARM_VLONG")
    private String f1MSGPARMVLONG;
    @JsonProperty("M1_WORK_BY_DATE")
    private String m1WORKBYDATE;
    @JsonProperty("M1_ESTIMATED_DURATION")
    private String m1ESTIMATEDDURATION;
    @JsonProperty("COUNTRY")
    private String cOUNTRY;
    @JsonProperty("STEP_LOWER_LIMIT")
    private String sTEPLOWERLIMIT;
    @JsonProperty("M1_CUSTOMER_CONTACT_COMMENTS")
    private String m1CUSTOMERCONTACTCOMMENTS;
    @JsonProperty("M1_OFFLINE_LBL")
    private String m1OFFLINELBL;
    @JsonProperty("M1_CONCURRENT_TASK_ID")
    private String m1CONCURRENTTASKID;
    @JsonProperty("M1_LOGON_DELAY")
    private String m1LOGONDELAY;
    @JsonProperty("M1_MOB_APP_LBL")
    private String m1MOBAPPLBL;
    @JsonProperty("M1_CONTRACTOR_LBL")
    private String m1CONTRACTORLBL;
    @JsonProperty("M1_ITEM_ATTR_VALUE")
    private String m1ITEMATTRVALUE;
    @JsonProperty("M1_NON_PRD_TASK_BO")
    private String m1NONPRDTASKBO;
    @JsonProperty("M1_DELIVERY_COMPLETE")
    private String m1DELIVERYCOMPLETE;
    @JsonProperty("M1_TIMESHEET_LBL")
    private String m1TIMESHEETLBL;
    @JsonProperty("M1_APPENDERS_LBL")
    private String m1APPENDERSLBL;
    @JsonProperty("M1_BREAK_BO")
    private String m1BREAKBO;
    @JsonProperty("M1_COMMON_COMPLETION_LBL")
    private String m1COMMONCOMPLETIONLBL;
    @JsonProperty("M1_CREW_TIM_UGG_DIM_MAIN_LBL")
    private String m1CREWTIMUGGDIMMAINLBL;
    @JsonProperty("NUM1_LBL")
    private String nUM1LBL;
    @JsonProperty("M1_ACT_STE_LBL")
    private String m1ACTSTELBL;
    @JsonProperty("M1_TRAVELTIME_DURATION")
    private String m1TRAVELTIMEDURATION;
    @JsonProperty("M1_COMPLETE_WITHIN_TIME")
    private String m1COMPLETEWITHINTIME;
    @JsonProperty("LOG_ENTRY_TYPE_FLG")
    private String lOGENTRYTYPEFLG;
    @JsonProperty("M1_ATTENDANCE_LBL")
    private String m1ATTENDANCELBL;
    @JsonProperty("ADDR4_LBL")
    private String aDDR4LBL;
    @JsonProperty("F1_ATTACHMENT_RECORD")
    private String f1ATTACHMENTRECORD;
    @JsonProperty("M1_DEPOT_TASK_DECLINE_REASON")
    private String m1DEPOTTASKDECLINEREASON;
    @JsonProperty("M1_THEME_E_LBL")
    private String m1THEMEELBL;
    @JsonProperty("DRIP_MODE_FLG")
    private String dRIPMODEFLG;
    @JsonProperty("STEP_STATE_FLG")
    private String sTEPSTATEFLG;
    @JsonProperty("M1_ADD_NEW_LBL")
    private String m1ADDNEWLBL;
    @JsonProperty("CRE_DTTM")
    private String cREDTTM;
    @JsonProperty("VARIABLE_SHIFT_FLG")
    private String vARIABLESHIFTFLG;
    @JsonProperty("M1_ACTIVITY_COMPLETE_FLG")
    private String m1ACTIVITYCOMPLETEFLG;
    @JsonProperty("ALL_LBL")
    private String aLLLBL;
    @JsonProperty("M1_UNDELIVERED_LBL")
    private String m1UNDELIVEREDLBL;
    @JsonProperty("M1_STRT_SHIFT_LBL")
    private String m1STRTSHIFTLBL;
    @JsonProperty("M1_ADD_REMARK_TYP_LBL")
    private String m1ADDREMARKTYPLBL;
    @JsonProperty("PROCEDURE_CLEARANCE_REQ_FLG")
    private String pROCEDURECLEARANCEREQFLG;
    @JsonProperty("HOST_EXTERNAL_ID")
    private String hOSTEXTERNALID;
    @JsonProperty("M1_LIST_LBL")
    private String m1LISTLBL;
    @JsonProperty("M1_DEPENDENCY_RSN_FLG")
    private String m1DEPENDENCYRSNFLG;
    @JsonProperty("SUBURB")
    private String sUBURB;
    @JsonProperty("M1_DEPOT_LBL")
    private String m1DEPOTLBL;
    @JsonProperty("DESCR100")
    private String dESCR100;
    @JsonProperty("M1_COUNT")
    private String m1COUNT;
    @JsonProperty("M1_LOG_LEVEL_LBL")
    private String m1LOGLEVELLBL;
    @JsonProperty("M1_LIFE_SPAN")
    private String m1LIFESPAN;
    @JsonProperty("M1_CREATED_BY_CREW_SW")
    private String m1CREATEDBYCREWSW;
    @JsonProperty("M1_NONCUM_CAPACITY_FLG")
    private String m1NONCUMCAPACITYFLG;
    @JsonProperty("M1_ACTUAL_ARR_DTTM")
    private String m1ACTUALARRDTTM;
    @JsonProperty("M1_CANCEL_CHGS_BTN_LBL")
    private String m1CANCELCHGSBTNLBL;
    @JsonProperty("M1_DATA_SENT_AT_DTTM")
    private String m1DATASENTATDTTM;
    @JsonProperty("M1_MAIL_MSG_CLS_FLG")
    private String m1MAILMSGCLSFLG;
    @JsonProperty("PARM_SEQ")
    private String pARMSEQ;
    @JsonProperty("M1_CLOSEDBY_ADV_DISP_FLG")
    private String m1CLOSEDBYADVDISPFLG;
    @JsonProperty("HOUSE_TYPE_LBL")
    private String hOUSETYPELBL;
    @JsonProperty("RMK_TYPE_CD")
    private String rMKTYPECD;
    @JsonProperty("M1_PICKUP_ACTIVITY_LBL")
    private String m1PICKUPACTIVITYLBL;
    @JsonProperty("M1_ITEM_LOAD_DCLN_RSN_FLG")
    private String m1ITEMLOADDCLNRSNFLG;
    @JsonProperty("M1_RESEND_MAIL_LBL")
    private String m1RESENDMAILLBL;
    @JsonProperty("M1_CONTR_ELIG_ID")
    private String m1CONTRELIGID;
    @JsonProperty("M1_END_SHIFT_LBL")
    private String m1ENDSHIFTLBL;
    @JsonProperty("M1_RVW_TMSH_DEV_LBL")
    private String m1RVWTMSHDEVLBL;
    @JsonProperty("M1_CUSTOMER_ACCEPTANCE_LBL")
    private String m1CUSTOMERACCEPTANCELBL;
    @JsonProperty("M1_KEEP_WITH_CREW_LBL")
    private String m1KEEPWITHCREWLBL;
    @JsonProperty("M1_MEETING_INFORMATION_LBL")
    private String m1MEETINGINFORMATIONLBL;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The nUM2LBL
     */
    @JsonProperty("NUM2_LBL")
    public String getNUM2LBL() {
        return nUM2LBL;
    }

    /**
     * 
     * @param nUM2LBL
     *     The NUM2_LBL
     */
    @JsonProperty("NUM2_LBL")
    public void setNUM2LBL(String nUM2LBL) {
        this.nUM2LBL = nUM2LBL;
    }

    /**
     * 
     * @return
     *     The m1RELATEDENTITYLBL
     */
    @JsonProperty("M1_RELATED_ENTITY_LBL")
    public String getM1RELATEDENTITYLBL() {
        return m1RELATEDENTITYLBL;
    }

    /**
     * 
     * @param m1RELATEDENTITYLBL
     *     The M1_RELATED_ENTITY_LBL
     */
    @JsonProperty("M1_RELATED_ENTITY_LBL")
    public void setM1RELATEDENTITYLBL(String m1RELATEDENTITYLBL) {
        this.m1RELATEDENTITYLBL = m1RELATEDENTITYLBL;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEOPTIONFLG
     */
    @JsonProperty("M1_COMPLETE_OPTION_FLG")
    public String getM1COMPLETEOPTIONFLG() {
        return m1COMPLETEOPTIONFLG;
    }

    /**
     * 
     * @param m1COMPLETEOPTIONFLG
     *     The M1_COMPLETE_OPTION_FLG
     */
    @JsonProperty("M1_COMPLETE_OPTION_FLG")
    public void setM1COMPLETEOPTIONFLG(String m1COMPLETEOPTIONFLG) {
        this.m1COMPLETEOPTIONFLG = m1COMPLETEOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1PERFLBL
     */
    @JsonProperty("M1_PERF_LBL")
    public String getM1PERFLBL() {
        return m1PERFLBL;
    }

    /**
     * 
     * @param m1PERFLBL
     *     The M1_PERF_LBL
     */
    @JsonProperty("M1_PERF_LBL")
    public void setM1PERFLBL(String m1PERFLBL) {
        this.m1PERFLBL = m1PERFLBL;
    }

    /**
     * 
     * @return
     *     The m1ATTACHMENT
     */
    @JsonProperty("M1_ATTACHMENT")
    public String getM1ATTACHMENT() {
        return m1ATTACHMENT;
    }

    /**
     * 
     * @param m1ATTACHMENT
     *     The M1_ATTACHMENT
     */
    @JsonProperty("M1_ATTACHMENT")
    public void setM1ATTACHMENT(String m1ATTACHMENT) {
        this.m1ATTACHMENT = m1ATTACHMENT;
    }

    /**
     * 
     * @return
     *     The m1MAXSTRTTRVL
     */
    @JsonProperty("M1_MAX_STRT_TRVL")
    public String getM1MAXSTRTTRVL() {
        return m1MAXSTRTTRVL;
    }

    /**
     * 
     * @param m1MAXSTRTTRVL
     *     The M1_MAX_STRT_TRVL
     */
    @JsonProperty("M1_MAX_STRT_TRVL")
    public void setM1MAXSTRTTRVL(String m1MAXSTRTTRVL) {
        this.m1MAXSTRTTRVL = m1MAXSTRTTRVL;
    }

    /**
     * 
     * @return
     *     The tASKID
     */
    @JsonProperty("TASK_ID")
    public String getTASKID() {
        return tASKID;
    }

    /**
     * 
     * @param tASKID
     *     The TASK_ID
     */
    @JsonProperty("TASK_ID")
    public void setTASKID(String tASKID) {
        this.tASKID = tASKID;
    }

    /**
     * 
     * @return
     *     The m1VALIDREMARKTYPES
     */
    @JsonProperty("M1_VALID_REMARK_TYPES")
    public String getM1VALIDREMARKTYPES() {
        return m1VALIDREMARKTYPES;
    }

    /**
     * 
     * @param m1VALIDREMARKTYPES
     *     The M1_VALID_REMARK_TYPES
     */
    @JsonProperty("M1_VALID_REMARK_TYPES")
    public void setM1VALIDREMARKTYPES(String m1VALIDREMARKTYPES) {
        this.m1VALIDREMARKTYPES = m1VALIDREMARKTYPES;
    }

    /**
     * 
     * @return
     *     The aTTACHLBL
     */
    @JsonProperty("ATTACH_LBL")
    public String getATTACHLBL() {
        return aTTACHLBL;
    }

    /**
     * 
     * @param aTTACHLBL
     *     The ATTACH_LBL
     */
    @JsonProperty("ATTACH_LBL")
    public void setATTACHLBL(String aTTACHLBL) {
        this.aTTACHLBL = aTTACHLBL;
    }

    /**
     * 
     * @return
     *     The oVERRIDECLEARANCEFLG
     */
    @JsonProperty("OVERRIDE_CLEARANCE_FLG")
    public String getOVERRIDECLEARANCEFLG() {
        return oVERRIDECLEARANCEFLG;
    }

    /**
     * 
     * @param oVERRIDECLEARANCEFLG
     *     The OVERRIDE_CLEARANCE_FLG
     */
    @JsonProperty("OVERRIDE_CLEARANCE_FLG")
    public void setOVERRIDECLEARANCEFLG(String oVERRIDECLEARANCEFLG) {
        this.oVERRIDECLEARANCEFLG = oVERRIDECLEARANCEFLG;
    }

    /**
     * 
     * @return
     *     The aDDRESS2
     */
    @JsonProperty("ADDRESS2")
    public String getADDRESS2() {
        return aDDRESS2;
    }

    /**
     * 
     * @param aDDRESS2
     *     The ADDRESS2
     */
    @JsonProperty("ADDRESS2")
    public void setADDRESS2(String aDDRESS2) {
        this.aDDRESS2 = aDDRESS2;
    }

    /**
     * 
     * @return
     *     The m1LOGOFFLOCATIONTYPE
     */
    @JsonProperty("M1_LOGOFF_LOCATION_TYPE")
    public String getM1LOGOFFLOCATIONTYPE() {
        return m1LOGOFFLOCATIONTYPE;
    }

    /**
     * 
     * @param m1LOGOFFLOCATIONTYPE
     *     The M1_LOGOFF_LOCATION_TYPE
     */
    @JsonProperty("M1_LOGOFF_LOCATION_TYPE")
    public void setM1LOGOFFLOCATIONTYPE(String m1LOGOFFLOCATIONTYPE) {
        this.m1LOGOFFLOCATIONTYPE = m1LOGOFFLOCATIONTYPE;
    }

    /**
     * 
     * @return
     *     The aDDRESS3
     */
    @JsonProperty("ADDRESS3")
    public String getADDRESS3() {
        return aDDRESS3;
    }

    /**
     * 
     * @param aDDRESS3
     *     The ADDRESS3
     */
    @JsonProperty("ADDRESS3")
    public void setADDRESS3(String aDDRESS3) {
        this.aDDRESS3 = aDDRESS3;
    }

    /**
     * 
     * @return
     *     The aDDRESS1
     */
    @JsonProperty("ADDRESS1")
    public String getADDRESS1() {
        return aDDRESS1;
    }

    /**
     * 
     * @param aDDRESS1
     *     The ADDRESS1
     */
    @JsonProperty("ADDRESS1")
    public void setADDRESS1(String aDDRESS1) {
        this.aDDRESS1 = aDDRESS1;
    }

    /**
     * 
     * @return
     *     The m1WINDOWMODEFLG
     */
    @JsonProperty("M1_WINDOW_MODE_FLG")
    public String getM1WINDOWMODEFLG() {
        return m1WINDOWMODEFLG;
    }

    /**
     * 
     * @param m1WINDOWMODEFLG
     *     The M1_WINDOW_MODE_FLG
     */
    @JsonProperty("M1_WINDOW_MODE_FLG")
    public void setM1WINDOWMODEFLG(String m1WINDOWMODEFLG) {
        this.m1WINDOWMODEFLG = m1WINDOWMODEFLG;
    }

    /**
     * 
     * @return
     *     The m1REVIEWEDLBL
     */
    @JsonProperty("M1_REVIEWED_LBL")
    public String getM1REVIEWEDLBL() {
        return m1REVIEWEDLBL;
    }

    /**
     * 
     * @param m1REVIEWEDLBL
     *     The M1_REVIEWED_LBL
     */
    @JsonProperty("M1_REVIEWED_LBL")
    public void setM1REVIEWEDLBL(String m1REVIEWEDLBL) {
        this.m1REVIEWEDLBL = m1REVIEWEDLBL;
    }

    /**
     * 
     * @return
     *     The eXTCAPTYPECD
     */
    @JsonProperty("EXT_CAP_TYPE_CD")
    public String getEXTCAPTYPECD() {
        return eXTCAPTYPECD;
    }

    /**
     * 
     * @param eXTCAPTYPECD
     *     The EXT_CAP_TYPE_CD
     */
    @JsonProperty("EXT_CAP_TYPE_CD")
    public void setEXTCAPTYPECD(String eXTCAPTYPECD) {
        this.eXTCAPTYPECD = eXTCAPTYPECD;
    }

    /**
     * 
     * @return
     *     The m1POUABBLBL
     */
    @JsonProperty("M1_POUABB_LBL")
    public String getM1POUABBLBL() {
        return m1POUABBLBL;
    }

    /**
     * 
     * @param m1POUABBLBL
     *     The M1_POUABB_LBL
     */
    @JsonProperty("M1_POUABB_LBL")
    public void setM1POUABBLBL(String m1POUABBLBL) {
        this.m1POUABBLBL = m1POUABBLBL;
    }

    /**
     * 
     * @return
     *     The m1NUMOFEXTENSIONS
     */
    @JsonProperty("M1_NUM_OF_EXTENSIONS")
    public String getM1NUMOFEXTENSIONS() {
        return m1NUMOFEXTENSIONS;
    }

    /**
     * 
     * @param m1NUMOFEXTENSIONS
     *     The M1_NUM_OF_EXTENSIONS
     */
    @JsonProperty("M1_NUM_OF_EXTENSIONS")
    public void setM1NUMOFEXTENSIONS(String m1NUMOFEXTENSIONS) {
        this.m1NUMOFEXTENSIONS = m1NUMOFEXTENSIONS;
    }

    /**
     * 
     * @return
     *     The m1STATUSREASONUSAGEFLG
     */
    @JsonProperty("M1_STATUS_REASON_USAGE_FLG")
    public String getM1STATUSREASONUSAGEFLG() {
        return m1STATUSREASONUSAGEFLG;
    }

    /**
     * 
     * @param m1STATUSREASONUSAGEFLG
     *     The M1_STATUS_REASON_USAGE_FLG
     */
    @JsonProperty("M1_STATUS_REASON_USAGE_FLG")
    public void setM1STATUSREASONUSAGEFLG(String m1STATUSREASONUSAGEFLG) {
        this.m1STATUSREASONUSAGEFLG = m1STATUSREASONUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The m1COMMONATTACHMENT
     */
    @JsonProperty("M1_COMMON_ATTACHMENT")
    public String getM1COMMONATTACHMENT() {
        return m1COMMONATTACHMENT;
    }

    /**
     * 
     * @param m1COMMONATTACHMENT
     *     The M1_COMMON_ATTACHMENT
     */
    @JsonProperty("M1_COMMON_ATTACHMENT")
    public void setM1COMMONATTACHMENT(String m1COMMONATTACHMENT) {
        this.m1COMMONATTACHMENT = m1COMMONATTACHMENT;
    }

    /**
     * 
     * @return
     *     The m1RESPONSETIMESLA
     */
    @JsonProperty("M1_RESPONSE_TIME_SLA")
    public String getM1RESPONSETIMESLA() {
        return m1RESPONSETIMESLA;
    }

    /**
     * 
     * @param m1RESPONSETIMESLA
     *     The M1_RESPONSE_TIME_SLA
     */
    @JsonProperty("M1_RESPONSE_TIME_SLA")
    public void setM1RESPONSETIMESLA(String m1RESPONSETIMESLA) {
        this.m1RESPONSETIMESLA = m1RESPONSETIMESLA;
    }

    /**
     * 
     * @return
     *     The aDDRESS4
     */
    @JsonProperty("ADDRESS4")
    public String getADDRESS4() {
        return aDDRESS4;
    }

    /**
     * 
     * @param aDDRESS4
     *     The ADDRESS4
     */
    @JsonProperty("ADDRESS4")
    public void setADDRESS4(String aDDRESS4) {
        this.aDDRESS4 = aDDRESS4;
    }

    /**
     * 
     * @return
     *     The m1RESRCNAME
     */
    @JsonProperty("M1_RESRC_NAME")
    public String getM1RESRCNAME() {
        return m1RESRCNAME;
    }

    /**
     * 
     * @param m1RESRCNAME
     *     The M1_RESRC_NAME
     */
    @JsonProperty("M1_RESRC_NAME")
    public void setM1RESRCNAME(String m1RESRCNAME) {
        this.m1RESRCNAME = m1RESRCNAME;
    }

    /**
     * 
     * @return
     *     The m1CITY
     */
    @JsonProperty("M1_CITY")
    public String getM1CITY() {
        return m1CITY;
    }

    /**
     * 
     * @param m1CITY
     *     The M1_CITY
     */
    @JsonProperty("M1_CITY")
    public void setM1CITY(String m1CITY) {
        this.m1CITY = m1CITY;
    }

    /**
     * 
     * @return
     *     The m1RESERVECAPPERCENT
     */
    @JsonProperty("M1_RESERVE_CAP_PERCENT")
    public String getM1RESERVECAPPERCENT() {
        return m1RESERVECAPPERCENT;
    }

    /**
     * 
     * @param m1RESERVECAPPERCENT
     *     The M1_RESERVE_CAP_PERCENT
     */
    @JsonProperty("M1_RESERVE_CAP_PERCENT")
    public void setM1RESERVECAPPERCENT(String m1RESERVECAPPERCENT) {
        this.m1RESERVECAPPERCENT = m1RESERVECAPPERCENT;
    }

    /**
     * 
     * @return
     *     The m1POSTPONETIME
     */
    @JsonProperty("M1_POSTPONE_TIME")
    public String getM1POSTPONETIME() {
        return m1POSTPONETIME;
    }

    /**
     * 
     * @param m1POSTPONETIME
     *     The M1_POSTPONE_TIME
     */
    @JsonProperty("M1_POSTPONE_TIME")
    public void setM1POSTPONETIME(String m1POSTPONETIME) {
        this.m1POSTPONETIME = m1POSTPONETIME;
    }

    /**
     * 
     * @return
     *     The m1CRSHTROUTELBL
     */
    @JsonProperty("M1_CRSHT_ROUTE_LBL")
    public String getM1CRSHTROUTELBL() {
        return m1CRSHTROUTELBL;
    }

    /**
     * 
     * @param m1CRSHTROUTELBL
     *     The M1_CRSHT_ROUTE_LBL
     */
    @JsonProperty("M1_CRSHT_ROUTE_LBL")
    public void setM1CRSHTROUTELBL(String m1CRSHTROUTELBL) {
        this.m1CRSHTROUTELBL = m1CRSHTROUTELBL;
    }

    /**
     * 
     * @return
     *     The m1TIMELIMIT
     */
    @JsonProperty("M1_TIME_LIMIT")
    public String getM1TIMELIMIT() {
        return m1TIMELIMIT;
    }

    /**
     * 
     * @param m1TIMELIMIT
     *     The M1_TIME_LIMIT
     */
    @JsonProperty("M1_TIME_LIMIT")
    public void setM1TIMELIMIT(String m1TIMELIMIT) {
        this.m1TIMELIMIT = m1TIMELIMIT;
    }

    /**
     * 
     * @return
     *     The eXTSYSTYPFLG
     */
    @JsonProperty("EXT_SYS_TYP_FLG")
    public String getEXTSYSTYPFLG() {
        return eXTSYSTYPFLG;
    }

    /**
     * 
     * @param eXTSYSTYPFLG
     *     The EXT_SYS_TYP_FLG
     */
    @JsonProperty("EXT_SYS_TYP_FLG")
    public void setEXTSYSTYPFLG(String eXTSYSTYPFLG) {
        this.eXTSYSTYPFLG = eXTSYSTYPFLG;
    }

    /**
     * 
     * @return
     *     The m1SCANANYLBL
     */
    @JsonProperty("M1_SCAN_ANY_LBL")
    public String getM1SCANANYLBL() {
        return m1SCANANYLBL;
    }

    /**
     * 
     * @param m1SCANANYLBL
     *     The M1_SCAN_ANY_LBL
     */
    @JsonProperty("M1_SCAN_ANY_LBL")
    public void setM1SCANANYLBL(String m1SCANANYLBL) {
        this.m1SCANANYLBL = m1SCANANYLBL;
    }

    /**
     * 
     * @return
     *     The m1RETURNEDLBL
     */
    @JsonProperty("M1_RETURNED_LBL")
    public String getM1RETURNEDLBL() {
        return m1RETURNEDLBL;
    }

    /**
     * 
     * @param m1RETURNEDLBL
     *     The M1_RETURNED_LBL
     */
    @JsonProperty("M1_RETURNED_LBL")
    public void setM1RETURNEDLBL(String m1RETURNEDLBL) {
        this.m1RETURNEDLBL = m1RETURNEDLBL;
    }

    /**
     * 
     * @return
     *     The m1MAXOFFSET
     */
    @JsonProperty("M1_MAX_OFFSET")
    public String getM1MAXOFFSET() {
        return m1MAXOFFSET;
    }

    /**
     * 
     * @param m1MAXOFFSET
     *     The M1_MAX_OFFSET
     */
    @JsonProperty("M1_MAX_OFFSET")
    public void setM1MAXOFFSET(String m1MAXOFFSET) {
        this.m1MAXOFFSET = m1MAXOFFSET;
    }

    /**
     * 
     * @return
     *     The cHARVAL
     */
    @JsonProperty("CHAR_VAL")
    public String getCHARVAL() {
        return cHARVAL;
    }

    /**
     * 
     * @param cHARVAL
     *     The CHAR_VAL
     */
    @JsonProperty("CHAR_VAL")
    public void setCHARVAL(String cHARVAL) {
        this.cHARVAL = cHARVAL;
    }

    /**
     * 
     * @return
     *     The m1POSTAL
     */
    @JsonProperty("M1_POSTAL")
    public String getM1POSTAL() {
        return m1POSTAL;
    }

    /**
     * 
     * @param m1POSTAL
     *     The M1_POSTAL
     */
    @JsonProperty("M1_POSTAL")
    public void setM1POSTAL(String m1POSTAL) {
        this.m1POSTAL = m1POSTAL;
    }

    /**
     * 
     * @return
     *     The m1UPTOBUSPRIVAL
     */
    @JsonProperty("M1_UPTO_BUS_PRI_VAL")
    public String getM1UPTOBUSPRIVAL() {
        return m1UPTOBUSPRIVAL;
    }

    /**
     * 
     * @param m1UPTOBUSPRIVAL
     *     The M1_UPTO_BUS_PRI_VAL
     */
    @JsonProperty("M1_UPTO_BUS_PRI_VAL")
    public void setM1UPTOBUSPRIVAL(String m1UPTOBUSPRIVAL) {
        this.m1UPTOBUSPRIVAL = m1UPTOBUSPRIVAL;
    }

    /**
     * 
     * @return
     *     The m1PREVIEWTASKLISTLBL
     */
    @JsonProperty("M1_PREVIEW_TASK_LIST_LBL")
    public String getM1PREVIEWTASKLISTLBL() {
        return m1PREVIEWTASKLISTLBL;
    }

    /**
     * 
     * @param m1PREVIEWTASKLISTLBL
     *     The M1_PREVIEW_TASK_LIST_LBL
     */
    @JsonProperty("M1_PREVIEW_TASK_LIST_LBL")
    public void setM1PREVIEWTASKLISTLBL(String m1PREVIEWTASKLISTLBL) {
        this.m1PREVIEWTASKLISTLBL = m1PREVIEWTASKLISTLBL;
    }

    /**
     * 
     * @return
     *     The m1ALLOWEARNINGTIMEFLG
     */
    @JsonProperty("M1_ALLOW_EARNING_TIME_FLG")
    public String getM1ALLOWEARNINGTIMEFLG() {
        return m1ALLOWEARNINGTIMEFLG;
    }

    /**
     * 
     * @param m1ALLOWEARNINGTIMEFLG
     *     The M1_ALLOW_EARNING_TIME_FLG
     */
    @JsonProperty("M1_ALLOW_EARNING_TIME_FLG")
    public void setM1ALLOWEARNINGTIMEFLG(String m1ALLOWEARNINGTIMEFLG) {
        this.m1ALLOWEARNINGTIMEFLG = m1ALLOWEARNINGTIMEFLG;
    }

    /**
     * 
     * @return
     *     The eRRORMSG
     */
    @JsonProperty("ERROR_MSG")
    public String getERRORMSG() {
        return eRRORMSG;
    }

    /**
     * 
     * @param eRRORMSG
     *     The ERROR_MSG
     */
    @JsonProperty("ERROR_MSG")
    public void setERRORMSG(String eRRORMSG) {
        this.eRRORMSG = eRRORMSG;
    }

    /**
     * 
     * @return
     *     The sHFTCOPRFCD
     */
    @JsonProperty("SHFT_COPRF_CD")
    public String getSHFTCOPRFCD() {
        return sHFTCOPRFCD;
    }

    /**
     * 
     * @param sHFTCOPRFCD
     *     The SHFT_COPRF_CD
     */
    @JsonProperty("SHFT_COPRF_CD")
    public void setSHFTCOPRFCD(String sHFTCOPRFCD) {
        this.sHFTCOPRFCD = sHFTCOPRFCD;
    }

    /**
     * 
     * @return
     *     The m1SORTSEQUENCE
     */
    @JsonProperty("M1_SORT_SEQUENCE")
    public String getM1SORTSEQUENCE() {
        return m1SORTSEQUENCE;
    }

    /**
     * 
     * @param m1SORTSEQUENCE
     *     The M1_SORT_SEQUENCE
     */
    @JsonProperty("M1_SORT_SEQUENCE")
    public void setM1SORTSEQUENCE(String m1SORTSEQUENCE) {
        this.m1SORTSEQUENCE = m1SORTSEQUENCE;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYCOMMENTS
     */
    @JsonProperty("M1_ACTIVITY_COMMENTS")
    public String getM1ACTIVITYCOMMENTS() {
        return m1ACTIVITYCOMMENTS;
    }

    /**
     * 
     * @param m1ACTIVITYCOMMENTS
     *     The M1_ACTIVITY_COMMENTS
     */
    @JsonProperty("M1_ACTIVITY_COMMENTS")
    public void setM1ACTIVITYCOMMENTS(String m1ACTIVITYCOMMENTS) {
        this.m1ACTIVITYCOMMENTS = m1ACTIVITYCOMMENTS;
    }

    /**
     * 
     * @return
     *     The eNROUTEDTTM
     */
    @JsonProperty("ENROUTE_DTTM")
    public String getENROUTEDTTM() {
        return eNROUTEDTTM;
    }

    /**
     * 
     * @param eNROUTEDTTM
     *     The ENROUTE_DTTM
     */
    @JsonProperty("ENROUTE_DTTM")
    public void setENROUTEDTTM(String eNROUTEDTTM) {
        this.eNROUTEDTTM = eNROUTEDTTM;
    }

    /**
     * 
     * @return
     *     The m1AUTOALLOCATIONFLG
     */
    @JsonProperty("M1_AUTO_ALLOCATION_FLG")
    public String getM1AUTOALLOCATIONFLG() {
        return m1AUTOALLOCATIONFLG;
    }

    /**
     * 
     * @param m1AUTOALLOCATIONFLG
     *     The M1_AUTO_ALLOCATION_FLG
     */
    @JsonProperty("M1_AUTO_ALLOCATION_FLG")
    public void setM1AUTOALLOCATIONFLG(String m1AUTOALLOCATIONFLG) {
        this.m1AUTOALLOCATIONFLG = m1AUTOALLOCATIONFLG;
    }

    /**
     * 
     * @return
     *     The tIMEWINDOWUSAGEFLG
     */
    @JsonProperty("TIME_WINDOW_USAGE_FLG")
    public String getTIMEWINDOWUSAGEFLG() {
        return tIMEWINDOWUSAGEFLG;
    }

    /**
     * 
     * @param tIMEWINDOWUSAGEFLG
     *     The TIME_WINDOW_USAGE_FLG
     */
    @JsonProperty("TIME_WINDOW_USAGE_FLG")
    public void setTIMEWINDOWUSAGEFLG(String tIMEWINDOWUSAGEFLG) {
        this.tIMEWINDOWUSAGEFLG = tIMEWINDOWUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The m1LOGONLOCATION
     */
    @JsonProperty("M1_LOGON_LOCATION")
    public String getM1LOGONLOCATION() {
        return m1LOGONLOCATION;
    }

    /**
     * 
     * @param m1LOGONLOCATION
     *     The M1_LOGON_LOCATION
     */
    @JsonProperty("M1_LOGON_LOCATION")
    public void setM1LOGONLOCATION(String m1LOGONLOCATION) {
        this.m1LOGONLOCATION = m1LOGONLOCATION;
    }

    /**
     * 
     * @return
     *     The m1MDTSOUNDDURATION
     */
    @JsonProperty("M1_MDT_SOUND_DURATION")
    public String getM1MDTSOUNDDURATION() {
        return m1MDTSOUNDDURATION;
    }

    /**
     * 
     * @param m1MDTSOUNDDURATION
     *     The M1_MDT_SOUND_DURATION
     */
    @JsonProperty("M1_MDT_SOUND_DURATION")
    public void setM1MDTSOUNDDURATION(String m1MDTSOUNDDURATION) {
        this.m1MDTSOUNDDURATION = m1MDTSOUNDDURATION;
    }

    /**
     * 
     * @return
     *     The bUSOBJCD
     */
    @JsonProperty("BUS_OBJ_CD")
    public String getBUSOBJCD() {
        return bUSOBJCD;
    }

    /**
     * 
     * @param bUSOBJCD
     *     The BUS_OBJ_CD
     */
    @JsonProperty("BUS_OBJ_CD")
    public void setBUSOBJCD(String bUSOBJCD) {
        this.bUSOBJCD = bUSOBJCD;
    }

    /**
     * 
     * @return
     *     The m1REMOVEFROMSHIFTLBL
     */
    @JsonProperty("M1_REMOVE_FROM_SHIFT_LBL")
    public String getM1REMOVEFROMSHIFTLBL() {
        return m1REMOVEFROMSHIFTLBL;
    }

    /**
     * 
     * @param m1REMOVEFROMSHIFTLBL
     *     The M1_REMOVE_FROM_SHIFT_LBL
     */
    @JsonProperty("M1_REMOVE_FROM_SHIFT_LBL")
    public void setM1REMOVEFROMSHIFTLBL(String m1REMOVEFROMSHIFTLBL) {
        this.m1REMOVEFROMSHIFTLBL = m1REMOVEFROMSHIFTLBL;
    }

    /**
     * 
     * @return
     *     The m1TIMINGOPTIONFLG
     */
    @JsonProperty("M1_TIMING_OPTION_FLG")
    public String getM1TIMINGOPTIONFLG() {
        return m1TIMINGOPTIONFLG;
    }

    /**
     * 
     * @param m1TIMINGOPTIONFLG
     *     The M1_TIMING_OPTION_FLG
     */
    @JsonProperty("M1_TIMING_OPTION_FLG")
    public void setM1TIMINGOPTIONFLG(String m1TIMINGOPTIONFLG) {
        this.m1TIMINGOPTIONFLG = m1TIMINGOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1COUNTY
     */
    @JsonProperty("M1_COUNTY")
    public String getM1COUNTY() {
        return m1COUNTY;
    }

    /**
     * 
     * @param m1COUNTY
     *     The M1_COUNTY
     */
    @JsonProperty("M1_COUNTY")
    public void setM1COUNTY(String m1COUNTY) {
        this.m1COUNTY = m1COUNTY;
    }

    /**
     * 
     * @return
     *     The aRRDDTTM
     */
    @JsonProperty("ARRD_DTTM")
    public String getARRDDTTM() {
        return aRRDDTTM;
    }

    /**
     * 
     * @param aRRDDTTM
     *     The ARRD_DTTM
     */
    @JsonProperty("ARRD_DTTM")
    public void setARRDDTTM(String aRRDDTTM) {
        this.aRRDDTTM = aRRDDTTM;
    }

    /**
     * 
     * @return
     *     The m1COMPLETIONTM
     */
    @JsonProperty("M1_COMPLETION_TM")
    public String getM1COMPLETIONTM() {
        return m1COMPLETIONTM;
    }

    /**
     * 
     * @param m1COMPLETIONTM
     *     The M1_COMPLETION_TM
     */
    @JsonProperty("M1_COMPLETION_TM")
    public void setM1COMPLETIONTM(String m1COMPLETIONTM) {
        this.m1COMPLETIONTM = m1COMPLETIONTM;
    }

    /**
     * 
     * @return
     *     The m1SEQNUMWRK
     */
    @JsonProperty("M1_SEQ_NUM_WRK")
    public String getM1SEQNUMWRK() {
        return m1SEQNUMWRK;
    }

    /**
     * 
     * @param m1SEQNUMWRK
     *     The M1_SEQ_NUM_WRK
     */
    @JsonProperty("M1_SEQ_NUM_WRK")
    public void setM1SEQNUMWRK(String m1SEQNUMWRK) {
        this.m1SEQNUMWRK = m1SEQNUMWRK;
    }

    /**
     * 
     * @return
     *     The m1STATUSCLASSANDSHIFTID
     */
    @JsonProperty("M1_STATUSCLASS_AND_SHIFTID")
    public String getM1STATUSCLASSANDSHIFTID() {
        return m1STATUSCLASSANDSHIFTID;
    }

    /**
     * 
     * @param m1STATUSCLASSANDSHIFTID
     *     The M1_STATUSCLASS_AND_SHIFTID
     */
    @JsonProperty("M1_STATUSCLASS_AND_SHIFTID")
    public void setM1STATUSCLASSANDSHIFTID(String m1STATUSCLASSANDSHIFTID) {
        this.m1STATUSCLASSANDSHIFTID = m1STATUSCLASSANDSHIFTID;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKLOADORDERFLG
     */
    @JsonProperty("M1_DEPOT_TASK_LOAD_ORDER_FLG")
    public String getM1DEPOTTASKLOADORDERFLG() {
        return m1DEPOTTASKLOADORDERFLG;
    }

    /**
     * 
     * @param m1DEPOTTASKLOADORDERFLG
     *     The M1_DEPOT_TASK_LOAD_ORDER_FLG
     */
    @JsonProperty("M1_DEPOT_TASK_LOAD_ORDER_FLG")
    public void setM1DEPOTTASKLOADORDERFLG(String m1DEPOTTASKLOADORDERFLG) {
        this.m1DEPOTTASKLOADORDERFLG = m1DEPOTTASKLOADORDERFLG;
    }

    /**
     * 
     * @return
     *     The m1STARTENDODOMETERLBL
     */
    @JsonProperty("M1_STARTEND_ODOMETER_LBL")
    public String getM1STARTENDODOMETERLBL() {
        return m1STARTENDODOMETERLBL;
    }

    /**
     * 
     * @param m1STARTENDODOMETERLBL
     *     The M1_STARTEND_ODOMETER_LBL
     */
    @JsonProperty("M1_STARTEND_ODOMETER_LBL")
    public void setM1STARTENDODOMETERLBL(String m1STARTENDODOMETERLBL) {
        this.m1STARTENDODOMETERLBL = m1STARTENDODOMETERLBL;
    }

    /**
     * 
     * @return
     *     The sTEPPASSVALUE
     */
    @JsonProperty("STEP_PASS_VALUE")
    public String getSTEPPASSVALUE() {
        return sTEPPASSVALUE;
    }

    /**
     * 
     * @param sTEPPASSVALUE
     *     The STEP_PASS_VALUE
     */
    @JsonProperty("STEP_PASS_VALUE")
    public void setSTEPPASSVALUE(String sTEPPASSVALUE) {
        this.sTEPPASSVALUE = sTEPPASSVALUE;
    }

    /**
     * 
     * @return
     *     The m1SCHEDPRIORITY
     */
    @JsonProperty("M1_SCHED_PRIORITY")
    public String getM1SCHEDPRIORITY() {
        return m1SCHEDPRIORITY;
    }

    /**
     * 
     * @param m1SCHEDPRIORITY
     *     The M1_SCHED_PRIORITY
     */
    @JsonProperty("M1_SCHED_PRIORITY")
    public void setM1SCHEDPRIORITY(String m1SCHEDPRIORITY) {
        this.m1SCHEDPRIORITY = m1SCHEDPRIORITY;
    }

    /**
     * 
     * @return
     *     The aUTODISPATCHFLG
     */
    @JsonProperty("AUTO_DISPATCH_FLG")
    public String getAUTODISPATCHFLG() {
        return aUTODISPATCHFLG;
    }

    /**
     * 
     * @param aUTODISPATCHFLG
     *     The AUTO_DISPATCH_FLG
     */
    @JsonProperty("AUTO_DISPATCH_FLG")
    public void setAUTODISPATCHFLG(String aUTODISPATCHFLG) {
        this.aUTODISPATCHFLG = aUTODISPATCHFLG;
    }

    /**
     * 
     * @return
     *     The mESSAGENBR
     */
    @JsonProperty("MESSAGE_NBR")
    public String getMESSAGENBR() {
        return mESSAGENBR;
    }

    /**
     * 
     * @param mESSAGENBR
     *     The MESSAGE_NBR
     */
    @JsonProperty("MESSAGE_NBR")
    public void setMESSAGENBR(String mESSAGENBR) {
        this.mESSAGENBR = mESSAGENBR;
    }

    /**
     * 
     * @return
     *     The m1INQUIRYHISTORYLBL
     */
    @JsonProperty("M1_INQUIRY_HISTORY_LBL")
    public String getM1INQUIRYHISTORYLBL() {
        return m1INQUIRYHISTORYLBL;
    }

    /**
     * 
     * @param m1INQUIRYHISTORYLBL
     *     The M1_INQUIRY_HISTORY_LBL
     */
    @JsonProperty("M1_INQUIRY_HISTORY_LBL")
    public void setM1INQUIRYHISTORYLBL(String m1INQUIRYHISTORYLBL) {
        this.m1INQUIRYHISTORYLBL = m1INQUIRYHISTORYLBL;
    }

    /**
     * 
     * @return
     *     The m1SENTLBL
     */
    @JsonProperty("M1_SENT_LBL")
    public String getM1SENTLBL() {
        return m1SENTLBL;
    }

    /**
     * 
     * @param m1SENTLBL
     *     The M1_SENT_LBL
     */
    @JsonProperty("M1_SENT_LBL")
    public void setM1SENTLBL(String m1SENTLBL) {
        this.m1SENTLBL = m1SENTLBL;
    }

    /**
     * 
     * @return
     *     The m1ACTUALCOMDTTM
     */
    @JsonProperty("M1_ACTUAL_COM_DTTM")
    public String getM1ACTUALCOMDTTM() {
        return m1ACTUALCOMDTTM;
    }

    /**
     * 
     * @param m1ACTUALCOMDTTM
     *     The M1_ACTUAL_COM_DTTM
     */
    @JsonProperty("M1_ACTUAL_COM_DTTM")
    public void setM1ACTUALCOMDTTM(String m1ACTUALCOMDTTM) {
        this.m1ACTUALCOMDTTM = m1ACTUALCOMDTTM;
    }

    /**
     * 
     * @return
     *     The m1APPTREQFLG
     */
    @JsonProperty("M1_APPT_REQ_FLG")
    public String getM1APPTREQFLG() {
        return m1APPTREQFLG;
    }

    /**
     * 
     * @param m1APPTREQFLG
     *     The M1_APPT_REQ_FLG
     */
    @JsonProperty("M1_APPT_REQ_FLG")
    public void setM1APPTREQFLG(String m1APPTREQFLG) {
        this.m1APPTREQFLG = m1APPTREQFLG;
    }

    /**
     * 
     * @return
     *     The m1SOUNDPAUSE
     */
    @JsonProperty("M1_SOUND_PAUSE")
    public String getM1SOUNDPAUSE() {
        return m1SOUNDPAUSE;
    }

    /**
     * 
     * @param m1SOUNDPAUSE
     *     The M1_SOUND_PAUSE
     */
    @JsonProperty("M1_SOUND_PAUSE")
    public void setM1SOUNDPAUSE(String m1SOUNDPAUSE) {
        this.m1SOUNDPAUSE = m1SOUNDPAUSE;
    }

    /**
     * 
     * @return
     *     The m1RELATEDPICKUPSEXISTSW
     */
    @JsonProperty("M1_RELATED_PICKUPS_EXIST_SW")
    public String getM1RELATEDPICKUPSEXISTSW() {
        return m1RELATEDPICKUPSEXISTSW;
    }

    /**
     * 
     * @param m1RELATEDPICKUPSEXISTSW
     *     The M1_RELATED_PICKUPS_EXIST_SW
     */
    @JsonProperty("M1_RELATED_PICKUPS_EXIST_SW")
    public void setM1RELATEDPICKUPSEXISTSW(String m1RELATEDPICKUPSEXISTSW) {
        this.m1RELATEDPICKUPSEXISTSW = m1RELATEDPICKUPSEXISTSW;
    }

    /**
     * 
     * @return
     *     The m1AFTERDURATION
     */
    @JsonProperty("M1_AFTER_DURATION")
    public String getM1AFTERDURATION() {
        return m1AFTERDURATION;
    }

    /**
     * 
     * @param m1AFTERDURATION
     *     The M1_AFTER_DURATION
     */
    @JsonProperty("M1_AFTER_DURATION")
    public void setM1AFTERDURATION(String m1AFTERDURATION) {
        this.m1AFTERDURATION = m1AFTERDURATION;
    }

    /**
     * 
     * @return
     *     The m1MARKALLASLOADEDLBL
     */
    @JsonProperty("M1_MARK_ALL_AS_LOADED_LBL")
    public String getM1MARKALLASLOADEDLBL() {
        return m1MARKALLASLOADEDLBL;
    }

    /**
     * 
     * @param m1MARKALLASLOADEDLBL
     *     The M1_MARK_ALL_AS_LOADED_LBL
     */
    @JsonProperty("M1_MARK_ALL_AS_LOADED_LBL")
    public void setM1MARKALLASLOADEDLBL(String m1MARKALLASLOADEDLBL) {
        this.m1MARKALLASLOADEDLBL = m1MARKALLASLOADEDLBL;
    }

    /**
     * 
     * @return
     *     The m1NOTLOADEDLBL
     */
    @JsonProperty("M1_NOT_LOADED_LBL")
    public String getM1NOTLOADEDLBL() {
        return m1NOTLOADEDLBL;
    }

    /**
     * 
     * @param m1NOTLOADEDLBL
     *     The M1_NOT_LOADED_LBL
     */
    @JsonProperty("M1_NOT_LOADED_LBL")
    public void setM1NOTLOADEDLBL(String m1NOTLOADEDLBL) {
        this.m1NOTLOADEDLBL = m1NOTLOADEDLBL;
    }

    /**
     * 
     * @return
     *     The m1MAXCAPACITYFLG
     */
    @JsonProperty("M1_MAX_CAPACITY_FLG")
    public String getM1MAXCAPACITYFLG() {
        return m1MAXCAPACITYFLG;
    }

    /**
     * 
     * @param m1MAXCAPACITYFLG
     *     The M1_MAX_CAPACITY_FLG
     */
    @JsonProperty("M1_MAX_CAPACITY_FLG")
    public void setM1MAXCAPACITYFLG(String m1MAXCAPACITYFLG) {
        this.m1MAXCAPACITYFLG = m1MAXCAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1ALERTSENTLBL
     */
    @JsonProperty("M1_ALERT_SENT_LBL")
    public String getM1ALERTSENTLBL() {
        return m1ALERTSENTLBL;
    }

    /**
     * 
     * @param m1ALERTSENTLBL
     *     The M1_ALERT_SENT_LBL
     */
    @JsonProperty("M1_ALERT_SENT_LBL")
    public void setM1ALERTSENTLBL(String m1ALERTSENTLBL) {
        this.m1ALERTSENTLBL = m1ALERTSENTLBL;
    }

    /**
     * 
     * @return
     *     The mDTCAPABILITYIMAGE
     */
    @JsonProperty("MDT_CAPABILITY_IMAGE")
    public String getMDTCAPABILITYIMAGE() {
        return mDTCAPABILITYIMAGE;
    }

    /**
     * 
     * @param mDTCAPABILITYIMAGE
     *     The MDT_CAPABILITY_IMAGE
     */
    @JsonProperty("MDT_CAPABILITY_IMAGE")
    public void setMDTCAPABILITYIMAGE(String mDTCAPABILITYIMAGE) {
        this.mDTCAPABILITYIMAGE = mDTCAPABILITYIMAGE;
    }

    /**
     * 
     * @return
     *     The iNSTR
     */
    @JsonProperty("INSTR")
    public String getINSTR() {
        return iNSTR;
    }

    /**
     * 
     * @param iNSTR
     *     The INSTR
     */
    @JsonProperty("INSTR")
    public void setINSTR(String iNSTR) {
        this.iNSTR = iNSTR;
    }

    /**
     * 
     * @return
     *     The f1EXTLOOKUPUSAGEFLG
     */
    @JsonProperty("F1_EXT_LOOKUP_USAGE_FLG")
    public String getF1EXTLOOKUPUSAGEFLG() {
        return f1EXTLOOKUPUSAGEFLG;
    }

    /**
     * 
     * @param f1EXTLOOKUPUSAGEFLG
     *     The F1_EXT_LOOKUP_USAGE_FLG
     */
    @JsonProperty("F1_EXT_LOOKUP_USAGE_FLG")
    public void setF1EXTLOOKUPUSAGEFLG(String f1EXTLOOKUPUSAGEFLG) {
        this.f1EXTLOOKUPUSAGEFLG = f1EXTLOOKUPUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The cOUNTY
     */
    @JsonProperty("COUNTY")
    public String getCOUNTY() {
        return cOUNTY;
    }

    /**
     * 
     * @param cOUNTY
     *     The COUNTY
     */
    @JsonProperty("COUNTY")
    public void setCOUNTY(String cOUNTY) {
        this.cOUNTY = cOUNTY;
    }

    /**
     * 
     * @return
     *     The m1POUTASKBO
     */
    @JsonProperty("M1_POU_TASK_BO")
    public String getM1POUTASKBO() {
        return m1POUTASKBO;
    }

    /**
     * 
     * @param m1POUTASKBO
     *     The M1_POU_TASK_BO
     */
    @JsonProperty("M1_POU_TASK_BO")
    public void setM1POUTASKBO(String m1POUTASKBO) {
        this.m1POUTASKBO = m1POUTASKBO;
    }

    /**
     * 
     * @return
     *     The m1WINDSTDTTM
     */
    @JsonProperty("M1_WIND_ST_DTTM")
    public String getM1WINDSTDTTM() {
        return m1WINDSTDTTM;
    }

    /**
     * 
     * @param m1WINDSTDTTM
     *     The M1_WIND_ST_DTTM
     */
    @JsonProperty("M1_WIND_ST_DTTM")
    public void setM1WINDSTDTTM(String m1WINDSTDTTM) {
        this.m1WINDSTDTTM = m1WINDSTDTTM;
    }

    /**
     * 
     * @return
     *     The m1OVERRIDDENFLIPSWLBL
     */
    @JsonProperty("M1_OVERRIDDEN_FLIPSW_LBL")
    public String getM1OVERRIDDENFLIPSWLBL() {
        return m1OVERRIDDENFLIPSWLBL;
    }

    /**
     * 
     * @param m1OVERRIDDENFLIPSWLBL
     *     The M1_OVERRIDDEN_FLIPSW_LBL
     */
    @JsonProperty("M1_OVERRIDDEN_FLIPSW_LBL")
    public void setM1OVERRIDDENFLIPSWLBL(String m1OVERRIDDENFLIPSWLBL) {
        this.m1OVERRIDDENFLIPSWLBL = m1OVERRIDDENFLIPSWLBL;
    }

    /**
     * 
     * @return
     *     The mAILID
     */
    @JsonProperty("MAIL_ID")
    public String getMAILID() {
        return mAILID;
    }

    /**
     * 
     * @param mAILID
     *     The MAIL_ID
     */
    @JsonProperty("MAIL_ID")
    public void setMAILID(String mAILID) {
        this.mAILID = mAILID;
    }

    /**
     * 
     * @return
     *     The m1PARENTASSIGNMENTID
     */
    @JsonProperty("M1_PARENT_ASSIGNMENT_ID")
    public String getM1PARENTASSIGNMENTID() {
        return m1PARENTASSIGNMENTID;
    }

    /**
     * 
     * @param m1PARENTASSIGNMENTID
     *     The M1_PARENT_ASSIGNMENT_ID
     */
    @JsonProperty("M1_PARENT_ASSIGNMENT_ID")
    public void setM1PARENTASSIGNMENTID(String m1PARENTASSIGNMENTID) {
        this.m1PARENTASSIGNMENTID = m1PARENTASSIGNMENTID;
    }

    /**
     * 
     * @return
     *     The m1FILTERITEMSLBL
     */
    @JsonProperty("M1_FILTER_ITEMS_LBL")
    public String getM1FILTERITEMSLBL() {
        return m1FILTERITEMSLBL;
    }

    /**
     * 
     * @param m1FILTERITEMSLBL
     *     The M1_FILTER_ITEMS_LBL
     */
    @JsonProperty("M1_FILTER_ITEMS_LBL")
    public void setM1FILTERITEMSLBL(String m1FILTERITEMSLBL) {
        this.m1FILTERITEMSLBL = m1FILTERITEMSLBL;
    }

    /**
     * 
     * @return
     *     The rOUNDSTARTTIMEOPTFLG
     */
    @JsonProperty("ROUND_START_TIME_OPT_FLG")
    public String getROUNDSTARTTIMEOPTFLG() {
        return rOUNDSTARTTIMEOPTFLG;
    }

    /**
     * 
     * @param rOUNDSTARTTIMEOPTFLG
     *     The ROUND_START_TIME_OPT_FLG
     */
    @JsonProperty("ROUND_START_TIME_OPT_FLG")
    public void setROUNDSTARTTIMEOPTFLG(String rOUNDSTARTTIMEOPTFLG) {
        this.rOUNDSTARTTIMEOPTFLG = rOUNDSTARTTIMEOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1VIEWACTPRCDRLBL
     */
    @JsonProperty("M1_VIEW_ACT_PRCDR_LBL")
    public String getM1VIEWACTPRCDRLBL() {
        return m1VIEWACTPRCDRLBL;
    }

    /**
     * 
     * @param m1VIEWACTPRCDRLBL
     *     The M1_VIEW_ACT_PRCDR_LBL
     */
    @JsonProperty("M1_VIEW_ACT_PRCDR_LBL")
    public void setM1VIEWACTPRCDRLBL(String m1VIEWACTPRCDRLBL) {
        this.m1VIEWACTPRCDRLBL = m1VIEWACTPRCDRLBL;
    }

    /**
     * 
     * @return
     *     The m1SAVEBTNLBL
     */
    @JsonProperty("M1_SAVE_BTN_LBL")
    public String getM1SAVEBTNLBL() {
        return m1SAVEBTNLBL;
    }

    /**
     * 
     * @param m1SAVEBTNLBL
     *     The M1_SAVE_BTN_LBL
     */
    @JsonProperty("M1_SAVE_BTN_LBL")
    public void setM1SAVEBTNLBL(String m1SAVEBTNLBL) {
        this.m1SAVEBTNLBL = m1SAVEBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1FILEAPPENDERLBL
     */
    @JsonProperty("M1_FILE_APPENDER_LBL")
    public String getM1FILEAPPENDERLBL() {
        return m1FILEAPPENDERLBL;
    }

    /**
     * 
     * @param m1FILEAPPENDERLBL
     *     The M1_FILE_APPENDER_LBL
     */
    @JsonProperty("M1_FILE_APPENDER_LBL")
    public void setM1FILEAPPENDERLBL(String m1FILEAPPENDERLBL) {
        this.m1FILEAPPENDERLBL = m1FILEAPPENDERLBL;
    }

    /**
     * 
     * @return
     *     The m1SITEINSTRUCTIONS
     */
    @JsonProperty("M1_SITE_INSTRUCTIONS")
    public String getM1SITEINSTRUCTIONS() {
        return m1SITEINSTRUCTIONS;
    }

    /**
     * 
     * @param m1SITEINSTRUCTIONS
     *     The M1_SITE_INSTRUCTIONS
     */
    @JsonProperty("M1_SITE_INSTRUCTIONS")
    public void setM1SITEINSTRUCTIONS(String m1SITEINSTRUCTIONS) {
        this.m1SITEINSTRUCTIONS = m1SITEINSTRUCTIONS;
    }

    /**
     * 
     * @return
     *     The m1BRKWINDOWDUR
     */
    @JsonProperty("M1_BRK_WINDOW_DUR")
    public String getM1BRKWINDOWDUR() {
        return m1BRKWINDOWDUR;
    }

    /**
     * 
     * @param m1BRKWINDOWDUR
     *     The M1_BRK_WINDOW_DUR
     */
    @JsonProperty("M1_BRK_WINDOW_DUR")
    public void setM1BRKWINDOWDUR(String m1BRKWINDOWDUR) {
        this.m1BRKWINDOWDUR = m1BRKWINDOWDUR;
    }

    /**
     * 
     * @return
     *     The sTARTEDDTTM
     */
    @JsonProperty("STARTED_DTTM")
    public String getSTARTEDDTTM() {
        return sTARTEDDTTM;
    }

    /**
     * 
     * @param sTARTEDDTTM
     *     The STARTED_DTTM
     */
    @JsonProperty("STARTED_DTTM")
    public void setSTARTEDDTTM(String sTARTEDDTTM) {
        this.sTARTEDDTTM = sTARTEDDTTM;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITIESFORDEPOTLBL
     */
    @JsonProperty("M1_ACTIVITIES_FOR_DEPOT_LBL")
    public String getM1ACTIVITIESFORDEPOTLBL() {
        return m1ACTIVITIESFORDEPOTLBL;
    }

    /**
     * 
     * @param m1ACTIVITIESFORDEPOTLBL
     *     The M1_ACTIVITIES_FOR_DEPOT_LBL
     */
    @JsonProperty("M1_ACTIVITIES_FOR_DEPOT_LBL")
    public void setM1ACTIVITIESFORDEPOTLBL(String m1ACTIVITIESFORDEPOTLBL) {
        this.m1ACTIVITIESFORDEPOTLBL = m1ACTIVITIESFORDEPOTLBL;
    }

    /**
     * 
     * @return
     *     The m1FINALIZEDDTTM
     */
    @JsonProperty("M1_FINALIZED_DTTM")
    public String getM1FINALIZEDDTTM() {
        return m1FINALIZEDDTTM;
    }

    /**
     * 
     * @param m1FINALIZEDDTTM
     *     The M1_FINALIZED_DTTM
     */
    @JsonProperty("M1_FINALIZED_DTTM")
    public void setM1FINALIZEDDTTM(String m1FINALIZEDDTTM) {
        this.m1FINALIZEDDTTM = m1FINALIZEDDTTM;
    }

    /**
     * 
     * @return
     *     The m1DEPENDENCYTYPEFLG
     */
    @JsonProperty("M1_DEPENDENCY_TYPE_FLG")
    public String getM1DEPENDENCYTYPEFLG() {
        return m1DEPENDENCYTYPEFLG;
    }

    /**
     * 
     * @param m1DEPENDENCYTYPEFLG
     *     The M1_DEPENDENCY_TYPE_FLG
     */
    @JsonProperty("M1_DEPENDENCY_TYPE_FLG")
    public void setM1DEPENDENCYTYPEFLG(String m1DEPENDENCYTYPEFLG) {
        this.m1DEPENDENCYTYPEFLG = m1DEPENDENCYTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMCOMPLETIONCOMMENTS
     */
    @JsonProperty("M1_ITEM_COMPLETION_COMMENTS")
    public String getM1ITEMCOMPLETIONCOMMENTS() {
        return m1ITEMCOMPLETIONCOMMENTS;
    }

    /**
     * 
     * @param m1ITEMCOMPLETIONCOMMENTS
     *     The M1_ITEM_COMPLETION_COMMENTS
     */
    @JsonProperty("M1_ITEM_COMPLETION_COMMENTS")
    public void setM1ITEMCOMPLETIONCOMMENTS(String m1ITEMCOMPLETIONCOMMENTS) {
        this.m1ITEMCOMPLETIONCOMMENTS = m1ITEMCOMPLETIONCOMMENTS;
    }

    /**
     * 
     * @return
     *     The m1PANICALERTCOUNTDOWN
     */
    @JsonProperty("M1_PANIC_ALERT_COUNT_DOWN")
    public String getM1PANICALERTCOUNTDOWN() {
        return m1PANICALERTCOUNTDOWN;
    }

    /**
     * 
     * @param m1PANICALERTCOUNTDOWN
     *     The M1_PANIC_ALERT_COUNT_DOWN
     */
    @JsonProperty("M1_PANIC_ALERT_COUNT_DOWN")
    public void setM1PANICALERTCOUNTDOWN(String m1PANICALERTCOUNTDOWN) {
        this.m1PANICALERTCOUNTDOWN = m1PANICALERTCOUNTDOWN;
    }

    /**
     * 
     * @return
     *     The m1SLAFLEXIBILITY
     */
    @JsonProperty("M1_SLA_FLEXIBILITY")
    public String getM1SLAFLEXIBILITY() {
        return m1SLAFLEXIBILITY;
    }

    /**
     * 
     * @param m1SLAFLEXIBILITY
     *     The M1_SLA_FLEXIBILITY
     */
    @JsonProperty("M1_SLA_FLEXIBILITY")
    public void setM1SLAFLEXIBILITY(String m1SLAFLEXIBILITY) {
        this.m1SLAFLEXIBILITY = m1SLAFLEXIBILITY;
    }

    /**
     * 
     * @return
     *     The m1SERVERPROXYPORT
     */
    @JsonProperty("M1_SERVER_PROXY_PORT")
    public String getM1SERVERPROXYPORT() {
        return m1SERVERPROXYPORT;
    }

    /**
     * 
     * @param m1SERVERPROXYPORT
     *     The M1_SERVER_PROXY_PORT
     */
    @JsonProperty("M1_SERVER_PROXY_PORT")
    public void setM1SERVERPROXYPORT(String m1SERVERPROXYPORT) {
        this.m1SERVERPROXYPORT = m1SERVERPROXYPORT;
    }

    /**
     * 
     * @return
     *     The m1HIGHCORRLIMIT
     */
    @JsonProperty("M1_HIGH_CORR_LIMIT")
    public String getM1HIGHCORRLIMIT() {
        return m1HIGHCORRLIMIT;
    }

    /**
     * 
     * @param m1HIGHCORRLIMIT
     *     The M1_HIGH_CORR_LIMIT
     */
    @JsonProperty("M1_HIGH_CORR_LIMIT")
    public void setM1HIGHCORRLIMIT(String m1HIGHCORRLIMIT) {
        this.m1HIGHCORRLIMIT = m1HIGHCORRLIMIT;
    }

    /**
     * 
     * @return
     *     The m1NOLBL
     */
    @JsonProperty("M1_NO_LBL")
    public String getM1NOLBL() {
        return m1NOLBL;
    }

    /**
     * 
     * @param m1NOLBL
     *     The M1_NO_LBL
     */
    @JsonProperty("M1_NO_LBL")
    public void setM1NOLBL(String m1NOLBL) {
        this.m1NOLBL = m1NOLBL;
    }

    /**
     * 
     * @return
     *     The m1IGNORESEQLOCKFLG
     */
    @JsonProperty("M1_IGNORE_SEQ_LOCK_FLG")
    public String getM1IGNORESEQLOCKFLG() {
        return m1IGNORESEQLOCKFLG;
    }

    /**
     * 
     * @param m1IGNORESEQLOCKFLG
     *     The M1_IGNORE_SEQ_LOCK_FLG
     */
    @JsonProperty("M1_IGNORE_SEQ_LOCK_FLG")
    public void setM1IGNORESEQLOCKFLG(String m1IGNORESEQLOCKFLG) {
        this.m1IGNORESEQLOCKFLG = m1IGNORESEQLOCKFLG;
    }

    /**
     * 
     * @return
     *     The m1OVRDEXTENSIONLIMITFLG
     */
    @JsonProperty("M1_OVRD_EXTENSION_LIMIT_FLG")
    public String getM1OVRDEXTENSIONLIMITFLG() {
        return m1OVRDEXTENSIONLIMITFLG;
    }

    /**
     * 
     * @param m1OVRDEXTENSIONLIMITFLG
     *     The M1_OVRD_EXTENSION_LIMIT_FLG
     */
    @JsonProperty("M1_OVRD_EXTENSION_LIMIT_FLG")
    public void setM1OVRDEXTENSIONLIMITFLG(String m1OVRDEXTENSIONLIMITFLG) {
        this.m1OVRDEXTENSIONLIMITFLG = m1OVRDEXTENSIONLIMITFLG;
    }

    /**
     * 
     * @return
     *     The m1GANTTDISPLAYICONLBL
     */
    @JsonProperty("M1_GANTT_DISPLAY_ICON_LBL")
    public String getM1GANTTDISPLAYICONLBL() {
        return m1GANTTDISPLAYICONLBL;
    }

    /**
     * 
     * @param m1GANTTDISPLAYICONLBL
     *     The M1_GANTT_DISPLAY_ICON_LBL
     */
    @JsonProperty("M1_GANTT_DISPLAY_ICON_LBL")
    public void setM1GANTTDISPLAYICONLBL(String m1GANTTDISPLAYICONLBL) {
        this.m1GANTTDISPLAYICONLBL = m1GANTTDISPLAYICONLBL;
    }

    /**
     * 
     * @return
     *     The m1VEHICLETAG
     */
    @JsonProperty("M1_VEHICLE_TAG")
    public String getM1VEHICLETAG() {
        return m1VEHICLETAG;
    }

    /**
     * 
     * @param m1VEHICLETAG
     *     The M1_VEHICLE_TAG
     */
    @JsonProperty("M1_VEHICLE_TAG")
    public void setM1VEHICLETAG(String m1VEHICLETAG) {
        this.m1VEHICLETAG = m1VEHICLETAG;
    }

    /**
     * 
     * @return
     *     The m1STATE
     */
    @JsonProperty("M1_STATE")
    public String getM1STATE() {
        return m1STATE;
    }

    /**
     * 
     * @param m1STATE
     *     The M1_STATE
     */
    @JsonProperty("M1_STATE")
    public void setM1STATE(String m1STATE) {
        this.m1STATE = m1STATE;
    }

    /**
     * 
     * @return
     *     The oWNERFLG
     */
    @JsonProperty("OWNER_FLG")
    public String getOWNERFLG() {
        return oWNERFLG;
    }

    /**
     * 
     * @param oWNERFLG
     *     The OWNER_FLG
     */
    @JsonProperty("OWNER_FLG")
    public void setOWNERFLG(String oWNERFLG) {
        this.oWNERFLG = oWNERFLG;
    }

    /**
     * 
     * @return
     *     The m1STOPBTNLBL
     */
    @JsonProperty("M1_STOP_BTN_LBL")
    public String getM1STOPBTNLBL() {
        return m1STOPBTNLBL;
    }

    /**
     * 
     * @param m1STOPBTNLBL
     *     The M1_STOP_BTN_LBL
     */
    @JsonProperty("M1_STOP_BTN_LBL")
    public void setM1STOPBTNLBL(String m1STOPBTNLBL) {
        this.m1STOPBTNLBL = m1STOPBTNLBL;
    }

    /**
     * 
     * @return
     *     The sTARTTM
     */
    @JsonProperty("START_TM")
    public String getSTARTTM() {
        return sTARTTM;
    }

    /**
     * 
     * @param sTARTTM
     *     The START_TM
     */
    @JsonProperty("START_TM")
    public void setSTARTTM(String sTARTTM) {
        this.sTARTTM = sTARTTM;
    }

    /**
     * 
     * @return
     *     The m1ASSIGNMENTREMKSECLBL
     */
    @JsonProperty("M1_ASSIGNMENT_REMKSEC_LBL")
    public String getM1ASSIGNMENTREMKSECLBL() {
        return m1ASSIGNMENTREMKSECLBL;
    }

    /**
     * 
     * @param m1ASSIGNMENTREMKSECLBL
     *     The M1_ASSIGNMENT_REMKSEC_LBL
     */
    @JsonProperty("M1_ASSIGNMENT_REMKSEC_LBL")
    public void setM1ASSIGNMENTREMKSECLBL(String m1ASSIGNMENTREMKSECLBL) {
        this.m1ASSIGNMENTREMKSECLBL = m1ASSIGNMENTREMKSECLBL;
    }

    /**
     * 
     * @return
     *     The m1NONFINALSHIFTWARNLBL
     */
    @JsonProperty("M1_NON_FINAL_SHIFT_WARN_LBL")
    public String getM1NONFINALSHIFTWARNLBL() {
        return m1NONFINALSHIFTWARNLBL;
    }

    /**
     * 
     * @param m1NONFINALSHIFTWARNLBL
     *     The M1_NON_FINAL_SHIFT_WARN_LBL
     */
    @JsonProperty("M1_NON_FINAL_SHIFT_WARN_LBL")
    public void setM1NONFINALSHIFTWARNLBL(String m1NONFINALSHIFTWARNLBL) {
        this.m1NONFINALSHIFTWARNLBL = m1NONFINALSHIFTWARNLBL;
    }

    /**
     * 
     * @return
     *     The m1VEHICLESLBL
     */
    @JsonProperty("M1_VEHICLES_LBL")
    public String getM1VEHICLESLBL() {
        return m1VEHICLESLBL;
    }

    /**
     * 
     * @param m1VEHICLESLBL
     *     The M1_VEHICLES_LBL
     */
    @JsonProperty("M1_VEHICLES_LBL")
    public void setM1VEHICLESLBL(String m1VEHICLESLBL) {
        this.m1VEHICLESLBL = m1VEHICLESLBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMPACKAGEITEMS
     */
    @JsonProperty("M1_ITEM_PACKAGE_ITEMS")
    public String getM1ITEMPACKAGEITEMS() {
        return m1ITEMPACKAGEITEMS;
    }

    /**
     * 
     * @param m1ITEMPACKAGEITEMS
     *     The M1_ITEM_PACKAGE_ITEMS
     */
    @JsonProperty("M1_ITEM_PACKAGE_ITEMS")
    public void setM1ITEMPACKAGEITEMS(String m1ITEMPACKAGEITEMS) {
        this.m1ITEMPACKAGEITEMS = m1ITEMPACKAGEITEMS;
    }

    /**
     * 
     * @return
     *     The rESRCCLASSFLG
     */
    @JsonProperty("RESRC_CLASS_FLG")
    public String getRESRCCLASSFLG() {
        return rESRCCLASSFLG;
    }

    /**
     * 
     * @param rESRCCLASSFLG
     *     The RESRC_CLASS_FLG
     */
    @JsonProperty("RESRC_CLASS_FLG")
    public void setRESRCCLASSFLG(String rESRCCLASSFLG) {
        this.rESRCCLASSFLG = rESRCCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1NATIVEMAPSLBL
     */
    @JsonProperty("M1_NATIVE_MAPS_LBL")
    public String getM1NATIVEMAPSLBL() {
        return m1NATIVEMAPSLBL;
    }

    /**
     * 
     * @param m1NATIVEMAPSLBL
     *     The M1_NATIVE_MAPS_LBL
     */
    @JsonProperty("M1_NATIVE_MAPS_LBL")
    public void setM1NATIVEMAPSLBL(String m1NATIVEMAPSLBL) {
        this.m1NATIVEMAPSLBL = m1NATIVEMAPSLBL;
    }

    /**
     * 
     * @return
     *     The m1NONPRODTASKLBL
     */
    @JsonProperty("M1_NON_PROD_TASK_LBL")
    public String getM1NONPRODTASKLBL() {
        return m1NONPRODTASKLBL;
    }

    /**
     * 
     * @param m1NONPRODTASKLBL
     *     The M1_NON_PROD_TASK_LBL
     */
    @JsonProperty("M1_NON_PROD_TASK_LBL")
    public void setM1NONPRODTASKLBL(String m1NONPRODTASKLBL) {
        this.m1NONPRODTASKLBL = m1NONPRODTASKLBL;
    }

    /**
     * 
     * @return
     *     The m1RESTRICTIONVALUE
     */
    @JsonProperty("M1_RESTRICTION_VALUE")
    public String getM1RESTRICTIONVALUE() {
        return m1RESTRICTIONVALUE;
    }

    /**
     * 
     * @param m1RESTRICTIONVALUE
     *     The M1_RESTRICTION_VALUE
     */
    @JsonProperty("M1_RESTRICTION_VALUE")
    public void setM1RESTRICTIONVALUE(String m1RESTRICTIONVALUE) {
        this.m1RESTRICTIONVALUE = m1RESTRICTIONVALUE;
    }

    /**
     * 
     * @return
     *     The m1TAKENBY
     */
    @JsonProperty("M1_TAKEN_BY")
    public String getM1TAKENBY() {
        return m1TAKENBY;
    }

    /**
     * 
     * @param m1TAKENBY
     *     The M1_TAKEN_BY
     */
    @JsonProperty("M1_TAKEN_BY")
    public void setM1TAKENBY(String m1TAKENBY) {
        this.m1TAKENBY = m1TAKENBY;
    }

    /**
     * 
     * @return
     *     The cALENDARCD
     */
    @JsonProperty("CALENDAR_CD")
    public String getCALENDARCD() {
        return cALENDARCD;
    }

    /**
     * 
     * @param cALENDARCD
     *     The CALENDAR_CD
     */
    @JsonProperty("CALENDAR_CD")
    public void setCALENDARCD(String cALENDARCD) {
        this.cALENDARCD = cALENDARCD;
    }

    /**
     * 
     * @return
     *     The m1DEPTSKANLBL
     */
    @JsonProperty("M1DEPTSK_AN_LBL")
    public String getM1DEPTSKANLBL() {
        return m1DEPTSKANLBL;
    }

    /**
     * 
     * @param m1DEPTSKANLBL
     *     The M1DEPTSK_AN_LBL
     */
    @JsonProperty("M1DEPTSK_AN_LBL")
    public void setM1DEPTSKANLBL(String m1DEPTSKANLBL) {
        this.m1DEPTSKANLBL = m1DEPTSKANLBL;
    }

    /**
     * 
     * @return
     *     The aDHOCCHARVAL
     */
    @JsonProperty("ADHOC_CHAR_VAL")
    public String getADHOCCHARVAL() {
        return aDHOCCHARVAL;
    }

    /**
     * 
     * @param aDHOCCHARVAL
     *     The ADHOC_CHAR_VAL
     */
    @JsonProperty("ADHOC_CHAR_VAL")
    public void setADHOCCHARVAL(String aDHOCCHARVAL) {
        this.aDHOCCHARVAL = aDHOCCHARVAL;
    }

    /**
     * 
     * @return
     *     The m1DATASRCIND
     */
    @JsonProperty("M1_DATA_SRC_IND")
    public String getM1DATASRCIND() {
        return m1DATASRCIND;
    }

    /**
     * 
     * @param m1DATASRCIND
     *     The M1_DATA_SRC_IND
     */
    @JsonProperty("M1_DATA_SRC_IND")
    public void setM1DATASRCIND(String m1DATASRCIND) {
        this.m1DATASRCIND = m1DATASRCIND;
    }

    /**
     * 
     * @return
     *     The m1DEPOTACTCLASSFLG
     */
    @JsonProperty("M1_DEPOT_ACT_CLASS_FLG")
    public String getM1DEPOTACTCLASSFLG() {
        return m1DEPOTACTCLASSFLG;
    }

    /**
     * 
     * @param m1DEPOTACTCLASSFLG
     *     The M1_DEPOT_ACT_CLASS_FLG
     */
    @JsonProperty("M1_DEPOT_ACT_CLASS_FLG")
    public void setM1DEPOTACTCLASSFLG(String m1DEPOTACTCLASSFLG) {
        this.m1DEPOTACTCLASSFLG = m1DEPOTACTCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1ENDSLBL
     */
    @JsonProperty("M1_ENDS_LBL")
    public String getM1ENDSLBL() {
        return m1ENDSLBL;
    }

    /**
     * 
     * @param m1ENDSLBL
     *     The M1_ENDS_LBL
     */
    @JsonProperty("M1_ENDS_LBL")
    public void setM1ENDSLBL(String m1ENDSLBL) {
        this.m1ENDSLBL = m1ENDSLBL;
    }

    /**
     * 
     * @return
     *     The m1LOGGINGLBL
     */
    @JsonProperty("M1_LOGGING_LBL")
    public String getM1LOGGINGLBL() {
        return m1LOGGINGLBL;
    }

    /**
     * 
     * @param m1LOGGINGLBL
     *     The M1_LOGGING_LBL
     */
    @JsonProperty("M1_LOGGING_LBL")
    public void setM1LOGGINGLBL(String m1LOGGINGLBL) {
        this.m1LOGGINGLBL = m1LOGGINGLBL;
    }

    /**
     * 
     * @return
     *     The m1ISDECLINEALLOWEDSW
     */
    @JsonProperty("M1_IS_DECLINE_ALLOWED_SW")
    public String getM1ISDECLINEALLOWEDSW() {
        return m1ISDECLINEALLOWEDSW;
    }

    /**
     * 
     * @param m1ISDECLINEALLOWEDSW
     *     The M1_IS_DECLINE_ALLOWED_SW
     */
    @JsonProperty("M1_IS_DECLINE_ALLOWED_SW")
    public void setM1ISDECLINEALLOWEDSW(String m1ISDECLINEALLOWEDSW) {
        this.m1ISDECLINEALLOWEDSW = m1ISDECLINEALLOWEDSW;
    }

    /**
     * 
     * @return
     *     The m1REVIEWLBL
     */
    @JsonProperty("M1_REVIEW_LBL")
    public String getM1REVIEWLBL() {
        return m1REVIEWLBL;
    }

    /**
     * 
     * @param m1REVIEWLBL
     *     The M1_REVIEW_LBL
     */
    @JsonProperty("M1_REVIEW_LBL")
    public void setM1REVIEWLBL(String m1REVIEWLBL) {
        this.m1REVIEWLBL = m1REVIEWLBL;
    }

    /**
     * 
     * @return
     *     The m1MDTATTCHID
     */
    @JsonProperty("M1_MDT_ATTCH_ID")
    public String getM1MDTATTCHID() {
        return m1MDTATTCHID;
    }

    /**
     * 
     * @param m1MDTATTCHID
     *     The M1_MDT_ATTCH_ID
     */
    @JsonProperty("M1_MDT_ATTCH_ID")
    public void setM1MDTATTCHID(String m1MDTATTCHID) {
        this.m1MDTATTCHID = m1MDTATTCHID;
    }

    /**
     * 
     * @return
     *     The eNDDTTM
     */
    @JsonProperty("END_DTTM")
    public String getENDDTTM() {
        return eNDDTTM;
    }

    /**
     * 
     * @param eNDDTTM
     *     The END_DTTM
     */
    @JsonProperty("END_DTTM")
    public void setENDDTTM(String eNDDTTM) {
        this.eNDDTTM = eNDDTTM;
    }

    /**
     * 
     * @return
     *     The m1CREATEDBYASSIGNMENTID
     */
    @JsonProperty("M1_CREATED_BY_ASSIGNMENT_ID")
    public String getM1CREATEDBYASSIGNMENTID() {
        return m1CREATEDBYASSIGNMENTID;
    }

    /**
     * 
     * @param m1CREATEDBYASSIGNMENTID
     *     The M1_CREATED_BY_ASSIGNMENT_ID
     */
    @JsonProperty("M1_CREATED_BY_ASSIGNMENT_ID")
    public void setM1CREATEDBYASSIGNMENTID(String m1CREATEDBYASSIGNMENTID) {
        this.m1CREATEDBYASSIGNMENTID = m1CREATEDBYASSIGNMENTID;
    }

    /**
     * 
     * @return
     *     The tIMEZONECD
     */
    @JsonProperty("TIME_ZONE_CD")
    public String getTIMEZONECD() {
        return tIMEZONECD;
    }

    /**
     * 
     * @param tIMEZONECD
     *     The TIME_ZONE_CD
     */
    @JsonProperty("TIME_ZONE_CD")
    public void setTIMEZONECD(String tIMEZONECD) {
        this.tIMEZONECD = tIMEZONECD;
    }

    /**
     * 
     * @return
     *     The m1BRKCREDTTM
     */
    @JsonProperty("M1_BRK_CRE_DTTM")
    public String getM1BRKCREDTTM() {
        return m1BRKCREDTTM;
    }

    /**
     * 
     * @param m1BRKCREDTTM
     *     The M1_BRK_CRE_DTTM
     */
    @JsonProperty("M1_BRK_CRE_DTTM")
    public void setM1BRKCREDTTM(String m1BRKCREDTTM) {
        this.m1BRKCREDTTM = m1BRKCREDTTM;
    }

    /**
     * 
     * @return
     *     The cHARVALFK2
     */
    @JsonProperty("CHAR_VAL_FK2")
    public String getCHARVALFK2() {
        return cHARVALFK2;
    }

    /**
     * 
     * @param cHARVALFK2
     *     The CHAR_VAL_FK2
     */
    @JsonProperty("CHAR_VAL_FK2")
    public void setCHARVALFK2(String cHARVALFK2) {
        this.cHARVALFK2 = cHARVALFK2;
    }

    /**
     * 
     * @return
     *     The m1MOBILEPHONENUMBER
     */
    @JsonProperty("M1_MOBILE_PHONE_NUMBER")
    public String getM1MOBILEPHONENUMBER() {
        return m1MOBILEPHONENUMBER;
    }

    /**
     * 
     * @param m1MOBILEPHONENUMBER
     *     The M1_MOBILE_PHONE_NUMBER
     */
    @JsonProperty("M1_MOBILE_PHONE_NUMBER")
    public void setM1MOBILEPHONENUMBER(String m1MOBILEPHONENUMBER) {
        this.m1MOBILEPHONENUMBER = m1MOBILEPHONENUMBER;
    }

    /**
     * 
     * @return
     *     The cHARVALFK3
     */
    @JsonProperty("CHAR_VAL_FK3")
    public String getCHARVALFK3() {
        return cHARVALFK3;
    }

    /**
     * 
     * @param cHARVALFK3
     *     The CHAR_VAL_FK3
     */
    @JsonProperty("CHAR_VAL_FK3")
    public void setCHARVALFK3(String cHARVALFK3) {
        this.cHARVALFK3 = cHARVALFK3;
    }

    /**
     * 
     * @return
     *     The cREWSHFTTYPECD
     */
    @JsonProperty("CREW_SHFT_TYPE_CD")
    public String getCREWSHFTTYPECD() {
        return cREWSHFTTYPECD;
    }

    /**
     * 
     * @param cREWSHFTTYPECD
     *     The CREW_SHFT_TYPE_CD
     */
    @JsonProperty("CREW_SHFT_TYPE_CD")
    public void setCREWSHFTTYPECD(String cREWSHFTTYPECD) {
        this.cREWSHFTTYPECD = cREWSHFTTYPECD;
    }

    /**
     * 
     * @return
     *     The cHARVALFK1
     */
    @JsonProperty("CHAR_VAL_FK1")
    public String getCHARVALFK1() {
        return cHARVALFK1;
    }

    /**
     * 
     * @param cHARVALFK1
     *     The CHAR_VAL_FK1
     */
    @JsonProperty("CHAR_VAL_FK1")
    public void setCHARVALFK1(String cHARVALFK1) {
        this.cHARVALFK1 = cHARVALFK1;
    }

    /**
     * 
     * @return
     *     The cHARVALFK4
     */
    @JsonProperty("CHAR_VAL_FK4")
    public String getCHARVALFK4() {
        return cHARVALFK4;
    }

    /**
     * 
     * @param cHARVALFK4
     *     The CHAR_VAL_FK4
     */
    @JsonProperty("CHAR_VAL_FK4")
    public void setCHARVALFK4(String cHARVALFK4) {
        this.cHARVALFK4 = cHARVALFK4;
    }

    /**
     * 
     * @return
     *     The cHARVALFK5
     */
    @JsonProperty("CHAR_VAL_FK5")
    public String getCHARVALFK5() {
        return cHARVALFK5;
    }

    /**
     * 
     * @param cHARVALFK5
     *     The CHAR_VAL_FK5
     */
    @JsonProperty("CHAR_VAL_FK5")
    public void setCHARVALFK5(String cHARVALFK5) {
        this.cHARVALFK5 = cHARVALFK5;
    }

    /**
     * 
     * @return
     *     The m1APPOINTMENTWINDOWLBL
     */
    @JsonProperty("M1_APPOINTMENT_WINDOW_LBL")
    public String getM1APPOINTMENTWINDOWLBL() {
        return m1APPOINTMENTWINDOWLBL;
    }

    /**
     * 
     * @param m1APPOINTMENTWINDOWLBL
     *     The M1_APPOINTMENT_WINDOW_LBL
     */
    @JsonProperty("M1_APPOINTMENT_WINDOW_LBL")
    public void setM1APPOINTMENTWINDOWLBL(String m1APPOINTMENTWINDOWLBL) {
        this.m1APPOINTMENTWINDOWLBL = m1APPOINTMENTWINDOWLBL;
    }

    /**
     * 
     * @return
     *     The m1PENDINGDISPATCHAPPROVAL
     */
    @JsonProperty("M1_PENDING_DISPATCH_APPROVAL")
    public String getM1PENDINGDISPATCHAPPROVAL() {
        return m1PENDINGDISPATCHAPPROVAL;
    }

    /**
     * 
     * @param m1PENDINGDISPATCHAPPROVAL
     *     The M1_PENDING_DISPATCH_APPROVAL
     */
    @JsonProperty("M1_PENDING_DISPATCH_APPROVAL")
    public void setM1PENDINGDISPATCHAPPROVAL(String m1PENDINGDISPATCHAPPROVAL) {
        this.m1PENDINGDISPATCHAPPROVAL = m1PENDINGDISPATCHAPPROVAL;
    }

    /**
     * 
     * @return
     *     The m1CAPACITYCNTCMPLLBL
     */
    @JsonProperty("M1_CAPACITY_CNT_CMPL_LBL")
    public String getM1CAPACITYCNTCMPLLBL() {
        return m1CAPACITYCNTCMPLLBL;
    }

    /**
     * 
     * @param m1CAPACITYCNTCMPLLBL
     *     The M1_CAPACITY_CNT_CMPL_LBL
     */
    @JsonProperty("M1_CAPACITY_CNT_CMPL_LBL")
    public void setM1CAPACITYCNTCMPLLBL(String m1CAPACITYCNTCMPLLBL) {
        this.m1CAPACITYCNTCMPLLBL = m1CAPACITYCNTCMPLLBL;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYTYPEWORKCALENDAR
     */
    @JsonProperty("M1_ACTIVITY_TYPE_WORK_CALENDAR")
    public String getM1ACTIVITYTYPEWORKCALENDAR() {
        return m1ACTIVITYTYPEWORKCALENDAR;
    }

    /**
     * 
     * @param m1ACTIVITYTYPEWORKCALENDAR
     *     The M1_ACTIVITY_TYPE_WORK_CALENDAR
     */
    @JsonProperty("M1_ACTIVITY_TYPE_WORK_CALENDAR")
    public void setM1ACTIVITYTYPEWORKCALENDAR(String m1ACTIVITYTYPEWORKCALENDAR) {
        this.m1ACTIVITYTYPEWORKCALENDAR = m1ACTIVITYTYPEWORKCALENDAR;
    }

    /**
     * 
     * @return
     *     The m1MCPLAYERS
     */
    @JsonProperty("M1_MCP_LAYERS")
    public String getM1MCPLAYERS() {
        return m1MCPLAYERS;
    }

    /**
     * 
     * @param m1MCPLAYERS
     *     The M1_MCP_LAYERS
     */
    @JsonProperty("M1_MCP_LAYERS")
    public void setM1MCPLAYERS(String m1MCPLAYERS) {
        this.m1MCPLAYERS = m1MCPLAYERS;
    }

    /**
     * 
     * @return
     *     The m1RTDSTUNITFLG
     */
    @JsonProperty("M1_RT_DST_UNIT_FLG")
    public String getM1RTDSTUNITFLG() {
        return m1RTDSTUNITFLG;
    }

    /**
     * 
     * @param m1RTDSTUNITFLG
     *     The M1_RT_DST_UNIT_FLG
     */
    @JsonProperty("M1_RT_DST_UNIT_FLG")
    public void setM1RTDSTUNITFLG(String m1RTDSTUNITFLG) {
        this.m1RTDSTUNITFLG = m1RTDSTUNITFLG;
    }

    /**
     * 
     * @return
     *     The sHFTTMPLID
     */
    @JsonProperty("SHFT_TMPL_ID")
    public String getSHFTTMPLID() {
        return sHFTTMPLID;
    }

    /**
     * 
     * @param sHFTTMPLID
     *     The SHFT_TMPL_ID
     */
    @JsonProperty("SHFT_TMPL_ID")
    public void setSHFTTMPLID(String sHFTTMPLID) {
        this.sHFTTMPLID = sHFTTMPLID;
    }

    /**
     * 
     * @return
     *     The sHIFTDURATION
     */
    @JsonProperty("SHIFT_DURATION")
    public String getSHIFTDURATION() {
        return sHIFTDURATION;
    }

    /**
     * 
     * @param sHIFTDURATION
     *     The SHIFT_DURATION
     */
    @JsonProperty("SHIFT_DURATION")
    public void setSHIFTDURATION(String sHIFTDURATION) {
        this.sHIFTDURATION = sHIFTDURATION;
    }

    /**
     * 
     * @return
     *     The m1EFFDURIMPACT
     */
    @JsonProperty("M1_EFF_DUR_IMPACT")
    public String getM1EFFDURIMPACT() {
        return m1EFFDURIMPACT;
    }

    /**
     * 
     * @param m1EFFDURIMPACT
     *     The M1_EFF_DUR_IMPACT
     */
    @JsonProperty("M1_EFF_DUR_IMPACT")
    public void setM1EFFDURIMPACT(String m1EFFDURIMPACT) {
        this.m1EFFDURIMPACT = m1EFFDURIMPACT;
    }

    /**
     * 
     * @return
     *     The pROCEDURESTEPTEXT
     */
    @JsonProperty("PROCEDURE_STEP_TEXT")
    public String getPROCEDURESTEPTEXT() {
        return pROCEDURESTEPTEXT;
    }

    /**
     * 
     * @param pROCEDURESTEPTEXT
     *     The PROCEDURE_STEP_TEXT
     */
    @JsonProperty("PROCEDURE_STEP_TEXT")
    public void setPROCEDURESTEPTEXT(String pROCEDURESTEPTEXT) {
        this.pROCEDURESTEPTEXT = pROCEDURESTEPTEXT;
    }

    /**
     * 
     * @return
     *     The m1PICKUPSEQUENCENUMBER
     */
    @JsonProperty("M1_PICKUP_SEQUENCE_NUMBER")
    public String getM1PICKUPSEQUENCENUMBER() {
        return m1PICKUPSEQUENCENUMBER;
    }

    /**
     * 
     * @param m1PICKUPSEQUENCENUMBER
     *     The M1_PICKUP_SEQUENCE_NUMBER
     */
    @JsonProperty("M1_PICKUP_SEQUENCE_NUMBER")
    public void setM1PICKUPSEQUENCENUMBER(String m1PICKUPSEQUENCENUMBER) {
        this.m1PICKUPSEQUENCENUMBER = m1PICKUPSEQUENCENUMBER;
    }

    /**
     * 
     * @return
     *     The sVCAREACD
     */
    @JsonProperty("SVC_AREA_CD")
    public String getSVCAREACD() {
        return sVCAREACD;
    }

    /**
     * 
     * @param sVCAREACD
     *     The SVC_AREA_CD
     */
    @JsonProperty("SVC_AREA_CD")
    public void setSVCAREACD(String sVCAREACD) {
        this.sVCAREACD = sVCAREACD;
    }

    /**
     * 
     * @return
     *     The m1EXTENSIONLIMIT
     */
    @JsonProperty("M1_EXTENSION_LIMIT")
    public String getM1EXTENSIONLIMIT() {
        return m1EXTENSIONLIMIT;
    }

    /**
     * 
     * @param m1EXTENSIONLIMIT
     *     The M1_EXTENSION_LIMIT
     */
    @JsonProperty("M1_EXTENSION_LIMIT")
    public void setM1EXTENSIONLIMIT(String m1EXTENSIONLIMIT) {
        this.m1EXTENSIONLIMIT = m1EXTENSIONLIMIT;
    }

    /**
     * 
     * @return
     *     The pROCEDURETYPECD
     */
    @JsonProperty("PROCEDURE_TYPE_CD")
    public String getPROCEDURETYPECD() {
        return pROCEDURETYPECD;
    }

    /**
     * 
     * @param pROCEDURETYPECD
     *     The PROCEDURE_TYPE_CD
     */
    @JsonProperty("PROCEDURE_TYPE_CD")
    public void setPROCEDURETYPECD(String pROCEDURETYPECD) {
        this.pROCEDURETYPECD = pROCEDURETYPECD;
    }

    /**
     * 
     * @return
     *     The m1REFDELPOYLBL
     */
    @JsonProperty("M1_REF_DELPOY_LBL")
    public String getM1REFDELPOYLBL() {
        return m1REFDELPOYLBL;
    }

    /**
     * 
     * @param m1REFDELPOYLBL
     *     The M1_REF_DELPOY_LBL
     */
    @JsonProperty("M1_REF_DELPOY_LBL")
    public void setM1REFDELPOYLBL(String m1REFDELPOYLBL) {
        this.m1REFDELPOYLBL = m1REFDELPOYLBL;
    }

    /**
     * 
     * @return
     *     The m1RESOURCEOPTIONFLG
     */
    @JsonProperty("M1_RESOURCE_OPTION_FLG")
    public String getM1RESOURCEOPTIONFLG() {
        return m1RESOURCEOPTIONFLG;
    }

    /**
     * 
     * @param m1RESOURCEOPTIONFLG
     *     The M1_RESOURCE_OPTION_FLG
     */
    @JsonProperty("M1_RESOURCE_OPTION_FLG")
    public void setM1RESOURCEOPTIONFLG(String m1RESOURCEOPTIONFLG) {
        this.m1RESOURCEOPTIONFLG = m1RESOURCEOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1EXTENSIONDURATION
     */
    @JsonProperty("M1_EXTENSION_DURATION")
    public String getM1EXTENSIONDURATION() {
        return m1EXTENSIONDURATION;
    }

    /**
     * 
     * @param m1EXTENSIONDURATION
     *     The M1_EXTENSION_DURATION
     */
    @JsonProperty("M1_EXTENSION_DURATION")
    public void setM1EXTENSIONDURATION(String m1EXTENSIONDURATION) {
        this.m1EXTENSIONDURATION = m1EXTENSIONDURATION;
    }

    /**
     * 
     * @return
     *     The m1ADDBTNLBL
     */
    @JsonProperty("M1_ADD_BTN_LBL")
    public String getM1ADDBTNLBL() {
        return m1ADDBTNLBL;
    }

    /**
     * 
     * @param m1ADDBTNLBL
     *     The M1_ADD_BTN_LBL
     */
    @JsonProperty("M1_ADD_BTN_LBL")
    public void setM1ADDBTNLBL(String m1ADDBTNLBL) {
        this.m1ADDBTNLBL = m1ADDBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1SENDMAILLBL
     */
    @JsonProperty("M1_SEND_MAIL_LBL")
    public String getM1SENDMAILLBL() {
        return m1SENDMAILLBL;
    }

    /**
     * 
     * @param m1SENDMAILLBL
     *     The M1_SEND_MAIL_LBL
     */
    @JsonProperty("M1_SEND_MAIL_LBL")
    public void setM1SENDMAILLBL(String m1SENDMAILLBL) {
        this.m1SENDMAILLBL = m1SENDMAILLBL;
    }

    /**
     * 
     * @return
     *     The m1OFFLINEFLG
     */
    @JsonProperty("M1_OFFLINE_FLG")
    public String getM1OFFLINEFLG() {
        return m1OFFLINEFLG;
    }

    /**
     * 
     * @param m1OFFLINEFLG
     *     The M1_OFFLINE_FLG
     */
    @JsonProperty("M1_OFFLINE_FLG")
    public void setM1OFFLINEFLG(String m1OFFLINEFLG) {
        this.m1OFFLINEFLG = m1OFFLINEFLG;
    }

    /**
     * 
     * @return
     *     The m1PRDFSNDTOFLG
     */
    @JsonProperty("M1_PRDF_SNDTO_FLG")
    public String getM1PRDFSNDTOFLG() {
        return m1PRDFSNDTOFLG;
    }

    /**
     * 
     * @param m1PRDFSNDTOFLG
     *     The M1_PRDF_SNDTO_FLG
     */
    @JsonProperty("M1_PRDF_SNDTO_FLG")
    public void setM1PRDFSNDTOFLG(String m1PRDFSNDTOFLG) {
        this.m1PRDFSNDTOFLG = m1PRDFSNDTOFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTCHGSHFSTLBL
     */
    @JsonProperty("M1_ACT_CHG_SHFST_LBL")
    public String getM1ACTCHGSHFSTLBL() {
        return m1ACTCHGSHFSTLBL;
    }

    /**
     * 
     * @param m1ACTCHGSHFSTLBL
     *     The M1_ACT_CHG_SHFST_LBL
     */
    @JsonProperty("M1_ACT_CHG_SHFST_LBL")
    public void setM1ACTCHGSHFSTLBL(String m1ACTCHGSHFSTLBL) {
        this.m1ACTCHGSHFSTLBL = m1ACTCHGSHFSTLBL;
    }

    /**
     * 
     * @return
     *     The aDDR4AVAIL
     */
    @JsonProperty("ADDR4_AVAIL")
    public String getADDR4AVAIL() {
        return aDDR4AVAIL;
    }

    /**
     * 
     * @param aDDR4AVAIL
     *     The ADDR4_AVAIL
     */
    @JsonProperty("ADDR4_AVAIL")
    public void setADDR4AVAIL(String aDDR4AVAIL) {
        this.aDDR4AVAIL = aDDR4AVAIL;
    }

    /**
     * 
     * @return
     *     The m1CANCELOFFLINELBL
     */
    @JsonProperty("M1_CANCEL_OFFLINE_LBL")
    public String getM1CANCELOFFLINELBL() {
        return m1CANCELOFFLINELBL;
    }

    /**
     * 
     * @param m1CANCELOFFLINELBL
     *     The M1_CANCEL_OFFLINE_LBL
     */
    @JsonProperty("M1_CANCEL_OFFLINE_LBL")
    public void setM1CANCELOFFLINELBL(String m1CANCELOFFLINELBL) {
        this.m1CANCELOFFLINELBL = m1CANCELOFFLINELBL;
    }

    /**
     * 
     * @return
     *     The aTTACHMENTNAMELBL
     */
    @JsonProperty("ATTACHMENT_NAME_LBL")
    public String getATTACHMENTNAMELBL() {
        return aTTACHMENTNAMELBL;
    }

    /**
     * 
     * @param aTTACHMENTNAMELBL
     *     The ATTACHMENT_NAME_LBL
     */
    @JsonProperty("ATTACHMENT_NAME_LBL")
    public void setATTACHMENTNAMELBL(String aTTACHMENTNAMELBL) {
        this.aTTACHMENTNAMELBL = aTTACHMENTNAMELBL;
    }

    /**
     * 
     * @return
     *     The m1WARNINGLBL
     */
    @JsonProperty("M1_WARNING_LBL")
    public String getM1WARNINGLBL() {
        return m1WARNINGLBL;
    }

    /**
     * 
     * @param m1WARNINGLBL
     *     The M1_WARNING_LBL
     */
    @JsonProperty("M1_WARNING_LBL")
    public void setM1WARNINGLBL(String m1WARNINGLBL) {
        this.m1WARNINGLBL = m1WARNINGLBL;
    }

    /**
     * 
     * @return
     *     The m1CREWTMUSGCD
     */
    @JsonProperty("M1_CREW_TM_USG_CD")
    public String getM1CREWTMUSGCD() {
        return m1CREWTMUSGCD;
    }

    /**
     * 
     * @param m1CREWTMUSGCD
     *     The M1_CREW_TM_USG_CD
     */
    @JsonProperty("M1_CREW_TM_USG_CD")
    public void setM1CREWTMUSGCD(String m1CREWTMUSGCD) {
        this.m1CREWTMUSGCD = m1CREWTMUSGCD;
    }

    /**
     * 
     * @return
     *     The m1CHOOSEANACTIONLBL
     */
    @JsonProperty("M1_CHOOSE_AN_ACTION_LBL")
    public String getM1CHOOSEANACTIONLBL() {
        return m1CHOOSEANACTIONLBL;
    }

    /**
     * 
     * @param m1CHOOSEANACTIONLBL
     *     The M1_CHOOSE_AN_ACTION_LBL
     */
    @JsonProperty("M1_CHOOSE_AN_ACTION_LBL")
    public void setM1CHOOSEANACTIONLBL(String m1CHOOSEANACTIONLBL) {
        this.m1CHOOSEANACTIONLBL = m1CHOOSEANACTIONLBL;
    }

    /**
     * 
     * @return
     *     The sTATUSRSNUSAGE
     */
    @JsonProperty("STATUS_RSN_USAGE")
    public String getSTATUSRSNUSAGE() {
        return sTATUSRSNUSAGE;
    }

    /**
     * 
     * @param sTATUSRSNUSAGE
     *     The STATUS_RSN_USAGE
     */
    @JsonProperty("STATUS_RSN_USAGE")
    public void setSTATUSRSNUSAGE(String sTATUSRSNUSAGE) {
        this.sTATUSRSNUSAGE = sTATUSRSNUSAGE;
    }

    /**
     * 
     * @return
     *     The m1REQBYFLG
     */
    @JsonProperty("M1_REQ_BY_FLG")
    public String getM1REQBYFLG() {
        return m1REQBYFLG;
    }

    /**
     * 
     * @param m1REQBYFLG
     *     The M1_REQ_BY_FLG
     */
    @JsonProperty("M1_REQ_BY_FLG")
    public void setM1REQBYFLG(String m1REQBYFLG) {
        this.m1REQBYFLG = m1REQBYFLG;
    }

    /**
     * 
     * @return
     *     The m1ADVANCEDDISPATCHTASKS
     */
    @JsonProperty("M1_ADVANCED_DISPATCH_TASKS")
    public String getM1ADVANCEDDISPATCHTASKS() {
        return m1ADVANCEDDISPATCHTASKS;
    }

    /**
     * 
     * @param m1ADVANCEDDISPATCHTASKS
     *     The M1_ADVANCED_DISPATCH_TASKS
     */
    @JsonProperty("M1_ADVANCED_DISPATCH_TASKS")
    public void setM1ADVANCEDDISPATCHTASKS(String m1ADVANCEDDISPATCHTASKS) {
        this.m1ADVANCEDDISPATCHTASKS = m1ADVANCEDDISPATCHTASKS;
    }

    /**
     * 
     * @return
     *     The m1EARNINGTIMECMPLLBL
     */
    @JsonProperty("M1_EARNING_TIME_CMPL_LBL")
    public String getM1EARNINGTIMECMPLLBL() {
        return m1EARNINGTIMECMPLLBL;
    }

    /**
     * 
     * @param m1EARNINGTIMECMPLLBL
     *     The M1_EARNING_TIME_CMPL_LBL
     */
    @JsonProperty("M1_EARNING_TIME_CMPL_LBL")
    public void setM1EARNINGTIMECMPLLBL(String m1EARNINGTIMECMPLLBL) {
        this.m1EARNINGTIMECMPLLBL = m1EARNINGTIMECMPLLBL;
    }

    /**
     * 
     * @return
     *     The fIXEDCREW
     */
    @JsonProperty("FIXED_CREW")
    public String getFIXEDCREW() {
        return fIXEDCREW;
    }

    /**
     * 
     * @param fIXEDCREW
     *     The FIXED_CREW
     */
    @JsonProperty("FIXED_CREW")
    public void setFIXEDCREW(String fIXEDCREW) {
        this.fIXEDCREW = fIXEDCREW;
    }

    /**
     * 
     * @return
     *     The m1TRANSFERTYPEFLG
     */
    @JsonProperty("M1_TRANSFER_TYPE_FLG")
    public String getM1TRANSFERTYPEFLG() {
        return m1TRANSFERTYPEFLG;
    }

    /**
     * 
     * @param m1TRANSFERTYPEFLG
     *     The M1_TRANSFER_TYPE_FLG
     */
    @JsonProperty("M1_TRANSFER_TYPE_FLG")
    public void setM1TRANSFERTYPEFLG(String m1TRANSFERTYPEFLG) {
        this.m1TRANSFERTYPEFLG = m1TRANSFERTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1LOGOFFLOCATION
     */
    @JsonProperty("M1_LOGOFF_LOCATION")
    public String getM1LOGOFFLOCATION() {
        return m1LOGOFFLOCATION;
    }

    /**
     * 
     * @param m1LOGOFFLOCATION
     *     The M1_LOGOFF_LOCATION
     */
    @JsonProperty("M1_LOGOFF_LOCATION")
    public void setM1LOGOFFLOCATION(String m1LOGOFFLOCATION) {
        this.m1LOGOFFLOCATION = m1LOGOFFLOCATION;
    }

    /**
     * 
     * @return
     *     The m1NOTIFYHOSTCOMPLETIONONLY
     */
    @JsonProperty("M1_NOTIFY_HOST_COMPLETION_ONLY")
    public String getM1NOTIFYHOSTCOMPLETIONONLY() {
        return m1NOTIFYHOSTCOMPLETIONONLY;
    }

    /**
     * 
     * @param m1NOTIFYHOSTCOMPLETIONONLY
     *     The M1_NOTIFY_HOST_COMPLETION_ONLY
     */
    @JsonProperty("M1_NOTIFY_HOST_COMPLETION_ONLY")
    public void setM1NOTIFYHOSTCOMPLETIONONLY(String m1NOTIFYHOSTCOMPLETIONONLY) {
        this.m1NOTIFYHOSTCOMPLETIONONLY = m1NOTIFYHOSTCOMPLETIONONLY;
    }

    /**
     * 
     * @return
     *     The m1MDTDEBUGLBL
     */
    @JsonProperty("M1_MDT_DEBUG_LBL")
    public String getM1MDTDEBUGLBL() {
        return m1MDTDEBUGLBL;
    }

    /**
     * 
     * @param m1MDTDEBUGLBL
     *     The M1_MDT_DEBUG_LBL
     */
    @JsonProperty("M1_MDT_DEBUG_LBL")
    public void setM1MDTDEBUGLBL(String m1MDTDEBUGLBL) {
        this.m1MDTDEBUGLBL = m1MDTDEBUGLBL;
    }

    /**
     * 
     * @return
     *     The m1BUSPRINBR
     */
    @JsonProperty("M1_BUS_PRI_NBR")
    public String getM1BUSPRINBR() {
        return m1BUSPRINBR;
    }

    /**
     * 
     * @param m1BUSPRINBR
     *     The M1_BUS_PRI_NBR
     */
    @JsonProperty("M1_BUS_PRI_NBR")
    public void setM1BUSPRINBR(String m1BUSPRINBR) {
        this.m1BUSPRINBR = m1BUSPRINBR;
    }

    /**
     * 
     * @return
     *     The dELETEBTN
     */
    @JsonProperty("DELETE_BTN")
    public String getDELETEBTN() {
        return dELETEBTN;
    }

    /**
     * 
     * @param dELETEBTN
     *     The DELETE_BTN
     */
    @JsonProperty("DELETE_BTN")
    public void setDELETEBTN(String dELETEBTN) {
        this.dELETEBTN = dELETEBTN;
    }

    /**
     * 
     * @return
     *     The m1ENROUTETOLBL
     */
    @JsonProperty("M1_ENROUTE_TO_LBL")
    public String getM1ENROUTETOLBL() {
        return m1ENROUTETOLBL;
    }

    /**
     * 
     * @param m1ENROUTETOLBL
     *     The M1_ENROUTE_TO_LBL
     */
    @JsonProperty("M1_ENROUTE_TO_LBL")
    public void setM1ENROUTETOLBL(String m1ENROUTETOLBL) {
        this.m1ENROUTETOLBL = m1ENROUTETOLBL;
    }

    /**
     * 
     * @return
     *     The tIMESHEETPROCESSTYPECD
     */
    @JsonProperty("TIMESHEET_PROCESS_TYPE_CD")
    public String getTIMESHEETPROCESSTYPECD() {
        return tIMESHEETPROCESSTYPECD;
    }

    /**
     * 
     * @param tIMESHEETPROCESSTYPECD
     *     The TIMESHEET_PROCESS_TYPE_CD
     */
    @JsonProperty("TIMESHEET_PROCESS_TYPE_CD")
    public void setTIMESHEETPROCESSTYPECD(String tIMESHEETPROCESSTYPECD) {
        this.tIMESHEETPROCESSTYPECD = tIMESHEETPROCESSTYPECD;
    }

    /**
     * 
     * @return
     *     The m1TBDLBL
     */
    @JsonProperty("M1_TBD_LBL")
    public String getM1TBDLBL() {
        return m1TBDLBL;
    }

    /**
     * 
     * @param m1TBDLBL
     *     The M1_TBD_LBL
     */
    @JsonProperty("M1_TBD_LBL")
    public void setM1TBDLBL(String m1TBDLBL) {
        this.m1TBDLBL = m1TBDLBL;
    }

    /**
     * 
     * @return
     *     The gPSDATAENABLEDFLG
     */
    @JsonProperty("GPS_DATA_ENABLED_FLG")
    public String getGPSDATAENABLEDFLG() {
        return gPSDATAENABLEDFLG;
    }

    /**
     * 
     * @param gPSDATAENABLEDFLG
     *     The GPS_DATA_ENABLED_FLG
     */
    @JsonProperty("GPS_DATA_ENABLED_FLG")
    public void setGPSDATAENABLEDFLG(String gPSDATAENABLEDFLG) {
        this.gPSDATAENABLEDFLG = gPSDATAENABLEDFLG;
    }

    /**
     * 
     * @return
     *     The m1SMSCURRENTTASKID
     */
    @JsonProperty("M1_SMS_CURRENT_TASK_ID")
    public String getM1SMSCURRENTTASKID() {
        return m1SMSCURRENTTASKID;
    }

    /**
     * 
     * @param m1SMSCURRENTTASKID
     *     The M1_SMS_CURRENT_TASK_ID
     */
    @JsonProperty("M1_SMS_CURRENT_TASK_ID")
    public void setM1SMSCURRENTTASKID(String m1SMSCURRENTTASKID) {
        this.m1SMSCURRENTTASKID = m1SMSCURRENTTASKID;
    }

    /**
     * 
     * @return
     *     The m1REQUESTHELPLBL
     */
    @JsonProperty("M1_REQUEST_HELP_LBL")
    public String getM1REQUESTHELPLBL() {
        return m1REQUESTHELPLBL;
    }

    /**
     * 
     * @param m1REQUESTHELPLBL
     *     The M1_REQUEST_HELP_LBL
     */
    @JsonProperty("M1_REQUEST_HELP_LBL")
    public void setM1REQUESTHELPLBL(String m1REQUESTHELPLBL) {
        this.m1REQUESTHELPLBL = m1REQUESTHELPLBL;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYINFOLBL
     */
    @JsonProperty("M1_ACTIVITY_INFO_LBL")
    public String getM1ACTIVITYINFOLBL() {
        return m1ACTIVITYINFOLBL;
    }

    /**
     * 
     * @param m1ACTIVITYINFOLBL
     *     The M1_ACTIVITY_INFO_LBL
     */
    @JsonProperty("M1_ACTIVITY_INFO_LBL")
    public void setM1ACTIVITYINFOLBL(String m1ACTIVITYINFOLBL) {
        this.m1ACTIVITYINFOLBL = m1ACTIVITYINFOLBL;
    }

    /**
     * 
     * @return
     *     The pROCEDURESTEPSEQNO
     */
    @JsonProperty("PROCEDURE_STEP_SEQ_NO")
    public String getPROCEDURESTEPSEQNO() {
        return pROCEDURESTEPSEQNO;
    }

    /**
     * 
     * @param pROCEDURESTEPSEQNO
     *     The PROCEDURE_STEP_SEQ_NO
     */
    @JsonProperty("PROCEDURE_STEP_SEQ_NO")
    public void setPROCEDURESTEPSEQNO(String pROCEDURESTEPSEQNO) {
        this.pROCEDURESTEPSEQNO = pROCEDURESTEPSEQNO;
    }

    /**
     * 
     * @return
     *     The m1WINDOWCOST
     */
    @JsonProperty("M1_WINDOW_COST")
    public String getM1WINDOWCOST() {
        return m1WINDOWCOST;
    }

    /**
     * 
     * @param m1WINDOWCOST
     *     The M1_WINDOW_COST
     */
    @JsonProperty("M1_WINDOW_COST")
    public void setM1WINDOWCOST(String m1WINDOWCOST) {
        this.m1WINDOWCOST = m1WINDOWCOST;
    }

    /**
     * 
     * @return
     *     The m1RTPARMSLBL
     */
    @JsonProperty("M1_RT_PARMS_LBL")
    public String getM1RTPARMSLBL() {
        return m1RTPARMSLBL;
    }

    /**
     * 
     * @param m1RTPARMSLBL
     *     The M1_RT_PARMS_LBL
     */
    @JsonProperty("M1_RT_PARMS_LBL")
    public void setM1RTPARMSLBL(String m1RTPARMSLBL) {
        this.m1RTPARMSLBL = m1RTPARMSLBL;
    }

    /**
     * 
     * @return
     *     The m1TAG
     */
    @JsonProperty("M1_TAG")
    public String getM1TAG() {
        return m1TAG;
    }

    /**
     * 
     * @param m1TAG
     *     The M1_TAG
     */
    @JsonProperty("M1_TAG")
    public void setM1TAG(String m1TAG) {
        this.m1TAG = m1TAG;
    }

    /**
     * 
     * @return
     *     The eNTITYINFORMATION
     */
    @JsonProperty("ENTITY_INFORMATION")
    public String getENTITYINFORMATION() {
        return eNTITYINFORMATION;
    }

    /**
     * 
     * @param eNTITYINFORMATION
     *     The ENTITY_INFORMATION
     */
    @JsonProperty("ENTITY_INFORMATION")
    public void setENTITYINFORMATION(String eNTITYINFORMATION) {
        this.eNTITYINFORMATION = eNTITYINFORMATION;
    }

    /**
     * 
     * @return
     *     The m1ADDRESSCITY
     */
    @JsonProperty("M1_ADDRESS_CITY")
    public String getM1ADDRESSCITY() {
        return m1ADDRESSCITY;
    }

    /**
     * 
     * @param m1ADDRESSCITY
     *     The M1_ADDRESS_CITY
     */
    @JsonProperty("M1_ADDRESS_CITY")
    public void setM1ADDRESSCITY(String m1ADDRESSCITY) {
        this.m1ADDRESSCITY = m1ADDRESSCITY;
    }

    /**
     * 
     * @return
     *     The aTTENDEDPROCEDUREFLG
     */
    @JsonProperty("ATTENDED_PROCEDURE_FLG")
    public String getATTENDEDPROCEDUREFLG() {
        return aTTENDEDPROCEDUREFLG;
    }

    /**
     * 
     * @param aTTENDEDPROCEDUREFLG
     *     The ATTENDED_PROCEDURE_FLG
     */
    @JsonProperty("ATTENDED_PROCEDURE_FLG")
    public void setATTENDEDPROCEDUREFLG(String aTTENDEDPROCEDUREFLG) {
        this.aTTENDEDPROCEDUREFLG = aTTENDEDPROCEDUREFLG;
    }

    /**
     * 
     * @return
     *     The m1MAXFINSHTRVL
     */
    @JsonProperty("M1_MAX_FINSH_TRVL")
    public String getM1MAXFINSHTRVL() {
        return m1MAXFINSHTRVL;
    }

    /**
     * 
     * @param m1MAXFINSHTRVL
     *     The M1_MAX_FINSH_TRVL
     */
    @JsonProperty("M1_MAX_FINSH_TRVL")
    public void setM1MAXFINSHTRVL(String m1MAXFINSHTRVL) {
        this.m1MAXFINSHTRVL = m1MAXFINSHTRVL;
    }

    /**
     * 
     * @return
     *     The m1PARENTTASKID
     */
    @JsonProperty("M1_PARENT_TASK_ID")
    public String getM1PARENTTASKID() {
        return m1PARENTTASKID;
    }

    /**
     * 
     * @param m1PARENTTASKID
     *     The M1_PARENT_TASK_ID
     */
    @JsonProperty("M1_PARENT_TASK_ID")
    public void setM1PARENTTASKID(String m1PARENTTASKID) {
        this.m1PARENTTASKID = m1PARENTTASKID;
    }

    /**
     * 
     * @return
     *     The m1ATDEPOTLBL
     */
    @JsonProperty("M1_AT_DEPOT_LBL")
    public String getM1ATDEPOTLBL() {
        return m1ATDEPOTLBL;
    }

    /**
     * 
     * @param m1ATDEPOTLBL
     *     The M1_AT_DEPOT_LBL
     */
    @JsonProperty("M1_AT_DEPOT_LBL")
    public void setM1ATDEPOTLBL(String m1ATDEPOTLBL) {
        this.m1ATDEPOTLBL = m1ATDEPOTLBL;
    }

    /**
     * 
     * @return
     *     The cUSTNAME
     */
    @JsonProperty("CUST_NAME")
    public String getCUSTNAME() {
        return cUSTNAME;
    }

    /**
     * 
     * @param cUSTNAME
     *     The CUST_NAME
     */
    @JsonProperty("CUST_NAME")
    public void setCUSTNAME(String cUSTNAME) {
        this.cUSTNAME = cUSTNAME;
    }

    /**
     * 
     * @return
     *     The gEOLONG
     */
    @JsonProperty("GEO_LONG")
    public String getGEOLONG() {
        return gEOLONG;
    }

    /**
     * 
     * @param gEOLONG
     *     The GEO_LONG
     */
    @JsonProperty("GEO_LONG")
    public void setGEOLONG(String gEOLONG) {
        this.gEOLONG = gEOLONG;
    }

    /**
     * 
     * @return
     *     The sTATEAVAIL
     */
    @JsonProperty("STATE_AVAIL")
    public String getSTATEAVAIL() {
        return sTATEAVAIL;
    }

    /**
     * 
     * @param sTATEAVAIL
     *     The STATE_AVAIL
     */
    @JsonProperty("STATE_AVAIL")
    public void setSTATEAVAIL(String sTATEAVAIL) {
        this.sTATEAVAIL = sTATEAVAIL;
    }

    /**
     * 
     * @return
     *     The cREATEDBYLBL
     */
    @JsonProperty("CREATED_BY_LBL")
    public String getCREATEDBYLBL() {
        return cREATEDBYLBL;
    }

    /**
     * 
     * @param cREATEDBYLBL
     *     The CREATED_BY_LBL
     */
    @JsonProperty("CREATED_BY_LBL")
    public void setCREATEDBYLBL(String cREATEDBYLBL) {
        this.cREATEDBYLBL = cREATEDBYLBL;
    }

    /**
     * 
     * @return
     *     The m1CACEXTENSIONHIGHLIMIT
     */
    @JsonProperty("M1_CAC_EXTENSION_HIGH_LIMIT")
    public String getM1CACEXTENSIONHIGHLIMIT() {
        return m1CACEXTENSIONHIGHLIMIT;
    }

    /**
     * 
     * @param m1CACEXTENSIONHIGHLIMIT
     *     The M1_CAC_EXTENSION_HIGH_LIMIT
     */
    @JsonProperty("M1_CAC_EXTENSION_HIGH_LIMIT")
    public void setM1CACEXTENSIONHIGHLIMIT(String m1CACEXTENSIONHIGHLIMIT) {
        this.m1CACEXTENSIONHIGHLIMIT = m1CACEXTENSIONHIGHLIMIT;
    }

    /**
     * 
     * @return
     *     The m1SAMECREWFLG
     */
    @JsonProperty("M1_SAME_CREW_FLG")
    public String getM1SAMECREWFLG() {
        return m1SAMECREWFLG;
    }

    /**
     * 
     * @param m1SAMECREWFLG
     *     The M1_SAME_CREW_FLG
     */
    @JsonProperty("M1_SAME_CREW_FLG")
    public void setM1SAMECREWFLG(String m1SAMECREWFLG) {
        this.m1SAMECREWFLG = m1SAMECREWFLG;
    }

    /**
     * 
     * @return
     *     The m1CAPSYSEVENTFLG
     */
    @JsonProperty("M1_CAP_SYS_EVENT_FLG")
    public String getM1CAPSYSEVENTFLG() {
        return m1CAPSYSEVENTFLG;
    }

    /**
     * 
     * @param m1CAPSYSEVENTFLG
     *     The M1_CAP_SYS_EVENT_FLG
     */
    @JsonProperty("M1_CAP_SYS_EVENT_FLG")
    public void setM1CAPSYSEVENTFLG(String m1CAPSYSEVENTFLG) {
        this.m1CAPSYSEVENTFLG = m1CAPSYSEVENTFLG;
    }

    /**
     * 
     * @return
     *     The m1SVCSTATELBL
     */
    @JsonProperty("M1_SVC_STATE_LBL")
    public String getM1SVCSTATELBL() {
        return m1SVCSTATELBL;
    }

    /**
     * 
     * @param m1SVCSTATELBL
     *     The M1_SVC_STATE_LBL
     */
    @JsonProperty("M1_SVC_STATE_LBL")
    public void setM1SVCSTATELBL(String m1SVCSTATELBL) {
        this.m1SVCSTATELBL = m1SVCSTATELBL;
    }

    /**
     * 
     * @return
     *     The m1SENDNOWLBL
     */
    @JsonProperty("M1_SEND_NOW_LBL")
    public String getM1SENDNOWLBL() {
        return m1SENDNOWLBL;
    }

    /**
     * 
     * @param m1SENDNOWLBL
     *     The M1_SEND_NOW_LBL
     */
    @JsonProperty("M1_SEND_NOW_LBL")
    public void setM1SENDNOWLBL(String m1SENDNOWLBL) {
        this.m1SENDNOWLBL = m1SENDNOWLBL;
    }

    /**
     * 
     * @return
     *     The m1BRKTYPE
     */
    @JsonProperty("M1_BRK_TYPE")
    public String getM1BRKTYPE() {
        return m1BRKTYPE;
    }

    /**
     * 
     * @param m1BRKTYPE
     *     The M1_BRK_TYPE
     */
    @JsonProperty("M1_BRK_TYPE")
    public void setM1BRKTYPE(String m1BRKTYPE) {
        this.m1BRKTYPE = m1BRKTYPE;
    }

    /**
     * 
     * @return
     *     The m1STRICTTIMEFLG
     */
    @JsonProperty("M1_STRICT_TIME_FLG")
    public String getM1STRICTTIMEFLG() {
        return m1STRICTTIMEFLG;
    }

    /**
     * 
     * @param m1STRICTTIMEFLG
     *     The M1_STRICT_TIME_FLG
     */
    @JsonProperty("M1_STRICT_TIME_FLG")
    public void setM1STRICTTIMEFLG(String m1STRICTTIMEFLG) {
        this.m1STRICTTIMEFLG = m1STRICTTIMEFLG;
    }

    /**
     * 
     * @return
     *     The m1CAPACITYVAL
     */
    @JsonProperty("M1_CAPACITY_VAL")
    public String getM1CAPACITYVAL() {
        return m1CAPACITYVAL;
    }

    /**
     * 
     * @param m1CAPACITYVAL
     *     The M1_CAPACITY_VAL
     */
    @JsonProperty("M1_CAPACITY_VAL")
    public void setM1CAPACITYVAL(String m1CAPACITYVAL) {
        this.m1CAPACITYVAL = m1CAPACITYVAL;
    }

    /**
     * 
     * @return
     *     The m1MAPLBL
     */
    @JsonProperty("M1_MAP_LBL")
    public String getM1MAPLBL() {
        return m1MAPLBL;
    }

    /**
     * 
     * @param m1MAPLBL
     *     The M1_MAP_LBL
     */
    @JsonProperty("M1_MAP_LBL")
    public void setM1MAPLBL(String m1MAPLBL) {
        this.m1MAPLBL = m1MAPLBL;
    }

    /**
     * 
     * @return
     *     The m1CREWSIZE
     */
    @JsonProperty("M1_CREW_SIZE")
    public String getM1CREWSIZE() {
        return m1CREWSIZE;
    }

    /**
     * 
     * @param m1CREWSIZE
     *     The M1_CREW_SIZE
     */
    @JsonProperty("M1_CREW_SIZE")
    public void setM1CREWSIZE(String m1CREWSIZE) {
        this.m1CREWSIZE = m1CREWSIZE;
    }

    /**
     * 
     * @return
     *     The m1TIMEREMAINING
     */
    @JsonProperty("M1_TIME_REMAINING")
    public String getM1TIMEREMAINING() {
        return m1TIMEREMAINING;
    }

    /**
     * 
     * @param m1TIMEREMAINING
     *     The M1_TIME_REMAINING
     */
    @JsonProperty("M1_TIME_REMAINING")
    public void setM1TIMEREMAINING(String m1TIMEREMAINING) {
        this.m1TIMEREMAINING = m1TIMEREMAINING;
    }

    /**
     * 
     * @return
     *     The m1SCHEDOPTFLG
     */
    @JsonProperty("M1_SCHED_OPT_FLG")
    public String getM1SCHEDOPTFLG() {
        return m1SCHEDOPTFLG;
    }

    /**
     * 
     * @param m1SCHEDOPTFLG
     *     The M1_SCHED_OPT_FLG
     */
    @JsonProperty("M1_SCHED_OPT_FLG")
    public void setM1SCHEDOPTFLG(String m1SCHEDOPTFLG) {
        this.m1SCHEDOPTFLG = m1SCHEDOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1SHIFTPROCEDURESLBL
     */
    @JsonProperty("M1_SHIFT_PROCEDURES_LBL")
    public String getM1SHIFTPROCEDURESLBL() {
        return m1SHIFTPROCEDURESLBL;
    }

    /**
     * 
     * @param m1SHIFTPROCEDURESLBL
     *     The M1_SHIFT_PROCEDURES_LBL
     */
    @JsonProperty("M1_SHIFT_PROCEDURES_LBL")
    public void setM1SHIFTPROCEDURESLBL(String m1SHIFTPROCEDURESLBL) {
        this.m1SHIFTPROCEDURESLBL = m1SHIFTPROCEDURESLBL;
    }

    /**
     * 
     * @return
     *     The m1ORGJBLBL
     */
    @JsonProperty("M1_ORGJB_LBL")
    public String getM1ORGJBLBL() {
        return m1ORGJBLBL;
    }

    /**
     * 
     * @param m1ORGJBLBL
     *     The M1_ORGJB_LBL
     */
    @JsonProperty("M1_ORGJB_LBL")
    public void setM1ORGJBLBL(String m1ORGJBLBL) {
        this.m1ORGJBLBL = m1ORGJBLBL;
    }

    /**
     * 
     * @return
     *     The m1PLANSTARTTIME
     */
    @JsonProperty("M1_PLAN_START_TIME")
    public String getM1PLANSTARTTIME() {
        return m1PLANSTARTTIME;
    }

    /**
     * 
     * @param m1PLANSTARTTIME
     *     The M1_PLAN_START_TIME
     */
    @JsonProperty("M1_PLAN_START_TIME")
    public void setM1PLANSTARTTIME(String m1PLANSTARTTIME) {
        this.m1PLANSTARTTIME = m1PLANSTARTTIME;
    }

    /**
     * 
     * @return
     *     The m1CALCTRVLDIST
     */
    @JsonProperty("M1_CALC_TRVL_DIST")
    public String getM1CALCTRVLDIST() {
        return m1CALCTRVLDIST;
    }

    /**
     * 
     * @param m1CALCTRVLDIST
     *     The M1_CALC_TRVL_DIST
     */
    @JsonProperty("M1_CALC_TRVL_DIST")
    public void setM1CALCTRVLDIST(String m1CALCTRVLDIST) {
        this.m1CALCTRVLDIST = m1CALCTRVLDIST;
    }

    /**
     * 
     * @return
     *     The m1LOGONUSER
     */
    @JsonProperty("M1_LOGON_USER")
    public String getM1LOGONUSER() {
        return m1LOGONUSER;
    }

    /**
     * 
     * @param m1LOGONUSER
     *     The M1_LOGON_USER
     */
    @JsonProperty("M1_LOGON_USER")
    public void setM1LOGONUSER(String m1LOGONUSER) {
        this.m1LOGONUSER = m1LOGONUSER;
    }

    /**
     * 
     * @return
     *     The m1LOGOFFDELAY
     */
    @JsonProperty("M1_LOGOFF_DELAY")
    public String getM1LOGOFFDELAY() {
        return m1LOGOFFDELAY;
    }

    /**
     * 
     * @param m1LOGOFFDELAY
     *     The M1_LOGOFF_DELAY
     */
    @JsonProperty("M1_LOGOFF_DELAY")
    public void setM1LOGOFFDELAY(String m1LOGOFFDELAY) {
        this.m1LOGOFFDELAY = m1LOGOFFDELAY;
    }

    /**
     * 
     * @return
     *     The m1THEMEDLBL
     */
    @JsonProperty("M1_THEME_D_LBL")
    public String getM1THEMEDLBL() {
        return m1THEMEDLBL;
    }

    /**
     * 
     * @param m1THEMEDLBL
     *     The M1_THEME_D_LBL
     */
    @JsonProperty("M1_THEME_D_LBL")
    public void setM1THEMEDLBL(String m1THEMEDLBL) {
        this.m1THEMEDLBL = m1THEMEDLBL;
    }

    /**
     * 
     * @return
     *     The m1FORCEDLOGOFFSW
     */
    @JsonProperty("M1_FORCED_LOG_OFF_SW")
    public String getM1FORCEDLOGOFFSW() {
        return m1FORCEDLOGOFFSW;
    }

    /**
     * 
     * @param m1FORCEDLOGOFFSW
     *     The M1_FORCED_LOG_OFF_SW
     */
    @JsonProperty("M1_FORCED_LOG_OFF_SW")
    public void setM1FORCEDLOGOFFSW(String m1FORCEDLOGOFFSW) {
        this.m1FORCEDLOGOFFSW = m1FORCEDLOGOFFSW;
    }

    /**
     * 
     * @return
     *     The aDJDURATION
     */
    @JsonProperty("ADJ_DURATION")
    public String getADJDURATION() {
        return aDJDURATION;
    }

    /**
     * 
     * @param aDJDURATION
     *     The ADJ_DURATION
     */
    @JsonProperty("ADJ_DURATION")
    public void setADJDURATION(String aDJDURATION) {
        this.aDJDURATION = aDJDURATION;
    }

    /**
     * 
     * @return
     *     The aTTACHMENTDATA
     */
    @JsonProperty("ATTACHMENT_DATA")
    public String getATTACHMENTDATA() {
        return aTTACHMENTDATA;
    }

    /**
     * 
     * @param aTTACHMENTDATA
     *     The ATTACHMENT_DATA
     */
    @JsonProperty("ATTACHMENT_DATA")
    public void setATTACHMENTDATA(String aTTACHMENTDATA) {
        this.aTTACHMENTDATA = aTTACHMENTDATA;
    }

    /**
     * 
     * @return
     *     The m1WINDOWDURATION
     */
    @JsonProperty("M1_WINDOW_DURATION")
    public String getM1WINDOWDURATION() {
        return m1WINDOWDURATION;
    }

    /**
     * 
     * @param m1WINDOWDURATION
     *     The M1_WINDOW_DURATION
     */
    @JsonProperty("M1_WINDOW_DURATION")
    public void setM1WINDOWDURATION(String m1WINDOWDURATION) {
        this.m1WINDOWDURATION = m1WINDOWDURATION;
    }

    /**
     * 
     * @return
     *     The m1PROCEDURESLBL
     */
    @JsonProperty("M1_PROCEDURES_LBL")
    public String getM1PROCEDURESLBL() {
        return m1PROCEDURESLBL;
    }

    /**
     * 
     * @param m1PROCEDURESLBL
     *     The M1_PROCEDURES_LBL
     */
    @JsonProperty("M1_PROCEDURES_LBL")
    public void setM1PROCEDURESLBL(String m1PROCEDURESLBL) {
        this.m1PROCEDURESLBL = m1PROCEDURESLBL;
    }

    /**
     * 
     * @return
     *     The m1CAPTYPEUSAGEFLG
     */
    @JsonProperty("M1_CAP_TYPE_USAGE_FLG")
    public String getM1CAPTYPEUSAGEFLG() {
        return m1CAPTYPEUSAGEFLG;
    }

    /**
     * 
     * @param m1CAPTYPEUSAGEFLG
     *     The M1_CAP_TYPE_USAGE_FLG
     */
    @JsonProperty("M1_CAP_TYPE_USAGE_FLG")
    public void setM1CAPTYPEUSAGEFLG(String m1CAPTYPEUSAGEFLG) {
        this.m1CAPTYPEUSAGEFLG = m1CAPTYPEUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The cITYAVAIL
     */
    @JsonProperty("CITY_AVAIL")
    public String getCITYAVAIL() {
        return cITYAVAIL;
    }

    /**
     * 
     * @param cITYAVAIL
     *     The CITY_AVAIL
     */
    @JsonProperty("CITY_AVAIL")
    public void setCITYAVAIL(String cITYAVAIL) {
        this.cITYAVAIL = cITYAVAIL;
    }

    /**
     * 
     * @return
     *     The sVCCLSCD
     */
    @JsonProperty("SVC_CLS_CD")
    public String getSVCCLSCD() {
        return sVCCLSCD;
    }

    /**
     * 
     * @param sVCCLSCD
     *     The SVC_CLS_CD
     */
    @JsonProperty("SVC_CLS_CD")
    public void setSVCCLSCD(String sVCCLSCD) {
        this.sVCCLSCD = sVCCLSCD;
    }

    /**
     * 
     * @return
     *     The m1RESRCMNGTLBL
     */
    @JsonProperty("M1_RESRC_MNGT_LBL")
    public String getM1RESRCMNGTLBL() {
        return m1RESRCMNGTLBL;
    }

    /**
     * 
     * @param m1RESRCMNGTLBL
     *     The M1_RESRC_MNGT_LBL
     */
    @JsonProperty("M1_RESRC_MNGT_LBL")
    public void setM1RESRCMNGTLBL(String m1RESRCMNGTLBL) {
        this.m1RESRCMNGTLBL = m1RESRCMNGTLBL;
    }

    /**
     * 
     * @return
     *     The m1NOTIFYHOSTOFDISPATCH
     */
    @JsonProperty("M1_NOTIFY_HOST_OF_DISPATCH")
    public String getM1NOTIFYHOSTOFDISPATCH() {
        return m1NOTIFYHOSTOFDISPATCH;
    }

    /**
     * 
     * @param m1NOTIFYHOSTOFDISPATCH
     *     The M1_NOTIFY_HOST_OF_DISPATCH
     */
    @JsonProperty("M1_NOTIFY_HOST_OF_DISPATCH")
    public void setM1NOTIFYHOSTOFDISPATCH(String m1NOTIFYHOSTOFDISPATCH) {
        this.m1NOTIFYHOSTOFDISPATCH = m1NOTIFYHOSTOFDISPATCH;
    }

    /**
     * 
     * @return
     *     The m1BREAKTYPE
     */
    @JsonProperty("M1_BREAK_TYPE")
    public String getM1BREAKTYPE() {
        return m1BREAKTYPE;
    }

    /**
     * 
     * @param m1BREAKTYPE
     *     The M1_BREAK_TYPE
     */
    @JsonProperty("M1_BREAK_TYPE")
    public void setM1BREAKTYPE(String m1BREAKTYPE) {
        this.m1BREAKTYPE = m1BREAKTYPE;
    }

    /**
     * 
     * @return
     *     The m1EMPLOYEEID
     */
    @JsonProperty("M1_EMPLOYEE_ID")
    public String getM1EMPLOYEEID() {
        return m1EMPLOYEEID;
    }

    /**
     * 
     * @param m1EMPLOYEEID
     *     The M1_EMPLOYEE_ID
     */
    @JsonProperty("M1_EMPLOYEE_ID")
    public void setM1EMPLOYEEID(String m1EMPLOYEEID) {
        this.m1EMPLOYEEID = m1EMPLOYEEID;
    }

    /**
     * 
     * @return
     *     The m1ELEMXPATH
     */
    @JsonProperty("M1_ELEM_XPATH")
    public String getM1ELEMXPATH() {
        return m1ELEMXPATH;
    }

    /**
     * 
     * @param m1ELEMXPATH
     *     The M1_ELEM_XPATH
     */
    @JsonProperty("M1_ELEM_XPATH")
    public void setM1ELEMXPATH(String m1ELEMXPATH) {
        this.m1ELEMXPATH = m1ELEMXPATH;
    }

    /**
     * 
     * @return
     *     The m1OPENLBL
     */
    @JsonProperty("M1_OPEN_LBL")
    public String getM1OPENLBL() {
        return m1OPENLBL;
    }

    /**
     * 
     * @param m1OPENLBL
     *     The M1_OPEN_LBL
     */
    @JsonProperty("M1_OPEN_LBL")
    public void setM1OPENLBL(String m1OPENLBL) {
        this.m1OPENLBL = m1OPENLBL;
    }

    /**
     * 
     * @return
     *     The nUM1AVAIL
     */
    @JsonProperty("NUM1_AVAIL")
    public String getNUM1AVAIL() {
        return nUM1AVAIL;
    }

    /**
     * 
     * @param nUM1AVAIL
     *     The NUM1_AVAIL
     */
    @JsonProperty("NUM1_AVAIL")
    public void setNUM1AVAIL(String nUM1AVAIL) {
        this.nUM1AVAIL = nUM1AVAIL;
    }

    /**
     * 
     * @return
     *     The m1DURATIONLBL
     */
    @JsonProperty("M1_DURATION_LBL")
    public String getM1DURATIONLBL() {
        return m1DURATIONLBL;
    }

    /**
     * 
     * @param m1DURATIONLBL
     *     The M1_DURATION_LBL
     */
    @JsonProperty("M1_DURATION_LBL")
    public void setM1DURATIONLBL(String m1DURATIONLBL) {
        this.m1DURATIONLBL = m1DURATIONLBL;
    }

    /**
     * 
     * @return
     *     The f1CONFIRMDELLBL
     */
    @JsonProperty("F1_CONFIRM_DEL_LBL")
    public String getF1CONFIRMDELLBL() {
        return f1CONFIRMDELLBL;
    }

    /**
     * 
     * @param f1CONFIRMDELLBL
     *     The F1_CONFIRM_DEL_LBL
     */
    @JsonProperty("F1_CONFIRM_DEL_LBL")
    public void setF1CONFIRMDELLBL(String f1CONFIRMDELLBL) {
        this.f1CONFIRMDELLBL = f1CONFIRMDELLBL;
    }

    /**
     * 
     * @return
     *     The m1ALERTMESSAGE
     */
    @JsonProperty("M1_ALERT_MESSAGE")
    public String getM1ALERTMESSAGE() {
        return m1ALERTMESSAGE;
    }

    /**
     * 
     * @param m1ALERTMESSAGE
     *     The M1_ALERT_MESSAGE
     */
    @JsonProperty("M1_ALERT_MESSAGE")
    public void setM1ALERTMESSAGE(String m1ALERTMESSAGE) {
        this.m1ALERTMESSAGE = m1ALERTMESSAGE;
    }

    /**
     * 
     * @return
     *     The mDTCAPABILITYTYPE
     */
    @JsonProperty("MDT_CAPABILITY_TYPE")
    public String getMDTCAPABILITYTYPE() {
        return mDTCAPABILITYTYPE;
    }

    /**
     * 
     * @param mDTCAPABILITYTYPE
     *     The MDT_CAPABILITY_TYPE
     */
    @JsonProperty("MDT_CAPABILITY_TYPE")
    public void setMDTCAPABILITYTYPE(String mDTCAPABILITYTYPE) {
        this.mDTCAPABILITYTYPE = mDTCAPABILITYTYPE;
    }

    /**
     * 
     * @return
     *     The m1ARRTM
     */
    @JsonProperty("M1_ARR_TM")
    public String getM1ARRTM() {
        return m1ARRTM;
    }

    /**
     * 
     * @param m1ARRTM
     *     The M1_ARR_TM
     */
    @JsonProperty("M1_ARR_TM")
    public void setM1ARRTM(String m1ARRTM) {
        this.m1ARRTM = m1ARRTM;
    }

    /**
     * 
     * @return
     *     The kEYLBL
     */
    @JsonProperty("KEY_LBL")
    public String getKEYLBL() {
        return kEYLBL;
    }

    /**
     * 
     * @param kEYLBL
     *     The KEY_LBL
     */
    @JsonProperty("KEY_LBL")
    public void setKEYLBL(String kEYLBL) {
        this.kEYLBL = kEYLBL;
    }

    /**
     * 
     * @return
     *     The m1ATTACHMENTDETAILSLBL
     */
    @JsonProperty("M1_ATTACHMENT_DETAILS_LBL")
    public String getM1ATTACHMENTDETAILSLBL() {
        return m1ATTACHMENTDETAILSLBL;
    }

    /**
     * 
     * @param m1ATTACHMENTDETAILSLBL
     *     The M1_ATTACHMENT_DETAILS_LBL
     */
    @JsonProperty("M1_ATTACHMENT_DETAILS_LBL")
    public void setM1ATTACHMENTDETAILSLBL(String m1ATTACHMENTDETAILSLBL) {
        this.m1ATTACHMENTDETAILSLBL = m1ATTACHMENTDETAILSLBL;
    }

    /**
     * 
     * @return
     *     The tRAVELTIMESHEETTYPE
     */
    @JsonProperty("TRAVEL_TIMESHEET_TYPE")
    public String getTRAVELTIMESHEETTYPE() {
        return tRAVELTIMESHEETTYPE;
    }

    /**
     * 
     * @param tRAVELTIMESHEETTYPE
     *     The TRAVEL_TIMESHEET_TYPE
     */
    @JsonProperty("TRAVEL_TIMESHEET_TYPE")
    public void setTRAVELTIMESHEETTYPE(String tRAVELTIMESHEETTYPE) {
        this.tRAVELTIMESHEETTYPE = tRAVELTIMESHEETTYPE;
    }

    /**
     * 
     * @return
     *     The dESCROVRD
     */
    @JsonProperty("DESCR_OVRD")
    public String getDESCROVRD() {
        return dESCROVRD;
    }

    /**
     * 
     * @param dESCROVRD
     *     The DESCR_OVRD
     */
    @JsonProperty("DESCR_OVRD")
    public void setDESCROVRD(String dESCROVRD) {
        this.dESCROVRD = dESCROVRD;
    }

    /**
     * 
     * @return
     *     The rELATEDENTITYFLG
     */
    @JsonProperty("RELATED_ENTITY_FLG")
    public String getRELATEDENTITYFLG() {
        return rELATEDENTITYFLG;
    }

    /**
     * 
     * @param rELATEDENTITYFLG
     *     The RELATED_ENTITY_FLG
     */
    @JsonProperty("RELATED_ENTITY_FLG")
    public void setRELATEDENTITYFLG(String rELATEDENTITYFLG) {
        this.rELATEDENTITYFLG = rELATEDENTITYFLG;
    }

    /**
     * 
     * @return
     *     The m1TASKLISTLBL
     */
    @JsonProperty("M1_TASK_LIST_LBL")
    public String getM1TASKLISTLBL() {
        return m1TASKLISTLBL;
    }

    /**
     * 
     * @param m1TASKLISTLBL
     *     The M1_TASK_LIST_LBL
     */
    @JsonProperty("M1_TASK_LIST_LBL")
    public void setM1TASKLISTLBL(String m1TASKLISTLBL) {
        this.m1TASKLISTLBL = m1TASKLISTLBL;
    }

    /**
     * 
     * @return
     *     The eXPDTTM
     */
    @JsonProperty("EXP_DTTM")
    public String getEXPDTTM() {
        return eXPDTTM;
    }

    /**
     * 
     * @param eXPDTTM
     *     The EXP_DTTM
     */
    @JsonProperty("EXP_DTTM")
    public void setEXPDTTM(String eXPDTTM) {
        this.eXPDTTM = eXPDTTM;
    }

    /**
     * 
     * @return
     *     The aTTACHMENTID
     */
    @JsonProperty("ATTACHMENT_ID")
    public String getATTACHMENTID() {
        return aTTACHMENTID;
    }

    /**
     * 
     * @param aTTACHMENTID
     *     The ATTACHMENT_ID
     */
    @JsonProperty("ATTACHMENT_ID")
    public void setATTACHMENTID(String aTTACHMENTID) {
        this.aTTACHMENTID = aTTACHMENTID;
    }

    /**
     * 
     * @return
     *     The m1AUTOALLOCATIONDUR
     */
    @JsonProperty("M1_AUTO_ALLOCATION_DUR")
    public String getM1AUTOALLOCATIONDUR() {
        return m1AUTOALLOCATIONDUR;
    }

    /**
     * 
     * @param m1AUTOALLOCATIONDUR
     *     The M1_AUTO_ALLOCATION_DUR
     */
    @JsonProperty("M1_AUTO_ALLOCATION_DUR")
    public void setM1AUTOALLOCATIONDUR(String m1AUTOALLOCATIONDUR) {
        this.m1AUTOALLOCATIONDUR = m1AUTOALLOCATIONDUR;
    }

    /**
     * 
     * @return
     *     The m1SCHEDULINGINFOLBL
     */
    @JsonProperty("M1_SCHEDULING_INFO_LBL")
    public String getM1SCHEDULINGINFOLBL() {
        return m1SCHEDULINGINFOLBL;
    }

    /**
     * 
     * @param m1SCHEDULINGINFOLBL
     *     The M1_SCHEDULING_INFO_LBL
     */
    @JsonProperty("M1_SCHEDULING_INFO_LBL")
    public void setM1SCHEDULINGINFOLBL(String m1SCHEDULINGINFOLBL) {
        this.m1SCHEDULINGINFOLBL = m1SCHEDULINGINFOLBL;
    }

    /**
     * 
     * @return
     *     The m1POUTYPE
     */
    @JsonProperty("M1_POU_TYPE")
    public String getM1POUTYPE() {
        return m1POUTYPE;
    }

    /**
     * 
     * @param m1POUTYPE
     *     The M1_POU_TYPE
     */
    @JsonProperty("M1_POU_TYPE")
    public void setM1POUTYPE(String m1POUTYPE) {
        this.m1POUTYPE = m1POUTYPE;
    }

    /**
     * 
     * @return
     *     The m1DELIVERALLITEMSLBL
     */
    @JsonProperty("M1_DELIVER_ALL_ITEMS_LBL")
    public String getM1DELIVERALLITEMSLBL() {
        return m1DELIVERALLITEMSLBL;
    }

    /**
     * 
     * @param m1DELIVERALLITEMSLBL
     *     The M1_DELIVER_ALL_ITEMS_LBL
     */
    @JsonProperty("M1_DELIVER_ALL_ITEMS_LBL")
    public void setM1DELIVERALLITEMSLBL(String m1DELIVERALLITEMSLBL) {
        this.m1DELIVERALLITEMSLBL = m1DELIVERALLITEMSLBL;
    }

    /**
     * 
     * @return
     *     The m1ADDVEHICLELBL
     */
    @JsonProperty("M1_ADD_VEHICLE_LBL")
    public String getM1ADDVEHICLELBL() {
        return m1ADDVEHICLELBL;
    }

    /**
     * 
     * @param m1ADDVEHICLELBL
     *     The M1_ADD_VEHICLE_LBL
     */
    @JsonProperty("M1_ADD_VEHICLE_LBL")
    public void setM1ADDVEHICLELBL(String m1ADDVEHICLELBL) {
        this.m1ADDVEHICLELBL = m1ADDVEHICLELBL;
    }

    /**
     * 
     * @return
     *     The dESCRLONG
     */
    @JsonProperty("DESCRLONG")
    public String getDESCRLONG() {
        return dESCRLONG;
    }

    /**
     * 
     * @param dESCRLONG
     *     The DESCRLONG
     */
    @JsonProperty("DESCRLONG")
    public void setDESCRLONG(String dESCRLONG) {
        this.dESCRLONG = dESCRLONG;
    }

    /**
     * 
     * @return
     *     The m1GPSRESRCID
     */
    @JsonProperty("M1_GPS_RESRC_ID")
    public String getM1GPSRESRCID() {
        return m1GPSRESRCID;
    }

    /**
     * 
     * @param m1GPSRESRCID
     *     The M1_GPS_RESRC_ID
     */
    @JsonProperty("M1_GPS_RESRC_ID")
    public void setM1GPSRESRCID(String m1GPSRESRCID) {
        this.m1GPSRESRCID = m1GPSRESRCID;
    }

    /**
     * 
     * @return
     *     The m1MLPOUTASKLBL
     */
    @JsonProperty("M1_ML_POU_TASK_LBL")
    public String getM1MLPOUTASKLBL() {
        return m1MLPOUTASKLBL;
    }

    /**
     * 
     * @param m1MLPOUTASKLBL
     *     The M1_ML_POU_TASK_LBL
     */
    @JsonProperty("M1_ML_POU_TASK_LBL")
    public void setM1MLPOUTASKLBL(String m1MLPOUTASKLBL) {
        this.m1MLPOUTASKLBL = m1MLPOUTASKLBL;
    }

    /**
     * 
     * @return
     *     The pLANENDDTTM
     */
    @JsonProperty("PLAN_END_DTTM")
    public String getPLANENDDTTM() {
        return pLANENDDTTM;
    }

    /**
     * 
     * @param pLANENDDTTM
     *     The PLAN_END_DTTM
     */
    @JsonProperty("PLAN_END_DTTM")
    public void setPLANENDDTTM(String pLANENDDTTM) {
        this.pLANENDDTTM = pLANENDDTTM;
    }

    /**
     * 
     * @return
     *     The aVGDUR
     */
    @JsonProperty("AVG_DUR")
    public String getAVGDUR() {
        return aVGDUR;
    }

    /**
     * 
     * @param aVGDUR
     *     The AVG_DUR
     */
    @JsonProperty("AVG_DUR")
    public void setAVGDUR(String aVGDUR) {
        this.aVGDUR = aVGDUR;
    }

    /**
     * 
     * @return
     *     The m1RESRVCAPACITYLEADOPTFLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_LEAD_OPT_FLG")
    public String getM1RESRVCAPACITYLEADOPTFLG() {
        return m1RESRVCAPACITYLEADOPTFLG;
    }

    /**
     * 
     * @param m1RESRVCAPACITYLEADOPTFLG
     *     The M1_RESRV_CAPACITY_LEAD_OPT_FLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_LEAD_OPT_FLG")
    public void setM1RESRVCAPACITYLEADOPTFLG(String m1RESRVCAPACITYLEADOPTFLG) {
        this.m1RESRVCAPACITYLEADOPTFLG = m1RESRVCAPACITYLEADOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1ADVDISPATCHMODEFLG
     */
    @JsonProperty("M1_ADV_DISPATCH_MODE_FLG")
    public String getM1ADVDISPATCHMODEFLG() {
        return m1ADVDISPATCHMODEFLG;
    }

    /**
     * 
     * @param m1ADVDISPATCHMODEFLG
     *     The M1_ADV_DISPATCH_MODE_FLG
     */
    @JsonProperty("M1_ADV_DISPATCH_MODE_FLG")
    public void setM1ADVDISPATCHMODEFLG(String m1ADVDISPATCHMODEFLG) {
        this.m1ADVDISPATCHMODEFLG = m1ADVDISPATCHMODEFLG;
    }

    /**
     * 
     * @return
     *     The m1OFFLINEBTNLBL
     */
    @JsonProperty("M1_OFFLINE_BTN_LBL")
    public String getM1OFFLINEBTNLBL() {
        return m1OFFLINEBTNLBL;
    }

    /**
     * 
     * @param m1OFFLINEBTNLBL
     *     The M1_OFFLINE_BTN_LBL
     */
    @JsonProperty("M1_OFFLINE_BTN_LBL")
    public void setM1OFFLINEBTNLBL(String m1OFFLINEBTNLBL) {
        this.m1OFFLINEBTNLBL = m1OFFLINEBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1THEMEBLBL
     */
    @JsonProperty("M1_THEME_B_LBL")
    public String getM1THEMEBLBL() {
        return m1THEMEBLBL;
    }

    /**
     * 
     * @param m1THEMEBLBL
     *     The M1_THEME_B_LBL
     */
    @JsonProperty("M1_THEME_B_LBL")
    public void setM1THEMEBLBL(String m1THEMEBLBL) {
        this.m1THEMEBLBL = m1THEMEBLBL;
    }

    /**
     * 
     * @return
     *     The m1RESERVECAPLEADTM
     */
    @JsonProperty("M1_RESERVE_CAP_LEAD_TM")
    public String getM1RESERVECAPLEADTM() {
        return m1RESERVECAPLEADTM;
    }

    /**
     * 
     * @param m1RESERVECAPLEADTM
     *     The M1_RESERVE_CAP_LEAD_TM
     */
    @JsonProperty("M1_RESERVE_CAP_LEAD_TM")
    public void setM1RESERVECAPLEADTM(String m1RESERVECAPLEADTM) {
        this.m1RESERVECAPLEADTM = m1RESERVECAPLEADTM;
    }

    /**
     * 
     * @return
     *     The m1COUNTRY
     */
    @JsonProperty("M1_COUNTRY")
    public String getM1COUNTRY() {
        return m1COUNTRY;
    }

    /**
     * 
     * @param m1COUNTRY
     *     The M1_COUNTRY
     */
    @JsonProperty("M1_COUNTRY")
    public void setM1COUNTRY(String m1COUNTRY) {
        this.m1COUNTRY = m1COUNTRY;
    }

    /**
     * 
     * @return
     *     The m1SIGNATURELBL
     */
    @JsonProperty("M1_SIGNATURE_LBL")
    public String getM1SIGNATURELBL() {
        return m1SIGNATURELBL;
    }

    /**
     * 
     * @param m1SIGNATURELBL
     *     The M1_SIGNATURE_LBL
     */
    @JsonProperty("M1_SIGNATURE_LBL")
    public void setM1SIGNATURELBL(String m1SIGNATURELBL) {
        this.m1SIGNATURELBL = m1SIGNATURELBL;
    }

    /**
     * 
     * @return
     *     The m1DESCLBL
     */
    @JsonProperty("M1_DESC_LBL")
    public String getM1DESCLBL() {
        return m1DESCLBL;
    }

    /**
     * 
     * @param m1DESCLBL
     *     The M1_DESC_LBL
     */
    @JsonProperty("M1_DESC_LBL")
    public void setM1DESCLBL(String m1DESCLBL) {
        this.m1DESCLBL = m1DESCLBL;
    }

    /**
     * 
     * @return
     *     The m1DOWNLOAD
     */
    @JsonProperty("M1_DOWNLOAD")
    public String getM1DOWNLOAD() {
        return m1DOWNLOAD;
    }

    /**
     * 
     * @param m1DOWNLOAD
     *     The M1_DOWNLOAD
     */
    @JsonProperty("M1_DOWNLOAD")
    public void setM1DOWNLOAD(String m1DOWNLOAD) {
        this.m1DOWNLOAD = m1DOWNLOAD;
    }

    /**
     * 
     * @return
     *     The bUSSTATUSDTTM
     */
    @JsonProperty("BUS_STATUS_DTTM")
    public String getBUSSTATUSDTTM() {
        return bUSSTATUSDTTM;
    }

    /**
     * 
     * @param bUSSTATUSDTTM
     *     The BUS_STATUS_DTTM
     */
    @JsonProperty("BUS_STATUS_DTTM")
    public void setBUSSTATUSDTTM(String bUSSTATUSDTTM) {
        this.bUSSTATUSDTTM = bUSSTATUSDTTM;
    }

    /**
     * 
     * @return
     *     The aLLOWOVERRIDEFLG
     */
    @JsonProperty("ALLOW_OVERRIDE_FLG")
    public String getALLOWOVERRIDEFLG() {
        return aLLOWOVERRIDEFLG;
    }

    /**
     * 
     * @param aLLOWOVERRIDEFLG
     *     The ALLOW_OVERRIDE_FLG
     */
    @JsonProperty("ALLOW_OVERRIDE_FLG")
    public void setALLOWOVERRIDEFLG(String aLLOWOVERRIDEFLG) {
        this.aLLOWOVERRIDEFLG = aLLOWOVERRIDEFLG;
    }

    /**
     * 
     * @return
     *     The m1SENTMAILLBL
     */
    @JsonProperty("M1_SENT_MAIL_LBL")
    public String getM1SENTMAILLBL() {
        return m1SENTMAILLBL;
    }

    /**
     * 
     * @param m1SENTMAILLBL
     *     The M1_SENT_MAIL_LBL
     */
    @JsonProperty("M1_SENT_MAIL_LBL")
    public void setM1SENTMAILLBL(String m1SENTMAILLBL) {
        this.m1SENTMAILLBL = m1SENTMAILLBL;
    }

    /**
     * 
     * @return
     *     The m1STARTODOMTRLBL
     */
    @JsonProperty("M1_START_ODOMTR_LBL")
    public String getM1STARTODOMTRLBL() {
        return m1STARTODOMTRLBL;
    }

    /**
     * 
     * @param m1STARTODOMTRLBL
     *     The M1_START_ODOMTR_LBL
     */
    @JsonProperty("M1_START_ODOMTR_LBL")
    public void setM1STARTODOMTRLBL(String m1STARTODOMTRLBL) {
        this.m1STARTODOMTRLBL = m1STARTODOMTRLBL;
    }

    /**
     * 
     * @return
     *     The m1TOLBL
     */
    @JsonProperty("M1_TO_LBL")
    public String getM1TOLBL() {
        return m1TOLBL;
    }

    /**
     * 
     * @param m1TOLBL
     *     The M1_TO_LBL
     */
    @JsonProperty("M1_TO_LBL")
    public void setM1TOLBL(String m1TOLBL) {
        this.m1TOLBL = m1TOLBL;
    }

    /**
     * 
     * @return
     *     The m1MDT
     */
    @JsonProperty("M1_MDT")
    public String getM1MDT() {
        return m1MDT;
    }

    /**
     * 
     * @param m1MDT
     *     The M1_MDT
     */
    @JsonProperty("M1_MDT")
    public void setM1MDT(String m1MDT) {
        this.m1MDT = m1MDT;
    }

    /**
     * 
     * @return
     *     The dEPOTTIMESHEETTYPE
     */
    @JsonProperty("DEPOT_TIMESHEET_TYPE")
    public String getDEPOTTIMESHEETTYPE() {
        return dEPOTTIMESHEETTYPE;
    }

    /**
     * 
     * @param dEPOTTIMESHEETTYPE
     *     The DEPOT_TIMESHEET_TYPE
     */
    @JsonProperty("DEPOT_TIMESHEET_TYPE")
    public void setDEPOTTIMESHEETTYPE(String dEPOTTIMESHEETTYPE) {
        this.dEPOTTIMESHEETTYPE = dEPOTTIMESHEETTYPE;
    }

    /**
     * 
     * @return
     *     The m1MINOFFSET
     */
    @JsonProperty("M1_MIN_OFFSET")
    public String getM1MINOFFSET() {
        return m1MINOFFSET;
    }

    /**
     * 
     * @param m1MINOFFSET
     *     The M1_MIN_OFFSET
     */
    @JsonProperty("M1_MIN_OFFSET")
    public void setM1MINOFFSET(String m1MINOFFSET) {
        this.m1MINOFFSET = m1MINOFFSET;
    }

    /**
     * 
     * @return
     *     The m1DEPOTCLASSFLG
     */
    @JsonProperty("M1_DEPOT_CLASS_FLG")
    public String getM1DEPOTCLASSFLG() {
        return m1DEPOTCLASSFLG;
    }

    /**
     * 
     * @param m1DEPOTCLASSFLG
     *     The M1_DEPOT_CLASS_FLG
     */
    @JsonProperty("M1_DEPOT_CLASS_FLG")
    public void setM1DEPOTCLASSFLG(String m1DEPOTCLASSFLG) {
        this.m1DEPOTCLASSFLG = m1DEPOTCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1SHFDTLLBL
     */
    @JsonProperty("M1_SHF_DTL_LBL")
    public String getM1SHFDTLLBL() {
        return m1SHFDTLLBL;
    }

    /**
     * 
     * @param m1SHFDTLLBL
     *     The M1_SHF_DTL_LBL
     */
    @JsonProperty("M1_SHF_DTL_LBL")
    public void setM1SHFDTLLBL(String m1SHFDTLLBL) {
        this.m1SHFDTLLBL = m1SHFDTLLBL;
    }

    /**
     * 
     * @return
     *     The m1DEPOTCD
     */
    @JsonProperty("M1_DEPOT_CD")
    public String getM1DEPOTCD() {
        return m1DEPOTCD;
    }

    /**
     * 
     * @param m1DEPOTCD
     *     The M1_DEPOT_CD
     */
    @JsonProperty("M1_DEPOT_CD")
    public void setM1DEPOTCD(String m1DEPOTCD) {
        this.m1DEPOTCD = m1DEPOTCD;
    }

    /**
     * 
     * @return
     *     The m1CALCTRVLTM
     */
    @JsonProperty("M1_CALC_TRVL_TM")
    public String getM1CALCTRVLTM() {
        return m1CALCTRVLTM;
    }

    /**
     * 
     * @param m1CALCTRVLTM
     *     The M1_CALC_TRVL_TM
     */
    @JsonProperty("M1_CALC_TRVL_TM")
    public void setM1CALCTRVLTM(String m1CALCTRVLTM) {
        this.m1CALCTRVLTM = m1CALCTRVLTM;
    }

    /**
     * 
     * @return
     *     The m1CREWINQUIRYLBL
     */
    @JsonProperty("M1_CREWINQUIRY_LBL")
    public String getM1CREWINQUIRYLBL() {
        return m1CREWINQUIRYLBL;
    }

    /**
     * 
     * @param m1CREWINQUIRYLBL
     *     The M1_CREWINQUIRY_LBL
     */
    @JsonProperty("M1_CREWINQUIRY_LBL")
    public void setM1CREWINQUIRYLBL(String m1CREWINQUIRYLBL) {
        this.m1CREWINQUIRYLBL = m1CREWINQUIRYLBL;
    }

    /**
     * 
     * @return
     *     The m1ADDANOTHERBTNLBL
     */
    @JsonProperty("M1_ADD_ANOTHER_BTN_LBL")
    public String getM1ADDANOTHERBTNLBL() {
        return m1ADDANOTHERBTNLBL;
    }

    /**
     * 
     * @param m1ADDANOTHERBTNLBL
     *     The M1_ADD_ANOTHER_BTN_LBL
     */
    @JsonProperty("M1_ADD_ANOTHER_BTN_LBL")
    public void setM1ADDANOTHERBTNLBL(String m1ADDANOTHERBTNLBL) {
        this.m1ADDANOTHERBTNLBL = m1ADDANOTHERBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMDETAILSLBL
     */
    @JsonProperty("M1_ITEM_DETAILS_LBL")
    public String getM1ITEMDETAILSLBL() {
        return m1ITEMDETAILSLBL;
    }

    /**
     * 
     * @param m1ITEMDETAILSLBL
     *     The M1_ITEM_DETAILS_LBL
     */
    @JsonProperty("M1_ITEM_DETAILS_LBL")
    public void setM1ITEMDETAILSLBL(String m1ITEMDETAILSLBL) {
        this.m1ITEMDETAILSLBL = m1ITEMDETAILSLBL;
    }

    /**
     * 
     * @return
     *     The m1POSTPONEDTTM
     */
    @JsonProperty("M1_POSTPONE_DTTM")
    public String getM1POSTPONEDTTM() {
        return m1POSTPONEDTTM;
    }

    /**
     * 
     * @param m1POSTPONEDTTM
     *     The M1_POSTPONE_DTTM
     */
    @JsonProperty("M1_POSTPONE_DTTM")
    public void setM1POSTPONEDTTM(String m1POSTPONEDTTM) {
        this.m1POSTPONEDTTM = m1POSTPONEDTTM;
    }

    /**
     * 
     * @return
     *     The m1NETWORKCOMMUNICATIONLBL
     */
    @JsonProperty("M1_NETWORK_COMMUNICATION_LBL")
    public String getM1NETWORKCOMMUNICATIONLBL() {
        return m1NETWORKCOMMUNICATIONLBL;
    }

    /**
     * 
     * @param m1NETWORKCOMMUNICATIONLBL
     *     The M1_NETWORK_COMMUNICATION_LBL
     */
    @JsonProperty("M1_NETWORK_COMMUNICATION_LBL")
    public void setM1NETWORKCOMMUNICATIONLBL(String m1NETWORKCOMMUNICATIONLBL) {
        this.m1NETWORKCOMMUNICATIONLBL = m1NETWORKCOMMUNICATIONLBL;
    }

    /**
     * 
     * @return
     *     The m1FATALLBL
     */
    @JsonProperty("M1_FATAL_LBL")
    public String getM1FATALLBL() {
        return m1FATALLBL;
    }

    /**
     * 
     * @param m1FATALLBL
     *     The M1_FATAL_LBL
     */
    @JsonProperty("M1_FATAL_LBL")
    public void setM1FATALLBL(String m1FATALLBL) {
        this.m1FATALLBL = m1FATALLBL;
    }

    /**
     * 
     * @return
     *     The m1APPTENDDTTM
     */
    @JsonProperty("M1_APPT_END_DTTM")
    public String getM1APPTENDDTTM() {
        return m1APPTENDDTTM;
    }

    /**
     * 
     * @param m1APPTENDDTTM
     *     The M1_APPT_END_DTTM
     */
    @JsonProperty("M1_APPT_END_DTTM")
    public void setM1APPTENDDTTM(String m1APPTENDDTTM) {
        this.m1APPTENDDTTM = m1APPTENDDTTM;
    }

    /**
     * 
     * @return
     *     The mOBLOGDTTM
     */
    @JsonProperty("MOB_LOG_DTTM")
    public String getMOBLOGDTTM() {
        return mOBLOGDTTM;
    }

    /**
     * 
     * @param mOBLOGDTTM
     *     The MOB_LOG_DTTM
     */
    @JsonProperty("MOB_LOG_DTTM")
    public void setMOBLOGDTTM(String mOBLOGDTTM) {
        this.mOBLOGDTTM = mOBLOGDTTM;
    }

    /**
     * 
     * @return
     *     The m1CALCADJDURATIONLBL
     */
    @JsonProperty("M1_CALCADJ_DURATION_LBL")
    public String getM1CALCADJDURATIONLBL() {
        return m1CALCADJDURATIONLBL;
    }

    /**
     * 
     * @param m1CALCADJDURATIONLBL
     *     The M1_CALCADJ_DURATION_LBL
     */
    @JsonProperty("M1_CALCADJ_DURATION_LBL")
    public void setM1CALCADJDURATIONLBL(String m1CALCADJDURATIONLBL) {
        this.m1CALCADJDURATIONLBL = m1CALCADJDURATIONLBL;
    }

    /**
     * 
     * @return
     *     The mSTCONFIGDATA
     */
    @JsonProperty("MST_CONFIG_DATA")
    public String getMSTCONFIGDATA() {
        return mSTCONFIGDATA;
    }

    /**
     * 
     * @param mSTCONFIGDATA
     *     The MST_CONFIG_DATA
     */
    @JsonProperty("MST_CONFIG_DATA")
    public void setMSTCONFIGDATA(String mSTCONFIGDATA) {
        this.mSTCONFIGDATA = mSTCONFIGDATA;
    }

    /**
     * 
     * @return
     *     The m1TARGETTASKTYPE
     */
    @JsonProperty("M1_TARGET_TASK_TYPE")
    public String getM1TARGETTASKTYPE() {
        return m1TARGETTASKTYPE;
    }

    /**
     * 
     * @param m1TARGETTASKTYPE
     *     The M1_TARGET_TASK_TYPE
     */
    @JsonProperty("M1_TARGET_TASK_TYPE")
    public void setM1TARGETTASKTYPE(String m1TARGETTASKTYPE) {
        this.m1TARGETTASKTYPE = m1TARGETTASKTYPE;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYTYPE
     */
    @JsonProperty("M1_ACTIVITY_TYPE")
    public String getM1ACTIVITYTYPE() {
        return m1ACTIVITYTYPE;
    }

    /**
     * 
     * @param m1ACTIVITYTYPE
     *     The M1_ACTIVITY_TYPE
     */
    @JsonProperty("M1_ACTIVITY_TYPE")
    public void setM1ACTIVITYTYPE(String m1ACTIVITYTYPE) {
        this.m1ACTIVITYTYPE = m1ACTIVITYTYPE;
    }

    /**
     * 
     * @return
     *     The m1ADDRESS4
     */
    @JsonProperty("M1_ADDRESS_4")
    public String getM1ADDRESS4() {
        return m1ADDRESS4;
    }

    /**
     * 
     * @param m1ADDRESS4
     *     The M1_ADDRESS_4
     */
    @JsonProperty("M1_ADDRESS_4")
    public void setM1ADDRESS4(String m1ADDRESS4) {
        this.m1ADDRESS4 = m1ADDRESS4;
    }

    /**
     * 
     * @return
     *     The m1ADDRESS2
     */
    @JsonProperty("M1_ADDRESS_2")
    public String getM1ADDRESS2() {
        return m1ADDRESS2;
    }

    /**
     * 
     * @param m1ADDRESS2
     *     The M1_ADDRESS_2
     */
    @JsonProperty("M1_ADDRESS_2")
    public void setM1ADDRESS2(String m1ADDRESS2) {
        this.m1ADDRESS2 = m1ADDRESS2;
    }

    /**
     * 
     * @return
     *     The m1ADDRESS3
     */
    @JsonProperty("M1_ADDRESS_3")
    public String getM1ADDRESS3() {
        return m1ADDRESS3;
    }

    /**
     * 
     * @param m1ADDRESS3
     *     The M1_ADDRESS_3
     */
    @JsonProperty("M1_ADDRESS_3")
    public void setM1ADDRESS3(String m1ADDRESS3) {
        this.m1ADDRESS3 = m1ADDRESS3;
    }

    /**
     * 
     * @return
     *     The pROCEDURESTATEFLG
     */
    @JsonProperty("PROCEDURE_STATE_FLG")
    public String getPROCEDURESTATEFLG() {
        return pROCEDURESTATEFLG;
    }

    /**
     * 
     * @param pROCEDURESTATEFLG
     *     The PROCEDURE_STATE_FLG
     */
    @JsonProperty("PROCEDURE_STATE_FLG")
    public void setPROCEDURESTATEFLG(String pROCEDURESTATEFLG) {
        this.pROCEDURESTATEFLG = pROCEDURESTATEFLG;
    }

    /**
     * 
     * @return
     *     The m1ADDRESS1
     */
    @JsonProperty("M1_ADDRESS_1")
    public String getM1ADDRESS1() {
        return m1ADDRESS1;
    }

    /**
     * 
     * @param m1ADDRESS1
     *     The M1_ADDRESS_1
     */
    @JsonProperty("M1_ADDRESS_1")
    public void setM1ADDRESS1(String m1ADDRESS1) {
        this.m1ADDRESS1 = m1ADDRESS1;
    }

    /**
     * 
     * @return
     *     The eFFDTTM
     */
    @JsonProperty("EFF_DTTM")
    public String getEFFDTTM() {
        return eFFDTTM;
    }

    /**
     * 
     * @param eFFDTTM
     *     The EFF_DTTM
     */
    @JsonProperty("EFF_DTTM")
    public void setEFFDTTM(String eFFDTTM) {
        this.eFFDTTM = eFFDTTM;
    }

    /**
     * 
     * @return
     *     The m1USERID
     */
    @JsonProperty("M1_USER_ID")
    public String getM1USERID() {
        return m1USERID;
    }

    /**
     * 
     * @param m1USERID
     *     The M1_USER_ID
     */
    @JsonProperty("M1_USER_ID")
    public void setM1USERID(String m1USERID) {
        this.m1USERID = m1USERID;
    }

    /**
     * 
     * @return
     *     The f1FILEUPLOADDTTM
     */
    @JsonProperty("F1_FILE_UPLOAD_DTTM")
    public String getF1FILEUPLOADDTTM() {
        return f1FILEUPLOADDTTM;
    }

    /**
     * 
     * @param f1FILEUPLOADDTTM
     *     The F1_FILE_UPLOAD_DTTM
     */
    @JsonProperty("F1_FILE_UPLOAD_DTTM")
    public void setF1FILEUPLOADDTTM(String f1FILEUPLOADDTTM) {
        this.f1FILEUPLOADDTTM = f1FILEUPLOADDTTM;
    }

    /**
     * 
     * @return
     *     The m1CANCELALERTACTTYPE
     */
    @JsonProperty("M1_CANCEL_ALERT_ACT_TYPE")
    public String getM1CANCELALERTACTTYPE() {
        return m1CANCELALERTACTTYPE;
    }

    /**
     * 
     * @param m1CANCELALERTACTTYPE
     *     The M1_CANCEL_ALERT_ACT_TYPE
     */
    @JsonProperty("M1_CANCEL_ALERT_ACT_TYPE")
    public void setM1CANCELALERTACTTYPE(String m1CANCELALERTACTTYPE) {
        this.m1CANCELALERTACTTYPE = m1CANCELALERTACTTYPE;
    }

    /**
     * 
     * @return
     *     The m1TASKTYPEFORPOU
     */
    @JsonProperty("M1_TASK_TYPE_FOR_POU")
    public String getM1TASKTYPEFORPOU() {
        return m1TASKTYPEFORPOU;
    }

    /**
     * 
     * @param m1TASKTYPEFORPOU
     *     The M1_TASK_TYPE_FOR_POU
     */
    @JsonProperty("M1_TASK_TYPE_FOR_POU")
    public void setM1TASKTYPEFORPOU(String m1TASKTYPEFORPOU) {
        this.m1TASKTYPEFORPOU = m1TASKTYPEFORPOU;
    }

    /**
     * 
     * @return
     *     The m1DISCONNECTTHRESHOLD
     */
    @JsonProperty("M1_DISCONNECT_THRESHOLD")
    public String getM1DISCONNECTTHRESHOLD() {
        return m1DISCONNECTTHRESHOLD;
    }

    /**
     * 
     * @param m1DISCONNECTTHRESHOLD
     *     The M1_DISCONNECT_THRESHOLD
     */
    @JsonProperty("M1_DISCONNECT_THRESHOLD")
    public void setM1DISCONNECTTHRESHOLD(String m1DISCONNECTTHRESHOLD) {
        this.m1DISCONNECTTHRESHOLD = m1DISCONNECTTHRESHOLD;
    }

    /**
     * 
     * @return
     *     The pROCEDUREID
     */
    @JsonProperty("PROCEDURE_ID")
    public String getPROCEDUREID() {
        return pROCEDUREID;
    }

    /**
     * 
     * @param pROCEDUREID
     *     The PROCEDURE_ID
     */
    @JsonProperty("PROCEDURE_ID")
    public void setPROCEDUREID(String pROCEDUREID) {
        this.pROCEDUREID = pROCEDUREID;
    }

    /**
     * 
     * @return
     *     The m1OKBTNLBL
     */
    @JsonProperty("M1_OK_BTN_LBL")
    public String getM1OKBTNLBL() {
        return m1OKBTNLBL;
    }

    /**
     * 
     * @param m1OKBTNLBL
     *     The M1_OK_BTN_LBL
     */
    @JsonProperty("M1_OK_BTN_LBL")
    public void setM1OKBTNLBL(String m1OKBTNLBL) {
        this.m1OKBTNLBL = m1OKBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1TIMEDEVENTALERTLBL
     */
    @JsonProperty("M1_TIMED_EVENT_ALERT_LBL")
    public String getM1TIMEDEVENTALERTLBL() {
        return m1TIMEDEVENTALERTLBL;
    }

    /**
     * 
     * @param m1TIMEDEVENTALERTLBL
     *     The M1_TIMED_EVENT_ALERT_LBL
     */
    @JsonProperty("M1_TIMED_EVENT_ALERT_LBL")
    public void setM1TIMEDEVENTALERTLBL(String m1TIMEDEVENTALERTLBL) {
        this.m1TIMEDEVENTALERTLBL = m1TIMEDEVENTALERTLBL;
    }

    /**
     * 
     * @return
     *     The m1WORKDURATION
     */
    @JsonProperty("M1_WORK_DURATION")
    public String getM1WORKDURATION() {
        return m1WORKDURATION;
    }

    /**
     * 
     * @param m1WORKDURATION
     *     The M1_WORK_DURATION
     */
    @JsonProperty("M1_WORK_DURATION")
    public void setM1WORKDURATION(String m1WORKDURATION) {
        this.m1WORKDURATION = m1WORKDURATION;
    }

    /**
     * 
     * @return
     *     The lOCATIONCD
     */
    @JsonProperty("LOCATION_CD")
    public String getLOCATIONCD() {
        return lOCATIONCD;
    }

    /**
     * 
     * @param lOCATIONCD
     *     The LOCATION_CD
     */
    @JsonProperty("LOCATION_CD")
    public void setLOCATIONCD(String lOCATIONCD) {
        this.lOCATIONCD = lOCATIONCD;
    }

    /**
     * 
     * @return
     *     The m1KEYID
     */
    @JsonProperty("M1_KEY_ID")
    public String getM1KEYID() {
        return m1KEYID;
    }

    /**
     * 
     * @param m1KEYID
     *     The M1_KEY_ID
     */
    @JsonProperty("M1_KEY_ID")
    public void setM1KEYID(String m1KEYID) {
        this.m1KEYID = m1KEYID;
    }

    /**
     * 
     * @return
     *     The m1ASIGNCMPLRECEIPTOPTFLG
     */
    @JsonProperty("M1_ASIGN_CMPL_RECEIPT_OPT_FLG")
    public String getM1ASIGNCMPLRECEIPTOPTFLG() {
        return m1ASIGNCMPLRECEIPTOPTFLG;
    }

    /**
     * 
     * @param m1ASIGNCMPLRECEIPTOPTFLG
     *     The M1_ASIGN_CMPL_RECEIPT_OPT_FLG
     */
    @JsonProperty("M1_ASIGN_CMPL_RECEIPT_OPT_FLG")
    public void setM1ASIGNCMPLRECEIPTOPTFLG(String m1ASIGNCMPLRECEIPTOPTFLG) {
        this.m1ASIGNCMPLRECEIPTOPTFLG = m1ASIGNCMPLRECEIPTOPTFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMPROVIDEDQUANTITY
     */
    @JsonProperty("M1_ITEM_PROVIDED_QUANTITY")
    public String getM1ITEMPROVIDEDQUANTITY() {
        return m1ITEMPROVIDEDQUANTITY;
    }

    /**
     * 
     * @param m1ITEMPROVIDEDQUANTITY
     *     The M1_ITEM_PROVIDED_QUANTITY
     */
    @JsonProperty("M1_ITEM_PROVIDED_QUANTITY")
    public void setM1ITEMPROVIDEDQUANTITY(String m1ITEMPROVIDEDQUANTITY) {
        this.m1ITEMPROVIDEDQUANTITY = m1ITEMPROVIDEDQUANTITY;
    }

    /**
     * 
     * @return
     *     The m1ADDRESSLBL
     */
    @JsonProperty("M1_ADDRESS_LBL")
    public String getM1ADDRESSLBL() {
        return m1ADDRESSLBL;
    }

    /**
     * 
     * @param m1ADDRESSLBL
     *     The M1_ADDRESS_LBL
     */
    @JsonProperty("M1_ADDRESS_LBL")
    public void setM1ADDRESSLBL(String m1ADDRESSLBL) {
        this.m1ADDRESSLBL = m1ADDRESSLBL;
    }

    /**
     * 
     * @return
     *     The m1TASKSTATUSFLG
     */
    @JsonProperty("M1_TASK_STATUS_FLG")
    public String getM1TASKSTATUSFLG() {
        return m1TASKSTATUSFLG;
    }

    /**
     * 
     * @param m1TASKSTATUSFLG
     *     The M1_TASK_STATUS_FLG
     */
    @JsonProperty("M1_TASK_STATUS_FLG")
    public void setM1TASKSTATUSFLG(String m1TASKSTATUSFLG) {
        this.m1TASKSTATUSFLG = m1TASKSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1ALLOWCREWTIMEFLG
     */
    @JsonProperty("M1_ALLOW_CREW_TIME_FLG")
    public String getM1ALLOWCREWTIMEFLG() {
        return m1ALLOWCREWTIMEFLG;
    }

    /**
     * 
     * @param m1ALLOWCREWTIMEFLG
     *     The M1_ALLOW_CREW_TIME_FLG
     */
    @JsonProperty("M1_ALLOW_CREW_TIME_FLG")
    public void setM1ALLOWCREWTIMEFLG(String m1ALLOWCREWTIMEFLG) {
        this.m1ALLOWCREWTIMEFLG = m1ALLOWCREWTIMEFLG;
    }

    /**
     * 
     * @return
     *     The hOUSETYPEAVAIL
     */
    @JsonProperty("HOUSE_TYPE_AVAIL")
    public String getHOUSETYPEAVAIL() {
        return hOUSETYPEAVAIL;
    }

    /**
     * 
     * @param hOUSETYPEAVAIL
     *     The HOUSE_TYPE_AVAIL
     */
    @JsonProperty("HOUSE_TYPE_AVAIL")
    public void setHOUSETYPEAVAIL(String hOUSETYPEAVAIL) {
        this.hOUSETYPEAVAIL = hOUSETYPEAVAIL;
    }

    /**
     * 
     * @return
     *     The m1ACTAFRALBL
     */
    @JsonProperty("M1_ACT_AFRA_LBL")
    public String getM1ACTAFRALBL() {
        return m1ACTAFRALBL;
    }

    /**
     * 
     * @param m1ACTAFRALBL
     *     The M1_ACT_AFRA_LBL
     */
    @JsonProperty("M1_ACT_AFRA_LBL")
    public void setM1ACTAFRALBL(String m1ACTAFRALBL) {
        this.m1ACTAFRALBL = m1ACTAFRALBL;
    }

    /**
     * 
     * @return
     *     The aDDR1LBL
     */
    @JsonProperty("ADDR1_LBL")
    public String getADDR1LBL() {
        return aDDR1LBL;
    }

    /**
     * 
     * @param aDDR1LBL
     *     The ADDR1_LBL
     */
    @JsonProperty("ADDR1_LBL")
    public void setADDR1LBL(String aDDR1LBL) {
        this.aDDR1LBL = aDDR1LBL;
    }

    /**
     * 
     * @return
     *     The sHFTUSAGEFLG
     */
    @JsonProperty("SHFT_USAGE_FLG")
    public String getSHFTUSAGEFLG() {
        return sHFTUSAGEFLG;
    }

    /**
     * 
     * @param sHFTUSAGEFLG
     *     The SHFT_USAGE_FLG
     */
    @JsonProperty("SHFT_USAGE_FLG")
    public void setSHFTUSAGEFLG(String sHFTUSAGEFLG) {
        this.sHFTUSAGEFLG = sHFTUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The m1SYNCALERTTHRESHOLD
     */
    @JsonProperty("M1_SYNC_ALERT_THRESHOLD")
    public String getM1SYNCALERTTHRESHOLD() {
        return m1SYNCALERTTHRESHOLD;
    }

    /**
     * 
     * @param m1SYNCALERTTHRESHOLD
     *     The M1_SYNC_ALERT_THRESHOLD
     */
    @JsonProperty("M1_SYNC_ALERT_THRESHOLD")
    public void setM1SYNCALERTTHRESHOLD(String m1SYNCALERTTHRESHOLD) {
        this.m1SYNCALERTTHRESHOLD = m1SYNCALERTTHRESHOLD;
    }

    /**
     * 
     * @return
     *     The sTATUSFLG
     */
    @JsonProperty("STATUS_FLG")
    public String getSTATUSFLG() {
        return sTATUSFLG;
    }

    /**
     * 
     * @param sTATUSFLG
     *     The STATUS_FLG
     */
    @JsonProperty("STATUS_FLG")
    public void setSTATUSFLG(String sTATUSFLG) {
        this.sTATUSFLG = sTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1YESLBL
     */
    @JsonProperty("M1_YES_LBL")
    public String getM1YESLBL() {
        return m1YESLBL;
    }

    /**
     * 
     * @param m1YESLBL
     *     The M1_YES_LBL
     */
    @JsonProperty("M1_YES_LBL")
    public void setM1YESLBL(String m1YESLBL) {
        this.m1YESLBL = m1YESLBL;
    }

    /**
     * 
     * @return
     *     The m1NOTIFYHOSTOFSTATUS
     */
    @JsonProperty("M1_NOTIFY_HOST_OF_STATUS")
    public String getM1NOTIFYHOSTOFSTATUS() {
        return m1NOTIFYHOSTOFSTATUS;
    }

    /**
     * 
     * @param m1NOTIFYHOSTOFSTATUS
     *     The M1_NOTIFY_HOST_OF_STATUS
     */
    @JsonProperty("M1_NOTIFY_HOST_OF_STATUS")
    public void setM1NOTIFYHOSTOFSTATUS(String m1NOTIFYHOSTOFSTATUS) {
        this.m1NOTIFYHOSTOFSTATUS = m1NOTIFYHOSTOFSTATUS;
    }

    /**
     * 
     * @return
     *     The iNCITYLIMLBL
     */
    @JsonProperty("IN_CITY_LIM_LBL")
    public String getINCITYLIMLBL() {
        return iNCITYLIMLBL;
    }

    /**
     * 
     * @param iNCITYLIMLBL
     *     The IN_CITY_LIM_LBL
     */
    @JsonProperty("IN_CITY_LIM_LBL")
    public void setINCITYLIMLBL(String iNCITYLIMLBL) {
        this.iNCITYLIMLBL = iNCITYLIMLBL;
    }

    /**
     * 
     * @return
     *     The mANALLOCTOSHIFT
     */
    @JsonProperty("MAN_ALLOC_TO_SHIFT")
    public String getMANALLOCTOSHIFT() {
        return mANALLOCTOSHIFT;
    }

    /**
     * 
     * @param mANALLOCTOSHIFT
     *     The MAN_ALLOC_TO_SHIFT
     */
    @JsonProperty("MAN_ALLOC_TO_SHIFT")
    public void setMANALLOCTOSHIFT(String mANALLOCTOSHIFT) {
        this.mANALLOCTOSHIFT = mANALLOCTOSHIFT;
    }

    /**
     * 
     * @return
     *     The pARENTTASKALTID
     */
    @JsonProperty("PARENT_TASK_ALT_ID")
    public String getPARENTTASKALTID() {
        return pARENTTASKALTID;
    }

    /**
     * 
     * @param pARENTTASKALTID
     *     The PARENT_TASK_ALT_ID
     */
    @JsonProperty("PARENT_TASK_ALT_ID")
    public void setPARENTTASKALTID(String pARENTTASKALTID) {
        this.pARENTTASKALTID = pARENTTASKALTID;
    }

    /**
     * 
     * @return
     *     The dRIPHORIZON
     */
    @JsonProperty("DRIP_HORIZON")
    public String getDRIPHORIZON() {
        return dRIPHORIZON;
    }

    /**
     * 
     * @param dRIPHORIZON
     *     The DRIP_HORIZON
     */
    @JsonProperty("DRIP_HORIZON")
    public void setDRIPHORIZON(String dRIPHORIZON) {
        this.dRIPHORIZON = dRIPHORIZON;
    }

    /**
     * 
     * @return
     *     The m1BACKBTNLBL
     */
    @JsonProperty("M1_BACK_BTN_LBL")
    public String getM1BACKBTNLBL() {
        return m1BACKBTNLBL;
    }

    /**
     * 
     * @param m1BACKBTNLBL
     *     The M1_BACK_BTN_LBL
     */
    @JsonProperty("M1_BACK_BTN_LBL")
    public void setM1BACKBTNLBL(String m1BACKBTNLBL) {
        this.m1BACKBTNLBL = m1BACKBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKITEMID
     */
    @JsonProperty("M1_DEPOT_TASK_ITEM_ID")
    public String getM1DEPOTTASKITEMID() {
        return m1DEPOTTASKITEMID;
    }

    /**
     * 
     * @param m1DEPOTTASKITEMID
     *     The M1_DEPOT_TASK_ITEM_ID
     */
    @JsonProperty("M1_DEPOT_TASK_ITEM_ID")
    public void setM1DEPOTTASKITEMID(String m1DEPOTTASKITEMID) {
        this.m1DEPOTTASKITEMID = m1DEPOTTASKITEMID;
    }

    /**
     * 
     * @return
     *     The tSKTMWINDENDDTTM
     */
    @JsonProperty("TSK_TM_WIND_END_DTTM")
    public String getTSKTMWINDENDDTTM() {
        return tSKTMWINDENDDTTM;
    }

    /**
     * 
     * @param tSKTMWINDENDDTTM
     *     The TSK_TM_WIND_END_DTTM
     */
    @JsonProperty("TSK_TM_WIND_END_DTTM")
    public void setTSKTMWINDENDDTTM(String tSKTMWINDENDDTTM) {
        this.tSKTMWINDENDDTTM = tSKTMWINDENDDTTM;
    }

    /**
     * 
     * @return
     *     The m1PLANHORIZON
     */
    @JsonProperty("M1_PLAN_HORIZON")
    public String getM1PLANHORIZON() {
        return m1PLANHORIZON;
    }

    /**
     * 
     * @param m1PLANHORIZON
     *     The M1_PLAN_HORIZON
     */
    @JsonProperty("M1_PLAN_HORIZON")
    public void setM1PLANHORIZON(String m1PLANHORIZON) {
        this.m1PLANHORIZON = m1PLANHORIZON;
    }

    /**
     * 
     * @return
     *     The gEOCODELBL
     */
    @JsonProperty("GEO_CODE_LBL")
    public String getGEOCODELBL() {
        return gEOCODELBL;
    }

    /**
     * 
     * @param gEOCODELBL
     *     The GEO_CODE_LBL
     */
    @JsonProperty("GEO_CODE_LBL")
    public void setGEOCODELBL(String gEOCODELBL) {
        this.gEOCODELBL = gEOCODELBL;
    }

    /**
     * 
     * @return
     *     The m1DEPOTRUNCLOSEDFLG
     */
    @JsonProperty("M1_DEPOT_RUN_CLOSED_FLG")
    public String getM1DEPOTRUNCLOSEDFLG() {
        return m1DEPOTRUNCLOSEDFLG;
    }

    /**
     * 
     * @param m1DEPOTRUNCLOSEDFLG
     *     The M1_DEPOT_RUN_CLOSED_FLG
     */
    @JsonProperty("M1_DEPOT_RUN_CLOSED_FLG")
    public void setM1DEPOTRUNCLOSEDFLG(String m1DEPOTRUNCLOSEDFLG) {
        this.m1DEPOTRUNCLOSEDFLG = m1DEPOTRUNCLOSEDFLG;
    }

    /**
     * 
     * @return
     *     The m1FORCELOGOFFREASONFLG
     */
    @JsonProperty("M1_FORCE_LOGOFF_REASON_FLG")
    public String getM1FORCELOGOFFREASONFLG() {
        return m1FORCELOGOFFREASONFLG;
    }

    /**
     * 
     * @param m1FORCELOGOFFREASONFLG
     *     The M1_FORCE_LOGOFF_REASON_FLG
     */
    @JsonProperty("M1_FORCE_LOGOFF_REASON_FLG")
    public void setM1FORCELOGOFFREASONFLG(String m1FORCELOGOFFREASONFLG) {
        this.m1FORCELOGOFFREASONFLG = m1FORCELOGOFFREASONFLG;
    }

    /**
     * 
     * @return
     *     The m1SCANALLITEMSLBL
     */
    @JsonProperty("M1_SCAN_ALL_ITEMS_LBL")
    public String getM1SCANALLITEMSLBL() {
        return m1SCANALLITEMSLBL;
    }

    /**
     * 
     * @param m1SCANALLITEMSLBL
     *     The M1_SCAN_ALL_ITEMS_LBL
     */
    @JsonProperty("M1_SCAN_ALL_ITEMS_LBL")
    public void setM1SCANALLITEMSLBL(String m1SCANALLITEMSLBL) {
        this.m1SCANALLITEMSLBL = m1SCANALLITEMSLBL;
    }

    /**
     * 
     * @return
     *     The cREATEUSERLBL
     */
    @JsonProperty("CREATE_USER_LBL")
    public String getCREATEUSERLBL() {
        return cREATEUSERLBL;
    }

    /**
     * 
     * @param cREATEUSERLBL
     *     The CREATE_USER_LBL
     */
    @JsonProperty("CREATE_USER_LBL")
    public void setCREATEUSERLBL(String cREATEUSERLBL) {
        this.cREATEUSERLBL = cREATEUSERLBL;
    }

    /**
     * 
     * @return
     *     The aNSWERTYPEFLG
     */
    @JsonProperty("ANSWER_TYPE_FLG")
    public String getANSWERTYPEFLG() {
        return aNSWERTYPEFLG;
    }

    /**
     * 
     * @param aNSWERTYPEFLG
     *     The ANSWER_TYPE_FLG
     */
    @JsonProperty("ANSWER_TYPE_FLG")
    public void setANSWERTYPEFLG(String aNSWERTYPEFLG) {
        this.aNSWERTYPEFLG = aNSWERTYPEFLG;
    }

    /**
     * 
     * @return
     *     The mDTINDICATORIMAGE
     */
    @JsonProperty("MDT_INDICATOR_IMAGE")
    public String getMDTINDICATORIMAGE() {
        return mDTINDICATORIMAGE;
    }

    /**
     * 
     * @param mDTINDICATORIMAGE
     *     The MDT_INDICATOR_IMAGE
     */
    @JsonProperty("MDT_INDICATOR_IMAGE")
    public void setMDTINDICATORIMAGE(String mDTINDICATORIMAGE) {
        this.mDTINDICATORIMAGE = mDTINDICATORIMAGE;
    }

    /**
     * 
     * @return
     *     The rESRCID
     */
    @JsonProperty("RESRC_ID")
    public String getRESRCID() {
        return rESRCID;
    }

    /**
     * 
     * @param rESRCID
     *     The RESRC_ID
     */
    @JsonProperty("RESRC_ID")
    public void setRESRCID(String rESRCID) {
        this.rESRCID = rESRCID;
    }

    /**
     * 
     * @return
     *     The m1THEMELBL
     */
    @JsonProperty("M1_THEME_LBL")
    public String getM1THEMELBL() {
        return m1THEMELBL;
    }

    /**
     * 
     * @param m1THEMELBL
     *     The M1_THEME_LBL
     */
    @JsonProperty("M1_THEME_LBL")
    public void setM1THEMELBL(String m1THEMELBL) {
        this.m1THEMELBL = m1THEMELBL;
    }

    /**
     * 
     * @return
     *     The m1SITEDELAY
     */
    @JsonProperty("M1_SITE_DELAY")
    public String getM1SITEDELAY() {
        return m1SITEDELAY;
    }

    /**
     * 
     * @param m1SITEDELAY
     *     The M1_SITE_DELAY
     */
    @JsonProperty("M1_SITE_DELAY")
    public void setM1SITEDELAY(String m1SITEDELAY) {
        this.m1SITEDELAY = m1SITEDELAY;
    }

    /**
     * 
     * @return
     *     The m1SCANLBL
     */
    @JsonProperty("M1_SCAN_LBL")
    public String getM1SCANLBL() {
        return m1SCANLBL;
    }

    /**
     * 
     * @param m1SCANLBL
     *     The M1_SCAN_LBL
     */
    @JsonProperty("M1_SCAN_LBL")
    public void setM1SCANLBL(String m1SCANLBL) {
        this.m1SCANLBL = m1SCANLBL;
    }

    /**
     * 
     * @return
     *     The m1ALERTSOUND
     */
    @JsonProperty("M1_ALERT_SOUND")
    public String getM1ALERTSOUND() {
        return m1ALERTSOUND;
    }

    /**
     * 
     * @param m1ALERTSOUND
     *     The M1_ALERT_SOUND
     */
    @JsonProperty("M1_ALERT_SOUND")
    public void setM1ALERTSOUND(String m1ALERTSOUND) {
        this.m1ALERTSOUND = m1ALERTSOUND;
    }

    /**
     * 
     * @return
     *     The m1SERVICEADDRESS
     */
    @JsonProperty("M1_SERVICE_ADDRESS")
    public String getM1SERVICEADDRESS() {
        return m1SERVICEADDRESS;
    }

    /**
     * 
     * @param m1SERVICEADDRESS
     *     The M1_SERVICE_ADDRESS
     */
    @JsonProperty("M1_SERVICE_ADDRESS")
    public void setM1SERVICEADDRESS(String m1SERVICEADDRESS) {
        this.m1SERVICEADDRESS = m1SERVICEADDRESS;
    }

    /**
     * 
     * @return
     *     The m1EARNINGTYPE
     */
    @JsonProperty("M1_EARNING_TYPE")
    public String getM1EARNINGTYPE() {
        return m1EARNINGTYPE;
    }

    /**
     * 
     * @param m1EARNINGTYPE
     *     The M1_EARNING_TYPE
     */
    @JsonProperty("M1_EARNING_TYPE")
    public void setM1EARNINGTYPE(String m1EARNINGTYPE) {
        this.m1EARNINGTYPE = m1EARNINGTYPE;
    }

    /**
     * 
     * @return
     *     The m1CUTOFFDTTM
     */
    @JsonProperty("M1_CUTOFF_DTTM")
    public String getM1CUTOFFDTTM() {
        return m1CUTOFFDTTM;
    }

    /**
     * 
     * @param m1CUTOFFDTTM
     *     The M1_CUTOFF_DTTM
     */
    @JsonProperty("M1_CUTOFF_DTTM")
    public void setM1CUTOFFDTTM(String m1CUTOFFDTTM) {
        this.m1CUTOFFDTTM = m1CUTOFFDTTM;
    }

    /**
     * 
     * @return
     *     The fIRSTNAME
     */
    @JsonProperty("FIRST_NAME")
    public String getFIRSTNAME() {
        return fIRSTNAME;
    }

    /**
     * 
     * @param fIRSTNAME
     *     The FIRST_NAME
     */
    @JsonProperty("FIRST_NAME")
    public void setFIRSTNAME(String fIRSTNAME) {
        this.fIRSTNAME = fIRSTNAME;
    }

    /**
     * 
     * @return
     *     The aDDR2AVAIL
     */
    @JsonProperty("ADDR2_AVAIL")
    public String getADDR2AVAIL() {
        return aDDR2AVAIL;
    }

    /**
     * 
     * @param aDDR2AVAIL
     *     The ADDR2_AVAIL
     */
    @JsonProperty("ADDR2_AVAIL")
    public void setADDR2AVAIL(String aDDR2AVAIL) {
        this.aDDR2AVAIL = aDDR2AVAIL;
    }

    /**
     * 
     * @return
     *     The pROCEDUREEXPDT
     */
    @JsonProperty("PROCEDURE_EXP_DT")
    public String getPROCEDUREEXPDT() {
        return pROCEDUREEXPDT;
    }

    /**
     * 
     * @param pROCEDUREEXPDT
     *     The PROCEDURE_EXP_DT
     */
    @JsonProperty("PROCEDURE_EXP_DT")
    public void setPROCEDUREEXPDT(String pROCEDUREEXPDT) {
        this.pROCEDUREEXPDT = pROCEDUREEXPDT;
    }

    /**
     * 
     * @return
     *     The m1VEHENDODOMTR
     */
    @JsonProperty("M1_VEH_END_ODO_MTR")
    public String getM1VEHENDODOMTR() {
        return m1VEHENDODOMTR;
    }

    /**
     * 
     * @param m1VEHENDODOMTR
     *     The M1_VEH_END_ODO_MTR
     */
    @JsonProperty("M1_VEH_END_ODO_MTR")
    public void setM1VEHENDODOMTR(String m1VEHENDODOMTR) {
        this.m1VEHENDODOMTR = m1VEHENDODOMTR;
    }

    /**
     * 
     * @return
     *     The f1ATTACHMENTFILESIZE
     */
    @JsonProperty("F1_ATTACHMENT_FILE_SIZE")
    public String getF1ATTACHMENTFILESIZE() {
        return f1ATTACHMENTFILESIZE;
    }

    /**
     * 
     * @param f1ATTACHMENTFILESIZE
     *     The F1_ATTACHMENT_FILE_SIZE
     */
    @JsonProperty("F1_ATTACHMENT_FILE_SIZE")
    public void setF1ATTACHMENTFILESIZE(String f1ATTACHMENTFILESIZE) {
        this.f1ATTACHMENTFILESIZE = f1ATTACHMENTFILESIZE;
    }

    /**
     * 
     * @return
     *     The m1RANK
     */
    @JsonProperty("M1_RANK")
    public String getM1RANK() {
        return m1RANK;
    }

    /**
     * 
     * @param m1RANK
     *     The M1_RANK
     */
    @JsonProperty("M1_RANK")
    public void setM1RANK(String m1RANK) {
        this.m1RANK = m1RANK;
    }

    /**
     * 
     * @return
     *     The cANCELLBL
     */
    @JsonProperty("CANCEL_LBL")
    public String getCANCELLBL() {
        return cANCELLBL;
    }

    /**
     * 
     * @param cANCELLBL
     *     The CANCEL_LBL
     */
    @JsonProperty("CANCEL_LBL")
    public void setCANCELLBL(String cANCELLBL) {
        this.cANCELLBL = cANCELLBL;
    }

    /**
     * 
     * @return
     *     The m1SENDTOHOST
     */
    @JsonProperty("M1_SEND_TO_HOST")
    public String getM1SENDTOHOST() {
        return m1SENDTOHOST;
    }

    /**
     * 
     * @param m1SENDTOHOST
     *     The M1_SEND_TO_HOST
     */
    @JsonProperty("M1_SEND_TO_HOST")
    public void setM1SENDTOHOST(String m1SENDTOHOST) {
        this.m1SENDTOHOST = m1SENDTOHOST;
    }

    /**
     * 
     * @return
     *     The oRIGPLANNEDSTARTDTTM
     */
    @JsonProperty("ORIG_PLANNED_START_DTTM")
    public String getORIGPLANNEDSTARTDTTM() {
        return oRIGPLANNEDSTARTDTTM;
    }

    /**
     * 
     * @param oRIGPLANNEDSTARTDTTM
     *     The ORIG_PLANNED_START_DTTM
     */
    @JsonProperty("ORIG_PLANNED_START_DTTM")
    public void setORIGPLANNEDSTARTDTTM(String oRIGPLANNEDSTARTDTTM) {
        this.oRIGPLANNEDSTARTDTTM = oRIGPLANNEDSTARTDTTM;
    }

    /**
     * 
     * @return
     *     The m1ONLINELBL
     */
    @JsonProperty("M1_ONLINE_LBL")
    public String getM1ONLINELBL() {
        return m1ONLINELBL;
    }

    /**
     * 
     * @param m1ONLINELBL
     *     The M1_ONLINE_LBL
     */
    @JsonProperty("M1_ONLINE_LBL")
    public void setM1ONLINELBL(String m1ONLINELBL) {
        this.m1ONLINELBL = m1ONLINELBL;
    }

    /**
     * 
     * @return
     *     The m1TMSHEETCORRFLG
     */
    @JsonProperty("M1_TMSHEET_CORR_FLG")
    public String getM1TMSHEETCORRFLG() {
        return m1TMSHEETCORRFLG;
    }

    /**
     * 
     * @param m1TMSHEETCORRFLG
     *     The M1_TMSHEET_CORR_FLG
     */
    @JsonProperty("M1_TMSHEET_CORR_FLG")
    public void setM1TMSHEETCORRFLG(String m1TMSHEETCORRFLG) {
        this.m1TMSHEETCORRFLG = m1TMSHEETCORRFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMQUANTITY
     */
    @JsonProperty("M1_ITEM_QUANTITY")
    public String getM1ITEMQUANTITY() {
        return m1ITEMQUANTITY;
    }

    /**
     * 
     * @param m1ITEMQUANTITY
     *     The M1_ITEM_QUANTITY
     */
    @JsonProperty("M1_ITEM_QUANTITY")
    public void setM1ITEMQUANTITY(String m1ITEMQUANTITY) {
        this.m1ITEMQUANTITY = m1ITEMQUANTITY;
    }

    /**
     * 
     * @return
     *     The gEOCODEAVAIL
     */
    @JsonProperty("GEO_CODE_AVAIL")
    public String getGEOCODEAVAIL() {
        return gEOCODEAVAIL;
    }

    /**
     * 
     * @param gEOCODEAVAIL
     *     The GEO_CODE_AVAIL
     */
    @JsonProperty("GEO_CODE_AVAIL")
    public void setGEOCODEAVAIL(String gEOCODEAVAIL) {
        this.gEOCODEAVAIL = gEOCODEAVAIL;
    }

    /**
     * 
     * @return
     *     The m1SHIFTID
     */
    @JsonProperty("M1_SHIFT_ID")
    public String getM1SHIFTID() {
        return m1SHIFTID;
    }

    /**
     * 
     * @param m1SHIFTID
     *     The M1_SHIFT_ID
     */
    @JsonProperty("M1_SHIFT_ID")
    public void setM1SHIFTID(String m1SHIFTID) {
        this.m1SHIFTID = m1SHIFTID;
    }

    /**
     * 
     * @return
     *     The m1STATUSRSNLBL
     */
    @JsonProperty("M1_STATUS_RSN_LBL")
    public String getM1STATUSRSNLBL() {
        return m1STATUSRSNLBL;
    }

    /**
     * 
     * @param m1STATUSRSNLBL
     *     The M1_STATUS_RSN_LBL
     */
    @JsonProperty("M1_STATUS_RSN_LBL")
    public void setM1STATUSRSNLBL(String m1STATUSRSNLBL) {
        this.m1STATUSRSNLBL = m1STATUSRSNLBL;
    }

    /**
     * 
     * @return
     *     The cAPTYPECD
     */
    @JsonProperty("CAP_TYPE_CD")
    public String getCAPTYPECD() {
        return cAPTYPECD;
    }

    /**
     * 
     * @param cAPTYPECD
     *     The CAP_TYPE_CD
     */
    @JsonProperty("CAP_TYPE_CD")
    public void setCAPTYPECD(String cAPTYPECD) {
        this.cAPTYPECD = cAPTYPECD;
    }

    /**
     * 
     * @return
     *     The m1EXPIRATIONTDTYPE
     */
    @JsonProperty("M1_EXPIRATION_TD_TYPE")
    public String getM1EXPIRATIONTDTYPE() {
        return m1EXPIRATIONTDTYPE;
    }

    /**
     * 
     * @param m1EXPIRATIONTDTYPE
     *     The M1_EXPIRATION_TD_TYPE
     */
    @JsonProperty("M1_EXPIRATION_TD_TYPE")
    public void setM1EXPIRATIONTDTYPE(String m1EXPIRATIONTDTYPE) {
        this.m1EXPIRATIONTDTYPE = m1EXPIRATIONTDTYPE;
    }

    /**
     * 
     * @return
     *     The oVERRIDEFAILUREFLG
     */
    @JsonProperty("OVERRIDE_FAILURE_FLG")
    public String getOVERRIDEFAILUREFLG() {
        return oVERRIDEFAILUREFLG;
    }

    /**
     * 
     * @param oVERRIDEFAILUREFLG
     *     The OVERRIDE_FAILURE_FLG
     */
    @JsonProperty("OVERRIDE_FAILURE_FLG")
    public void setOVERRIDEFAILUREFLG(String oVERRIDEFAILUREFLG) {
        this.oVERRIDEFAILUREFLG = oVERRIDEFAILUREFLG;
    }

    /**
     * 
     * @return
     *     The m1UPDATELBL
     */
    @JsonProperty("M1_UPDATE_LBL")
    public String getM1UPDATELBL() {
        return m1UPDATELBL;
    }

    /**
     * 
     * @param m1UPDATELBL
     *     The M1_UPDATE_LBL
     */
    @JsonProperty("M1_UPDATE_LBL")
    public void setM1UPDATELBL(String m1UPDATELBL) {
        this.m1UPDATELBL = m1UPDATELBL;
    }

    /**
     * 
     * @return
     *     The sTATUSUPDDTTM
     */
    @JsonProperty("STATUS_UPD_DTTM")
    public String getSTATUSUPDDTTM() {
        return sTATUSUPDDTTM;
    }

    /**
     * 
     * @param sTATUSUPDDTTM
     *     The STATUS_UPD_DTTM
     */
    @JsonProperty("STATUS_UPD_DTTM")
    public void setSTATUSUPDDTTM(String sTATUSUPDDTTM) {
        this.sTATUSUPDDTTM = sTATUSUPDDTTM;
    }

    /**
     * 
     * @return
     *     The m1SENTFROMCREWSHFT
     */
    @JsonProperty("M1_SENT_FROM_CREW_SHFT")
    public String getM1SENTFROMCREWSHFT() {
        return m1SENTFROMCREWSHFT;
    }

    /**
     * 
     * @param m1SENTFROMCREWSHFT
     *     The M1_SENT_FROM_CREW_SHFT
     */
    @JsonProperty("M1_SENT_FROM_CREW_SHFT")
    public void setM1SENTFROMCREWSHFT(String m1SENTFROMCREWSHFT) {
        this.m1SENTFROMCREWSHFT = m1SENTFROMCREWSHFT;
    }

    /**
     * 
     * @return
     *     The hOSTSYSTEMCD
     */
    @JsonProperty("HOST_SYSTEM_CD")
    public String getHOSTSYSTEMCD() {
        return hOSTSYSTEMCD;
    }

    /**
     * 
     * @param hOSTSYSTEMCD
     *     The HOST_SYSTEM_CD
     */
    @JsonProperty("HOST_SYSTEM_CD")
    public void setHOSTSYSTEMCD(String hOSTSYSTEMCD) {
        this.hOSTSYSTEMCD = hOSTSYSTEMCD;
    }

    /**
     * 
     * @return
     *     The eSTIMATEDDURATION
     */
    @JsonProperty("ESTIMATED_DURATION")
    public String getESTIMATEDDURATION() {
        return eSTIMATEDDURATION;
    }

    /**
     * 
     * @param eSTIMATEDDURATION
     *     The ESTIMATED_DURATION
     */
    @JsonProperty("ESTIMATED_DURATION")
    public void setESTIMATEDDURATION(String eSTIMATEDDURATION) {
        this.eSTIMATEDDURATION = eSTIMATEDDURATION;
    }

    /**
     * 
     * @return
     *     The m1LOCOPTFLG
     */
    @JsonProperty("M1_LOC_OPT_FLG")
    public String getM1LOCOPTFLG() {
        return m1LOCOPTFLG;
    }

    /**
     * 
     * @param m1LOCOPTFLG
     *     The M1_LOC_OPT_FLG
     */
    @JsonProperty("M1_LOC_OPT_FLG")
    public void setM1LOCOPTFLG(String m1LOCOPTFLG) {
        this.m1LOCOPTFLG = m1LOCOPTFLG;
    }

    /**
     * 
     * @return
     *     The tIMESHEETTYPECD
     */
    @JsonProperty("TIMESHEET_TYPE_CD")
    public String getTIMESHEETTYPECD() {
        return tIMESHEETTYPECD;
    }

    /**
     * 
     * @param tIMESHEETTYPECD
     *     The TIMESHEET_TYPE_CD
     */
    @JsonProperty("TIMESHEET_TYPE_CD")
    public void setTIMESHEETTYPECD(String tIMESHEETTYPECD) {
        this.tIMESHEETTYPECD = tIMESHEETTYPECD;
    }

    /**
     * 
     * @return
     *     The m1ACTCPFLBL
     */
    @JsonProperty("M1_ACT_CPF_LBL")
    public String getM1ACTCPFLBL() {
        return m1ACTCPFLBL;
    }

    /**
     * 
     * @param m1ACTCPFLBL
     *     The M1_ACT_CPF_LBL
     */
    @JsonProperty("M1_ACT_CPF_LBL")
    public void setM1ACTCPFLBL(String m1ACTCPFLBL) {
        this.m1ACTCPFLBL = m1ACTCPFLBL;
    }

    /**
     * 
     * @return
     *     The nUMBERANSWER
     */
    @JsonProperty("NUMBER_ANSWER")
    public String getNUMBERANSWER() {
        return nUMBERANSWER;
    }

    /**
     * 
     * @param nUMBERANSWER
     *     The NUMBER_ANSWER
     */
    @JsonProperty("NUMBER_ANSWER")
    public void setNUMBERANSWER(String nUMBERANSWER) {
        this.nUMBERANSWER = nUMBERANSWER;
    }

    /**
     * 
     * @return
     *     The m1SVCCATEGORYCD
     */
    @JsonProperty("M1_SVC_CATEGORY_CD")
    public String getM1SVCCATEGORYCD() {
        return m1SVCCATEGORYCD;
    }

    /**
     * 
     * @param m1SVCCATEGORYCD
     *     The M1_SVC_CATEGORY_CD
     */
    @JsonProperty("M1_SVC_CATEGORY_CD")
    public void setM1SVCCATEGORYCD(String m1SVCCATEGORYCD) {
        this.m1SVCCATEGORYCD = m1SVCCATEGORYCD;
    }

    /**
     * 
     * @return
     *     The m1MESSAGESLBL
     */
    @JsonProperty("M1_MESSAGES_LBL")
    public String getM1MESSAGESLBL() {
        return m1MESSAGESLBL;
    }

    /**
     * 
     * @param m1MESSAGESLBL
     *     The M1_MESSAGES_LBL
     */
    @JsonProperty("M1_MESSAGES_LBL")
    public void setM1MESSAGESLBL(String m1MESSAGESLBL) {
        this.m1MESSAGESLBL = m1MESSAGESLBL;
    }

    /**
     * 
     * @return
     *     The f1ATTACHIDLBL
     */
    @JsonProperty("F1-ATTACHIDLBL")
    public String getF1ATTACHIDLBL() {
        return f1ATTACHIDLBL;
    }

    /**
     * 
     * @param f1ATTACHIDLBL
     *     The F1-ATTACHIDLBL
     */
    @JsonProperty("F1-ATTACHIDLBL")
    public void setF1ATTACHIDLBL(String f1ATTACHIDLBL) {
        this.f1ATTACHIDLBL = f1ATTACHIDLBL;
    }

    /**
     * 
     * @return
     *     The m1PREVIEWBTNLBL
     */
    @JsonProperty("M1_PREVIEW_BTN_LBL")
    public String getM1PREVIEWBTNLBL() {
        return m1PREVIEWBTNLBL;
    }

    /**
     * 
     * @param m1PREVIEWBTNLBL
     *     The M1_PREVIEW_BTN_LBL
     */
    @JsonProperty("M1_PREVIEW_BTN_LBL")
    public void setM1PREVIEWBTNLBL(String m1PREVIEWBTNLBL) {
        this.m1PREVIEWBTNLBL = m1PREVIEWBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1ELIGIBLEASSISTFLG
     */
    @JsonProperty("M1_ELIGIBLE_ASSIST_FLG")
    public String getM1ELIGIBLEASSISTFLG() {
        return m1ELIGIBLEASSISTFLG;
    }

    /**
     * 
     * @param m1ELIGIBLEASSISTFLG
     *     The M1_ELIGIBLE_ASSIST_FLG
     */
    @JsonProperty("M1_ELIGIBLE_ASSIST_FLG")
    public void setM1ELIGIBLEASSISTFLG(String m1ELIGIBLEASSISTFLG) {
        this.m1ELIGIBLEASSISTFLG = m1ELIGIBLEASSISTFLG;
    }

    /**
     * 
     * @return
     *     The sTARTDTTM
     */
    @JsonProperty("START_DTTM")
    public String getSTARTDTTM() {
        return sTARTDTTM;
    }

    /**
     * 
     * @param sTARTDTTM
     *     The START_DTTM
     */
    @JsonProperty("START_DTTM")
    public void setSTARTDTTM(String sTARTDTTM) {
        this.sTARTDTTM = sTARTDTTM;
    }

    /**
     * 
     * @return
     *     The sTEPUPPERLIMIT
     */
    @JsonProperty("STEP_UPPER_LIMIT")
    public String getSTEPUPPERLIMIT() {
        return sTEPUPPERLIMIT;
    }

    /**
     * 
     * @param sTEPUPPERLIMIT
     *     The STEP_UPPER_LIMIT
     */
    @JsonProperty("STEP_UPPER_LIMIT")
    public void setSTEPUPPERLIMIT(String sTEPUPPERLIMIT) {
        this.sTEPUPPERLIMIT = sTEPUPPERLIMIT;
    }

    /**
     * 
     * @return
     *     The lOGONMOBILEPHONE
     */
    @JsonProperty("LOGON_MOBILE_PHONE")
    public String getLOGONMOBILEPHONE() {
        return lOGONMOBILEPHONE;
    }

    /**
     * 
     * @param lOGONMOBILEPHONE
     *     The LOGON_MOBILE_PHONE
     */
    @JsonProperty("LOGON_MOBILE_PHONE")
    public void setLOGONMOBILEPHONE(String lOGONMOBILEPHONE) {
        this.lOGONMOBILEPHONE = lOGONMOBILEPHONE;
    }

    /**
     * 
     * @return
     *     The m1RESOURCELBL
     */
    @JsonProperty("M1_RESOURCE_LBL")
    public String getM1RESOURCELBL() {
        return m1RESOURCELBL;
    }

    /**
     * 
     * @param m1RESOURCELBL
     *     The M1_RESOURCE_LBL
     */
    @JsonProperty("M1_RESOURCE_LBL")
    public void setM1RESOURCELBL(String m1RESOURCELBL) {
        this.m1RESOURCELBL = m1RESOURCELBL;
    }

    /**
     * 
     * @return
     *     The m1AUTOEXTENSION
     */
    @JsonProperty("M1_AUTO_EXTENSION")
    public String getM1AUTOEXTENSION() {
        return m1AUTOEXTENSION;
    }

    /**
     * 
     * @param m1AUTOEXTENSION
     *     The M1_AUTO_EXTENSION
     */
    @JsonProperty("M1_AUTO_EXTENSION")
    public void setM1AUTOEXTENSION(String m1AUTOEXTENSION) {
        this.m1AUTOEXTENSION = m1AUTOEXTENSION;
    }

    /**
     * 
     * @return
     *     The cOUNTYAVAIL
     */
    @JsonProperty("COUNTY_AVAIL")
    public String getCOUNTYAVAIL() {
        return cOUNTYAVAIL;
    }

    /**
     * 
     * @param cOUNTYAVAIL
     *     The COUNTY_AVAIL
     */
    @JsonProperty("COUNTY_AVAIL")
    public void setCOUNTYAVAIL(String cOUNTYAVAIL) {
        this.cOUNTYAVAIL = cOUNTYAVAIL;
    }

    /**
     * 
     * @return
     *     The m1DATAENCRYPTIONGCFLG
     */
    @JsonProperty("M1_DATA_ENCRYPTION_GC_FLG")
    public String getM1DATAENCRYPTIONGCFLG() {
        return m1DATAENCRYPTIONGCFLG;
    }

    /**
     * 
     * @param m1DATAENCRYPTIONGCFLG
     *     The M1_DATA_ENCRYPTION_GC_FLG
     */
    @JsonProperty("M1_DATA_ENCRYPTION_GC_FLG")
    public void setM1DATAENCRYPTIONGCFLG(String m1DATAENCRYPTIONGCFLG) {
        this.m1DATAENCRYPTIONGCFLG = m1DATAENCRYPTIONGCFLG;
    }

    /**
     * 
     * @return
     *     The m1CAMERALBL
     */
    @JsonProperty("M1_CAMERA_LBL")
    public String getM1CAMERALBL() {
        return m1CAMERALBL;
    }

    /**
     * 
     * @param m1CAMERALBL
     *     The M1_CAMERA_LBL
     */
    @JsonProperty("M1_CAMERA_LBL")
    public void setM1CAMERALBL(String m1CAMERALBL) {
        this.m1CAMERALBL = m1CAMERALBL;
    }

    /**
     * 
     * @return
     *     The m1REMOTEAPPENDERLBL
     */
    @JsonProperty("M1_REMOTE_APPENDER_LBL")
    public String getM1REMOTEAPPENDERLBL() {
        return m1REMOTEAPPENDERLBL;
    }

    /**
     * 
     * @param m1REMOTEAPPENDERLBL
     *     The M1_REMOTE_APPENDER_LBL
     */
    @JsonProperty("M1_REMOTE_APPENDER_LBL")
    public void setM1REMOTEAPPENDERLBL(String m1REMOTEAPPENDERLBL) {
        this.m1REMOTEAPPENDERLBL = m1REMOTEAPPENDERLBL;
    }

    /**
     * 
     * @return
     *     The m1BREAKTASKLBL
     */
    @JsonProperty("M1_BREAK_TASK_LBL")
    public String getM1BREAKTASKLBL() {
        return m1BREAKTASKLBL;
    }

    /**
     * 
     * @param m1BREAKTASKLBL
     *     The M1_BREAK_TASK_LBL
     */
    @JsonProperty("M1_BREAK_TASK_LBL")
    public void setM1BREAKTASKLBL(String m1BREAKTASKLBL) {
        this.m1BREAKTASKLBL = m1BREAKTASKLBL;
    }

    /**
     * 
     * @return
     *     The bOSTATUSCD
     */
    @JsonProperty("BO_STATUS_CD")
    public String getBOSTATUSCD() {
        return bOSTATUSCD;
    }

    /**
     * 
     * @param bOSTATUSCD
     *     The BO_STATUS_CD
     */
    @JsonProperty("BO_STATUS_CD")
    public void setBOSTATUSCD(String bOSTATUSCD) {
        this.bOSTATUSCD = bOSTATUSCD;
    }

    /**
     * 
     * @return
     *     The eXTOPTTYPE
     */
    @JsonProperty("EXT_OPT_TYPE")
    public String getEXTOPTTYPE() {
        return eXTOPTTYPE;
    }

    /**
     * 
     * @param eXTOPTTYPE
     *     The EXT_OPT_TYPE
     */
    @JsonProperty("EXT_OPT_TYPE")
    public void setEXTOPTTYPE(String eXTOPTTYPE) {
        this.eXTOPTTYPE = eXTOPTTYPE;
    }

    /**
     * 
     * @return
     *     The m1SUBURB
     */
    @JsonProperty("M1_SUBURB")
    public String getM1SUBURB() {
        return m1SUBURB;
    }

    /**
     * 
     * @param m1SUBURB
     *     The M1_SUBURB
     */
    @JsonProperty("M1_SUBURB")
    public void setM1SUBURB(String m1SUBURB) {
        this.m1SUBURB = m1SUBURB;
    }

    /**
     * 
     * @return
     *     The m1ITEMLOADSTATUSFLG
     */
    @JsonProperty("M1_ITEM_LOAD_STATUS_FLG")
    public String getM1ITEMLOADSTATUSFLG() {
        return m1ITEMLOADSTATUSFLG;
    }

    /**
     * 
     * @param m1ITEMLOADSTATUSFLG
     *     The M1_ITEM_LOAD_STATUS_FLG
     */
    @JsonProperty("M1_ITEM_LOAD_STATUS_FLG")
    public void setM1ITEMLOADSTATUSFLG(String m1ITEMLOADSTATUSFLG) {
        this.m1ITEMLOADSTATUSFLG = m1ITEMLOADSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The pROCEDURECOMMENTS
     */
    @JsonProperty("PROCEDURE_COMMENTS")
    public String getPROCEDURECOMMENTS() {
        return pROCEDURECOMMENTS;
    }

    /**
     * 
     * @param pROCEDURECOMMENTS
     *     The PROCEDURE_COMMENTS
     */
    @JsonProperty("PROCEDURE_COMMENTS")
    public void setPROCEDURECOMMENTS(String pROCEDURECOMMENTS) {
        this.pROCEDURECOMMENTS = pROCEDURECOMMENTS;
    }

    /**
     * 
     * @return
     *     The m1SHIFTACTIONSLBL
     */
    @JsonProperty("M1_SHIFT_ACTIONS_LBL")
    public String getM1SHIFTACTIONSLBL() {
        return m1SHIFTACTIONSLBL;
    }

    /**
     * 
     * @param m1SHIFTACTIONSLBL
     *     The M1_SHIFT_ACTIONS_LBL
     */
    @JsonProperty("M1_SHIFT_ACTIONS_LBL")
    public void setM1SHIFTACTIONSLBL(String m1SHIFTACTIONSLBL) {
        this.m1SHIFTACTIONSLBL = m1SHIFTACTIONSLBL;
    }

    /**
     * 
     * @return
     *     The m1CONTACTNAME
     */
    @JsonProperty("M1_CONTACT_NAME")
    public String getM1CONTACTNAME() {
        return m1CONTACTNAME;
    }

    /**
     * 
     * @param m1CONTACTNAME
     *     The M1_CONTACT_NAME
     */
    @JsonProperty("M1_CONTACT_NAME")
    public void setM1CONTACTNAME(String m1CONTACTNAME) {
        this.m1CONTACTNAME = m1CONTACTNAME;
    }

    /**
     * 
     * @return
     *     The m1GALLERYLBL
     */
    @JsonProperty("M1_GALLERY_LBL")
    public String getM1GALLERYLBL() {
        return m1GALLERYLBL;
    }

    /**
     * 
     * @param m1GALLERYLBL
     *     The M1_GALLERY_LBL
     */
    @JsonProperty("M1_GALLERY_LBL")
    public void setM1GALLERYLBL(String m1GALLERYLBL) {
        this.m1GALLERYLBL = m1GALLERYLBL;
    }

    /**
     * 
     * @return
     *     The m1SYNCALERTTYPE
     */
    @JsonProperty("M1_SYNC_ALERT_TYPE")
    public String getM1SYNCALERTTYPE() {
        return m1SYNCALERTTYPE;
    }

    /**
     * 
     * @param m1SYNCALERTTYPE
     *     The M1_SYNC_ALERT_TYPE
     */
    @JsonProperty("M1_SYNC_ALERT_TYPE")
    public void setM1SYNCALERTTYPE(String m1SYNCALERTTYPE) {
        this.m1SYNCALERTTYPE = m1SYNCALERTTYPE;
    }

    /**
     * 
     * @return
     *     The m1SCHEDPRIORITYVAL
     */
    @JsonProperty("M1_SCHED_PRIORITY_VAL")
    public String getM1SCHEDPRIORITYVAL() {
        return m1SCHEDPRIORITYVAL;
    }

    /**
     * 
     * @param m1SCHEDPRIORITYVAL
     *     The M1_SCHED_PRIORITY_VAL
     */
    @JsonProperty("M1_SCHED_PRIORITY_VAL")
    public void setM1SCHEDPRIORITYVAL(String m1SCHEDPRIORITYVAL) {
        this.m1SCHEDPRIORITYVAL = m1SCHEDPRIORITYVAL;
    }

    /**
     * 
     * @return
     *     The m1LEFTATLBL
     */
    @JsonProperty("M1_LEFT_AT_LBL")
    public String getM1LEFTATLBL() {
        return m1LEFTATLBL;
    }

    /**
     * 
     * @param m1LEFTATLBL
     *     The M1_LEFT_AT_LBL
     */
    @JsonProperty("M1_LEFT_AT_LBL")
    public void setM1LEFTATLBL(String m1LEFTATLBL) {
        this.m1LEFTATLBL = m1LEFTATLBL;
    }

    /**
     * 
     * @return
     *     The m1LATECOST
     */
    @JsonProperty("M1_LATE_COST")
    public String getM1LATECOST() {
        return m1LATECOST;
    }

    /**
     * 
     * @param m1LATECOST
     *     The M1_LATE_COST
     */
    @JsonProperty("M1_LATE_COST")
    public void setM1LATECOST(String m1LATECOST) {
        this.m1LATECOST = m1LATECOST;
    }

    /**
     * 
     * @return
     *     The m1POUSHIFTID
     */
    @JsonProperty("M1_POU_SHIFT_ID")
    public String getM1POUSHIFTID() {
        return m1POUSHIFTID;
    }

    /**
     * 
     * @param m1POUSHIFTID
     *     The M1_POU_SHIFT_ID
     */
    @JsonProperty("M1_POU_SHIFT_ID")
    public void setM1POUSHIFTID(String m1POUSHIFTID) {
        this.m1POUSHIFTID = m1POUSHIFTID;
    }

    /**
     * 
     * @return
     *     The m1SERVERSYNC
     */
    @JsonProperty("M1_SERVERSYNC")
    public String getM1SERVERSYNC() {
        return m1SERVERSYNC;
    }

    /**
     * 
     * @param m1SERVERSYNC
     *     The M1_SERVERSYNC
     */
    @JsonProperty("M1_SERVERSYNC")
    public void setM1SERVERSYNC(String m1SERVERSYNC) {
        this.m1SERVERSYNC = m1SERVERSYNC;
    }

    /**
     * 
     * @return
     *     The m1ELGBCONTRACTINGFLG
     */
    @JsonProperty("M1_ELGB_CONTRACTING_FLG")
    public String getM1ELGBCONTRACTINGFLG() {
        return m1ELGBCONTRACTINGFLG;
    }

    /**
     * 
     * @param m1ELGBCONTRACTINGFLG
     *     The M1_ELGB_CONTRACTING_FLG
     */
    @JsonProperty("M1_ELGB_CONTRACTING_FLG")
    public void setM1ELGBCONTRACTINGFLG(String m1ELGBCONTRACTINGFLG) {
        this.m1ELGBCONTRACTINGFLG = m1ELGBCONTRACTINGFLG;
    }

    /**
     * 
     * @return
     *     The bODATAAREA
     */
    @JsonProperty("BO_DATA_AREA")
    public String getBODATAAREA() {
        return bODATAAREA;
    }

    /**
     * 
     * @param bODATAAREA
     *     The BO_DATA_AREA
     */
    @JsonProperty("BO_DATA_AREA")
    public void setBODATAAREA(String bODATAAREA) {
        this.bODATAAREA = bODATAAREA;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYALTERNATEID
     */
    @JsonProperty("M1_ACTIVITY_ALTERNATE_ID")
    public String getM1ACTIVITYALTERNATEID() {
        return m1ACTIVITYALTERNATEID;
    }

    /**
     * 
     * @param m1ACTIVITYALTERNATEID
     *     The M1_ACTIVITY_ALTERNATE_ID
     */
    @JsonProperty("M1_ACTIVITY_ALTERNATE_ID")
    public void setM1ACTIVITYALTERNATEID(String m1ACTIVITYALTERNATEID) {
        this.m1ACTIVITYALTERNATEID = m1ACTIVITYALTERNATEID;
    }

    /**
     * 
     * @return
     *     The wFMMSGCD
     */
    @JsonProperty("WFM_MSG_CD")
    public String getWFMMSGCD() {
        return wFMMSGCD;
    }

    /**
     * 
     * @param wFMMSGCD
     *     The WFM_MSG_CD
     */
    @JsonProperty("WFM_MSG_CD")
    public void setWFMMSGCD(String wFMMSGCD) {
        this.wFMMSGCD = wFMMSGCD;
    }

    /**
     * 
     * @return
     *     The m1INBOXLBL
     */
    @JsonProperty("M1_INBOX_LBL")
    public String getM1INBOXLBL() {
        return m1INBOXLBL;
    }

    /**
     * 
     * @param m1INBOXLBL
     *     The M1_INBOX_LBL
     */
    @JsonProperty("M1_INBOX_LBL")
    public void setM1INBOXLBL(String m1INBOXLBL) {
        this.m1INBOXLBL = m1INBOXLBL;
    }

    /**
     * 
     * @return
     *     The m1INFOLBL
     */
    @JsonProperty("M1_INFO_LBL")
    public String getM1INFOLBL() {
        return m1INFOLBL;
    }

    /**
     * 
     * @param m1INFOLBL
     *     The M1_INFO_LBL
     */
    @JsonProperty("M1_INFO_LBL")
    public void setM1INFOLBL(String m1INFOLBL) {
        this.m1INFOLBL = m1INFOLBL;
    }

    /**
     * 
     * @return
     *     The m1LOADEDLBL
     */
    @JsonProperty("M1_LOADED_LBL")
    public String getM1LOADEDLBL() {
        return m1LOADEDLBL;
    }

    /**
     * 
     * @param m1LOADEDLBL
     *     The M1_LOADED_LBL
     */
    @JsonProperty("M1_LOADED_LBL")
    public void setM1LOADEDLBL(String m1LOADEDLBL) {
        this.m1LOADEDLBL = m1LOADEDLBL;
    }

    /**
     * 
     * @return
     *     The m1HOSTCHAINEXTID
     */
    @JsonProperty("M1_HOST_CHAIN_EXT_ID")
    public String getM1HOSTCHAINEXTID() {
        return m1HOSTCHAINEXTID;
    }

    /**
     * 
     * @param m1HOSTCHAINEXTID
     *     The M1_HOST_CHAIN_EXT_ID
     */
    @JsonProperty("M1_HOST_CHAIN_EXT_ID")
    public void setM1HOSTCHAINEXTID(String m1HOSTCHAINEXTID) {
        this.m1HOSTCHAINEXTID = m1HOSTCHAINEXTID;
    }

    /**
     * 
     * @return
     *     The m1CONTRELIGVERSION
     */
    @JsonProperty("M1_CONTR_ELIG_VERSION")
    public String getM1CONTRELIGVERSION() {
        return m1CONTRELIGVERSION;
    }

    /**
     * 
     * @param m1CONTRELIGVERSION
     *     The M1_CONTR_ELIG_VERSION
     */
    @JsonProperty("M1_CONTR_ELIG_VERSION")
    public void setM1CONTRELIGVERSION(String m1CONTRELIGVERSION) {
        this.m1CONTRELIGVERSION = m1CONTRELIGVERSION;
    }

    /**
     * 
     * @return
     *     The m1MDTOWNED
     */
    @JsonProperty("M1_MDTOWNED")
    public String getM1MDTOWNED() {
        return m1MDTOWNED;
    }

    /**
     * 
     * @param m1MDTOWNED
     *     The M1_MDTOWNED
     */
    @JsonProperty("M1_MDTOWNED")
    public void setM1MDTOWNED(String m1MDTOWNED) {
        this.m1MDTOWNED = m1MDTOWNED;
    }

    /**
     * 
     * @return
     *     The m1OVERRIDEFLIPSWLBL
     */
    @JsonProperty("M1_OVERRIDE_FLIPSW_LBL")
    public String getM1OVERRIDEFLIPSWLBL() {
        return m1OVERRIDEFLIPSWLBL;
    }

    /**
     * 
     * @param m1OVERRIDEFLIPSWLBL
     *     The M1_OVERRIDE_FLIPSW_LBL
     */
    @JsonProperty("M1_OVERRIDE_FLIPSW_LBL")
    public void setM1OVERRIDEFLIPSWLBL(String m1OVERRIDEFLIPSWLBL) {
        this.m1OVERRIDEFLIPSWLBL = m1OVERRIDEFLIPSWLBL;
    }

    /**
     * 
     * @return
     *     The m1PLANENDTIME
     */
    @JsonProperty("M1_PLAN_END_TIME")
    public String getM1PLANENDTIME() {
        return m1PLANENDTIME;
    }

    /**
     * 
     * @param m1PLANENDTIME
     *     The M1_PLAN_END_TIME
     */
    @JsonProperty("M1_PLAN_END_TIME")
    public void setM1PLANENDTIME(String m1PLANENDTIME) {
        this.m1PLANENDTIME = m1PLANENDTIME;
    }

    /**
     * 
     * @return
     *     The m1PRIMARYFUNCTION
     */
    @JsonProperty("M1_PRIMARY_FUNCTION")
    public String getM1PRIMARYFUNCTION() {
        return m1PRIMARYFUNCTION;
    }

    /**
     * 
     * @param m1PRIMARYFUNCTION
     *     The M1_PRIMARY_FUNCTION
     */
    @JsonProperty("M1_PRIMARY_FUNCTION")
    public void setM1PRIMARYFUNCTION(String m1PRIMARYFUNCTION) {
        this.m1PRIMARYFUNCTION = m1PRIMARYFUNCTION;
    }

    /**
     * 
     * @return
     *     The m1PERSONID
     */
    @JsonProperty("M1_PERSON_ID")
    public String getM1PERSONID() {
        return m1PERSONID;
    }

    /**
     * 
     * @param m1PERSONID
     *     The M1_PERSON_ID
     */
    @JsonProperty("M1_PERSON_ID")
    public void setM1PERSONID(String m1PERSONID) {
        this.m1PERSONID = m1PERSONID;
    }

    /**
     * 
     * @return
     *     The m1MAILLBL
     */
    @JsonProperty("M1_MAIL_LBL")
    public String getM1MAILLBL() {
        return m1MAILLBL;
    }

    /**
     * 
     * @param m1MAILLBL
     *     The M1_MAIL_LBL
     */
    @JsonProperty("M1_MAIL_LBL")
    public void setM1MAILLBL(String m1MAILLBL) {
        this.m1MAILLBL = m1MAILLBL;
    }

    /**
     * 
     * @return
     *     The cHARTYPECD
     */
    @JsonProperty("CHAR_TYPE_CD")
    public String getCHARTYPECD() {
        return cHARTYPECD;
    }

    /**
     * 
     * @param cHARTYPECD
     *     The CHAR_TYPE_CD
     */
    @JsonProperty("CHAR_TYPE_CD")
    public void setCHARTYPECD(String cHARTYPECD) {
        this.cHARTYPECD = cHARTYPECD;
    }

    /**
     * 
     * @return
     *     The m1ADVANCEDDISPATCHOFFSET
     */
    @JsonProperty("M1_ADVANCED_DISPATCH_OFFSET")
    public String getM1ADVANCEDDISPATCHOFFSET() {
        return m1ADVANCEDDISPATCHOFFSET;
    }

    /**
     * 
     * @param m1ADVANCEDDISPATCHOFFSET
     *     The M1_ADVANCED_DISPATCH_OFFSET
     */
    @JsonProperty("M1_ADVANCED_DISPATCH_OFFSET")
    public void setM1ADVANCEDDISPATCHOFFSET(String m1ADVANCEDDISPATCHOFFSET) {
        this.m1ADVANCEDDISPATCHOFFSET = m1ADVANCEDDISPATCHOFFSET;
    }

    /**
     * 
     * @return
     *     The eRRORLBL
     */
    @JsonProperty("ERROR_LBL")
    public String getERRORLBL() {
        return eRRORLBL;
    }

    /**
     * 
     * @param eRRORLBL
     *     The ERROR_LBL
     */
    @JsonProperty("ERROR_LBL")
    public void setERRORLBL(String eRRORLBL) {
        this.eRRORLBL = eRRORLBL;
    }

    /**
     * 
     * @return
     *     The m1CRWLBL
     */
    @JsonProperty("M1_CRW_LBL")
    public String getM1CRWLBL() {
        return m1CRWLBL;
    }

    /**
     * 
     * @param m1CRWLBL
     *     The M1_CRW_LBL
     */
    @JsonProperty("M1_CRW_LBL")
    public void setM1CRWLBL(String m1CRWLBL) {
        this.m1CRWLBL = m1CRWLBL;
    }

    /**
     * 
     * @return
     *     The pKVALUE2
     */
    @JsonProperty("PK_VALUE2")
    public String getPKVALUE2() {
        return pKVALUE2;
    }

    /**
     * 
     * @param pKVALUE2
     *     The PK_VALUE2
     */
    @JsonProperty("PK_VALUE2")
    public void setPKVALUE2(String pKVALUE2) {
        this.pKVALUE2 = pKVALUE2;
    }

    /**
     * 
     * @return
     *     The pKVALUE1
     */
    @JsonProperty("PK_VALUE1")
    public String getPKVALUE1() {
        return pKVALUE1;
    }

    /**
     * 
     * @param pKVALUE1
     *     The PK_VALUE1
     */
    @JsonProperty("PK_VALUE1")
    public void setPKVALUE1(String pKVALUE1) {
        this.pKVALUE1 = pKVALUE1;
    }

    /**
     * 
     * @return
     *     The pKVALUE4
     */
    @JsonProperty("PK_VALUE4")
    public String getPKVALUE4() {
        return pKVALUE4;
    }

    /**
     * 
     * @param pKVALUE4
     *     The PK_VALUE4
     */
    @JsonProperty("PK_VALUE4")
    public void setPKVALUE4(String pKVALUE4) {
        this.pKVALUE4 = pKVALUE4;
    }

    /**
     * 
     * @return
     *     The pKVALUE3
     */
    @JsonProperty("PK_VALUE3")
    public String getPKVALUE3() {
        return pKVALUE3;
    }

    /**
     * 
     * @param pKVALUE3
     *     The PK_VALUE3
     */
    @JsonProperty("PK_VALUE3")
    public void setPKVALUE3(String pKVALUE3) {
        this.pKVALUE3 = pKVALUE3;
    }

    /**
     * 
     * @return
     *     The m1LOGONLOCATIONTYPE
     */
    @JsonProperty("M1_LOGON_LOCATION_TYPE")
    public String getM1LOGONLOCATIONTYPE() {
        return m1LOGONLOCATIONTYPE;
    }

    /**
     * 
     * @param m1LOGONLOCATIONTYPE
     *     The M1_LOGON_LOCATION_TYPE
     */
    @JsonProperty("M1_LOGON_LOCATION_TYPE")
    public void setM1LOGONLOCATIONTYPE(String m1LOGONLOCATIONTYPE) {
        this.m1LOGONLOCATIONTYPE = m1LOGONLOCATIONTYPE;
    }

    /**
     * 
     * @return
     *     The pKVALUE5
     */
    @JsonProperty("PK_VALUE5")
    public String getPKVALUE5() {
        return pKVALUE5;
    }

    /**
     * 
     * @param pKVALUE5
     *     The PK_VALUE5
     */
    @JsonProperty("PK_VALUE5")
    public void setPKVALUE5(String pKVALUE5) {
        this.pKVALUE5 = pKVALUE5;
    }

    /**
     * 
     * @return
     *     The m1VIEWSHFPRCDRLBL
     */
    @JsonProperty("M1_VIEW_SHF_PRCDR_LBL")
    public String getM1VIEWSHFPRCDRLBL() {
        return m1VIEWSHFPRCDRLBL;
    }

    /**
     * 
     * @param m1VIEWSHFPRCDRLBL
     *     The M1_VIEW_SHF_PRCDR_LBL
     */
    @JsonProperty("M1_VIEW_SHF_PRCDR_LBL")
    public void setM1VIEWSHFPRCDRLBL(String m1VIEWSHFPRCDRLBL) {
        this.m1VIEWSHFPRCDRLBL = m1VIEWSHFPRCDRLBL;
    }

    /**
     * 
     * @return
     *     The m1SYSTEMGENFLG
     */
    @JsonProperty("M1_SYSTEM_GEN_FLG")
    public String getM1SYSTEMGENFLG() {
        return m1SYSTEMGENFLG;
    }

    /**
     * 
     * @param m1SYSTEMGENFLG
     *     The M1_SYSTEM_GEN_FLG
     */
    @JsonProperty("M1_SYSTEM_GEN_FLG")
    public void setM1SYSTEMGENFLG(String m1SYSTEMGENFLG) {
        this.m1SYSTEMGENFLG = m1SYSTEMGENFLG;
    }

    /**
     * 
     * @return
     *     The m1GEOCODELATITUDE
     */
    @JsonProperty("M1_GEOCODE_LATITUDE")
    public String getM1GEOCODELATITUDE() {
        return m1GEOCODELATITUDE;
    }

    /**
     * 
     * @param m1GEOCODELATITUDE
     *     The M1_GEOCODE_LATITUDE
     */
    @JsonProperty("M1_GEOCODE_LATITUDE")
    public void setM1GEOCODELATITUDE(String m1GEOCODELATITUDE) {
        this.m1GEOCODELATITUDE = m1GEOCODELATITUDE;
    }

    /**
     * 
     * @return
     *     The m1ELEMINDEX
     */
    @JsonProperty("M1_ELEM_INDEX")
    public String getM1ELEMINDEX() {
        return m1ELEMINDEX;
    }

    /**
     * 
     * @param m1ELEMINDEX
     *     The M1_ELEM_INDEX
     */
    @JsonProperty("M1_ELEM_INDEX")
    public void setM1ELEMINDEX(String m1ELEMINDEX) {
        this.m1ELEMINDEX = m1ELEMINDEX;
    }

    /**
     * 
     * @return
     *     The m1ITEMDELIVERYSTATUSFLG
     */
    @JsonProperty("M1_ITEM_DELIVERY_STATUS_FLG")
    public String getM1ITEMDELIVERYSTATUSFLG() {
        return m1ITEMDELIVERYSTATUSFLG;
    }

    /**
     * 
     * @param m1ITEMDELIVERYSTATUSFLG
     *     The M1_ITEM_DELIVERY_STATUS_FLG
     */
    @JsonProperty("M1_ITEM_DELIVERY_STATUS_FLG")
    public void setM1ITEMDELIVERYSTATUSFLG(String m1ITEMDELIVERYSTATUSFLG) {
        this.m1ITEMDELIVERYSTATUSFLG = m1ITEMDELIVERYSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYLBL
     */
    @JsonProperty("M1_ACTIVITY_LBL")
    public String getM1ACTIVITYLBL() {
        return m1ACTIVITYLBL;
    }

    /**
     * 
     * @param m1ACTIVITYLBL
     *     The M1_ACTIVITY_LBL
     */
    @JsonProperty("M1_ACTIVITY_LBL")
    public void setM1ACTIVITYLBL(String m1ACTIVITYLBL) {
        this.m1ACTIVITYLBL = m1ACTIVITYLBL;
    }

    /**
     * 
     * @return
     *     The m1DEPOTRELASSIGNMENTLBL
     */
    @JsonProperty("M1_DEPOT_REL_ASSIGNMENT_LBL")
    public String getM1DEPOTRELASSIGNMENTLBL() {
        return m1DEPOTRELASSIGNMENTLBL;
    }

    /**
     * 
     * @param m1DEPOTRELASSIGNMENTLBL
     *     The M1_DEPOT_REL_ASSIGNMENT_LBL
     */
    @JsonProperty("M1_DEPOT_REL_ASSIGNMENT_LBL")
    public void setM1DEPOTRELASSIGNMENTLBL(String m1DEPOTRELASSIGNMENTLBL) {
        this.m1DEPOTRELASSIGNMENTLBL = m1DEPOTRELASSIGNMENTLBL;
    }

    /**
     * 
     * @return
     *     The m1DEFERMENTCOMMENTS
     */
    @JsonProperty("M1_DEFERMENT_COMMENTS")
    public String getM1DEFERMENTCOMMENTS() {
        return m1DEFERMENTCOMMENTS;
    }

    /**
     * 
     * @param m1DEFERMENTCOMMENTS
     *     The M1_DEFERMENT_COMMENTS
     */
    @JsonProperty("M1_DEFERMENT_COMMENTS")
    public void setM1DEFERMENTCOMMENTS(String m1DEFERMENTCOMMENTS) {
        this.m1DEFERMENTCOMMENTS = m1DEFERMENTCOMMENTS;
    }

    /**
     * 
     * @return
     *     The m1CREWNAME
     */
    @JsonProperty("M1_CREW_NAME")
    public String getM1CREWNAME() {
        return m1CREWNAME;
    }

    /**
     * 
     * @param m1CREWNAME
     *     The M1_CREW_NAME
     */
    @JsonProperty("M1_CREW_NAME")
    public void setM1CREWNAME(String m1CREWNAME) {
        this.m1CREWNAME = m1CREWNAME;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYPROCEDURESLBL
     */
    @JsonProperty("M1_ACTIVITY_PROCEDURES_LBL")
    public String getM1ACTIVITYPROCEDURESLBL() {
        return m1ACTIVITYPROCEDURESLBL;
    }

    /**
     * 
     * @param m1ACTIVITYPROCEDURESLBL
     *     The M1_ACTIVITY_PROCEDURES_LBL
     */
    @JsonProperty("M1_ACTIVITY_PROCEDURES_LBL")
    public void setM1ACTIVITYPROCEDURESLBL(String m1ACTIVITYPROCEDURESLBL) {
        this.m1ACTIVITYPROCEDURESLBL = m1ACTIVITYPROCEDURESLBL;
    }

    /**
     * 
     * @return
     *     The oUTMSGPRIORFLG
     */
    @JsonProperty("OUTMSG_PRIOR_FLG")
    public String getOUTMSGPRIORFLG() {
        return oUTMSGPRIORFLG;
    }

    /**
     * 
     * @param oUTMSGPRIORFLG
     *     The OUTMSG_PRIOR_FLG
     */
    @JsonProperty("OUTMSG_PRIOR_FLG")
    public void setOUTMSGPRIORFLG(String oUTMSGPRIORFLG) {
        this.oUTMSGPRIORFLG = oUTMSGPRIORFLG;
    }

    /**
     * 
     * @return
     *     The m1AUTOCOMPFLG
     */
    @JsonProperty("M1_AUTO_COMP_FLG")
    public String getM1AUTOCOMPFLG() {
        return m1AUTOCOMPFLG;
    }

    /**
     * 
     * @param m1AUTOCOMPFLG
     *     The M1_AUTO_COMP_FLG
     */
    @JsonProperty("M1_AUTO_COMP_FLG")
    public void setM1AUTOCOMPFLG(String m1AUTOCOMPFLG) {
        this.m1AUTOCOMPFLG = m1AUTOCOMPFLG;
    }

    /**
     * 
     * @return
     *     The m1DOWNLOADALL
     */
    @JsonProperty("M1_DOWNLOAD_ALL")
    public String getM1DOWNLOADALL() {
        return m1DOWNLOADALL;
    }

    /**
     * 
     * @param m1DOWNLOADALL
     *     The M1_DOWNLOAD_ALL
     */
    @JsonProperty("M1_DOWNLOAD_ALL")
    public void setM1DOWNLOADALL(String m1DOWNLOADALL) {
        this.m1DOWNLOADALL = m1DOWNLOADALL;
    }

    /**
     * 
     * @return
     *     The m1COLLISIONDETECTEDTODOTYP
     */
    @JsonProperty("M1_COLLISION_DETECTED_TODO_TYP")
    public String getM1COLLISIONDETECTEDTODOTYP() {
        return m1COLLISIONDETECTEDTODOTYP;
    }

    /**
     * 
     * @param m1COLLISIONDETECTEDTODOTYP
     *     The M1_COLLISION_DETECTED_TODO_TYP
     */
    @JsonProperty("M1_COLLISION_DETECTED_TODO_TYP")
    public void setM1COLLISIONDETECTEDTODOTYP(String m1COLLISIONDETECTEDTODOTYP) {
        this.m1COLLISIONDETECTEDTODOTYP = m1COLLISIONDETECTEDTODOTYP;
    }

    /**
     * 
     * @return
     *     The m1GUARDELLBL
     */
    @JsonProperty("M1_GUAR_DEL_LBL")
    public String getM1GUARDELLBL() {
        return m1GUARDELLBL;
    }

    /**
     * 
     * @param m1GUARDELLBL
     *     The M1_GUAR_DEL_LBL
     */
    @JsonProperty("M1_GUAR_DEL_LBL")
    public void setM1GUARDELLBL(String m1GUARDELLBL) {
        this.m1GUARDELLBL = m1GUARDELLBL;
    }

    /**
     * 
     * @return
     *     The m1ADDRESSCOUNTY
     */
    @JsonProperty("M1_ADDRESS_COUNTY")
    public String getM1ADDRESSCOUNTY() {
        return m1ADDRESSCOUNTY;
    }

    /**
     * 
     * @param m1ADDRESSCOUNTY
     *     The M1_ADDRESS_COUNTY
     */
    @JsonProperty("M1_ADDRESS_COUNTY")
    public void setM1ADDRESSCOUNTY(String m1ADDRESSCOUNTY) {
        this.m1ADDRESSCOUNTY = m1ADDRESSCOUNTY;
    }

    /**
     * 
     * @return
     *     The m1DEFERMENTREASONFLG
     */
    @JsonProperty("M1_DEFERMENT_REASON_FLG")
    public String getM1DEFERMENTREASONFLG() {
        return m1DEFERMENTREASONFLG;
    }

    /**
     * 
     * @param m1DEFERMENTREASONFLG
     *     The M1_DEFERMENT_REASON_FLG
     */
    @JsonProperty("M1_DEFERMENT_REASON_FLG")
    public void setM1DEFERMENTREASONFLG(String m1DEFERMENTREASONFLG) {
        this.m1DEFERMENTREASONFLG = m1DEFERMENTREASONFLG;
    }

    /**
     * 
     * @return
     *     The m1SUBJECT
     */
    @JsonProperty("M1_SUBJECT")
    public String getM1SUBJECT() {
        return m1SUBJECT;
    }

    /**
     * 
     * @param m1SUBJECT
     *     The M1_SUBJECT
     */
    @JsonProperty("M1_SUBJECT")
    public void setM1SUBJECT(String m1SUBJECT) {
        this.m1SUBJECT = m1SUBJECT;
    }

    /**
     * 
     * @return
     *     The m1PANICHEADERLBL
     */
    @JsonProperty("M1_PANIC_HEADER_LBL")
    public String getM1PANICHEADERLBL() {
        return m1PANICHEADERLBL;
    }

    /**
     * 
     * @param m1PANICHEADERLBL
     *     The M1_PANIC_HEADER_LBL
     */
    @JsonProperty("M1_PANIC_HEADER_LBL")
    public void setM1PANICHEADERLBL(String m1PANICHEADERLBL) {
        this.m1PANICHEADERLBL = m1PANICHEADERLBL;
    }

    /**
     * 
     * @return
     *     The tASKALTID
     */
    @JsonProperty("TASK_ALT_ID")
    public String getTASKALTID() {
        return tASKALTID;
    }

    /**
     * 
     * @param tASKALTID
     *     The TASK_ALT_ID
     */
    @JsonProperty("TASK_ALT_ID")
    public void setTASKALTID(String tASKALTID) {
        this.tASKALTID = tASKALTID;
    }

    /**
     * 
     * @return
     *     The sEQNUM
     */
    @JsonProperty("SEQ_NUM")
    public String getSEQNUM() {
        return sEQNUM;
    }

    /**
     * 
     * @param sEQNUM
     *     The SEQ_NUM
     */
    @JsonProperty("SEQ_NUM")
    public void setSEQNUM(String sEQNUM) {
        this.sEQNUM = sEQNUM;
    }

    /**
     * 
     * @return
     *     The m1LOADALLITEMSLBL
     */
    @JsonProperty("M1_LOAD_ALL_ITEMS_LBL")
    public String getM1LOADALLITEMSLBL() {
        return m1LOADALLITEMSLBL;
    }

    /**
     * 
     * @param m1LOADALLITEMSLBL
     *     The M1_LOAD_ALL_ITEMS_LBL
     */
    @JsonProperty("M1_LOAD_ALL_ITEMS_LBL")
    public void setM1LOADALLITEMSLBL(String m1LOADALLITEMSLBL) {
        this.m1LOADALLITEMSLBL = m1LOADALLITEMSLBL;
    }

    /**
     * 
     * @return
     *     The m1SHOWMORELBL
     */
    @JsonProperty("M1_SHOW_MORE_LBL")
    public String getM1SHOWMORELBL() {
        return m1SHOWMORELBL;
    }

    /**
     * 
     * @param m1SHOWMORELBL
     *     The M1_SHOW_MORE_LBL
     */
    @JsonProperty("M1_SHOW_MORE_LBL")
    public void setM1SHOWMORELBL(String m1SHOWMORELBL) {
        this.m1SHOWMORELBL = m1SHOWMORELBL;
    }

    /**
     * 
     * @return
     *     The m1UPDATEDETA
     */
    @JsonProperty("M1_UPDATED_ETA")
    public String getM1UPDATEDETA() {
        return m1UPDATEDETA;
    }

    /**
     * 
     * @param m1UPDATEDETA
     *     The M1_UPDATED_ETA
     */
    @JsonProperty("M1_UPDATED_ETA")
    public void setM1UPDATEDETA(String m1UPDATEDETA) {
        this.m1UPDATEDETA = m1UPDATEDETA;
    }

    /**
     * 
     * @return
     *     The m1RESETSIGNATURELBL
     */
    @JsonProperty("M1_RESET_SIGNATURE_LBL")
    public String getM1RESETSIGNATURELBL() {
        return m1RESETSIGNATURELBL;
    }

    /**
     * 
     * @param m1RESETSIGNATURELBL
     *     The M1_RESET_SIGNATURE_LBL
     */
    @JsonProperty("M1_RESET_SIGNATURE_LBL")
    public void setM1RESETSIGNATURELBL(String m1RESETSIGNATURELBL) {
        this.m1RESETSIGNATURELBL = m1RESETSIGNATURELBL;
    }

    /**
     * 
     * @return
     *     The m1DELIVEREDLBL
     */
    @JsonProperty("M1_DELIVERED_LBL")
    public String getM1DELIVEREDLBL() {
        return m1DELIVEREDLBL;
    }

    /**
     * 
     * @param m1DELIVEREDLBL
     *     The M1_DELIVERED_LBL
     */
    @JsonProperty("M1_DELIVERED_LBL")
    public void setM1DELIVEREDLBL(String m1DELIVEREDLBL) {
        this.m1DELIVEREDLBL = m1DELIVEREDLBL;
    }

    /**
     * 
     * @return
     *     The m1REMARKTYPE
     */
    @JsonProperty("M1_REMARK_TYPE")
    public String getM1REMARKTYPE() {
        return m1REMARKTYPE;
    }

    /**
     * 
     * @param m1REMARKTYPE
     *     The M1_REMARK_TYPE
     */
    @JsonProperty("M1_REMARK_TYPE")
    public void setM1REMARKTYPE(String m1REMARKTYPE) {
        this.m1REMARKTYPE = m1REMARKTYPE;
    }

    /**
     * 
     * @return
     *     The m1LOCKEDTODEPOTTASKID
     */
    @JsonProperty("M1_LOCKED_TO_DEPOT_TASK_ID")
    public String getM1LOCKEDTODEPOTTASKID() {
        return m1LOCKEDTODEPOTTASKID;
    }

    /**
     * 
     * @param m1LOCKEDTODEPOTTASKID
     *     The M1_LOCKED_TO_DEPOT_TASK_ID
     */
    @JsonProperty("M1_LOCKED_TO_DEPOT_TASK_ID")
    public void setM1LOCKEDTODEPOTTASKID(String m1LOCKEDTODEPOTTASKID) {
        this.m1LOCKEDTODEPOTTASKID = m1LOCKEDTODEPOTTASKID;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKBO
     */
    @JsonProperty("M1_DEPOT_TASK_BO")
    public String getM1DEPOTTASKBO() {
        return m1DEPOTTASKBO;
    }

    /**
     * 
     * @param m1DEPOTTASKBO
     *     The M1_DEPOT_TASK_BO
     */
    @JsonProperty("M1_DEPOT_TASK_BO")
    public void setM1DEPOTTASKBO(String m1DEPOTTASKBO) {
        this.m1DEPOTTASKBO = m1DEPOTTASKBO;
    }

    /**
     * 
     * @return
     *     The m1SVCTYPEFLG
     */
    @JsonProperty("M1_SVC_TYPE_FLG")
    public String getM1SVCTYPEFLG() {
        return m1SVCTYPEFLG;
    }

    /**
     * 
     * @param m1SVCTYPEFLG
     *     The M1_SVC_TYPE_FLG
     */
    @JsonProperty("M1_SVC_TYPE_FLG")
    public void setM1SVCTYPEFLG(String m1SVCTYPEFLG) {
        this.m1SVCTYPEFLG = m1SVCTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1MBLWKRLBL
     */
    @JsonProperty("M1_MBL_WKR_LBL")
    public String getM1MBLWKRLBL() {
        return m1MBLWKRLBL;
    }

    /**
     * 
     * @param m1MBLWKRLBL
     *     The M1_MBL_WKR_LBL
     */
    @JsonProperty("M1_MBL_WKR_LBL")
    public void setM1MBLWKRLBL(String m1MBLWKRLBL) {
        this.m1MBLWKRLBL = m1MBLWKRLBL;
    }

    /**
     * 
     * @return
     *     The m1REACHDESTLBL
     */
    @JsonProperty("M1_REACH_DEST_LBL")
    public String getM1REACHDESTLBL() {
        return m1REACHDESTLBL;
    }

    /**
     * 
     * @param m1REACHDESTLBL
     *     The M1_REACH_DEST_LBL
     */
    @JsonProperty("M1_REACH_DEST_LBL")
    public void setM1REACHDESTLBL(String m1REACHDESTLBL) {
        this.m1REACHDESTLBL = m1REACHDESTLBL;
    }

    /**
     * 
     * @return
     *     The wFMMSGCATFLG
     */
    @JsonProperty("WFM_MSG_CAT_FLG")
    public String getWFMMSGCATFLG() {
        return wFMMSGCATFLG;
    }

    /**
     * 
     * @param wFMMSGCATFLG
     *     The WFM_MSG_CAT_FLG
     */
    @JsonProperty("WFM_MSG_CAT_FLG")
    public void setWFMMSGCATFLG(String wFMMSGCATFLG) {
        this.wFMMSGCATFLG = wFMMSGCATFLG;
    }

    /**
     * 
     * @return
     *     The m1SENTBYMAILID
     */
    @JsonProperty("M1_SENT_BY_MAIL_ID")
    public String getM1SENTBYMAILID() {
        return m1SENTBYMAILID;
    }

    /**
     * 
     * @param m1SENTBYMAILID
     *     The M1_SENT_BY_MAIL_ID
     */
    @JsonProperty("M1_SENT_BY_MAIL_ID")
    public void setM1SENTBYMAILID(String m1SENTBYMAILID) {
        this.m1SENTBYMAILID = m1SENTBYMAILID;
    }

    /**
     * 
     * @return
     *     The m1LOGOFFBTNLBL
     */
    @JsonProperty("M1_LOGOFF_BTN_LBL")
    public String getM1LOGOFFBTNLBL() {
        return m1LOGOFFBTNLBL;
    }

    /**
     * 
     * @param m1LOGOFFBTNLBL
     *     The M1_LOGOFF_BTN_LBL
     */
    @JsonProperty("M1_LOGOFF_BTN_LBL")
    public void setM1LOGOFFBTNLBL(String m1LOGOFFBTNLBL) {
        this.m1LOGOFFBTNLBL = m1LOGOFFBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1CHANGESEQUENCEFLG
     */
    @JsonProperty("M1_CHANGE_SEQUENCE_FLG")
    public String getM1CHANGESEQUENCEFLG() {
        return m1CHANGESEQUENCEFLG;
    }

    /**
     * 
     * @param m1CHANGESEQUENCEFLG
     *     The M1_CHANGE_SEQUENCE_FLG
     */
    @JsonProperty("M1_CHANGE_SEQUENCE_FLG")
    public void setM1CHANGESEQUENCEFLG(String m1CHANGESEQUENCEFLG) {
        this.m1CHANGESEQUENCEFLG = m1CHANGESEQUENCEFLG;
    }

    /**
     * 
     * @return
     *     The tSKTMWINDSTARTDTTM
     */
    @JsonProperty("TSK_TM_WIND_START_DTTM")
    public String getTSKTMWINDSTARTDTTM() {
        return tSKTMWINDSTARTDTTM;
    }

    /**
     * 
     * @param tSKTMWINDSTARTDTTM
     *     The TSK_TM_WIND_START_DTTM
     */
    @JsonProperty("TSK_TM_WIND_START_DTTM")
    public void setTSKTMWINDSTARTDTTM(String tSKTMWINDSTARTDTTM) {
        this.tSKTMWINDSTARTDTTM = tSKTMWINDSTARTDTTM;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKTYPE
     */
    @JsonProperty("M1_DEPOT_TASK_TYPE")
    public String getM1DEPOTTASKTYPE() {
        return m1DEPOTTASKTYPE;
    }

    /**
     * 
     * @param m1DEPOTTASKTYPE
     *     The M1_DEPOT_TASK_TYPE
     */
    @JsonProperty("M1_DEPOT_TASK_TYPE")
    public void setM1DEPOTTASKTYPE(String m1DEPOTTASKTYPE) {
        this.m1DEPOTTASKTYPE = m1DEPOTTASKTYPE;
    }

    /**
     * 
     * @return
     *     The mDTINDICATORPOSITION
     */
    @JsonProperty("MDT_INDICATOR_POSITION")
    public String getMDTINDICATORPOSITION() {
        return mDTINDICATORPOSITION;
    }

    /**
     * 
     * @param mDTINDICATORPOSITION
     *     The MDT_INDICATOR_POSITION
     */
    @JsonProperty("MDT_INDICATOR_POSITION")
    public void setMDTINDICATORPOSITION(String mDTINDICATORPOSITION) {
        this.mDTINDICATORPOSITION = mDTINDICATORPOSITION;
    }

    /**
     * 
     * @return
     *     The m1RTNTOSVCLBL
     */
    @JsonProperty("M1_RTN_TO_SVC_LBL")
    public String getM1RTNTOSVCLBL() {
        return m1RTNTOSVCLBL;
    }

    /**
     * 
     * @param m1RTNTOSVCLBL
     *     The M1_RTN_TO_SVC_LBL
     */
    @JsonProperty("M1_RTN_TO_SVC_LBL")
    public void setM1RTNTOSVCLBL(String m1RTNTOSVCLBL) {
        this.m1RTNTOSVCLBL = m1RTNTOSVCLBL;
    }

    /**
     * 
     * @return
     *     The m1OVERTIMETYPEEXTID
     */
    @JsonProperty("M1_OVERTIME_TYPE_EXT_ID")
    public String getM1OVERTIMETYPEEXTID() {
        return m1OVERTIMETYPEEXTID;
    }

    /**
     * 
     * @param m1OVERTIMETYPEEXTID
     *     The M1_OVERTIME_TYPE_EXT_ID
     */
    @JsonProperty("M1_OVERTIME_TYPE_EXT_ID")
    public void setM1OVERTIMETYPEEXTID(String m1OVERTIMETYPEEXTID) {
        this.m1OVERTIMETYPEEXTID = m1OVERTIMETYPEEXTID;
    }

    /**
     * 
     * @return
     *     The m1NEWFUNCTIONLBL
     */
    @JsonProperty("M1_NEW_FUNCTION_LBL")
    public String getM1NEWFUNCTIONLBL() {
        return m1NEWFUNCTIONLBL;
    }

    /**
     * 
     * @param m1NEWFUNCTIONLBL
     *     The M1_NEW_FUNCTION_LBL
     */
    @JsonProperty("M1_NEW_FUNCTION_LBL")
    public void setM1NEWFUNCTIONLBL(String m1NEWFUNCTIONLBL) {
        this.m1NEWFUNCTIONLBL = m1NEWFUNCTIONLBL;
    }

    /**
     * 
     * @return
     *     The m1CORRECTLBL
     */
    @JsonProperty("M1_CORRECT_LBL")
    public String getM1CORRECTLBL() {
        return m1CORRECTLBL;
    }

    /**
     * 
     * @param m1CORRECTLBL
     *     The M1_CORRECT_LBL
     */
    @JsonProperty("M1_CORRECT_LBL")
    public void setM1CORRECTLBL(String m1CORRECTLBL) {
        this.m1CORRECTLBL = m1CORRECTLBL;
    }

    /**
     * 
     * @return
     *     The m1BREAKTIME
     */
    @JsonProperty("M1_BREAK_TIME")
    public String getM1BREAKTIME() {
        return m1BREAKTIME;
    }

    /**
     * 
     * @param m1BREAKTIME
     *     The M1_BREAK_TIME
     */
    @JsonProperty("M1_BREAK_TIME")
    public void setM1BREAKTIME(String m1BREAKTIME) {
        this.m1BREAKTIME = m1BREAKTIME;
    }

    /**
     * 
     * @return
     *     The m1RTNSVCPRPT
     */
    @JsonProperty("M1_RTN_SVC_PRPT")
    public String getM1RTNSVCPRPT() {
        return m1RTNSVCPRPT;
    }

    /**
     * 
     * @param m1RTNSVCPRPT
     *     The M1_RTN_SVC_PRPT
     */
    @JsonProperty("M1_RTN_SVC_PRPT")
    public void setM1RTNSVCPRPT(String m1RTNSVCPRPT) {
        this.m1RTNSVCPRPT = m1RTNSVCPRPT;
    }

    /**
     * 
     * @return
     *     The m1MCPCAPABILITYTYPMAINLBL
     */
    @JsonProperty("M1_MCP_CAPABILITY_TYP_MAIN_LBL")
    public String getM1MCPCAPABILITYTYPMAINLBL() {
        return m1MCPCAPABILITYTYPMAINLBL;
    }

    /**
     * 
     * @param m1MCPCAPABILITYTYPMAINLBL
     *     The M1_MCP_CAPABILITY_TYP_MAIN_LBL
     */
    @JsonProperty("M1_MCP_CAPABILITY_TYP_MAIN_LBL")
    public void setM1MCPCAPABILITYTYPMAINLBL(String m1MCPCAPABILITYTYPMAINLBL) {
        this.m1MCPCAPABILITYTYPMAINLBL = m1MCPCAPABILITYTYPMAINLBL;
    }

    /**
     * 
     * @return
     *     The m1CREWINQUIRYTYPE
     */
    @JsonProperty("M1_CREWINQUIRY_TYPE")
    public String getM1CREWINQUIRYTYPE() {
        return m1CREWINQUIRYTYPE;
    }

    /**
     * 
     * @param m1CREWINQUIRYTYPE
     *     The M1_CREWINQUIRY_TYPE
     */
    @JsonProperty("M1_CREWINQUIRY_TYPE")
    public void setM1CREWINQUIRYTYPE(String m1CREWINQUIRYTYPE) {
        this.m1CREWINQUIRYTYPE = m1CREWINQUIRYTYPE;
    }

    /**
     * 
     * @return
     *     The aDDR1AVAIL
     */
    @JsonProperty("ADDR1_AVAIL")
    public String getADDR1AVAIL() {
        return aDDR1AVAIL;
    }

    /**
     * 
     * @param aDDR1AVAIL
     *     The ADDR1_AVAIL
     */
    @JsonProperty("ADDR1_AVAIL")
    public void setADDR1AVAIL(String aDDR1AVAIL) {
        this.aDDR1AVAIL = aDDR1AVAIL;
    }

    /**
     * 
     * @return
     *     The m1SCANNEXTLBL
     */
    @JsonProperty("M1_SCAN_NEXT_LBL")
    public String getM1SCANNEXTLBL() {
        return m1SCANNEXTLBL;
    }

    /**
     * 
     * @param m1SCANNEXTLBL
     *     The M1_SCAN_NEXT_LBL
     */
    @JsonProperty("M1_SCAN_NEXT_LBL")
    public void setM1SCANNEXTLBL(String m1SCANNEXTLBL) {
        this.m1SCANNEXTLBL = m1SCANNEXTLBL;
    }

    /**
     * 
     * @return
     *     The oVERRIDEALLOCATIONRULE
     */
    @JsonProperty("OVERRIDE_ALLOCATION_RULE")
    public String getOVERRIDEALLOCATIONRULE() {
        return oVERRIDEALLOCATIONRULE;
    }

    /**
     * 
     * @param oVERRIDEALLOCATIONRULE
     *     The OVERRIDE_ALLOCATION_RULE
     */
    @JsonProperty("OVERRIDE_ALLOCATION_RULE")
    public void setOVERRIDEALLOCATIONRULE(String oVERRIDEALLOCATIONRULE) {
        this.oVERRIDEALLOCATIONRULE = oVERRIDEALLOCATIONRULE;
    }

    /**
     * 
     * @return
     *     The m1SECONDSLBL
     */
    @JsonProperty("M1_SECONDS_LBL")
    public String getM1SECONDSLBL() {
        return m1SECONDSLBL;
    }

    /**
     * 
     * @param m1SECONDSLBL
     *     The M1_SECONDS_LBL
     */
    @JsonProperty("M1_SECONDS_LBL")
    public void setM1SECONDSLBL(String m1SECONDSLBL) {
        this.m1SECONDSLBL = m1SECONDSLBL;
    }

    /**
     * 
     * @return
     *     The mDTINDICATORCODE
     */
    @JsonProperty("MDT_INDICATOR_CODE")
    public String getMDTINDICATORCODE() {
        return mDTINDICATORCODE;
    }

    /**
     * 
     * @param mDTINDICATORCODE
     *     The MDT_INDICATOR_CODE
     */
    @JsonProperty("MDT_INDICATOR_CODE")
    public void setMDTINDICATORCODE(String mDTINDICATORCODE) {
        this.mDTINDICATORCODE = mDTINDICATORCODE;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYCLASSFLG
     */
    @JsonProperty("M1_ACTIVITY_CLASS_FLG")
    public String getM1ACTIVITYCLASSFLG() {
        return m1ACTIVITYCLASSFLG;
    }

    /**
     * 
     * @param m1ACTIVITYCLASSFLG
     *     The M1_ACTIVITY_CLASS_FLG
     */
    @JsonProperty("M1_ACTIVITY_CLASS_FLG")
    public void setM1ACTIVITYCLASSFLG(String m1ACTIVITYCLASSFLG) {
        this.m1ACTIVITYCLASSFLG = m1ACTIVITYCLASSFLG;
    }

    /**
     * 
     * @return
     *     The m1DURATION
     */
    @JsonProperty("M1_DURATION")
    public String getM1DURATION() {
        return m1DURATION;
    }

    /**
     * 
     * @param m1DURATION
     *     The M1_DURATION
     */
    @JsonProperty("M1_DURATION")
    public void setM1DURATION(String m1DURATION) {
        this.m1DURATION = m1DURATION;
    }

    /**
     * 
     * @return
     *     The m1SSLBL
     */
    @JsonProperty("M1_SS_LBL")
    public String getM1SSLBL() {
        return m1SSLBL;
    }

    /**
     * 
     * @param m1SSLBL
     *     The M1_SS_LBL
     */
    @JsonProperty("M1_SS_LBL")
    public void setM1SSLBL(String m1SSLBL) {
        this.m1SSLBL = m1SSLBL;
    }

    /**
     * 
     * @return
     *     The m1PROCEDUREMESSAGENBR
     */
    @JsonProperty("M1_PROCEDURE_MESSAGE_NBR")
    public String getM1PROCEDUREMESSAGENBR() {
        return m1PROCEDUREMESSAGENBR;
    }

    /**
     * 
     * @param m1PROCEDUREMESSAGENBR
     *     The M1_PROCEDURE_MESSAGE_NBR
     */
    @JsonProperty("M1_PROCEDURE_MESSAGE_NBR")
    public void setM1PROCEDUREMESSAGENBR(String m1PROCEDUREMESSAGENBR) {
        this.m1PROCEDUREMESSAGENBR = m1PROCEDUREMESSAGENBR;
    }

    /**
     * 
     * @return
     *     The m1ACTUALCOMPLETIONTIME
     */
    @JsonProperty("M1_ACTUAL_COMPLETION_TIME")
    public String getM1ACTUALCOMPLETIONTIME() {
        return m1ACTUALCOMPLETIONTIME;
    }

    /**
     * 
     * @param m1ACTUALCOMPLETIONTIME
     *     The M1_ACTUAL_COMPLETION_TIME
     */
    @JsonProperty("M1_ACTUAL_COMPLETION_TIME")
    public void setM1ACTUALCOMPLETIONTIME(String m1ACTUALCOMPLETIONTIME) {
        this.m1ACTUALCOMPLETIONTIME = m1ACTUALCOMPLETIONTIME;
    }

    /**
     * 
     * @return
     *     The f1EXTLOOKUPVALUE
     */
    @JsonProperty("F1_EXT_LOOKUP_VALUE")
    public String getF1EXTLOOKUPVALUE() {
        return f1EXTLOOKUPVALUE;
    }

    /**
     * 
     * @param f1EXTLOOKUPVALUE
     *     The F1_EXT_LOOKUP_VALUE
     */
    @JsonProperty("F1_EXT_LOOKUP_VALUE")
    public void setF1EXTLOOKUPVALUE(String f1EXTLOOKUPVALUE) {
        this.f1EXTLOOKUPVALUE = f1EXTLOOKUPVALUE;
    }

    /**
     * 
     * @return
     *     The m1DECLINEALLITEMSLBL
     */
    @JsonProperty("M1_DECLINE_ALL_ITEMS_LBL")
    public String getM1DECLINEALLITEMSLBL() {
        return m1DECLINEALLITEMSLBL;
    }

    /**
     * 
     * @param m1DECLINEALLITEMSLBL
     *     The M1_DECLINE_ALL_ITEMS_LBL
     */
    @JsonProperty("M1_DECLINE_ALL_ITEMS_LBL")
    public void setM1DECLINEALLITEMSLBL(String m1DECLINEALLITEMSLBL) {
        this.m1DECLINEALLITEMSLBL = m1DECLINEALLITEMSLBL;
    }

    /**
     * 
     * @return
     *     The m1POUTASKID
     */
    @JsonProperty("M1_POUTASK_ID")
    public String getM1POUTASKID() {
        return m1POUTASKID;
    }

    /**
     * 
     * @param m1POUTASKID
     *     The M1_POUTASK_ID
     */
    @JsonProperty("M1_POUTASK_ID")
    public void setM1POUTASKID(String m1POUTASKID) {
        this.m1POUTASKID = m1POUTASKID;
    }

    /**
     * 
     * @return
     *     The m1ONLINEBTNLBL
     */
    @JsonProperty("M1_ONLINE_BTN_LBL")
    public String getM1ONLINEBTNLBL() {
        return m1ONLINEBTNLBL;
    }

    /**
     * 
     * @param m1ONLINEBTNLBL
     *     The M1_ONLINE_BTN_LBL
     */
    @JsonProperty("M1_ONLINE_BTN_LBL")
    public void setM1ONLINEBTNLBL(String m1ONLINEBTNLBL) {
        this.m1ONLINEBTNLBL = m1ONLINEBTNLBL;
    }

    /**
     * 
     * @return
     *     The bOSTATUSREASONCD
     */
    @JsonProperty("BO_STATUS_REASON_CD")
    public String getBOSTATUSREASONCD() {
        return bOSTATUSREASONCD;
    }

    /**
     * 
     * @param bOSTATUSREASONCD
     *     The BO_STATUS_REASON_CD
     */
    @JsonProperty("BO_STATUS_REASON_CD")
    public void setBOSTATUSREASONCD(String bOSTATUSREASONCD) {
        this.bOSTATUSREASONCD = bOSTATUSREASONCD;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYID
     */
    @JsonProperty("M1_ACTIVITY_ID")
    public String getM1ACTIVITYID() {
        return m1ACTIVITYID;
    }

    /**
     * 
     * @param m1ACTIVITYID
     *     The M1_ACTIVITY_ID
     */
    @JsonProperty("M1_ACTIVITY_ID")
    public void setM1ACTIVITYID(String m1ACTIVITYID) {
        this.m1ACTIVITYID = m1ACTIVITYID;
    }

    /**
     * 
     * @return
     *     The lOCTYPEFLG
     */
    @JsonProperty("LOC_TYPE_FLG")
    public String getLOCTYPEFLG() {
        return lOCTYPEFLG;
    }

    /**
     * 
     * @param lOCTYPEFLG
     *     The LOC_TYPE_FLG
     */
    @JsonProperty("LOC_TYPE_FLG")
    public void setLOCTYPEFLG(String lOCTYPEFLG) {
        this.lOCTYPEFLG = lOCTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1PICKUPSTATUSFLG
     */
    @JsonProperty("M1_PICKUP_STATUS_FLG")
    public String getM1PICKUPSTATUSFLG() {
        return m1PICKUPSTATUSFLG;
    }

    /**
     * 
     * @param m1PICKUPSTATUSFLG
     *     The M1_PICKUP_STATUS_FLG
     */
    @JsonProperty("M1_PICKUP_STATUS_FLG")
    public void setM1PICKUPSTATUSFLG(String m1PICKUPSTATUSFLG) {
        this.m1PICKUPSTATUSFLG = m1PICKUPSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1WARNLBL
     */
    @JsonProperty("M1_WARN_LBL")
    public String getM1WARNLBL() {
        return m1WARNLBL;
    }

    /**
     * 
     * @param m1WARNLBL
     *     The M1_WARN_LBL
     */
    @JsonProperty("M1_WARN_LBL")
    public void setM1WARNLBL(String m1WARNLBL) {
        this.m1WARNLBL = m1WARNLBL;
    }

    /**
     * 
     * @return
     *     The m1ISSUEDETECTEDTODOTYPE
     */
    @JsonProperty("M1_ISSUE_DETECTED_TODO_TYPE")
    public String getM1ISSUEDETECTEDTODOTYPE() {
        return m1ISSUEDETECTEDTODOTYPE;
    }

    /**
     * 
     * @param m1ISSUEDETECTEDTODOTYPE
     *     The M1_ISSUE_DETECTED_TODO_TYPE
     */
    @JsonProperty("M1_ISSUE_DETECTED_TODO_TYPE")
    public void setM1ISSUEDETECTEDTODOTYPE(String m1ISSUEDETECTEDTODOTYPE) {
        this.m1ISSUEDETECTEDTODOTYPE = m1ISSUEDETECTEDTODOTYPE;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEDLBL
     */
    @JsonProperty("M1_COMPLETED_LBL")
    public String getM1COMPLETEDLBL() {
        return m1COMPLETEDLBL;
    }

    /**
     * 
     * @param m1COMPLETEDLBL
     *     The M1_COMPLETED_LBL
     */
    @JsonProperty("M1_COMPLETED_LBL")
    public void setM1COMPLETEDLBL(String m1COMPLETEDLBL) {
        this.m1COMPLETEDLBL = m1COMPLETEDLBL;
    }

    /**
     * 
     * @return
     *     The m1HOSTJOBEXTERNALID
     */
    @JsonProperty("M1_HOST_JOB_EXTERNAL_ID")
    public String getM1HOSTJOBEXTERNALID() {
        return m1HOSTJOBEXTERNALID;
    }

    /**
     * 
     * @param m1HOSTJOBEXTERNALID
     *     The M1_HOST_JOB_EXTERNAL_ID
     */
    @JsonProperty("M1_HOST_JOB_EXTERNAL_ID")
    public void setM1HOSTJOBEXTERNALID(String m1HOSTJOBEXTERNALID) {
        this.m1HOSTJOBEXTERNALID = m1HOSTJOBEXTERNALID;
    }

    /**
     * 
     * @return
     *     The m1MARKALLASUNLOADEDLBL
     */
    @JsonProperty("M1_MARK_ALL_AS_UNLOADED_LBL")
    public String getM1MARKALLASUNLOADEDLBL() {
        return m1MARKALLASUNLOADEDLBL;
    }

    /**
     * 
     * @param m1MARKALLASUNLOADEDLBL
     *     The M1_MARK_ALL_AS_UNLOADED_LBL
     */
    @JsonProperty("M1_MARK_ALL_AS_UNLOADED_LBL")
    public void setM1MARKALLASUNLOADEDLBL(String m1MARKALLASUNLOADEDLBL) {
        this.m1MARKALLASUNLOADEDLBL = m1MARKALLASUNLOADEDLBL;
    }

    /**
     * 
     * @return
     *     The tOTALLBL
     */
    @JsonProperty("TOTAL_LBL")
    public String getTOTALLBL() {
        return tOTALLBL;
    }

    /**
     * 
     * @param tOTALLBL
     *     The TOTAL_LBL
     */
    @JsonProperty("TOTAL_LBL")
    public void setTOTALLBL(String tOTALLBL) {
        this.tOTALLBL = tOTALLBL;
    }

    /**
     * 
     * @return
     *     The bREAKTIMESHEETTYPE
     */
    @JsonProperty("BREAK_TIMESHEET_TYPE")
    public String getBREAKTIMESHEETTYPE() {
        return bREAKTIMESHEETTYPE;
    }

    /**
     * 
     * @param bREAKTIMESHEETTYPE
     *     The BREAK_TIMESHEET_TYPE
     */
    @JsonProperty("BREAK_TIMESHEET_TYPE")
    public void setBREAKTIMESHEETTYPE(String bREAKTIMESHEETTYPE) {
        this.bREAKTIMESHEETTYPE = bREAKTIMESHEETTYPE;
    }

    /**
     * 
     * @return
     *     The m1PREVCUTOFFDTTM
     */
    @JsonProperty("M1_PREV_CUTOFF_DTTM")
    public String getM1PREVCUTOFFDTTM() {
        return m1PREVCUTOFFDTTM;
    }

    /**
     * 
     * @param m1PREVCUTOFFDTTM
     *     The M1_PREV_CUTOFF_DTTM
     */
    @JsonProperty("M1_PREV_CUTOFF_DTTM")
    public void setM1PREVCUTOFFDTTM(String m1PREVCUTOFFDTTM) {
        this.m1PREVCUTOFFDTTM = m1PREVCUTOFFDTTM;
    }

    /**
     * 
     * @return
     *     The m1SENDTOCREW
     */
    @JsonProperty("M1_SENDTOCREW")
    public String getM1SENDTOCREW() {
        return m1SENDTOCREW;
    }

    /**
     * 
     * @param m1SENDTOCREW
     *     The M1_SENDTOCREW
     */
    @JsonProperty("M1_SENDTOCREW")
    public void setM1SENDTOCREW(String m1SENDTOCREW) {
        this.m1SENDTOCREW = m1SENDTOCREW;
    }

    /**
     * 
     * @return
     *     The m1CELLPHONE
     */
    @JsonProperty("M1_CELL_PHONE")
    public String getM1CELLPHONE() {
        return m1CELLPHONE;
    }

    /**
     * 
     * @param m1CELLPHONE
     *     The M1_CELL_PHONE
     */
    @JsonProperty("M1_CELL_PHONE")
    public void setM1CELLPHONE(String m1CELLPHONE) {
        this.m1CELLPHONE = m1CELLPHONE;
    }

    /**
     * 
     * @return
     *     The m1CAPTURESIGNATURELBL
     */
    @JsonProperty("M1_CAPTURE_SIGNATURE_LBL")
    public String getM1CAPTURESIGNATURELBL() {
        return m1CAPTURESIGNATURELBL;
    }

    /**
     * 
     * @param m1CAPTURESIGNATURELBL
     *     The M1_CAPTURE_SIGNATURE_LBL
     */
    @JsonProperty("M1_CAPTURE_SIGNATURE_LBL")
    public void setM1CAPTURESIGNATURELBL(String m1CAPTURESIGNATURELBL) {
        this.m1CAPTURESIGNATURELBL = m1CAPTURESIGNATURELBL;
    }

    /**
     * 
     * @return
     *     The vERSION
     */
    @JsonProperty("VERSION")
    public String getVERSION() {
        return vERSION;
    }

    /**
     * 
     * @param vERSION
     *     The VERSION
     */
    @JsonProperty("VERSION")
    public void setVERSION(String vERSION) {
        this.vERSION = vERSION;
    }

    /**
     * 
     * @return
     *     The m1MCPMARKERS
     */
    @JsonProperty("M1_MCP_MARKERS")
    public String getM1MCPMARKERS() {
        return m1MCPMARKERS;
    }

    /**
     * 
     * @param m1MCPMARKERS
     *     The M1_MCP_MARKERS
     */
    @JsonProperty("M1_MCP_MARKERS")
    public void setM1MCPMARKERS(String m1MCPMARKERS) {
        this.m1MCPMARKERS = m1MCPMARKERS;
    }

    /**
     * 
     * @return
     *     The m1RVETMWAITLBL
     */
    @JsonProperty("M1_RVE_TM_WAIT_LBL")
    public String getM1RVETMWAITLBL() {
        return m1RVETMWAITLBL;
    }

    /**
     * 
     * @param m1RVETMWAITLBL
     *     The M1_RVE_TM_WAIT_LBL
     */
    @JsonProperty("M1_RVE_TM_WAIT_LBL")
    public void setM1RVETMWAITLBL(String m1RVETMWAITLBL) {
        this.m1RVETMWAITLBL = m1RVETMWAITLBL;
    }

    /**
     * 
     * @return
     *     The m1ERRORLBL
     */
    @JsonProperty("M1_ERROR_LBL")
    public String getM1ERRORLBL() {
        return m1ERRORLBL;
    }

    /**
     * 
     * @param m1ERRORLBL
     *     The M1_ERROR_LBL
     */
    @JsonProperty("M1_ERROR_LBL")
    public void setM1ERRORLBL(String m1ERRORLBL) {
        this.m1ERRORLBL = m1ERRORLBL;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEDBYASSIGNMENTID
     */
    @JsonProperty("M1_COMPLETED_BY_ASSIGNMENT_ID")
    public String getM1COMPLETEDBYASSIGNMENTID() {
        return m1COMPLETEDBYASSIGNMENTID;
    }

    /**
     * 
     * @param m1COMPLETEDBYASSIGNMENTID
     *     The M1_COMPLETED_BY_ASSIGNMENT_ID
     */
    @JsonProperty("M1_COMPLETED_BY_ASSIGNMENT_ID")
    public void setM1COMPLETEDBYASSIGNMENTID(String m1COMPLETEDBYASSIGNMENTID) {
        this.m1COMPLETEDBYASSIGNMENTID = m1COMPLETEDBYASSIGNMENTID;
    }

    /**
     * 
     * @return
     *     The wFMOPTVAL
     */
    @JsonProperty("WFM_OPT_VAL")
    public String getWFMOPTVAL() {
        return wFMOPTVAL;
    }

    /**
     * 
     * @param wFMOPTVAL
     *     The WFM_OPT_VAL
     */
    @JsonProperty("WFM_OPT_VAL")
    public void setWFMOPTVAL(String wFMOPTVAL) {
        this.wFMOPTVAL = wFMOPTVAL;
    }

    /**
     * 
     * @return
     *     The m1CAPACITYPREFERREDFLG
     */
    @JsonProperty("M1_CAPACITY_PREFERRED_FLG")
    public String getM1CAPACITYPREFERREDFLG() {
        return m1CAPACITYPREFERREDFLG;
    }

    /**
     * 
     * @param m1CAPACITYPREFERREDFLG
     *     The M1_CAPACITY_PREFERRED_FLG
     */
    @JsonProperty("M1_CAPACITY_PREFERRED_FLG")
    public void setM1CAPACITYPREFERREDFLG(String m1CAPACITYPREFERREDFLG) {
        this.m1CAPACITYPREFERREDFLG = m1CAPACITYPREFERREDFLG;
    }

    /**
     * 
     * @return
     *     The pARENTTASKID
     */
    @JsonProperty("PARENT_TASK_ID")
    public String getPARENTTASKID() {
        return pARENTTASKID;
    }

    /**
     * 
     * @param pARENTTASKID
     *     The PARENT_TASK_ID
     */
    @JsonProperty("PARENT_TASK_ID")
    public void setPARENTTASKID(String pARENTTASKID) {
        this.pARENTTASKID = pARENTTASKID;
    }

    /**
     * 
     * @return
     *     The m1PRETIMEFAC
     */
    @JsonProperty("M1_PRE_TIME_FAC")
    public String getM1PRETIMEFAC() {
        return m1PRETIMEFAC;
    }

    /**
     * 
     * @param m1PRETIMEFAC
     *     The M1_PRE_TIME_FAC
     */
    @JsonProperty("M1_PRE_TIME_FAC")
    public void setM1PRETIMEFAC(String m1PRETIMEFAC) {
        this.m1PRETIMEFAC = m1PRETIMEFAC;
    }

    /**
     * 
     * @return
     *     The m1COMPLEXACTCMPLLBL
     */
    @JsonProperty("M1_COMPLEX_ACT_CMPL_LBL")
    public String getM1COMPLEXACTCMPLLBL() {
        return m1COMPLEXACTCMPLLBL;
    }

    /**
     * 
     * @param m1COMPLEXACTCMPLLBL
     *     The M1_COMPLEX_ACT_CMPL_LBL
     */
    @JsonProperty("M1_COMPLEX_ACT_CMPL_LBL")
    public void setM1COMPLEXACTCMPLLBL(String m1COMPLEXACTCMPLLBL) {
        this.m1COMPLEXACTCMPLLBL = m1COMPLEXACTCMPLLBL;
    }

    /**
     * 
     * @return
     *     The m1THEMEALBL
     */
    @JsonProperty("M1_THEME_A_LBL")
    public String getM1THEMEALBL() {
        return m1THEMEALBL;
    }

    /**
     * 
     * @param m1THEMEALBL
     *     The M1_THEME_A_LBL
     */
    @JsonProperty("M1_THEME_A_LBL")
    public void setM1THEMEALBL(String m1THEMEALBL) {
        this.m1THEMEALBL = m1THEMEALBL;
    }

    /**
     * 
     * @return
     *     The m1ATTACHMENTFILENAME
     */
    @JsonProperty("M1_ATTACHMENT_FILE_NAME")
    public String getM1ATTACHMENTFILENAME() {
        return m1ATTACHMENTFILENAME;
    }

    /**
     * 
     * @param m1ATTACHMENTFILENAME
     *     The M1_ATTACHMENT_FILE_NAME
     */
    @JsonProperty("M1_ATTACHMENT_FILE_NAME")
    public void setM1ATTACHMENTFILENAME(String m1ATTACHMENTFILENAME) {
        this.m1ATTACHMENTFILENAME = m1ATTACHMENTFILENAME;
    }

    /**
     * 
     * @return
     *     The nUM2AVAIL
     */
    @JsonProperty("NUM2_AVAIL")
    public String getNUM2AVAIL() {
        return nUM2AVAIL;
    }

    /**
     * 
     * @param nUM2AVAIL
     *     The NUM2_AVAIL
     */
    @JsonProperty("NUM2_AVAIL")
    public void setNUM2AVAIL(String nUM2AVAIL) {
        this.nUM2AVAIL = nUM2AVAIL;
    }

    /**
     * 
     * @return
     *     The gEOLAT
     */
    @JsonProperty("GEO_LAT")
    public String getGEOLAT() {
        return gEOLAT;
    }

    /**
     * 
     * @param gEOLAT
     *     The GEO_LAT
     */
    @JsonProperty("GEO_LAT")
    public void setGEOLAT(String gEOLAT) {
        this.gEOLAT = gEOLAT;
    }

    /**
     * 
     * @return
     *     The m1DOWNLOADINPROGRESSLBL
     */
    @JsonProperty("M1_DOWNLOAD_IN_PROGRESS_LBL")
    public String getM1DOWNLOADINPROGRESSLBL() {
        return m1DOWNLOADINPROGRESSLBL;
    }

    /**
     * 
     * @param m1DOWNLOADINPROGRESSLBL
     *     The M1_DOWNLOAD_IN_PROGRESS_LBL
     */
    @JsonProperty("M1_DOWNLOAD_IN_PROGRESS_LBL")
    public void setM1DOWNLOADINPROGRESSLBL(String m1DOWNLOADINPROGRESSLBL) {
        this.m1DOWNLOADINPROGRESSLBL = m1DOWNLOADINPROGRESSLBL;
    }

    /**
     * 
     * @return
     *     The m1POSTPONEDTTMNODEFAULTSW
     */
    @JsonProperty("M1_POSTPONE_DTTM_NO_DEFAULT_SW")
    public String getM1POSTPONEDTTMNODEFAULTSW() {
        return m1POSTPONEDTTMNODEFAULTSW;
    }

    /**
     * 
     * @param m1POSTPONEDTTMNODEFAULTSW
     *     The M1_POSTPONE_DTTM_NO_DEFAULT_SW
     */
    @JsonProperty("M1_POSTPONE_DTTM_NO_DEFAULT_SW")
    public void setM1POSTPONEDTTMNODEFAULTSW(String m1POSTPONEDTTMNODEFAULTSW) {
        this.m1POSTPONEDTTMNODEFAULTSW = m1POSTPONEDTTMNODEFAULTSW;
    }

    /**
     * 
     * @return
     *     The m1SNDTOLBL
     */
    @JsonProperty("M1_SND_TO_LBL")
    public String getM1SNDTOLBL() {
        return m1SNDTOLBL;
    }

    /**
     * 
     * @param m1SNDTOLBL
     *     The M1_SND_TO_LBL
     */
    @JsonProperty("M1_SND_TO_LBL")
    public void setM1SNDTOLBL(String m1SNDTOLBL) {
        this.m1SNDTOLBL = m1SNDTOLBL;
    }

    /**
     * 
     * @return
     *     The m1HASATTACHMENTSSW
     */
    @JsonProperty("M1_HAS_ATTACHMENTS_SW")
    public String getM1HASATTACHMENTSSW() {
        return m1HASATTACHMENTSSW;
    }

    /**
     * 
     * @param m1HASATTACHMENTSSW
     *     The M1_HAS_ATTACHMENTS_SW
     */
    @JsonProperty("M1_HAS_ATTACHMENTS_SW")
    public void setM1HASATTACHMENTSSW(String m1HASATTACHMENTSSW) {
        this.m1HASATTACHMENTSSW = m1HASATTACHMENTSSW;
    }

    /**
     * 
     * @return
     *     The m1LEGENDLBL
     */
    @JsonProperty("M1_LEGEND_LBL")
    public String getM1LEGENDLBL() {
        return m1LEGENDLBL;
    }

    /**
     * 
     * @param m1LEGENDLBL
     *     The M1_LEGEND_LBL
     */
    @JsonProperty("M1_LEGEND_LBL")
    public void setM1LEGENDLBL(String m1LEGENDLBL) {
        this.m1LEGENDLBL = m1LEGENDLBL;
    }

    /**
     * 
     * @return
     *     The m1TASKDETAILSLBL
     */
    @JsonProperty("M1_TASK_DETAILS_LBL")
    public String getM1TASKDETAILSLBL() {
        return m1TASKDETAILSLBL;
    }

    /**
     * 
     * @param m1TASKDETAILSLBL
     *     The M1_TASK_DETAILS_LBL
     */
    @JsonProperty("M1_TASK_DETAILS_LBL")
    public void setM1TASKDETAILSLBL(String m1TASKDETAILSLBL) {
        this.m1TASKDETAILSLBL = m1TASKDETAILSLBL;
    }

    /**
     * 
     * @return
     *     The m1HHLBL
     */
    @JsonProperty("M1_HH_LBL")
    public String getM1HHLBL() {
        return m1HHLBL;
    }

    /**
     * 
     * @param m1HHLBL
     *     The M1_HH_LBL
     */
    @JsonProperty("M1_HH_LBL")
    public void setM1HHLBL(String m1HHLBL) {
        this.m1HHLBL = m1HHLBL;
    }

    /**
     * 
     * @return
     *     The m1COMPOSEMAILLBL
     */
    @JsonProperty("M1_COMPOSE_MAIL_LBL")
    public String getM1COMPOSEMAILLBL() {
        return m1COMPOSEMAILLBL;
    }

    /**
     * 
     * @param m1COMPOSEMAILLBL
     *     The M1_COMPOSE_MAIL_LBL
     */
    @JsonProperty("M1_COMPOSE_MAIL_LBL")
    public void setM1COMPOSEMAILLBL(String m1COMPOSEMAILLBL) {
        this.m1COMPOSEMAILLBL = m1COMPOSEMAILLBL;
    }

    /**
     * 
     * @return
     *     The m1MOBILEWORKER
     */
    @JsonProperty("M1_MOBILE_WORKER")
    public String getM1MOBILEWORKER() {
        return m1MOBILEWORKER;
    }

    /**
     * 
     * @param m1MOBILEWORKER
     *     The M1_MOBILE_WORKER
     */
    @JsonProperty("M1_MOBILE_WORKER")
    public void setM1MOBILEWORKER(String m1MOBILEWORKER) {
        this.m1MOBILEWORKER = m1MOBILEWORKER;
    }

    /**
     * 
     * @return
     *     The tASKCLSFLG
     */
    @JsonProperty("TASK_CLS_FLG")
    public String getTASKCLSFLG() {
        return tASKCLSFLG;
    }

    /**
     * 
     * @param tASKCLSFLG
     *     The TASK_CLS_FLG
     */
    @JsonProperty("TASK_CLS_FLG")
    public void setTASKCLSFLG(String tASKCLSFLG) {
        this.tASKCLSFLG = tASKCLSFLG;
    }

    /**
     * 
     * @return
     *     The pROCEDUREBUSOBJCD
     */
    @JsonProperty("PROCEDURE_BUS_OBJ_CD")
    public String getPROCEDUREBUSOBJCD() {
        return pROCEDUREBUSOBJCD;
    }

    /**
     * 
     * @param pROCEDUREBUSOBJCD
     *     The PROCEDURE_BUS_OBJ_CD
     */
    @JsonProperty("PROCEDURE_BUS_OBJ_CD")
    public void setPROCEDUREBUSOBJCD(String pROCEDUREBUSOBJCD) {
        this.pROCEDUREBUSOBJCD = pROCEDUREBUSOBJCD;
    }

    /**
     * 
     * @return
     *     The cALCDURATION
     */
    @JsonProperty("CALC_DURATION")
    public String getCALCDURATION() {
        return cALCDURATION;
    }

    /**
     * 
     * @param cALCDURATION
     *     The CALC_DURATION
     */
    @JsonProperty("CALC_DURATION")
    public void setCALCDURATION(String cALCDURATION) {
        this.cALCDURATION = cALCDURATION;
    }

    /**
     * 
     * @return
     *     The m1PANICALERTTYPE
     */
    @JsonProperty("M1_PANIC_ALERT_TYPE")
    public String getM1PANICALERTTYPE() {
        return m1PANICALERTTYPE;
    }

    /**
     * 
     * @param m1PANICALERTTYPE
     *     The M1_PANIC_ALERT_TYPE
     */
    @JsonProperty("M1_PANIC_ALERT_TYPE")
    public void setM1PANICALERTTYPE(String m1PANICALERTTYPE) {
        this.m1PANICALERTTYPE = m1PANICALERTTYPE;
    }

    /**
     * 
     * @return
     *     The m1MDTSOUNDPAUSE
     */
    @JsonProperty("M1_MDT_SOUND_PAUSE")
    public String getM1MDTSOUNDPAUSE() {
        return m1MDTSOUNDPAUSE;
    }

    /**
     * 
     * @param m1MDTSOUNDPAUSE
     *     The M1_MDT_SOUND_PAUSE
     */
    @JsonProperty("M1_MDT_SOUND_PAUSE")
    public void setM1MDTSOUNDPAUSE(String m1MDTSOUNDPAUSE) {
        this.m1MDTSOUNDPAUSE = m1MDTSOUNDPAUSE;
    }

    /**
     * 
     * @return
     *     The m1CUSTCONTACTTYPEMAINLBL
     */
    @JsonProperty("M1_CUST_CONTACT_TYPE_MAIN_LBL")
    public String getM1CUSTCONTACTTYPEMAINLBL() {
        return m1CUSTCONTACTTYPEMAINLBL;
    }

    /**
     * 
     * @param m1CUSTCONTACTTYPEMAINLBL
     *     The M1_CUST_CONTACT_TYPE_MAIN_LBL
     */
    @JsonProperty("M1_CUST_CONTACT_TYPE_MAIN_LBL")
    public void setM1CUSTCONTACTTYPEMAINLBL(String m1CUSTCONTACTTYPEMAINLBL) {
        this.m1CUSTCONTACTTYPEMAINLBL = m1CUSTCONTACTTYPEMAINLBL;
    }

    /**
     * 
     * @return
     *     The m1MAXNONCUMCAPACITYFLG
     */
    @JsonProperty("M1_MAX_NONCUM_CAPACITY_FLG")
    public String getM1MAXNONCUMCAPACITYFLG() {
        return m1MAXNONCUMCAPACITYFLG;
    }

    /**
     * 
     * @param m1MAXNONCUMCAPACITYFLG
     *     The M1_MAX_NONCUM_CAPACITY_FLG
     */
    @JsonProperty("M1_MAX_NONCUM_CAPACITY_FLG")
    public void setM1MAXNONCUMCAPACITYFLG(String m1MAXNONCUMCAPACITYFLG) {
        this.m1MAXNONCUMCAPACITYFLG = m1MAXNONCUMCAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1CREWTMUSGCLSFLG
     */
    @JsonProperty("M1_CREW_TM_USG_CLS_FLG")
    public String getM1CREWTMUSGCLSFLG() {
        return m1CREWTMUSGCLSFLG;
    }

    /**
     * 
     * @param m1CREWTMUSGCLSFLG
     *     The M1_CREW_TM_USG_CLS_FLG
     */
    @JsonProperty("M1_CREW_TM_USG_CLS_FLG")
    public void setM1CREWTMUSGCLSFLG(String m1CREWTMUSGCLSFLG) {
        this.m1CREWTMUSGCLSFLG = m1CREWTMUSGCLSFLG;
    }

    /**
     * 
     * @return
     *     The m1CACEXTENSIONLOWLIMIT
     */
    @JsonProperty("M1_CAC_EXTENSION_LOW_LIMIT")
    public String getM1CACEXTENSIONLOWLIMIT() {
        return m1CACEXTENSIONLOWLIMIT;
    }

    /**
     * 
     * @param m1CACEXTENSIONLOWLIMIT
     *     The M1_CAC_EXTENSION_LOW_LIMIT
     */
    @JsonProperty("M1_CAC_EXTENSION_LOW_LIMIT")
    public void setM1CACEXTENSIONLOWLIMIT(String m1CACEXTENSIONLOWLIMIT) {
        this.m1CACEXTENSIONLOWLIMIT = m1CACEXTENSIONLOWLIMIT;
    }

    /**
     * 
     * @return
     *     The wFMNAME
     */
    @JsonProperty("WFM_NAME")
    public String getWFMNAME() {
        return wFMNAME;
    }

    /**
     * 
     * @param wFMNAME
     *     The WFM_NAME
     */
    @JsonProperty("WFM_NAME")
    public void setWFMNAME(String wFMNAME) {
        this.wFMNAME = wFMNAME;
    }

    /**
     * 
     * @return
     *     The pLANSTARTDTTM
     */
    @JsonProperty("PLAN_START_DTTM")
    public String getPLANSTARTDTTM() {
        return pLANSTARTDTTM;
    }

    /**
     * 
     * @param pLANSTARTDTTM
     *     The PLAN_START_DTTM
     */
    @JsonProperty("PLAN_START_DTTM")
    public void setPLANSTARTDTTM(String pLANSTARTDTTM) {
        this.pLANSTARTDTTM = pLANSTARTDTTM;
    }

    /**
     * 
     * @return
     *     The m1ESTREMAININGDURATION
     */
    @JsonProperty("M1_EST_REMAINING_DURATION")
    public String getM1ESTREMAININGDURATION() {
        return m1ESTREMAININGDURATION;
    }

    /**
     * 
     * @param m1ESTREMAININGDURATION
     *     The M1_EST_REMAINING_DURATION
     */
    @JsonProperty("M1_EST_REMAINING_DURATION")
    public void setM1ESTREMAININGDURATION(String m1ESTREMAININGDURATION) {
        this.m1ESTREMAININGDURATION = m1ESTREMAININGDURATION;
    }

    /**
     * 
     * @return
     *     The m1TMSHTOVRDFLG
     */
    @JsonProperty("M1_TMSHT_OVRD_FLG")
    public String getM1TMSHTOVRDFLG() {
        return m1TMSHTOVRDFLG;
    }

    /**
     * 
     * @param m1TMSHTOVRDFLG
     *     The M1_TMSHT_OVRD_FLG
     */
    @JsonProperty("M1_TMSHT_OVRD_FLG")
    public void setM1TMSHTOVRDFLG(String m1TMSHTOVRDFLG) {
        this.m1TMSHTOVRDFLG = m1TMSHTOVRDFLG;
    }

    /**
     * 
     * @return
     *     The m1INQUIRYHISTORY
     */
    @JsonProperty("M1_INQUIRY_HISTORY")
    public String getM1INQUIRYHISTORY() {
        return m1INQUIRYHISTORY;
    }

    /**
     * 
     * @param m1INQUIRYHISTORY
     *     The M1_INQUIRY_HISTORY
     */
    @JsonProperty("M1_INQUIRY_HISTORY")
    public void setM1INQUIRYHISTORY(String m1INQUIRYHISTORY) {
        this.m1INQUIRYHISTORY = m1INQUIRYHISTORY;
    }

    /**
     * 
     * @return
     *     The m1CALCDURATION
     */
    @JsonProperty("M1_CALC_DURATION")
    public String getM1CALCDURATION() {
        return m1CALCDURATION;
    }

    /**
     * 
     * @param m1CALCDURATION
     *     The M1_CALC_DURATION
     */
    @JsonProperty("M1_CALC_DURATION")
    public void setM1CALCDURATION(String m1CALCDURATION) {
        this.m1CALCDURATION = m1CALCDURATION;
    }

    /**
     * 
     * @return
     *     The pROCEDUREEFFDT
     */
    @JsonProperty("PROCEDURE_EFF_DT")
    public String getPROCEDUREEFFDT() {
        return pROCEDUREEFFDT;
    }

    /**
     * 
     * @param pROCEDUREEFFDT
     *     The PROCEDURE_EFF_DT
     */
    @JsonProperty("PROCEDURE_EFF_DT")
    public void setPROCEDUREEFFDT(String pROCEDUREEFFDT) {
        this.pROCEDUREEFFDT = pROCEDUREEFFDT;
    }

    /**
     * 
     * @return
     *     The m1UPLOADEDIMAGESLBL
     */
    @JsonProperty("M1_UPLOADED_IMAGES_LBL")
    public String getM1UPLOADEDIMAGESLBL() {
        return m1UPLOADEDIMAGESLBL;
    }

    /**
     * 
     * @param m1UPLOADEDIMAGESLBL
     *     The M1_UPLOADED_IMAGES_LBL
     */
    @JsonProperty("M1_UPLOADED_IMAGES_LBL")
    public void setM1UPLOADEDIMAGESLBL(String m1UPLOADEDIMAGESLBL) {
        this.m1UPLOADEDIMAGESLBL = m1UPLOADEDIMAGESLBL;
    }

    /**
     * 
     * @return
     *     The m1ADDWORKERLBL
     */
    @JsonProperty("M1_ADD_WORKER_LBL")
    public String getM1ADDWORKERLBL() {
        return m1ADDWORKERLBL;
    }

    /**
     * 
     * @param m1ADDWORKERLBL
     *     The M1_ADD_WORKER_LBL
     */
    @JsonProperty("M1_ADD_WORKER_LBL")
    public void setM1ADDWORKERLBL(String m1ADDWORKERLBL) {
        this.m1ADDWORKERLBL = m1ADDWORKERLBL;
    }

    /**
     * 
     * @return
     *     The m1SITEID
     */
    @JsonProperty("M1_SITE_ID")
    public String getM1SITEID() {
        return m1SITEID;
    }

    /**
     * 
     * @param m1SITEID
     *     The M1_SITE_ID
     */
    @JsonProperty("M1_SITE_ID")
    public void setM1SITEID(String m1SITEID) {
        this.m1SITEID = m1SITEID;
    }

    /**
     * 
     * @return
     *     The sTATELBL
     */
    @JsonProperty("STATE_LBL")
    public String getSTATELBL() {
        return sTATELBL;
    }

    /**
     * 
     * @param sTATELBL
     *     The STATE_LBL
     */
    @JsonProperty("STATE_LBL")
    public void setSTATELBL(String sTATELBL) {
        this.sTATELBL = sTATELBL;
    }

    /**
     * 
     * @return
     *     The uSERID
     */
    @JsonProperty("USER_ID")
    public String getUSERID() {
        return uSERID;
    }

    /**
     * 
     * @param uSERID
     *     The USER_ID
     */
    @JsonProperty("USER_ID")
    public void setUSERID(String uSERID) {
        this.uSERID = uSERID;
    }

    /**
     * 
     * @return
     *     The m1ASSIGNEDENGINEER
     */
    @JsonProperty("M1_ASSIGNED_ENGINEER")
    public String getM1ASSIGNEDENGINEER() {
        return m1ASSIGNEDENGINEER;
    }

    /**
     * 
     * @param m1ASSIGNEDENGINEER
     *     The M1_ASSIGNED_ENGINEER
     */
    @JsonProperty("M1_ASSIGNED_ENGINEER")
    public void setM1ASSIGNEDENGINEER(String m1ASSIGNEDENGINEER) {
        this.m1ASSIGNEDENGINEER = m1ASSIGNEDENGINEER;
    }

    /**
     * 
     * @return
     *     The tMSHEETBOCD
     */
    @JsonProperty("TMSHEET_BO_CD")
    public String getTMSHEETBOCD() {
        return tMSHEETBOCD;
    }

    /**
     * 
     * @param tMSHEETBOCD
     *     The TMSHEET_BO_CD
     */
    @JsonProperty("TMSHEET_BO_CD")
    public void setTMSHEETBOCD(String tMSHEETBOCD) {
        this.tMSHEETBOCD = tMSHEETBOCD;
    }

    /**
     * 
     * @return
     *     The m1ACTCALLBL
     */
    @JsonProperty("M1_ACT_CAL_LBL")
    public String getM1ACTCALLBL() {
        return m1ACTCALLBL;
    }

    /**
     * 
     * @param m1ACTCALLBL
     *     The M1_ACT_CAL_LBL
     */
    @JsonProperty("M1_ACT_CAL_LBL")
    public void setM1ACTCALLBL(String m1ACTCALLBL) {
        this.m1ACTCALLBL = m1ACTCALLBL;
    }

    /**
     * 
     * @return
     *     The m1TIMEREMAININGASOFDTTM
     */
    @JsonProperty("M1_TIME_REMAINING_AS_OF_DTTM")
    public String getM1TIMEREMAININGASOFDTTM() {
        return m1TIMEREMAININGASOFDTTM;
    }

    /**
     * 
     * @param m1TIMEREMAININGASOFDTTM
     *     The M1_TIME_REMAINING_AS_OF_DTTM
     */
    @JsonProperty("M1_TIME_REMAINING_AS_OF_DTTM")
    public void setM1TIMEREMAININGASOFDTTM(String m1TIMEREMAININGASOFDTTM) {
        this.m1TIMEREMAININGASOFDTTM = m1TIMEREMAININGASOFDTTM;
    }

    /**
     * 
     * @return
     *     The m1POSTPONEUNTILLBL
     */
    @JsonProperty("M1_POSTPONE_UNTIL_LBL")
    public String getM1POSTPONEUNTILLBL() {
        return m1POSTPONEUNTILLBL;
    }

    /**
     * 
     * @param m1POSTPONEUNTILLBL
     *     The M1_POSTPONE_UNTIL_LBL
     */
    @JsonProperty("M1_POSTPONE_UNTIL_LBL")
    public void setM1POSTPONEUNTILLBL(String m1POSTPONEUNTILLBL) {
        this.m1POSTPONEUNTILLBL = m1POSTPONEUNTILLBL;
    }

    /**
     * 
     * @return
     *     The m1SOUNDDURATION
     */
    @JsonProperty("M1_SOUND_DURATION")
    public String getM1SOUNDDURATION() {
        return m1SOUNDDURATION;
    }

    /**
     * 
     * @param m1SOUNDDURATION
     *     The M1_SOUND_DURATION
     */
    @JsonProperty("M1_SOUND_DURATION")
    public void setM1SOUNDDURATION(String m1SOUNDDURATION) {
        this.m1SOUNDDURATION = m1SOUNDDURATION;
    }

    /**
     * 
     * @return
     *     The m1MDTTASKLISTLINE
     */
    @JsonProperty("M1_MDT_TASKLIST_LINE")
    public String getM1MDTTASKLISTLINE() {
        return m1MDTTASKLISTLINE;
    }

    /**
     * 
     * @param m1MDTTASKLISTLINE
     *     The M1_MDT_TASKLIST_LINE
     */
    @JsonProperty("M1_MDT_TASKLIST_LINE")
    public void setM1MDTTASKLISTLINE(String m1MDTTASKLISTLINE) {
        this.m1MDTTASKLISTLINE = m1MDTTASKLISTLINE;
    }

    /**
     * 
     * @return
     *     The pOSTAL
     */
    @JsonProperty("POSTAL")
    public String getPOSTAL() {
        return pOSTAL;
    }

    /**
     * 
     * @param pOSTAL
     *     The POSTAL
     */
    @JsonProperty("POSTAL")
    public void setPOSTAL(String pOSTAL) {
        this.pOSTAL = pOSTAL;
    }

    /**
     * 
     * @return
     *     The aDDR2LBL
     */
    @JsonProperty("ADDR2_LBL")
    public String getADDR2LBL() {
        return aDDR2LBL;
    }

    /**
     * 
     * @param aDDR2LBL
     *     The ADDR2_LBL
     */
    @JsonProperty("ADDR2_LBL")
    public void setADDR2LBL(String aDDR2LBL) {
        this.aDDR2LBL = aDDR2LBL;
    }

    /**
     * 
     * @return
     *     The m1CREWTIMEUSAGECMPLLBL
     */
    @JsonProperty("M1_CREW_TIME_USAGE_CMPL_LBL")
    public String getM1CREWTIMEUSAGECMPLLBL() {
        return m1CREWTIMEUSAGECMPLLBL;
    }

    /**
     * 
     * @param m1CREWTIMEUSAGECMPLLBL
     *     The M1_CREW_TIME_USAGE_CMPL_LBL
     */
    @JsonProperty("M1_CREW_TIME_USAGE_CMPL_LBL")
    public void setM1CREWTIMEUSAGECMPLLBL(String m1CREWTIMEUSAGECMPLLBL) {
        this.m1CREWTIMEUSAGECMPLLBL = m1CREWTIMEUSAGECMPLLBL;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYTYPELBL
     */
    @JsonProperty("M1_ACTIVITY_TYPE_LBL")
    public String getM1ACTIVITYTYPELBL() {
        return m1ACTIVITYTYPELBL;
    }

    /**
     * 
     * @param m1ACTIVITYTYPELBL
     *     The M1_ACTIVITY_TYPE_LBL
     */
    @JsonProperty("M1_ACTIVITY_TYPE_LBL")
    public void setM1ACTIVITYTYPELBL(String m1ACTIVITYTYPELBL) {
        this.m1ACTIVITYTYPELBL = m1ACTIVITYTYPELBL;
    }

    /**
     * 
     * @return
     *     The m1MCPMESCHEDULINGINFOLBL
     */
    @JsonProperty("M1_MCPME_SCHEDULING_INFO_LBL")
    public String getM1MCPMESCHEDULINGINFOLBL() {
        return m1MCPMESCHEDULINGINFOLBL;
    }

    /**
     * 
     * @param m1MCPMESCHEDULINGINFOLBL
     *     The M1_MCPME_SCHEDULING_INFO_LBL
     */
    @JsonProperty("M1_MCPME_SCHEDULING_INFO_LBL")
    public void setM1MCPMESCHEDULINGINFOLBL(String m1MCPMESCHEDULINGINFOLBL) {
        this.m1MCPMESCHEDULINGINFOLBL = m1MCPMESCHEDULINGINFOLBL;
    }

    /**
     * 
     * @return
     *     The m1LOWCORRLIMIT
     */
    @JsonProperty("M1_LOW_CORR_LIMIT")
    public String getM1LOWCORRLIMIT() {
        return m1LOWCORRLIMIT;
    }

    /**
     * 
     * @param m1LOWCORRLIMIT
     *     The M1_LOW_CORR_LIMIT
     */
    @JsonProperty("M1_LOW_CORR_LIMIT")
    public void setM1LOWCORRLIMIT(String m1LOWCORRLIMIT) {
        this.m1LOWCORRLIMIT = m1LOWCORRLIMIT;
    }

    /**
     * 
     * @return
     *     The m1ARRIVEDASSIGNMENTLBL
     */
    @JsonProperty("M1_ARRIVED_ASSIGNMENT_LBL")
    public String getM1ARRIVEDASSIGNMENTLBL() {
        return m1ARRIVEDASSIGNMENTLBL;
    }

    /**
     * 
     * @param m1ARRIVEDASSIGNMENTLBL
     *     The M1_ARRIVED_ASSIGNMENT_LBL
     */
    @JsonProperty("M1_ARRIVED_ASSIGNMENT_LBL")
    public void setM1ARRIVEDASSIGNMENTLBL(String m1ARRIVEDASSIGNMENTLBL) {
        this.m1ARRIVEDASSIGNMENTLBL = m1ARRIVEDASSIGNMENTLBL;
    }

    /**
     * 
     * @return
     *     The m1MMLBL
     */
    @JsonProperty("M1_MM_LBL")
    public String getM1MMLBL() {
        return m1MMLBL;
    }

    /**
     * 
     * @param m1MMLBL
     *     The M1_MM_LBL
     */
    @JsonProperty("M1_MM_LBL")
    public void setM1MMLBL(String m1MMLBL) {
        this.m1MMLBL = m1MMLBL;
    }

    /**
     * 
     * @return
     *     The m1DEPOTADDRESS
     */
    @JsonProperty("M1_DEPOT_ADDRESS")
    public String getM1DEPOTADDRESS() {
        return m1DEPOTADDRESS;
    }

    /**
     * 
     * @param m1DEPOTADDRESS
     *     The M1_DEPOT_ADDRESS
     */
    @JsonProperty("M1_DEPOT_ADDRESS")
    public void setM1DEPOTADDRESS(String m1DEPOTADDRESS) {
        this.m1DEPOTADDRESS = m1DEPOTADDRESS;
    }

    /**
     * 
     * @return
     *     The m1ASSIGNMENTID
     */
    @JsonProperty("M1_ASSIGNMENT_ID")
    public String getM1ASSIGNMENTID() {
        return m1ASSIGNMENTID;
    }

    /**
     * 
     * @param m1ASSIGNMENTID
     *     The M1_ASSIGNMENT_ID
     */
    @JsonProperty("M1_ASSIGNMENT_ID")
    public void setM1ASSIGNMENTID(String m1ASSIGNMENTID) {
        this.m1ASSIGNMENTID = m1ASSIGNMENTID;
    }

    /**
     * 
     * @return
     *     The m1TIMEDEVENTEXPDTTM
     */
    @JsonProperty("M1_TIMED_EVENT_EXP_DTTM")
    public String getM1TIMEDEVENTEXPDTTM() {
        return m1TIMEDEVENTEXPDTTM;
    }

    /**
     * 
     * @param m1TIMEDEVENTEXPDTTM
     *     The M1_TIMED_EVENT_EXP_DTTM
     */
    @JsonProperty("M1_TIMED_EVENT_EXP_DTTM")
    public void setM1TIMEDEVENTEXPDTTM(String m1TIMEDEVENTEXPDTTM) {
        this.m1TIMEDEVENTEXPDTTM = m1TIMEDEVENTEXPDTTM;
    }

    /**
     * 
     * @return
     *     The m1QUESTIONNAIRELBL
     */
    @JsonProperty("M1_QUESTIONNAIRE_LBL")
    public String getM1QUESTIONNAIRELBL() {
        return m1QUESTIONNAIRELBL;
    }

    /**
     * 
     * @param m1QUESTIONNAIRELBL
     *     The M1_QUESTIONNAIRE_LBL
     */
    @JsonProperty("M1_QUESTIONNAIRE_LBL")
    public void setM1QUESTIONNAIRELBL(String m1QUESTIONNAIRELBL) {
        this.m1QUESTIONNAIRELBL = m1QUESTIONNAIRELBL;
    }

    /**
     * 
     * @return
     *     The m1COMMENTS
     */
    @JsonProperty("M1_COMMENTS")
    public String getM1COMMENTS() {
        return m1COMMENTS;
    }

    /**
     * 
     * @param m1COMMENTS
     *     The M1_COMMENTS
     */
    @JsonProperty("M1_COMMENTS")
    public void setM1COMMENTS(String m1COMMENTS) {
        this.m1COMMENTS = m1COMMENTS;
    }

    /**
     * 
     * @return
     *     The m1RESERVECAPMAXPERCENT
     */
    @JsonProperty("M1_RESERVE_CAP_MAX_PERCENT")
    public String getM1RESERVECAPMAXPERCENT() {
        return m1RESERVECAPMAXPERCENT;
    }

    /**
     * 
     * @param m1RESERVECAPMAXPERCENT
     *     The M1_RESERVE_CAP_MAX_PERCENT
     */
    @JsonProperty("M1_RESERVE_CAP_MAX_PERCENT")
    public void setM1RESERVECAPMAXPERCENT(String m1RESERVECAPMAXPERCENT) {
        this.m1RESERVECAPMAXPERCENT = m1RESERVECAPMAXPERCENT;
    }

    /**
     * 
     * @return
     *     The m1DUREXTENSIONLIMIT
     */
    @JsonProperty("M1_DUR_EXTENSION_LIMIT")
    public String getM1DUREXTENSIONLIMIT() {
        return m1DUREXTENSIONLIMIT;
    }

    /**
     * 
     * @param m1DUREXTENSIONLIMIT
     *     The M1_DUR_EXTENSION_LIMIT
     */
    @JsonProperty("M1_DUR_EXTENSION_LIMIT")
    public void setM1DUREXTENSIONLIMIT(String m1DUREXTENSIONLIMIT) {
        this.m1DUREXTENSIONLIMIT = m1DUREXTENSIONLIMIT;
    }

    /**
     * 
     * @return
     *     The yESNOANSWERFLG
     */
    @JsonProperty("YES_NO_ANSWER_FLG")
    public String getYESNOANSWERFLG() {
        return yESNOANSWERFLG;
    }

    /**
     * 
     * @param yESNOANSWERFLG
     *     The YES_NO_ANSWER_FLG
     */
    @JsonProperty("YES_NO_ANSWER_FLG")
    public void setYESNOANSWERFLG(String yESNOANSWERFLG) {
        this.yESNOANSWERFLG = yESNOANSWERFLG;
    }

    /**
     * 
     * @return
     *     The m1DEPLOYMENTIDLBL
     */
    @JsonProperty("M1_DEPLOYMENT_ID_LBL")
    public String getM1DEPLOYMENTIDLBL() {
        return m1DEPLOYMENTIDLBL;
    }

    /**
     * 
     * @param m1DEPLOYMENTIDLBL
     *     The M1_DEPLOYMENT_ID_LBL
     */
    @JsonProperty("M1_DEPLOYMENT_ID_LBL")
    public void setM1DEPLOYMENTIDLBL(String m1DEPLOYMENTIDLBL) {
        this.m1DEPLOYMENTIDLBL = m1DEPLOYMENTIDLBL;
    }

    /**
     * 
     * @return
     *     The m1SCANBARCODELBL
     */
    @JsonProperty("M1_SCAN_BARCODE_LBL")
    public String getM1SCANBARCODELBL() {
        return m1SCANBARCODELBL;
    }

    /**
     * 
     * @param m1SCANBARCODELBL
     *     The M1_SCAN_BARCODE_LBL
     */
    @JsonProperty("M1_SCAN_BARCODE_LBL")
    public void setM1SCANBARCODELBL(String m1SCANBARCODELBL) {
        this.m1SCANBARCODELBL = m1SCANBARCODELBL;
    }

    /**
     * 
     * @return
     *     The tIMESHEETID
     */
    @JsonProperty("TIMESHEET_ID")
    public String getTIMESHEETID() {
        return tIMESHEETID;
    }

    /**
     * 
     * @param tIMESHEETID
     *     The TIMESHEET_ID
     */
    @JsonProperty("TIMESHEET_ID")
    public void setTIMESHEETID(String tIMESHEETID) {
        this.tIMESHEETID = tIMESHEETID;
    }

    /**
     * 
     * @return
     *     The m1SYNCLOGFILESLBL
     */
    @JsonProperty("M1_SYNC_LOG_FILES_LBL")
    public String getM1SYNCLOGFILESLBL() {
        return m1SYNCLOGFILESLBL;
    }

    /**
     * 
     * @param m1SYNCLOGFILESLBL
     *     The M1_SYNC_LOG_FILES_LBL
     */
    @JsonProperty("M1_SYNC_LOG_FILES_LBL")
    public void setM1SYNCLOGFILESLBL(String m1SYNCLOGFILESLBL) {
        this.m1SYNCLOGFILESLBL = m1SYNCLOGFILESLBL;
    }

    /**
     * 
     * @return
     *     The m1LOADINSTR
     */
    @JsonProperty("M1_LOAD_INSTR")
    public String getM1LOADINSTR() {
        return m1LOADINSTR;
    }

    /**
     * 
     * @param m1LOADINSTR
     *     The M1_LOAD_INSTR
     */
    @JsonProperty("M1_LOAD_INSTR")
    public void setM1LOADINSTR(String m1LOADINSTR) {
        this.m1LOADINSTR = m1LOADINSTR;
    }

    /**
     * 
     * @return
     *     The m1SUMMARYLBL
     */
    @JsonProperty("M1_SUMMARY_LBL")
    public String getM1SUMMARYLBL() {
        return m1SUMMARYLBL;
    }

    /**
     * 
     * @param m1SUMMARYLBL
     *     The M1_SUMMARY_LBL
     */
    @JsonProperty("M1_SUMMARY_LBL")
    public void setM1SUMMARYLBL(String m1SUMMARYLBL) {
        this.m1SUMMARYLBL = m1SUMMARYLBL;
    }

    /**
     * 
     * @return
     *     The m1DECLINECOMMENTS
     */
    @JsonProperty("M1_DECLINE_COMMENTS")
    public String getM1DECLINECOMMENTS() {
        return m1DECLINECOMMENTS;
    }

    /**
     * 
     * @param m1DECLINECOMMENTS
     *     The M1_DECLINE_COMMENTS
     */
    @JsonProperty("M1_DECLINE_COMMENTS")
    public void setM1DECLINECOMMENTS(String m1DECLINECOMMENTS) {
        this.m1DECLINECOMMENTS = m1DECLINECOMMENTS;
    }

    /**
     * 
     * @return
     *     The pKVAL5
     */
    @JsonProperty("PK_VAL5")
    public String getPKVAL5() {
        return pKVAL5;
    }

    /**
     * 
     * @param pKVAL5
     *     The PK_VAL5
     */
    @JsonProperty("PK_VAL5")
    public void setPKVAL5(String pKVAL5) {
        this.pKVAL5 = pKVAL5;
    }

    /**
     * 
     * @return
     *     The m1APPROVALDTTMLBL
     */
    @JsonProperty("M1_APPROVAL_DTTM_LBL")
    public String getM1APPROVALDTTMLBL() {
        return m1APPROVALDTTMLBL;
    }

    /**
     * 
     * @param m1APPROVALDTTMLBL
     *     The M1_APPROVAL_DTTM_LBL
     */
    @JsonProperty("M1_APPROVAL_DTTM_LBL")
    public void setM1APPROVALDTTMLBL(String m1APPROVALDTTMLBL) {
        this.m1APPROVALDTTMLBL = m1APPROVALDTTMLBL;
    }

    /**
     * 
     * @return
     *     The m1MAXLATE
     */
    @JsonProperty("M1_MAX_LATE")
    public String getM1MAXLATE() {
        return m1MAXLATE;
    }

    /**
     * 
     * @param m1MAXLATE
     *     The M1_MAX_LATE
     */
    @JsonProperty("M1_MAX_LATE")
    public void setM1MAXLATE(String m1MAXLATE) {
        this.m1MAXLATE = m1MAXLATE;
    }

    /**
     * 
     * @return
     *     The m1TASKSLBL
     */
    @JsonProperty("M1_TASKS_LBL")
    public String getM1TASKSLBL() {
        return m1TASKSLBL;
    }

    /**
     * 
     * @param m1TASKSLBL
     *     The M1_TASKS_LBL
     */
    @JsonProperty("M1_TASKS_LBL")
    public void setM1TASKSLBL(String m1TASKSLBL) {
        this.m1TASKSLBL = m1TASKSLBL;
    }

    /**
     * 
     * @return
     *     The pKVAL1
     */
    @JsonProperty("PK_VAL1")
    public String getPKVAL1() {
        return pKVAL1;
    }

    /**
     * 
     * @param pKVAL1
     *     The PK_VAL1
     */
    @JsonProperty("PK_VAL1")
    public void setPKVAL1(String pKVAL1) {
        this.pKVAL1 = pKVAL1;
    }

    /**
     * 
     * @return
     *     The pKVAL2
     */
    @JsonProperty("PK_VAL2")
    public String getPKVAL2() {
        return pKVAL2;
    }

    /**
     * 
     * @param pKVAL2
     *     The PK_VAL2
     */
    @JsonProperty("PK_VAL2")
    public void setPKVAL2(String pKVAL2) {
        this.pKVAL2 = pKVAL2;
    }

    /**
     * 
     * @return
     *     The m1PENDINGLBL
     */
    @JsonProperty("M1_PENDING_LBL")
    public String getM1PENDINGLBL() {
        return m1PENDINGLBL;
    }

    /**
     * 
     * @param m1PENDINGLBL
     *     The M1_PENDING_LBL
     */
    @JsonProperty("M1_PENDING_LBL")
    public void setM1PENDINGLBL(String m1PENDINGLBL) {
        this.m1PENDINGLBL = m1PENDINGLBL;
    }

    /**
     * 
     * @return
     *     The pKVAL3
     */
    @JsonProperty("PK_VAL3")
    public String getPKVAL3() {
        return pKVAL3;
    }

    /**
     * 
     * @param pKVAL3
     *     The PK_VAL3
     */
    @JsonProperty("PK_VAL3")
    public void setPKVAL3(String pKVAL3) {
        this.pKVAL3 = pKVAL3;
    }

    /**
     * 
     * @return
     *     The m1ITEMCUSTACCEPTEDFLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPTED_FLG")
    public String getM1ITEMCUSTACCEPTEDFLG() {
        return m1ITEMCUSTACCEPTEDFLG;
    }

    /**
     * 
     * @param m1ITEMCUSTACCEPTEDFLG
     *     The M1_ITEM_CUST_ACCEPTED_FLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPTED_FLG")
    public void setM1ITEMCUSTACCEPTEDFLG(String m1ITEMCUSTACCEPTEDFLG) {
        this.m1ITEMCUSTACCEPTEDFLG = m1ITEMCUSTACCEPTEDFLG;
    }

    /**
     * 
     * @return
     *     The pKVAL4
     */
    @JsonProperty("PK_VAL4")
    public String getPKVAL4() {
        return pKVAL4;
    }

    /**
     * 
     * @param pKVAL4
     *     The PK_VAL4
     */
    @JsonProperty("PK_VAL4")
    public void setPKVAL4(String pKVAL4) {
        this.pKVAL4 = pKVAL4;
    }

    /**
     * 
     * @return
     *     The cROSSSTREET
     */
    @JsonProperty("CROSS_STREET")
    public String getCROSSSTREET() {
        return cROSSSTREET;
    }

    /**
     * 
     * @param cROSSSTREET
     *     The CROSS_STREET
     */
    @JsonProperty("CROSS_STREET")
    public void setCROSSSTREET(String cROSSSTREET) {
        this.cROSSSTREET = cROSSSTREET;
    }

    /**
     * 
     * @return
     *     The m1OVERRIDEPRCDRCLEARLBL
     */
    @JsonProperty("M1_OVERRIDE_PRCDR_CLEAR_LBL")
    public String getM1OVERRIDEPRCDRCLEARLBL() {
        return m1OVERRIDEPRCDRCLEARLBL;
    }

    /**
     * 
     * @param m1OVERRIDEPRCDRCLEARLBL
     *     The M1_OVERRIDE_PRCDR_CLEAR_LBL
     */
    @JsonProperty("M1_OVERRIDE_PRCDR_CLEAR_LBL")
    public void setM1OVERRIDEPRCDRCLEARLBL(String m1OVERRIDEPRCDRCLEARLBL) {
        this.m1OVERRIDEPRCDRCLEARLBL = m1OVERRIDEPRCDRCLEARLBL;
    }

    /**
     * 
     * @return
     *     The pOUID
     */
    @JsonProperty("POU_ID")
    public String getPOUID() {
        return pOUID;
    }

    /**
     * 
     * @param pOUID
     *     The POU_ID
     */
    @JsonProperty("POU_ID")
    public void setPOUID(String pOUID) {
        this.pOUID = pOUID;
    }

    /**
     * 
     * @return
     *     The m1CREWSHFTLBL
     */
    @JsonProperty("M1_CREW_SHFT_LBL")
    public String getM1CREWSHFTLBL() {
        return m1CREWSHFTLBL;
    }

    /**
     * 
     * @param m1CREWSHFTLBL
     *     The M1_CREW_SHFT_LBL
     */
    @JsonProperty("M1_CREW_SHFT_LBL")
    public void setM1CREWSHFTLBL(String m1CREWSHFTLBL) {
        this.m1CREWSHFTLBL = m1CREWSHFTLBL;
    }

    /**
     * 
     * @return
     *     The m1RELBL
     */
    @JsonProperty("M1_RE_LBL")
    public String getM1RELBL() {
        return m1RELBL;
    }

    /**
     * 
     * @param m1RELBL
     *     The M1_RE_LBL
     */
    @JsonProperty("M1_RE_LBL")
    public void setM1RELBL(String m1RELBL) {
        this.m1RELBL = m1RELBL;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYEXPLBL
     */
    @JsonProperty("M1_ACTIVITY_EXP_LBL")
    public String getM1ACTIVITYEXPLBL() {
        return m1ACTIVITYEXPLBL;
    }

    /**
     * 
     * @param m1ACTIVITYEXPLBL
     *     The M1_ACTIVITY_EXP_LBL
     */
    @JsonProperty("M1_ACTIVITY_EXP_LBL")
    public void setM1ACTIVITYEXPLBL(String m1ACTIVITYEXPLBL) {
        this.m1ACTIVITYEXPLBL = m1ACTIVITYEXPLBL;
    }

    /**
     * 
     * @return
     *     The m1FROMLBL
     */
    @JsonProperty("M1_FROM_LBL")
    public String getM1FROMLBL() {
        return m1FROMLBL;
    }

    /**
     * 
     * @param m1FROMLBL
     *     The M1_FROM_LBL
     */
    @JsonProperty("M1_FROM_LBL")
    public void setM1FROMLBL(String m1FROMLBL) {
        this.m1FROMLBL = m1FROMLBL;
    }

    /**
     * 
     * @return
     *     The m1JOBID
     */
    @JsonProperty("M1_JOB_ID")
    public String getM1JOBID() {
        return m1JOBID;
    }

    /**
     * 
     * @param m1JOBID
     *     The M1_JOB_ID
     */
    @JsonProperty("M1_JOB_ID")
    public void setM1JOBID(String m1JOBID) {
        this.m1JOBID = m1JOBID;
    }

    /**
     * 
     * @return
     *     The cITYLBL
     */
    @JsonProperty("CITY_LBL")
    public String getCITYLBL() {
        return cITYLBL;
    }

    /**
     * 
     * @param cITYLBL
     *     The CITY_LBL
     */
    @JsonProperty("CITY_LBL")
    public void setCITYLBL(String cITYLBL) {
        this.cITYLBL = cITYLBL;
    }

    /**
     * 
     * @return
     *     The aPPOINTMENTFLG
     */
    @JsonProperty("APPOINTMENT_FLG")
    public String getAPPOINTMENTFLG() {
        return aPPOINTMENTFLG;
    }

    /**
     * 
     * @param aPPOINTMENTFLG
     *     The APPOINTMENT_FLG
     */
    @JsonProperty("APPOINTMENT_FLG")
    public void setAPPOINTMENTFLG(String aPPOINTMENTFLG) {
        this.aPPOINTMENTFLG = aPPOINTMENTFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYATTRIBUTE
     */
    @JsonProperty("M1_ACTIVITY_ATTRIBUTE")
    public String getM1ACTIVITYATTRIBUTE() {
        return m1ACTIVITYATTRIBUTE;
    }

    /**
     * 
     * @param m1ACTIVITYATTRIBUTE
     *     The M1_ACTIVITY_ATTRIBUTE
     */
    @JsonProperty("M1_ACTIVITY_ATTRIBUTE")
    public void setM1ACTIVITYATTRIBUTE(String m1ACTIVITYATTRIBUTE) {
        this.m1ACTIVITYATTRIBUTE = m1ACTIVITYATTRIBUTE;
    }

    /**
     * 
     * @return
     *     The m1LOADTASKBUTTONLBL
     */
    @JsonProperty("M1_LOAD_TASK_BUTTON_LBL")
    public String getM1LOADTASKBUTTONLBL() {
        return m1LOADTASKBUTTONLBL;
    }

    /**
     * 
     * @param m1LOADTASKBUTTONLBL
     *     The M1_LOAD_TASK_BUTTON_LBL
     */
    @JsonProperty("M1_LOAD_TASK_BUTTON_LBL")
    public void setM1LOADTASKBUTTONLBL(String m1LOADTASKBUTTONLBL) {
        this.m1LOADTASKBUTTONLBL = m1LOADTASKBUTTONLBL;
    }

    /**
     * 
     * @return
     *     The m1SELECTTHEMELBL
     */
    @JsonProperty("M1_SELECT_THEME_LBL")
    public String getM1SELECTTHEMELBL() {
        return m1SELECTTHEMELBL;
    }

    /**
     * 
     * @param m1SELECTTHEMELBL
     *     The M1_SELECT_THEME_LBL
     */
    @JsonProperty("M1_SELECT_THEME_LBL")
    public void setM1SELECTTHEMELBL(String m1SELECTTHEMELBL) {
        this.m1SELECTTHEMELBL = m1SELECTTHEMELBL;
    }

    /**
     * 
     * @return
     *     The m1MOREELLIPSISLBL
     */
    @JsonProperty("M1_MORE_ELLIPSIS_LBL")
    public String getM1MOREELLIPSISLBL() {
        return m1MOREELLIPSISLBL;
    }

    /**
     * 
     * @param m1MOREELLIPSISLBL
     *     The M1_MORE_ELLIPSIS_LBL
     */
    @JsonProperty("M1_MORE_ELLIPSIS_LBL")
    public void setM1MOREELLIPSISLBL(String m1MOREELLIPSISLBL) {
        this.m1MOREELLIPSISLBL = m1MOREELLIPSISLBL;
    }

    /**
     * 
     * @return
     *     The m1WORKSEQLBL
     */
    @JsonProperty("M1_WORK_SEQ_LBL")
    public String getM1WORKSEQLBL() {
        return m1WORKSEQLBL;
    }

    /**
     * 
     * @param m1WORKSEQLBL
     *     The M1_WORK_SEQ_LBL
     */
    @JsonProperty("M1_WORK_SEQ_LBL")
    public void setM1WORKSEQLBL(String m1WORKSEQLBL) {
        this.m1WORKSEQLBL = m1WORKSEQLBL;
    }

    /**
     * 
     * @return
     *     The m1ACTUALSTARTTIME
     */
    @JsonProperty("M1_ACTUAL_START_TIME")
    public String getM1ACTUALSTARTTIME() {
        return m1ACTUALSTARTTIME;
    }

    /**
     * 
     * @param m1ACTUALSTARTTIME
     *     The M1_ACTUAL_START_TIME
     */
    @JsonProperty("M1_ACTUAL_START_TIME")
    public void setM1ACTUALSTARTTIME(String m1ACTUALSTARTTIME) {
        this.m1ACTUALSTARTTIME = m1ACTUALSTARTTIME;
    }

    /**
     * 
     * @return
     *     The m1SETTINGSLBL
     */
    @JsonProperty("M1_SETTINGS_LBL")
    public String getM1SETTINGSLBL() {
        return m1SETTINGSLBL;
    }

    /**
     * 
     * @param m1SETTINGSLBL
     *     The M1_SETTINGS_LBL
     */
    @JsonProperty("M1_SETTINGS_LBL")
    public void setM1SETTINGSLBL(String m1SETTINGSLBL) {
        this.m1SETTINGSLBL = m1SETTINGSLBL;
    }

    /**
     * 
     * @return
     *     The m1EXTENSIONDAYS
     */
    @JsonProperty("M1_EXTENSION_DAYS")
    public String getM1EXTENSIONDAYS() {
        return m1EXTENSIONDAYS;
    }

    /**
     * 
     * @param m1EXTENSIONDAYS
     *     The M1_EXTENSION_DAYS
     */
    @JsonProperty("M1_EXTENSION_DAYS")
    public void setM1EXTENSIONDAYS(String m1EXTENSIONDAYS) {
        this.m1EXTENSIONDAYS = m1EXTENSIONDAYS;
    }

    /**
     * 
     * @return
     *     The hOSTTASKID
     */
    @JsonProperty("HOST_TASK_ID")
    public String getHOSTTASKID() {
        return hOSTTASKID;
    }

    /**
     * 
     * @param hOSTTASKID
     *     The HOST_TASK_ID
     */
    @JsonProperty("HOST_TASK_ID")
    public void setHOSTTASKID(String hOSTTASKID) {
        this.hOSTTASKID = hOSTTASKID;
    }

    /**
     * 
     * @return
     *     The m1ALLOWBREAKSFLG
     */
    @JsonProperty("M1_ALLOW_BREAKS_FLG")
    public String getM1ALLOWBREAKSFLG() {
        return m1ALLOWBREAKSFLG;
    }

    /**
     * 
     * @param m1ALLOWBREAKSFLG
     *     The M1_ALLOW_BREAKS_FLG
     */
    @JsonProperty("M1_ALLOW_BREAKS_FLG")
    public void setM1ALLOWBREAKSFLG(String m1ALLOWBREAKSFLG) {
        this.m1ALLOWBREAKSFLG = m1ALLOWBREAKSFLG;
    }

    /**
     * 
     * @return
     *     The m1MCPINDICATORMAINLBL
     */
    @JsonProperty("M1_MCP_INDICATOR_MAIN_LBL")
    public String getM1MCPINDICATORMAINLBL() {
        return m1MCPINDICATORMAINLBL;
    }

    /**
     * 
     * @param m1MCPINDICATORMAINLBL
     *     The M1_MCP_INDICATOR_MAIN_LBL
     */
    @JsonProperty("M1_MCP_INDICATOR_MAIN_LBL")
    public void setM1MCPINDICATORMAINLBL(String m1MCPINDICATORMAINLBL) {
        this.m1MCPINDICATORMAINLBL = m1MCPINDICATORMAINLBL;
    }

    /**
     * 
     * @return
     *     The m1COLLISIONDETECTEDTODOROL
     */
    @JsonProperty("M1_COLLISION_DETECTED_TODO_ROL")
    public String getM1COLLISIONDETECTEDTODOROL() {
        return m1COLLISIONDETECTEDTODOROL;
    }

    /**
     * 
     * @param m1COLLISIONDETECTEDTODOROL
     *     The M1_COLLISION_DETECTED_TODO_ROL
     */
    @JsonProperty("M1_COLLISION_DETECTED_TODO_ROL")
    public void setM1COLLISIONDETECTEDTODOROL(String m1COLLISIONDETECTEDTODOROL) {
        this.m1COLLISIONDETECTEDTODOROL = m1COLLISIONDETECTEDTODOROL;
    }

    /**
     * 
     * @return
     *     The m1CREATEBYCREWFLG
     */
    @JsonProperty("M1_CREATE_BY_CREW_FLG")
    public String getM1CREATEBYCREWFLG() {
        return m1CREATEBYCREWFLG;
    }

    /**
     * 
     * @param m1CREATEBYCREWFLG
     *     The M1_CREATE_BY_CREW_FLG
     */
    @JsonProperty("M1_CREATE_BY_CREW_FLG")
    public void setM1CREATEBYCREWFLG(String m1CREATEBYCREWFLG) {
        this.m1CREATEBYCREWFLG = m1CREATEBYCREWFLG;
    }

    /**
     * 
     * @return
     *     The m1SVCAREAUSAGE
     */
    @JsonProperty("M1_SVC_AREA_USAGE")
    public String getM1SVCAREAUSAGE() {
        return m1SVCAREAUSAGE;
    }

    /**
     * 
     * @param m1SVCAREAUSAGE
     *     The M1_SVC_AREA_USAGE
     */
    @JsonProperty("M1_SVC_AREA_USAGE")
    public void setM1SVCAREAUSAGE(String m1SVCAREAUSAGE) {
        this.m1SVCAREAUSAGE = m1SVCAREAUSAGE;
    }

    /**
     * 
     * @return
     *     The m1USEDUNTILLBL
     */
    @JsonProperty("M1_USED_UNTIL_LBL")
    public String getM1USEDUNTILLBL() {
        return m1USEDUNTILLBL;
    }

    /**
     * 
     * @param m1USEDUNTILLBL
     *     The M1_USED_UNTIL_LBL
     */
    @JsonProperty("M1_USED_UNTIL_LBL")
    public void setM1USEDUNTILLBL(String m1USEDUNTILLBL) {
        this.m1USEDUNTILLBL = m1USEDUNTILLBL;
    }

    /**
     * 
     * @return
     *     The m1CROSSSTREET
     */
    @JsonProperty("M1_CROSS_STREET")
    public String getM1CROSSSTREET() {
        return m1CROSSSTREET;
    }

    /**
     * 
     * @param m1CROSSSTREET
     *     The M1_CROSS_STREET
     */
    @JsonProperty("M1_CROSS_STREET")
    public void setM1CROSSSTREET(String m1CROSSSTREET) {
        this.m1CROSSSTREET = m1CROSSSTREET;
    }

    /**
     * 
     * @return
     *     The m1ETALBL
     */
    @JsonProperty("M1_ETA_LBL")
    public String getM1ETALBL() {
        return m1ETALBL;
    }

    /**
     * 
     * @param m1ETALBL
     *     The M1_ETA_LBL
     */
    @JsonProperty("M1_ETA_LBL")
    public void setM1ETALBL(String m1ETALBL) {
        this.m1ETALBL = m1ETALBL;
    }

    /**
     * 
     * @return
     *     The m1SERVICEINSTRUCTIONS
     */
    @JsonProperty("M1_SERVICE_INSTRUCTIONS")
    public String getM1SERVICEINSTRUCTIONS() {
        return m1SERVICEINSTRUCTIONS;
    }

    /**
     * 
     * @param m1SERVICEINSTRUCTIONS
     *     The M1_SERVICE_INSTRUCTIONS
     */
    @JsonProperty("M1_SERVICE_INSTRUCTIONS")
    public void setM1SERVICEINSTRUCTIONS(String m1SERVICEINSTRUCTIONS) {
        this.m1SERVICEINSTRUCTIONS = m1SERVICEINSTRUCTIONS;
    }

    /**
     * 
     * @return
     *     The m1RESTRICTIONTYPEFLG
     */
    @JsonProperty("M1_RESTRICTION_TYPE_FLG")
    public String getM1RESTRICTIONTYPEFLG() {
        return m1RESTRICTIONTYPEFLG;
    }

    /**
     * 
     * @param m1RESTRICTIONTYPEFLG
     *     The M1_RESTRICTION_TYPE_FLG
     */
    @JsonProperty("M1_RESTRICTION_TYPE_FLG")
    public void setM1RESTRICTIONTYPEFLG(String m1RESTRICTIONTYPEFLG) {
        this.m1RESTRICTIONTYPEFLG = m1RESTRICTIONTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1SCHEDULINGORDER
     */
    @JsonProperty("M1_SCHEDULING_ORDER")
    public String getM1SCHEDULINGORDER() {
        return m1SCHEDULINGORDER;
    }

    /**
     * 
     * @param m1SCHEDULINGORDER
     *     The M1_SCHEDULING_ORDER
     */
    @JsonProperty("M1_SCHEDULING_ORDER")
    public void setM1SCHEDULINGORDER(String m1SCHEDULINGORDER) {
        this.m1SCHEDULINGORDER = m1SCHEDULINGORDER;
    }

    /**
     * 
     * @return
     *     The m1TEMPLATESHIFT
     */
    @JsonProperty("M1_TEMPLATE_SHIFT")
    public String getM1TEMPLATESHIFT() {
        return m1TEMPLATESHIFT;
    }

    /**
     * 
     * @param m1TEMPLATESHIFT
     *     The M1_TEMPLATE_SHIFT
     */
    @JsonProperty("M1_TEMPLATE_SHIFT")
    public void setM1TEMPLATESHIFT(String m1TEMPLATESHIFT) {
        this.m1TEMPLATESHIFT = m1TEMPLATESHIFT;
    }

    /**
     * 
     * @return
     *     The sTATUSREASONSELECTFLG
     */
    @JsonProperty("STATUS_REASON_SELECT_FLG")
    public String getSTATUSREASONSELECTFLG() {
        return sTATUSREASONSELECTFLG;
    }

    /**
     * 
     * @param sTATUSREASONSELECTFLG
     *     The STATUS_REASON_SELECT_FLG
     */
    @JsonProperty("STATUS_REASON_SELECT_FLG")
    public void setSTATUSREASONSELECTFLG(String sTATUSREASONSELECTFLG) {
        this.sTATUSREASONSELECTFLG = sTATUSREASONSELECTFLG;
    }

    /**
     * 
     * @return
     *     The m1AFTERDAYS
     */
    @JsonProperty("M1_AFTER_DAYS")
    public String getM1AFTERDAYS() {
        return m1AFTERDAYS;
    }

    /**
     * 
     * @param m1AFTERDAYS
     *     The M1_AFTER_DAYS
     */
    @JsonProperty("M1_AFTER_DAYS")
    public void setM1AFTERDAYS(String m1AFTERDAYS) {
        this.m1AFTERDAYS = m1AFTERDAYS;
    }

    /**
     * 
     * @return
     *     The dIRECTIONSLBL
     */
    @JsonProperty("DIRECTIONS_LBL")
    public String getDIRECTIONSLBL() {
        return dIRECTIONSLBL;
    }

    /**
     * 
     * @param dIRECTIONSLBL
     *     The DIRECTIONS_LBL
     */
    @JsonProperty("DIRECTIONS_LBL")
    public void setDIRECTIONSLBL(String dIRECTIONSLBL) {
        this.dIRECTIONSLBL = dIRECTIONSLBL;
    }

    /**
     * 
     * @return
     *     The m1CUSTOMERINFOLBL
     */
    @JsonProperty("M1_CUSTOMER_INFO_LBL")
    public String getM1CUSTOMERINFOLBL() {
        return m1CUSTOMERINFOLBL;
    }

    /**
     * 
     * @param m1CUSTOMERINFOLBL
     *     The M1_CUSTOMER_INFO_LBL
     */
    @JsonProperty("M1_CUSTOMER_INFO_LBL")
    public void setM1CUSTOMERINFOLBL(String m1CUSTOMERINFOLBL) {
        this.m1CUSTOMERINFOLBL = m1CUSTOMERINFOLBL;
    }

    /**
     * 
     * @return
     *     The dESCR
     */
    @JsonProperty("DESCR")
    public String getDESCR() {
        return dESCR;
    }

    /**
     * 
     * @param dESCR
     *     The DESCR
     */
    @JsonProperty("DESCR")
    public void setDESCR(String dESCR) {
        this.dESCR = dESCR;
    }

    /**
     * 
     * @return
     *     The cREWSHFTID
     */
    @JsonProperty("CREW_SHFT_ID")
    public String getCREWSHFTID() {
        return cREWSHFTID;
    }

    /**
     * 
     * @param cREWSHFTID
     *     The CREW_SHFT_ID
     */
    @JsonProperty("CREW_SHFT_ID")
    public void setCREWSHFTID(String cREWSHFTID) {
        this.cREWSHFTID = cREWSHFTID;
    }

    /**
     * 
     * @return
     *     The m1SELPRIFUNCTIONLBL
     */
    @JsonProperty("M1_SEL_PRI_FUNCTION_LBL")
    public String getM1SELPRIFUNCTIONLBL() {
        return m1SELPRIFUNCTIONLBL;
    }

    /**
     * 
     * @param m1SELPRIFUNCTIONLBL
     *     The M1_SEL_PRI_FUNCTION_LBL
     */
    @JsonProperty("M1_SEL_PRI_FUNCTION_LBL")
    public void setM1SELPRIFUNCTIONLBL(String m1SELPRIFUNCTIONLBL) {
        this.m1SELPRIFUNCTIONLBL = m1SELPRIFUNCTIONLBL;
    }

    /**
     * 
     * @return
     *     The m1ADJUSTEDDURATION
     */
    @JsonProperty("M1_ADJUSTED_DURATION")
    public String getM1ADJUSTEDDURATION() {
        return m1ADJUSTEDDURATION;
    }

    /**
     * 
     * @param m1ADJUSTEDDURATION
     *     The M1_ADJUSTED_DURATION
     */
    @JsonProperty("M1_ADJUSTED_DURATION")
    public void setM1ADJUSTEDDURATION(String m1ADJUSTEDDURATION) {
        this.m1ADJUSTEDDURATION = m1ADJUSTEDDURATION;
    }

    /**
     * 
     * @return
     *     The m1CALCERRORSW
     */
    @JsonProperty("M1_CALC_ERROR_SW")
    public String getM1CALCERRORSW() {
        return m1CALCERRORSW;
    }

    /**
     * 
     * @param m1CALCERRORSW
     *     The M1_CALC_ERROR_SW
     */
    @JsonProperty("M1_CALC_ERROR_SW")
    public void setM1CALCERRORSW(String m1CALCERRORSW) {
        this.m1CALCERRORSW = m1CALCERRORSW;
    }

    /**
     * 
     * @return
     *     The m1ATLBL
     */
    @JsonProperty("M1_AT_LBL")
    public String getM1ATLBL() {
        return m1ATLBL;
    }

    /**
     * 
     * @param m1ATLBL
     *     The M1_AT_LBL
     */
    @JsonProperty("M1_AT_LBL")
    public void setM1ATLBL(String m1ATLBL) {
        this.m1ATLBL = m1ATLBL;
    }

    /**
     * 
     * @return
     *     The m1APPTSTDTTM
     */
    @JsonProperty("M1_APPT_ST_DTTM")
    public String getM1APPTSTDTTM() {
        return m1APPTSTDTTM;
    }

    /**
     * 
     * @param m1APPTSTDTTM
     *     The M1_APPT_ST_DTTM
     */
    @JsonProperty("M1_APPT_ST_DTTM")
    public void setM1APPTSTDTTM(String m1APPTSTDTTM) {
        this.m1APPTSTDTTM = m1APPTSTDTTM;
    }

    /**
     * 
     * @return
     *     The m1LOADTASKCOMPLETELBL
     */
    @JsonProperty("M1_LOAD_TASK_COMPLETE_LBL")
    public String getM1LOADTASKCOMPLETELBL() {
        return m1LOADTASKCOMPLETELBL;
    }

    /**
     * 
     * @param m1LOADTASKCOMPLETELBL
     *     The M1_LOAD_TASK_COMPLETE_LBL
     */
    @JsonProperty("M1_LOAD_TASK_COMPLETE_LBL")
    public void setM1LOADTASKCOMPLETELBL(String m1LOADTASKCOMPLETELBL) {
        this.m1LOADTASKCOMPLETELBL = m1LOADTASKCOMPLETELBL;
    }

    /**
     * 
     * @return
     *     The m1EXTENTITYNAME
     */
    @JsonProperty("M1_EXT_ENTITY_NAME")
    public String getM1EXTENTITYNAME() {
        return m1EXTENTITYNAME;
    }

    /**
     * 
     * @param m1EXTENTITYNAME
     *     The M1_EXT_ENTITY_NAME
     */
    @JsonProperty("M1_EXT_ENTITY_NAME")
    public void setM1EXTENTITYNAME(String m1EXTENTITYNAME) {
        this.m1EXTENTITYNAME = m1EXTENTITYNAME;
    }

    /**
     * 
     * @return
     *     The m1DOWNLOADED
     */
    @JsonProperty("M1_DOWNLOADED")
    public String getM1DOWNLOADED() {
        return m1DOWNLOADED;
    }

    /**
     * 
     * @param m1DOWNLOADED
     *     The M1_DOWNLOADED
     */
    @JsonProperty("M1_DOWNLOADED")
    public void setM1DOWNLOADED(String m1DOWNLOADED) {
        this.m1DOWNLOADED = m1DOWNLOADED;
    }

    /**
     * 
     * @return
     *     The m1DEPOTINFORMATIONLBL
     */
    @JsonProperty("M1_DEPOT_INFORMATION_LBL")
    public String getM1DEPOTINFORMATIONLBL() {
        return m1DEPOTINFORMATIONLBL;
    }

    /**
     * 
     * @param m1DEPOTINFORMATIONLBL
     *     The M1_DEPOT_INFORMATION_LBL
     */
    @JsonProperty("M1_DEPOT_INFORMATION_LBL")
    public void setM1DEPOTINFORMATIONLBL(String m1DEPOTINFORMATIONLBL) {
        this.m1DEPOTINFORMATIONLBL = m1DEPOTINFORMATIONLBL;
    }

    /**
     * 
     * @return
     *     The m1FOLDERFLG
     */
    @JsonProperty("M1_FOLDER_FLG")
    public String getM1FOLDERFLG() {
        return m1FOLDERFLG;
    }

    /**
     * 
     * @param m1FOLDERFLG
     *     The M1_FOLDER_FLG
     */
    @JsonProperty("M1_FOLDER_FLG")
    public void setM1FOLDERFLG(String m1FOLDERFLG) {
        this.m1FOLDERFLG = m1FOLDERFLG;
    }

    /**
     * 
     * @return
     *     The pOSTALAVAIL
     */
    @JsonProperty("POSTAL_AVAIL")
    public String getPOSTALAVAIL() {
        return pOSTALAVAIL;
    }

    /**
     * 
     * @param pOSTALAVAIL
     *     The POSTAL_AVAIL
     */
    @JsonProperty("POSTAL_AVAIL")
    public void setPOSTALAVAIL(String pOSTALAVAIL) {
        this.pOSTALAVAIL = pOSTALAVAIL;
    }

    /**
     * 
     * @return
     *     The m1MAILID
     */
    @JsonProperty("M1_MAIL_ID")
    public String getM1MAILID() {
        return m1MAILID;
    }

    /**
     * 
     * @param m1MAILID
     *     The M1_MAIL_ID
     */
    @JsonProperty("M1_MAIL_ID")
    public void setM1MAILID(String m1MAILID) {
        this.m1MAILID = m1MAILID;
    }

    /**
     * 
     * @return
     *     The m1BRKDUR
     */
    @JsonProperty("M1_BRK_DUR")
    public String getM1BRKDUR() {
        return m1BRKDUR;
    }

    /**
     * 
     * @param m1BRKDUR
     *     The M1_BRK_DUR
     */
    @JsonProperty("M1_BRK_DUR")
    public void setM1BRKDUR(String m1BRKDUR) {
        this.m1BRKDUR = m1BRKDUR;
    }

    /**
     * 
     * @return
     *     The m1ITEMBARCODETYPE
     */
    @JsonProperty("M1_ITEM_BARCODE_TYPE")
    public String getM1ITEMBARCODETYPE() {
        return m1ITEMBARCODETYPE;
    }

    /**
     * 
     * @param m1ITEMBARCODETYPE
     *     The M1_ITEM_BARCODE_TYPE
     */
    @JsonProperty("M1_ITEM_BARCODE_TYPE")
    public void setM1ITEMBARCODETYPE(String m1ITEMBARCODETYPE) {
        this.m1ITEMBARCODETYPE = m1ITEMBARCODETYPE;
    }

    /**
     * 
     * @return
     *     The m1NPTLBL
     */
    @JsonProperty("M1_NPT_LBL")
    public String getM1NPTLBL() {
        return m1NPTLBL;
    }

    /**
     * 
     * @param m1NPTLBL
     *     The M1_NPT_LBL
     */
    @JsonProperty("M1_NPT_LBL")
    public void setM1NPTLBL(String m1NPTLBL) {
        this.m1NPTLBL = m1NPTLBL;
    }

    /**
     * 
     * @return
     *     The m1SELECTONELBL
     */
    @JsonProperty("M1_SELECT_ONE_LBL")
    public String getM1SELECTONELBL() {
        return m1SELECTONELBL;
    }

    /**
     * 
     * @param m1SELECTONELBL
     *     The M1_SELECT_ONE_LBL
     */
    @JsonProperty("M1_SELECT_ONE_LBL")
    public void setM1SELECTONELBL(String m1SELECTONELBL) {
        this.m1SELECTONELBL = m1SELECTONELBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMBARCODE
     */
    @JsonProperty("M1_ITEM_BARCODE")
    public String getM1ITEMBARCODE() {
        return m1ITEMBARCODE;
    }

    /**
     * 
     * @param m1ITEMBARCODE
     *     The M1_ITEM_BARCODE
     */
    @JsonProperty("M1_ITEM_BARCODE")
    public void setM1ITEMBARCODE(String m1ITEMBARCODE) {
        this.m1ITEMBARCODE = m1ITEMBARCODE;
    }

    /**
     * 
     * @return
     *     The m1UNACKNEMERGALERTTYPE
     */
    @JsonProperty("M1_UNACKN_EMERG_ALERT_TYPE")
    public String getM1UNACKNEMERGALERTTYPE() {
        return m1UNACKNEMERGALERTTYPE;
    }

    /**
     * 
     * @param m1UNACKNEMERGALERTTYPE
     *     The M1_UNACKN_EMERG_ALERT_TYPE
     */
    @JsonProperty("M1_UNACKN_EMERG_ALERT_TYPE")
    public void setM1UNACKNEMERGALERTTYPE(String m1UNACKNEMERGALERTTYPE) {
        this.m1UNACKNEMERGALERTTYPE = m1UNACKNEMERGALERTTYPE;
    }

    /**
     * 
     * @return
     *     The m1MCPMEPOSTPONED
     */
    @JsonProperty("M1-MCPMEPOSTPONED")
    public String getM1MCPMEPOSTPONED() {
        return m1MCPMEPOSTPONED;
    }

    /**
     * 
     * @param m1MCPMEPOSTPONED
     *     The M1-MCPMEPOSTPONED
     */
    @JsonProperty("M1-MCPMEPOSTPONED")
    public void setM1MCPMEPOSTPONED(String m1MCPMEPOSTPONED) {
        this.m1MCPMEPOSTPONED = m1MCPMEPOSTPONED;
    }

    /**
     * 
     * @return
     *     The m1ITEMADDITIONALDETAILS
     */
    @JsonProperty("M1_ITEM_ADDITIONAL_DETAILS")
    public String getM1ITEMADDITIONALDETAILS() {
        return m1ITEMADDITIONALDETAILS;
    }

    /**
     * 
     * @param m1ITEMADDITIONALDETAILS
     *     The M1_ITEM_ADDITIONAL_DETAILS
     */
    @JsonProperty("M1_ITEM_ADDITIONAL_DETAILS")
    public void setM1ITEMADDITIONALDETAILS(String m1ITEMADDITIONALDETAILS) {
        this.m1ITEMADDITIONALDETAILS = m1ITEMADDITIONALDETAILS;
    }

    /**
     * 
     * @return
     *     The aCCEPTLBL
     */
    @JsonProperty("ACCEPT_LBL")
    public String getACCEPTLBL() {
        return aCCEPTLBL;
    }

    /**
     * 
     * @param aCCEPTLBL
     *     The ACCEPT_LBL
     */
    @JsonProperty("ACCEPT_LBL")
    public void setACCEPTLBL(String aCCEPTLBL) {
        this.aCCEPTLBL = aCCEPTLBL;
    }

    /**
     * 
     * @return
     *     The wORKTIMESHEETTYPE
     */
    @JsonProperty("WORK_TIMESHEET_TYPE")
    public String getWORKTIMESHEETTYPE() {
        return wORKTIMESHEETTYPE;
    }

    /**
     * 
     * @param wORKTIMESHEETTYPE
     *     The WORK_TIMESHEET_TYPE
     */
    @JsonProperty("WORK_TIMESHEET_TYPE")
    public void setWORKTIMESHEETTYPE(String wORKTIMESHEETTYPE) {
        this.wORKTIMESHEETTYPE = wORKTIMESHEETTYPE;
    }

    /**
     * 
     * @return
     *     The m1RECEIVEDLBL
     */
    @JsonProperty("M1_RECEIVED_LBL")
    public String getM1RECEIVEDLBL() {
        return m1RECEIVEDLBL;
    }

    /**
     * 
     * @param m1RECEIVEDLBL
     *     The M1_RECEIVED_LBL
     */
    @JsonProperty("M1_RECEIVED_LBL")
    public void setM1RECEIVEDLBL(String m1RECEIVEDLBL) {
        this.m1RECEIVEDLBL = m1RECEIVEDLBL;
    }

    /**
     * 
     * @return
     *     The m1RETURNALLITEMSLBL
     */
    @JsonProperty("M1_RETURN_ALL_ITEMS_LBL")
    public String getM1RETURNALLITEMSLBL() {
        return m1RETURNALLITEMSLBL;
    }

    /**
     * 
     * @param m1RETURNALLITEMSLBL
     *     The M1_RETURN_ALL_ITEMS_LBL
     */
    @JsonProperty("M1_RETURN_ALL_ITEMS_LBL")
    public void setM1RETURNALLITEMSLBL(String m1RETURNALLITEMSLBL) {
        this.m1RETURNALLITEMSLBL = m1RETURNALLITEMSLBL;
    }

    /**
     * 
     * @return
     *     The m1CUMULATIVECAPACITYFLG
     */
    @JsonProperty("M1_CUMULATIVE_CAPACITY_FLG")
    public String getM1CUMULATIVECAPACITYFLG() {
        return m1CUMULATIVECAPACITYFLG;
    }

    /**
     * 
     * @param m1CUMULATIVECAPACITYFLG
     *     The M1_CUMULATIVE_CAPACITY_FLG
     */
    @JsonProperty("M1_CUMULATIVE_CAPACITY_FLG")
    public void setM1CUMULATIVECAPACITYFLG(String m1CUMULATIVECAPACITYFLG) {
        this.m1CUMULATIVECAPACITYFLG = m1CUMULATIVECAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1MAINPHONE
     */
    @JsonProperty("M1_MAIN_PHONE")
    public String getM1MAINPHONE() {
        return m1MAINPHONE;
    }

    /**
     * 
     * @param m1MAINPHONE
     *     The M1_MAIN_PHONE
     */
    @JsonProperty("M1_MAIN_PHONE")
    public void setM1MAINPHONE(String m1MAINPHONE) {
        this.m1MAINPHONE = m1MAINPHONE;
    }

    /**
     * 
     * @return
     *     The m1MAILINGLISTCD
     */
    @JsonProperty("M1_MAILING_LIST_CD")
    public String getM1MAILINGLISTCD() {
        return m1MAILINGLISTCD;
    }

    /**
     * 
     * @param m1MAILINGLISTCD
     *     The M1_MAILING_LIST_CD
     */
    @JsonProperty("M1_MAILING_LIST_CD")
    public void setM1MAILINGLISTCD(String m1MAILINGLISTCD) {
        this.m1MAILINGLISTCD = m1MAILINGLISTCD;
    }

    /**
     * 
     * @return
     *     The m1EARNINGTYPEEXTID
     */
    @JsonProperty("M1_EARNING_TYPE_EXT_ID")
    public String getM1EARNINGTYPEEXTID() {
        return m1EARNINGTYPEEXTID;
    }

    /**
     * 
     * @param m1EARNINGTYPEEXTID
     *     The M1_EARNING_TYPE_EXT_ID
     */
    @JsonProperty("M1_EARNING_TYPE_EXT_ID")
    public void setM1EARNINGTYPEEXTID(String m1EARNINGTYPEEXTID) {
        this.m1EARNINGTYPEEXTID = m1EARNINGTYPEEXTID;
    }

    /**
     * 
     * @return
     *     The m1FINALDTTM
     */
    @JsonProperty("M1_FINAL_DTTM")
    public String getM1FINALDTTM() {
        return m1FINALDTTM;
    }

    /**
     * 
     * @param m1FINALDTTM
     *     The M1_FINAL_DTTM
     */
    @JsonProperty("M1_FINAL_DTTM")
    public void setM1FINALDTTM(String m1FINALDTTM) {
        this.m1FINALDTTM = m1FINALDTTM;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKID
     */
    @JsonProperty("M1_DEPOT_TASK_ID")
    public String getM1DEPOTTASKID() {
        return m1DEPOTTASKID;
    }

    /**
     * 
     * @param m1DEPOTTASKID
     *     The M1_DEPOT_TASK_ID
     */
    @JsonProperty("M1_DEPOT_TASK_ID")
    public void setM1DEPOTTASKID(String m1DEPOTTASKID) {
        this.m1DEPOTTASKID = m1DEPOTTASKID;
    }

    /**
     * 
     * @return
     *     The m1POSTPONEDATE
     */
    @JsonProperty("M1_POSTPONE_DATE")
    public String getM1POSTPONEDATE() {
        return m1POSTPONEDATE;
    }

    /**
     * 
     * @param m1POSTPONEDATE
     *     The M1_POSTPONE_DATE
     */
    @JsonProperty("M1_POSTPONE_DATE")
    public void setM1POSTPONEDATE(String m1POSTPONEDATE) {
        this.m1POSTPONEDATE = m1POSTPONEDATE;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYATTRIBUSAGEFLG
     */
    @JsonProperty("M1_ACTIVITY_ATTRIB_USAGE_FLG")
    public String getM1ACTIVITYATTRIBUSAGEFLG() {
        return m1ACTIVITYATTRIBUSAGEFLG;
    }

    /**
     * 
     * @param m1ACTIVITYATTRIBUSAGEFLG
     *     The M1_ACTIVITY_ATTRIB_USAGE_FLG
     */
    @JsonProperty("M1_ACTIVITY_ATTRIB_USAGE_FLG")
    public void setM1ACTIVITYATTRIBUSAGEFLG(String m1ACTIVITYATTRIBUSAGEFLG) {
        this.m1ACTIVITYATTRIBUSAGEFLG = m1ACTIVITYATTRIBUSAGEFLG;
    }

    /**
     * 
     * @return
     *     The sENDBTNLBL
     */
    @JsonProperty("SEND_BTN_LBL")
    public String getSENDBTNLBL() {
        return sENDBTNLBL;
    }

    /**
     * 
     * @param sENDBTNLBL
     *     The SEND_BTN_LBL
     */
    @JsonProperty("SEND_BTN_LBL")
    public void setSENDBTNLBL(String sENDBTNLBL) {
        this.sENDBTNLBL = sENDBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1GEOCODELONGITUDE
     */
    @JsonProperty("M1_GEOCODE_LONGITUDE")
    public String getM1GEOCODELONGITUDE() {
        return m1GEOCODELONGITUDE;
    }

    /**
     * 
     * @param m1GEOCODELONGITUDE
     *     The M1_GEOCODE_LONGITUDE
     */
    @JsonProperty("M1_GEOCODE_LONGITUDE")
    public void setM1GEOCODELONGITUDE(String m1GEOCODELONGITUDE) {
        this.m1GEOCODELONGITUDE = m1GEOCODELONGITUDE;
    }

    /**
     * 
     * @return
     *     The rESRCIDTYPEFLG
     */
    @JsonProperty("RESRC_ID_TYPE_FLG")
    public String getRESRCIDTYPEFLG() {
        return rESRCIDTYPEFLG;
    }

    /**
     * 
     * @param rESRCIDTYPEFLG
     *     The RESRC_ID_TYPE_FLG
     */
    @JsonProperty("RESRC_ID_TYPE_FLG")
    public void setRESRCIDTYPEFLG(String rESRCIDTYPEFLG) {
        this.rESRCIDTYPEFLG = rESRCIDTYPEFLG;
    }

    /**
     * 
     * @return
     *     The sEQNO
     */
    @JsonProperty("SEQNO")
    public String getSEQNO() {
        return sEQNO;
    }

    /**
     * 
     * @param sEQNO
     *     The SEQNO
     */
    @JsonProperty("SEQNO")
    public void setSEQNO(String sEQNO) {
        this.sEQNO = sEQNO;
    }

    /**
     * 
     * @return
     *     The m1CREATIONDTTM
     */
    @JsonProperty("M1_CREATION_DTTM")
    public String getM1CREATIONDTTM() {
        return m1CREATIONDTTM;
    }

    /**
     * 
     * @param m1CREATIONDTTM
     *     The M1_CREATION_DTTM
     */
    @JsonProperty("M1_CREATION_DTTM")
    public void setM1CREATIONDTTM(String m1CREATIONDTTM) {
        this.m1CREATIONDTTM = m1CREATIONDTTM;
    }

    /**
     * 
     * @return
     *     The m1STARTBTNLBL
     */
    @JsonProperty("M1_START_BTN_LBL")
    public String getM1STARTBTNLBL() {
        return m1STARTBTNLBL;
    }

    /**
     * 
     * @param m1STARTBTNLBL
     *     The M1_START_BTN_LBL
     */
    @JsonProperty("M1_START_BTN_LBL")
    public void setM1STARTBTNLBL(String m1STARTBTNLBL) {
        this.m1STARTBTNLBL = m1STARTBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1NONPRODTASKID
     */
    @JsonProperty("M1_NON_PROD_TASK_ID")
    public String getM1NONPRODTASKID() {
        return m1NONPRODTASKID;
    }

    /**
     * 
     * @param m1NONPRODTASKID
     *     The M1_NON_PROD_TASK_ID
     */
    @JsonProperty("M1_NON_PROD_TASK_ID")
    public void setM1NONPRODTASKID(String m1NONPRODTASKID) {
        this.m1NONPRODTASKID = m1NONPRODTASKID;
    }

    /**
     * 
     * @return
     *     The m1THEMECLBL
     */
    @JsonProperty("M1_THEME_C_LBL")
    public String getM1THEMECLBL() {
        return m1THEMECLBL;
    }

    /**
     * 
     * @param m1THEMECLBL
     *     The M1_THEME_C_LBL
     */
    @JsonProperty("M1_THEME_C_LBL")
    public void setM1THEMECLBL(String m1THEMECLBL) {
        this.m1THEMECLBL = m1THEMECLBL;
    }

    /**
     * 
     * @return
     *     The m1ONSITEDATE
     */
    @JsonProperty("M1_ON_SITE_DATE")
    public String getM1ONSITEDATE() {
        return m1ONSITEDATE;
    }

    /**
     * 
     * @param m1ONSITEDATE
     *     The M1_ON_SITE_DATE
     */
    @JsonProperty("M1_ON_SITE_DATE")
    public void setM1ONSITEDATE(String m1ONSITEDATE) {
        this.m1ONSITEDATE = m1ONSITEDATE;
    }

    /**
     * 
     * @return
     *     The m1ALERTSLBL
     */
    @JsonProperty("M1_ALERTS_LBL")
    public String getM1ALERTSLBL() {
        return m1ALERTSLBL;
    }

    /**
     * 
     * @param m1ALERTSLBL
     *     The M1_ALERTS_LBL
     */
    @JsonProperty("M1_ALERTS_LBL")
    public void setM1ALERTSLBL(String m1ALERTSLBL) {
        this.m1ALERTSLBL = m1ALERTSLBL;
    }

    /**
     * 
     * @return
     *     The m1REQUIREDFIELDSLBL
     */
    @JsonProperty("M1_REQUIRED_FIELDS_LBL")
    public String getM1REQUIREDFIELDSLBL() {
        return m1REQUIREDFIELDSLBL;
    }

    /**
     * 
     * @param m1REQUIREDFIELDSLBL
     *     The M1_REQUIRED_FIELDS_LBL
     */
    @JsonProperty("M1_REQUIRED_FIELDS_LBL")
    public void setM1REQUIREDFIELDSLBL(String m1REQUIREDFIELDSLBL) {
        this.m1REQUIREDFIELDSLBL = m1REQUIREDFIELDSLBL;
    }

    /**
     * 
     * @return
     *     The m1MINVISITDURATION
     */
    @JsonProperty("M1_MIN_VISIT_DURATION")
    public String getM1MINVISITDURATION() {
        return m1MINVISITDURATION;
    }

    /**
     * 
     * @param m1MINVISITDURATION
     *     The M1_MIN_VISIT_DURATION
     */
    @JsonProperty("M1_MIN_VISIT_DURATION")
    public void setM1MINVISITDURATION(String m1MINVISITDURATION) {
        this.m1MINVISITDURATION = m1MINVISITDURATION;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYTYPETODO
     */
    @JsonProperty("M1_ACTIVITY_TYPE_TODO")
    public String getM1ACTIVITYTYPETODO() {
        return m1ACTIVITYTYPETODO;
    }

    /**
     * 
     * @param m1ACTIVITYTYPETODO
     *     The M1_ACTIVITY_TYPE_TODO
     */
    @JsonProperty("M1_ACTIVITY_TYPE_TODO")
    public void setM1ACTIVITYTYPETODO(String m1ACTIVITYTYPETODO) {
        this.m1ACTIVITYTYPETODO = m1ACTIVITYTYPETODO;
    }

    /**
     * 
     * @return
     *     The m1NAME
     */
    @JsonProperty("M1_NAME")
    public String getM1NAME() {
        return m1NAME;
    }

    /**
     * 
     * @param m1NAME
     *     The M1_NAME
     */
    @JsonProperty("M1_NAME")
    public void setM1NAME(String m1NAME) {
        this.m1NAME = m1NAME;
    }

    /**
     * 
     * @return
     *     The m1ACCOUNTID
     */
    @JsonProperty("M1_ACCOUNT_ID")
    public String getM1ACCOUNTID() {
        return m1ACCOUNTID;
    }

    /**
     * 
     * @param m1ACCOUNTID
     *     The M1_ACCOUNT_ID
     */
    @JsonProperty("M1_ACCOUNT_ID")
    public void setM1ACCOUNTID(String m1ACCOUNTID) {
        this.m1ACCOUNTID = m1ACCOUNTID;
    }

    /**
     * 
     * @return
     *     The aTTACHMENTFILENAME
     */
    @JsonProperty("ATTACHMENT_FILE_NAME")
    public String getATTACHMENTFILENAME() {
        return aTTACHMENTFILENAME;
    }

    /**
     * 
     * @param aTTACHMENTFILENAME
     *     The ATTACHMENT_FILE_NAME
     */
    @JsonProperty("ATTACHMENT_FILE_NAME")
    public void setATTACHMENTFILENAME(String aTTACHMENTFILENAME) {
        this.aTTACHMENTFILENAME = aTTACHMENTFILENAME;
    }

    /**
     * 
     * @return
     *     The m1EXTENTITYVALUE
     */
    @JsonProperty("M1_EXT_ENTITY_VALUE")
    public String getM1EXTENTITYVALUE() {
        return m1EXTENTITYVALUE;
    }

    /**
     * 
     * @param m1EXTENTITYVALUE
     *     The M1_EXT_ENTITY_VALUE
     */
    @JsonProperty("M1_EXT_ENTITY_VALUE")
    public void setM1EXTENTITYVALUE(String m1EXTENTITYVALUE) {
        this.m1EXTENTITYVALUE = m1EXTENTITYVALUE;
    }

    /**
     * 
     * @return
     *     The sVCAREAUSGFLG
     */
    @JsonProperty("SVC_AREA_USG_FLG")
    public String getSVCAREAUSGFLG() {
        return sVCAREAUSGFLG;
    }

    /**
     * 
     * @param sVCAREAUSGFLG
     *     The SVC_AREA_USG_FLG
     */
    @JsonProperty("SVC_AREA_USG_FLG")
    public void setSVCAREAUSGFLG(String sVCAREAUSGFLG) {
        this.sVCAREAUSGFLG = sVCAREAUSGFLG;
    }

    /**
     * 
     * @return
     *     The pOUTIMESHEETTYPE
     */
    @JsonProperty("POU_TIMESHEET_TYPE")
    public String getPOUTIMESHEETTYPE() {
        return pOUTIMESHEETTYPE;
    }

    /**
     * 
     * @param pOUTIMESHEETTYPE
     *     The POU_TIMESHEET_TYPE
     */
    @JsonProperty("POU_TIMESHEET_TYPE")
    public void setPOUTIMESHEETTYPE(String pOUTIMESHEETTYPE) {
        this.pOUTIMESHEETTYPE = pOUTIMESHEETTYPE;
    }

    /**
     * 
     * @return
     *     The pRIPROFCD
     */
    @JsonProperty("PRI_PROF_CD")
    public String getPRIPROFCD() {
        return pRIPROFCD;
    }

    /**
     * 
     * @param pRIPROFCD
     *     The PRI_PROF_CD
     */
    @JsonProperty("PRI_PROF_CD")
    public void setPRIPROFCD(String pRIPROFCD) {
        this.pRIPROFCD = pRIPROFCD;
    }

    /**
     * 
     * @return
     *     The m1REVWONDEVFLG
     */
    @JsonProperty("M1_REVW_ON_DEV_FLG")
    public String getM1REVWONDEVFLG() {
        return m1REVWONDEVFLG;
    }

    /**
     * 
     * @param m1REVWONDEVFLG
     *     The M1_REVW_ON_DEV_FLG
     */
    @JsonProperty("M1_REVW_ON_DEV_FLG")
    public void setM1REVWONDEVFLG(String m1REVWONDEVFLG) {
        this.m1REVWONDEVFLG = m1REVWONDEVFLG;
    }

    /**
     * 
     * @return
     *     The pROCEDURESTATUSFLG
     */
    @JsonProperty("PROCEDURE_STATUS_FLG")
    public String getPROCEDURESTATUSFLG() {
        return pROCEDURESTATUSFLG;
    }

    /**
     * 
     * @param pROCEDURESTATUSFLG
     *     The PROCEDURE_STATUS_FLG
     */
    @JsonProperty("PROCEDURE_STATUS_FLG")
    public void setPROCEDURESTATUSFLG(String pROCEDURESTATUSFLG) {
        this.pROCEDURESTATUSFLG = pROCEDURESTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1AUTOALLOCATIONDAYS
     */
    @JsonProperty("M1_AUTO_ALLOCATION_DAYS")
    public String getM1AUTOALLOCATIONDAYS() {
        return m1AUTOALLOCATIONDAYS;
    }

    /**
     * 
     * @param m1AUTOALLOCATIONDAYS
     *     The M1_AUTO_ALLOCATION_DAYS
     */
    @JsonProperty("M1_AUTO_ALLOCATION_DAYS")
    public void setM1AUTOALLOCATIONDAYS(String m1AUTOALLOCATIONDAYS) {
        this.m1AUTOALLOCATIONDAYS = m1AUTOALLOCATIONDAYS;
    }

    /**
     * 
     * @return
     *     The sVCCLSUSGFLG
     */
    @JsonProperty("SVC_CLS_USG_FLG")
    public String getSVCCLSUSGFLG() {
        return sVCCLSUSGFLG;
    }

    /**
     * 
     * @param sVCCLSUSGFLG
     *     The SVC_CLS_USG_FLG
     */
    @JsonProperty("SVC_CLS_USG_FLG")
    public void setSVCCLSUSGFLG(String sVCCLSUSGFLG) {
        this.sVCCLSUSGFLG = sVCCLSUSGFLG;
    }

    /**
     * 
     * @return
     *     The m1TRAVELDISTANCE
     */
    @JsonProperty("M1_TRAVEL_DISTANCE")
    public String getM1TRAVELDISTANCE() {
        return m1TRAVELDISTANCE;
    }

    /**
     * 
     * @param m1TRAVELDISTANCE
     *     The M1_TRAVEL_DISTANCE
     */
    @JsonProperty("M1_TRAVEL_DISTANCE")
    public void setM1TRAVELDISTANCE(String m1TRAVELDISTANCE) {
        this.m1TRAVELDISTANCE = m1TRAVELDISTANCE;
    }

    /**
     * 
     * @return
     *     The m1CACREMAININGDURATION
     */
    @JsonProperty("M1_CAC_REMAINING_DURATION")
    public String getM1CACREMAININGDURATION() {
        return m1CACREMAININGDURATION;
    }

    /**
     * 
     * @param m1CACREMAININGDURATION
     *     The M1_CAC_REMAINING_DURATION
     */
    @JsonProperty("M1_CAC_REMAINING_DURATION")
    public void setM1CACREMAININGDURATION(String m1CACREMAININGDURATION) {
        this.m1CACREMAININGDURATION = m1CACREMAININGDURATION;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEBTNLBL
     */
    @JsonProperty("M1_COMPLETE_BTN_LBL")
    public String getM1COMPLETEBTNLBL() {
        return m1COMPLETEBTNLBL;
    }

    /**
     * 
     * @param m1COMPLETEBTNLBL
     *     The M1_COMPLETE_BTN_LBL
     */
    @JsonProperty("M1_COMPLETE_BTN_LBL")
    public void setM1COMPLETEBTNLBL(String m1COMPLETEBTNLBL) {
        this.m1COMPLETEBTNLBL = m1COMPLETEBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1GROUPLBL
     */
    @JsonProperty("M1_GROUP_LBL")
    public String getM1GROUPLBL() {
        return m1GROUPLBL;
    }

    /**
     * 
     * @param m1GROUPLBL
     *     The M1_GROUP_LBL
     */
    @JsonProperty("M1_GROUP_LBL")
    public void setM1GROUPLBL(String m1GROUPLBL) {
        this.m1GROUPLBL = m1GROUPLBL;
    }

    /**
     * 
     * @return
     *     The sTEPREQUIREDFLG
     */
    @JsonProperty("STEP_REQUIRED_FLG")
    public String getSTEPREQUIREDFLG() {
        return sTEPREQUIREDFLG;
    }

    /**
     * 
     * @param sTEPREQUIREDFLG
     *     The STEP_REQUIRED_FLG
     */
    @JsonProperty("STEP_REQUIRED_FLG")
    public void setSTEPREQUIREDFLG(String sTEPREQUIREDFLG) {
        this.sTEPREQUIREDFLG = sTEPREQUIREDFLG;
    }

    /**
     * 
     * @return
     *     The m1CUSTOMERCONTACTTYPECD
     */
    @JsonProperty("M1_CUSTOMER_CONTACT_TYPE_CD")
    public String getM1CUSTOMERCONTACTTYPECD() {
        return m1CUSTOMERCONTACTTYPECD;
    }

    /**
     * 
     * @param m1CUSTOMERCONTACTTYPECD
     *     The M1_CUSTOMER_CONTACT_TYPE_CD
     */
    @JsonProperty("M1_CUSTOMER_CONTACT_TYPE_CD")
    public void setM1CUSTOMERCONTACTTYPECD(String m1CUSTOMERCONTACTTYPECD) {
        this.m1CUSTOMERCONTACTTYPECD = m1CUSTOMERCONTACTTYPECD;
    }

    /**
     * 
     * @return
     *     The mDTCAPABILITYATTACHMENTBO
     */
    @JsonProperty("MDT_CAPABILITY_ATTACHMENT_BO")
    public String getMDTCAPABILITYATTACHMENTBO() {
        return mDTCAPABILITYATTACHMENTBO;
    }

    /**
     * 
     * @param mDTCAPABILITYATTACHMENTBO
     *     The MDT_CAPABILITY_ATTACHMENT_BO
     */
    @JsonProperty("MDT_CAPABILITY_ATTACHMENT_BO")
    public void setMDTCAPABILITYATTACHMENTBO(String mDTCAPABILITYATTACHMENTBO) {
        this.mDTCAPABILITYATTACHMENTBO = mDTCAPABILITYATTACHMENTBO;
    }

    /**
     * 
     * @return
     *     The m1PERCENTAGEDEVIATION
     */
    @JsonProperty("M1_PERCENTAGE_DEVIATION")
    public String getM1PERCENTAGEDEVIATION() {
        return m1PERCENTAGEDEVIATION;
    }

    /**
     * 
     * @param m1PERCENTAGEDEVIATION
     *     The M1_PERCENTAGE_DEVIATION
     */
    @JsonProperty("M1_PERCENTAGE_DEVIATION")
    public void setM1PERCENTAGEDEVIATION(String m1PERCENTAGEDEVIATION) {
        this.m1PERCENTAGEDEVIATION = m1PERCENTAGEDEVIATION;
    }

    /**
     * 
     * @return
     *     The m1ORTASKCAPABILITYFLG
     */
    @JsonProperty("M1_OR_TASK_CAPABILITY_FLG")
    public String getM1ORTASKCAPABILITYFLG() {
        return m1ORTASKCAPABILITYFLG;
    }

    /**
     * 
     * @param m1ORTASKCAPABILITYFLG
     *     The M1_OR_TASK_CAPABILITY_FLG
     */
    @JsonProperty("M1_OR_TASK_CAPABILITY_FLG")
    public void setM1ORTASKCAPABILITYFLG(String m1ORTASKCAPABILITYFLG) {
        this.m1ORTASKCAPABILITYFLG = m1ORTASKCAPABILITYFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMATTRNAME
     */
    @JsonProperty("M1_ITEM_ATTR_NAME")
    public String getM1ITEMATTRNAME() {
        return m1ITEMATTRNAME;
    }

    /**
     * 
     * @param m1ITEMATTRNAME
     *     The M1_ITEM_ATTR_NAME
     */
    @JsonProperty("M1_ITEM_ATTR_NAME")
    public void setM1ITEMATTRNAME(String m1ITEMATTRNAME) {
        this.m1ITEMATTRNAME = m1ITEMATTRNAME;
    }

    /**
     * 
     * @return
     *     The m1MLRDSTATUSFLG
     */
    @JsonProperty("M1_MLRD_STATUS_FLG")
    public String getM1MLRDSTATUSFLG() {
        return m1MLRDSTATUSFLG;
    }

    /**
     * 
     * @param m1MLRDSTATUSFLG
     *     The M1_MLRD_STATUS_FLG
     */
    @JsonProperty("M1_MLRD_STATUS_FLG")
    public void setM1MLRDSTATUSFLG(String m1MLRDSTATUSFLG) {
        this.m1MLRDSTATUSFLG = m1MLRDSTATUSFLG;
    }

    /**
     * 
     * @return
     *     The m1RELATEDACTIVITYTYPES
     */
    @JsonProperty("M1_RELATED_ACTIVITY_TYPES")
    public String getM1RELATEDACTIVITYTYPES() {
        return m1RELATEDACTIVITYTYPES;
    }

    /**
     * 
     * @param m1RELATEDACTIVITYTYPES
     *     The M1_RELATED_ACTIVITY_TYPES
     */
    @JsonProperty("M1_RELATED_ACTIVITY_TYPES")
    public void setM1RELATEDACTIVITYTYPES(String m1RELATEDACTIVITYTYPES) {
        this.m1RELATEDACTIVITYTYPES = m1RELATEDACTIVITYTYPES;
    }

    /**
     * 
     * @return
     *     The m1AVGVISITDURATION
     */
    @JsonProperty("M1_AVG_VISIT_DURATION")
    public String getM1AVGVISITDURATION() {
        return m1AVGVISITDURATION;
    }

    /**
     * 
     * @param m1AVGVISITDURATION
     *     The M1_AVG_VISIT_DURATION
     */
    @JsonProperty("M1_AVG_VISIT_DURATION")
    public void setM1AVGVISITDURATION(String m1AVGVISITDURATION) {
        this.m1AVGVISITDURATION = m1AVGVISITDURATION;
    }

    /**
     * 
     * @return
     *     The m1CONTRACTORID
     */
    @JsonProperty("M1_CONTRACTOR_ID")
    public String getM1CONTRACTORID() {
        return m1CONTRACTORID;
    }

    /**
     * 
     * @param m1CONTRACTORID
     *     The M1_CONTRACTOR_ID
     */
    @JsonProperty("M1_CONTRACTOR_ID")
    public void setM1CONTRACTORID(String m1CONTRACTORID) {
        this.m1CONTRACTORID = m1CONTRACTORID;
    }

    /**
     * 
     * @return
     *     The m1GOOUTSVCLBL
     */
    @JsonProperty("M1_GO_OUT_SVC_LBL")
    public String getM1GOOUTSVCLBL() {
        return m1GOOUTSVCLBL;
    }

    /**
     * 
     * @param m1GOOUTSVCLBL
     *     The M1_GO_OUT_SVC_LBL
     */
    @JsonProperty("M1_GO_OUT_SVC_LBL")
    public void setM1GOOUTSVCLBL(String m1GOOUTSVCLBL) {
        this.m1GOOUTSVCLBL = m1GOOUTSVCLBL;
    }

    /**
     * 
     * @return
     *     The m1DECLINEDLBL
     */
    @JsonProperty("M1_DECLINED_LBL")
    public String getM1DECLINEDLBL() {
        return m1DECLINEDLBL;
    }

    /**
     * 
     * @param m1DECLINEDLBL
     *     The M1_DECLINED_LBL
     */
    @JsonProperty("M1_DECLINED_LBL")
    public void setM1DECLINEDLBL(String m1DECLINEDLBL) {
        this.m1DECLINEDLBL = m1DECLINEDLBL;
    }

    /**
     * 
     * @return
     *     The nPTTIMESHEETTYPE
     */
    @JsonProperty("NPT_TIMESHEET_TYPE")
    public String getNPTTIMESHEETTYPE() {
        return nPTTIMESHEETTYPE;
    }

    /**
     * 
     * @param nPTTIMESHEETTYPE
     *     The NPT_TIMESHEET_TYPE
     */
    @JsonProperty("NPT_TIMESHEET_TYPE")
    public void setNPTTIMESHEETTYPE(String nPTTIMESHEETTYPE) {
        this.nPTTIMESHEETTYPE = nPTTIMESHEETTYPE;
    }

    /**
     * 
     * @return
     *     The m1ALLOWRELATEDACTIVITIES
     */
    @JsonProperty("M1_ALLOW_RELATED_ACTIVITIES")
    public String getM1ALLOWRELATEDACTIVITIES() {
        return m1ALLOWRELATEDACTIVITIES;
    }

    /**
     * 
     * @param m1ALLOWRELATEDACTIVITIES
     *     The M1_ALLOW_RELATED_ACTIVITIES
     */
    @JsonProperty("M1_ALLOW_RELATED_ACTIVITIES")
    public void setM1ALLOWRELATEDACTIVITIES(String m1ALLOWRELATEDACTIVITIES) {
        this.m1ALLOWRELATEDACTIVITIES = m1ALLOWRELATEDACTIVITIES;
    }

    /**
     * 
     * @return
     *     The m1WINDOWAPPENDERLBL
     */
    @JsonProperty("M1_WINDOW_APPENDER_LBL")
    public String getM1WINDOWAPPENDERLBL() {
        return m1WINDOWAPPENDERLBL;
    }

    /**
     * 
     * @param m1WINDOWAPPENDERLBL
     *     The M1_WINDOW_APPENDER_LBL
     */
    @JsonProperty("M1_WINDOW_APPENDER_LBL")
    public void setM1WINDOWAPPENDERLBL(String m1WINDOWAPPENDERLBL) {
        this.m1WINDOWAPPENDERLBL = m1WINDOWAPPENDERLBL;
    }

    /**
     * 
     * @return
     *     The dFLAPPTBOOKGRP
     */
    @JsonProperty("DFL_APPT_BOOK_GRP")
    public String getDFLAPPTBOOKGRP() {
        return dFLAPPTBOOKGRP;
    }

    /**
     * 
     * @param dFLAPPTBOOKGRP
     *     The DFL_APPT_BOOK_GRP
     */
    @JsonProperty("DFL_APPT_BOOK_GRP")
    public void setDFLAPPTBOOKGRP(String dFLAPPTBOOKGRP) {
        this.dFLAPPTBOOKGRP = dFLAPPTBOOKGRP;
    }

    /**
     * 
     * @return
     *     The m1ISSUEDETECTEDTODOROLE
     */
    @JsonProperty("M1_ISSUE_DETECTED_TODO_ROLE")
    public String getM1ISSUEDETECTEDTODOROLE() {
        return m1ISSUEDETECTEDTODOROLE;
    }

    /**
     * 
     * @param m1ISSUEDETECTEDTODOROLE
     *     The M1_ISSUE_DETECTED_TODO_ROLE
     */
    @JsonProperty("M1_ISSUE_DETECTED_TODO_ROLE")
    public void setM1ISSUEDETECTEDTODOROLE(String m1ISSUEDETECTEDTODOROLE) {
        this.m1ISSUEDETECTEDTODOROLE = m1ISSUEDETECTEDTODOROLE;
    }

    /**
     * 
     * @return
     *     The m1ENDTM
     */
    @JsonProperty("M1_END_TM")
    public String getM1ENDTM() {
        return m1ENDTM;
    }

    /**
     * 
     * @param m1ENDTM
     *     The M1_END_TM
     */
    @JsonProperty("M1_END_TM")
    public void setM1ENDTM(String m1ENDTM) {
        this.m1ENDTM = m1ENDTM;
    }

    /**
     * 
     * @return
     *     The m1REVIEWRQDLBL
     */
    @JsonProperty("M1_REVIEW_RQD_LBL")
    public String getM1REVIEWRQDLBL() {
        return m1REVIEWRQDLBL;
    }

    /**
     * 
     * @param m1REVIEWRQDLBL
     *     The M1_REVIEW_RQD_LBL
     */
    @JsonProperty("M1_REVIEW_RQD_LBL")
    public void setM1REVIEWRQDLBL(String m1REVIEWRQDLBL) {
        this.m1REVIEWRQDLBL = m1REVIEWRQDLBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMINFORMATIONLBL
     */
    @JsonProperty("M1_ITEM_INFORMATION_LBL")
    public String getM1ITEMINFORMATIONLBL() {
        return m1ITEMINFORMATIONLBL;
    }

    /**
     * 
     * @param m1ITEMINFORMATIONLBL
     *     The M1_ITEM_INFORMATION_LBL
     */
    @JsonProperty("M1_ITEM_INFORMATION_LBL")
    public void setM1ITEMINFORMATIONLBL(String m1ITEMINFORMATIONLBL) {
        this.m1ITEMINFORMATIONLBL = m1ITEMINFORMATIONLBL;
    }

    /**
     * 
     * @return
     *     The cAPDTTM
     */
    @JsonProperty("CAP_DTTM")
    public String getCAPDTTM() {
        return cAPDTTM;
    }

    /**
     * 
     * @param cAPDTTM
     *     The CAP_DTTM
     */
    @JsonProperty("CAP_DTTM")
    public void setCAPDTTM(String cAPDTTM) {
        this.cAPDTTM = cAPDTTM;
    }

    /**
     * 
     * @return
     *     The m1TRANSPORTRESTRICTIONFLG
     */
    @JsonProperty("M1_TRANSPORT_RESTRICTION_FLG")
    public String getM1TRANSPORTRESTRICTIONFLG() {
        return m1TRANSPORTRESTRICTIONFLG;
    }

    /**
     * 
     * @param m1TRANSPORTRESTRICTIONFLG
     *     The M1_TRANSPORT_RESTRICTION_FLG
     */
    @JsonProperty("M1_TRANSPORT_RESTRICTION_FLG")
    public void setM1TRANSPORTRESTRICTIONFLG(String m1TRANSPORTRESTRICTIONFLG) {
        this.m1TRANSPORTRESTRICTIONFLG = m1TRANSPORTRESTRICTIONFLG;
    }

    /**
     * 
     * @return
     *     The mAINTOBJCD
     */
    @JsonProperty("MAINT_OBJ_CD")
    public String getMAINTOBJCD() {
        return mAINTOBJCD;
    }

    /**
     * 
     * @param mAINTOBJCD
     *     The MAINT_OBJ_CD
     */
    @JsonProperty("MAINT_OBJ_CD")
    public void setMAINTOBJCD(String mAINTOBJCD) {
        this.mAINTOBJCD = mAINTOBJCD;
    }

    /**
     * 
     * @return
     *     The m1TIMEDEVENTALERTTYPE
     */
    @JsonProperty("M1_TIMED_EVENT_ALERT_TYPE")
    public String getM1TIMEDEVENTALERTTYPE() {
        return m1TIMEDEVENTALERTTYPE;
    }

    /**
     * 
     * @param m1TIMEDEVENTALERTTYPE
     *     The M1_TIMED_EVENT_ALERT_TYPE
     */
    @JsonProperty("M1_TIMED_EVENT_ALERT_TYPE")
    public void setM1TIMEDEVENTALERTTYPE(String m1TIMEDEVENTALERTTYPE) {
        this.m1TIMEDEVENTALERTTYPE = m1TIMEDEVENTALERTTYPE;
    }

    /**
     * 
     * @return
     *     The pOSTALLBL
     */
    @JsonProperty("POSTAL_LBL")
    public String getPOSTALLBL() {
        return pOSTALLBL;
    }

    /**
     * 
     * @param pOSTALLBL
     *     The POSTAL_LBL
     */
    @JsonProperty("POSTAL_LBL")
    public void setPOSTALLBL(String pOSTALLBL) {
        this.pOSTALLBL = pOSTALLBL;
    }

    /**
     * 
     * @return
     *     The m1RESRVCAPACITYBYFLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_BY_FLG")
    public String getM1RESRVCAPACITYBYFLG() {
        return m1RESRVCAPACITYBYFLG;
    }

    /**
     * 
     * @param m1RESRVCAPACITYBYFLG
     *     The M1_RESRV_CAPACITY_BY_FLG
     */
    @JsonProperty("M1_RESRV_CAPACITY_BY_FLG")
    public void setM1RESRVCAPACITYBYFLG(String m1RESRVCAPACITYBYFLG) {
        this.m1RESRVCAPACITYBYFLG = m1RESRVCAPACITYBYFLG;
    }

    /**
     * 
     * @return
     *     The m1ITEMDELIDCLNRSNFLG
     */
    @JsonProperty("M1_ITEM_DELI_DCLN_RSN_FLG")
    public String getM1ITEMDELIDCLNRSNFLG() {
        return m1ITEMDELIDCLNRSNFLG;
    }

    /**
     * 
     * @param m1ITEMDELIDCLNRSNFLG
     *     The M1_ITEM_DELI_DCLN_RSN_FLG
     */
    @JsonProperty("M1_ITEM_DELI_DCLN_RSN_FLG")
    public void setM1ITEMDELIDCLNRSNFLG(String m1ITEMDELIDCLNRSNFLG) {
        this.m1ITEMDELIDCLNRSNFLG = m1ITEMDELIDCLNRSNFLG;
    }

    /**
     * 
     * @return
     *     The m1STARTDAYOFWEEK
     */
    @JsonProperty("M1_START_DAY_OF_WEEK")
    public String getM1STARTDAYOFWEEK() {
        return m1STARTDAYOFWEEK;
    }

    /**
     * 
     * @param m1STARTDAYOFWEEK
     *     The M1_START_DAY_OF_WEEK
     */
    @JsonProperty("M1_START_DAY_OF_WEEK")
    public void setM1STARTDAYOFWEEK(String m1STARTDAYOFWEEK) {
        this.m1STARTDAYOFWEEK = m1STARTDAYOFWEEK;
    }

    /**
     * 
     * @return
     *     The m1RTDSTUNITABBRFLG
     */
    @JsonProperty("M1_RT_DST_UNIT_ABBR_FLG")
    public String getM1RTDSTUNITABBRFLG() {
        return m1RTDSTUNITABBRFLG;
    }

    /**
     * 
     * @param m1RTDSTUNITABBRFLG
     *     The M1_RT_DST_UNIT_ABBR_FLG
     */
    @JsonProperty("M1_RT_DST_UNIT_ABBR_FLG")
    public void setM1RTDSTUNITABBRFLG(String m1RTDSTUNITABBRFLG) {
        this.m1RTDSTUNITABBRFLG = m1RTDSTUNITABBRFLG;
    }

    /**
     * 
     * @return
     *     The m1REALGPSTHRESHOLD
     */
    @JsonProperty("M1_REAL_GPS_THRESHOLD")
    public String getM1REALGPSTHRESHOLD() {
        return m1REALGPSTHRESHOLD;
    }

    /**
     * 
     * @param m1REALGPSTHRESHOLD
     *     The M1_REAL_GPS_THRESHOLD
     */
    @JsonProperty("M1_REAL_GPS_THRESHOLD")
    public void setM1REALGPSTHRESHOLD(String m1REALGPSTHRESHOLD) {
        this.m1REALGPSTHRESHOLD = m1REALGPSTHRESHOLD;
    }

    /**
     * 
     * @return
     *     The rESETLBL
     */
    @JsonProperty("RESET_LBL")
    public String getRESETLBL() {
        return rESETLBL;
    }

    /**
     * 
     * @param rESETLBL
     *     The RESET_LBL
     */
    @JsonProperty("RESET_LBL")
    public void setRESETLBL(String rESETLBL) {
        this.rESETLBL = rESETLBL;
    }

    /**
     * 
     * @return
     *     The aDDR3LBL
     */
    @JsonProperty("ADDR3_LBL")
    public String getADDR3LBL() {
        return aDDR3LBL;
    }

    /**
     * 
     * @param aDDR3LBL
     *     The ADDR3_LBL
     */
    @JsonProperty("ADDR3_LBL")
    public void setADDR3LBL(String aDDR3LBL) {
        this.aDDR3LBL = aDDR3LBL;
    }

    /**
     * 
     * @return
     *     The aCKNOWLEDGEMENTREQFLG
     */
    @JsonProperty("ACKNOWLEDGEMENT_REQ_FLG")
    public String getACKNOWLEDGEMENTREQFLG() {
        return aCKNOWLEDGEMENTREQFLG;
    }

    /**
     * 
     * @param aCKNOWLEDGEMENTREQFLG
     *     The ACKNOWLEDGEMENT_REQ_FLG
     */
    @JsonProperty("ACKNOWLEDGEMENT_REQ_FLG")
    public void setACKNOWLEDGEMENTREQFLG(String aCKNOWLEDGEMENTREQFLG) {
        this.aCKNOWLEDGEMENTREQFLG = aCKNOWLEDGEMENTREQFLG;
    }

    /**
     * 
     * @return
     *     The m1FILEDESC
     */
    @JsonProperty("M1_FILE_DESC")
    public String getM1FILEDESC() {
        return m1FILEDESC;
    }

    /**
     * 
     * @param m1FILEDESC
     *     The M1_FILE_DESC
     */
    @JsonProperty("M1_FILE_DESC")
    public void setM1FILEDESC(String m1FILEDESC) {
        this.m1FILEDESC = m1FILEDESC;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEACTLBL
     */
    @JsonProperty("M1_COMPLETE_ACT_LBL")
    public String getM1COMPLETEACTLBL() {
        return m1COMPLETEACTLBL;
    }

    /**
     * 
     * @param m1COMPLETEACTLBL
     *     The M1_COMPLETE_ACT_LBL
     */
    @JsonProperty("M1_COMPLETE_ACT_LBL")
    public void setM1COMPLETEACTLBL(String m1COMPLETEACTLBL) {
        this.m1COMPLETEACTLBL = m1COMPLETEACTLBL;
    }

    /**
     * 
     * @return
     *     The m1RESERVECAPTYPE
     */
    @JsonProperty("M1_RESERVE_CAP_TYPE")
    public String getM1RESERVECAPTYPE() {
        return m1RESERVECAPTYPE;
    }

    /**
     * 
     * @param m1RESERVECAPTYPE
     *     The M1_RESERVE_CAP_TYPE
     */
    @JsonProperty("M1_RESERVE_CAP_TYPE")
    public void setM1RESERVECAPTYPE(String m1RESERVECAPTYPE) {
        this.m1RESERVECAPTYPE = m1RESERVECAPTYPE;
    }

    /**
     * 
     * @return
     *     The bOSTATUSBOCD
     */
    @JsonProperty("BO_STATUS_BO_CD")
    public String getBOSTATUSBOCD() {
        return bOSTATUSBOCD;
    }

    /**
     * 
     * @param bOSTATUSBOCD
     *     The BO_STATUS_BO_CD
     */
    @JsonProperty("BO_STATUS_BO_CD")
    public void setBOSTATUSBOCD(String bOSTATUSBOCD) {
        this.bOSTATUSBOCD = bOSTATUSBOCD;
    }

    /**
     * 
     * @return
     *     The m1HOSTPARENTEXTID
     */
    @JsonProperty("M1_HOST_PARENT_EXT_ID")
    public String getM1HOSTPARENTEXTID() {
        return m1HOSTPARENTEXTID;
    }

    /**
     * 
     * @param m1HOSTPARENTEXTID
     *     The M1_HOST_PARENT_EXT_ID
     */
    @JsonProperty("M1_HOST_PARENT_EXT_ID")
    public void setM1HOSTPARENTEXTID(String m1HOSTPARENTEXTID) {
        this.m1HOSTPARENTEXTID = m1HOSTPARENTEXTID;
    }

    /**
     * 
     * @return
     *     The m1RVWTMSHLBL
     */
    @JsonProperty("M1_RVW_TM_SH_LBL")
    public String getM1RVWTMSHLBL() {
        return m1RVWTMSHLBL;
    }

    /**
     * 
     * @param m1RVWTMSHLBL
     *     The M1_RVW_TM_SH_LBL
     */
    @JsonProperty("M1_RVW_TM_SH_LBL")
    public void setM1RVWTMSHLBL(String m1RVWTMSHLBL) {
        this.m1RVWTMSHLBL = m1RVWTMSHLBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMCUSTACCEPTREQFLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPT_REQ_FLG")
    public String getM1ITEMCUSTACCEPTREQFLG() {
        return m1ITEMCUSTACCEPTREQFLG;
    }

    /**
     * 
     * @param m1ITEMCUSTACCEPTREQFLG
     *     The M1_ITEM_CUST_ACCEPT_REQ_FLG
     */
    @JsonProperty("M1_ITEM_CUST_ACCEPT_REQ_FLG")
    public void setM1ITEMCUSTACCEPTREQFLG(String m1ITEMCUSTACCEPTREQFLG) {
        this.m1ITEMCUSTACCEPTREQFLG = m1ITEMCUSTACCEPTREQFLG;
    }

    /**
     * 
     * @return
     *     The m1MDTLOGLOC
     */
    @JsonProperty("M1_MDT_LOG_LOC")
    public String getM1MDTLOGLOC() {
        return m1MDTLOGLOC;
    }

    /**
     * 
     * @param m1MDTLOGLOC
     *     The M1_MDT_LOG_LOC
     */
    @JsonProperty("M1_MDT_LOG_LOC")
    public void setM1MDTLOGLOC(String m1MDTLOGLOC) {
        this.m1MDTLOGLOC = m1MDTLOGLOC;
    }

    /**
     * 
     * @return
     *     The m1DEPENDENTON
     */
    @JsonProperty("M1_DEPENDENT_ON")
    public String getM1DEPENDENTON() {
        return m1DEPENDENTON;
    }

    /**
     * 
     * @param m1DEPENDENTON
     *     The M1_DEPENDENT_ON
     */
    @JsonProperty("M1_DEPENDENT_ON")
    public void setM1DEPENDENTON(String m1DEPENDENTON) {
        this.m1DEPENDENTON = m1DEPENDENTON;
    }

    /**
     * 
     * @return
     *     The cITY
     */
    @JsonProperty("CITY")
    public String getCITY() {
        return cITY;
    }

    /**
     * 
     * @param cITY
     *     The CITY
     */
    @JsonProperty("CITY")
    public void setCITY(String cITY) {
        this.cITY = cITY;
    }

    /**
     * 
     * @return
     *     The m1LOCATION
     */
    @JsonProperty("M1_LOCATION")
    public String getM1LOCATION() {
        return m1LOCATION;
    }

    /**
     * 
     * @param m1LOCATION
     *     The M1_LOCATION
     */
    @JsonProperty("M1_LOCATION")
    public void setM1LOCATION(String m1LOCATION) {
        this.m1LOCATION = m1LOCATION;
    }

    /**
     * 
     * @return
     *     The mESSAGECATNBR
     */
    @JsonProperty("MESSAGE_CAT_NBR")
    public String getMESSAGECATNBR() {
        return mESSAGECATNBR;
    }

    /**
     * 
     * @param mESSAGECATNBR
     *     The MESSAGE_CAT_NBR
     */
    @JsonProperty("MESSAGE_CAT_NBR")
    public void setMESSAGECATNBR(String mESSAGECATNBR) {
        this.mESSAGECATNBR = mESSAGECATNBR;
    }

    /**
     * 
     * @return
     *     The m1DECLINEACTLBL
     */
    @JsonProperty("M1_DECLINE_ACT_LBL")
    public String getM1DECLINEACTLBL() {
        return m1DECLINEACTLBL;
    }

    /**
     * 
     * @param m1DECLINEACTLBL
     *     The M1_DECLINE_ACT_LBL
     */
    @JsonProperty("M1_DECLINE_ACT_LBL")
    public void setM1DECLINEACTLBL(String m1DECLINEACTLBL) {
        this.m1DECLINEACTLBL = m1DECLINEACTLBL;
    }

    /**
     * 
     * @return
     *     The m1MCPMECUSTOMERINFOLBL
     */
    @JsonProperty("M1_MCPME_CUSTOMER_INFO_LBL")
    public String getM1MCPMECUSTOMERINFOLBL() {
        return m1MCPMECUSTOMERINFOLBL;
    }

    /**
     * 
     * @param m1MCPMECUSTOMERINFOLBL
     *     The M1_MCPME_CUSTOMER_INFO_LBL
     */
    @JsonProperty("M1_MCPME_CUSTOMER_INFO_LBL")
    public void setM1MCPMECUSTOMERINFOLBL(String m1MCPMECUSTOMERINFOLBL) {
        this.m1MCPMECUSTOMERINFOLBL = m1MCPMECUSTOMERINFOLBL;
    }

    /**
     * 
     * @return
     *     The sTATE
     */
    @JsonProperty("STATE")
    public String getSTATE() {
        return sTATE;
    }

    /**
     * 
     * @param sTATE
     *     The STATE
     */
    @JsonProperty("STATE")
    public void setSTATE(String sTATE) {
        this.sTATE = sTATE;
    }

    /**
     * 
     * @return
     *     The m1CREWID
     */
    @JsonProperty("M1_CREW_ID")
    public String getM1CREWID() {
        return m1CREWID;
    }

    /**
     * 
     * @param m1CREWID
     *     The M1_CREW_ID
     */
    @JsonProperty("M1_CREW_ID")
    public void setM1CREWID(String m1CREWID) {
        this.m1CREWID = m1CREWID;
    }

    /**
     * 
     * @return
     *     The m1ACTEOSLBL
     */
    @JsonProperty("M1_ACT_EOS_LBL")
    public String getM1ACTEOSLBL() {
        return m1ACTEOSLBL;
    }

    /**
     * 
     * @param m1ACTEOSLBL
     *     The M1_ACT_EOS_LBL
     */
    @JsonProperty("M1_ACT_EOS_LBL")
    public void setM1ACTEOSLBL(String m1ACTEOSLBL) {
        this.m1ACTEOSLBL = m1ACTEOSLBL;
    }

    /**
     * 
     * @return
     *     The m1ACTUALSTDTTM
     */
    @JsonProperty("M1_ACTUAL_ST_DTTM")
    public String getM1ACTUALSTDTTM() {
        return m1ACTUALSTDTTM;
    }

    /**
     * 
     * @param m1ACTUALSTDTTM
     *     The M1_ACTUAL_ST_DTTM
     */
    @JsonProperty("M1_ACTUAL_ST_DTTM")
    public void setM1ACTUALSTDTTM(String m1ACTUALSTDTTM) {
        this.m1ACTUALSTDTTM = m1ACTUALSTDTTM;
    }

    /**
     * 
     * @return
     *     The m1DISPATCHDTTM
     */
    @JsonProperty("M1_DISPATCH_DTTM")
    public String getM1DISPATCHDTTM() {
        return m1DISPATCHDTTM;
    }

    /**
     * 
     * @param m1DISPATCHDTTM
     *     The M1_DISPATCH_DTTM
     */
    @JsonProperty("M1_DISPATCH_DTTM")
    public void setM1DISPATCHDTTM(String m1DISPATCHDTTM) {
        this.m1DISPATCHDTTM = m1DISPATCHDTTM;
    }

    /**
     * 
     * @return
     *     The m1TAKENDATE
     */
    @JsonProperty("M1_TAKEN_DATE")
    public String getM1TAKENDATE() {
        return m1TAKENDATE;
    }

    /**
     * 
     * @param m1TAKENDATE
     *     The M1_TAKEN_DATE
     */
    @JsonProperty("M1_TAKEN_DATE")
    public void setM1TAKENDATE(String m1TAKENDATE) {
        this.m1TAKENDATE = m1TAKENDATE;
    }

    /**
     * 
     * @return
     *     The m1AUTOCANCEL
     */
    @JsonProperty("M1_AUTO_CANCEL")
    public String getM1AUTOCANCEL() {
        return m1AUTOCANCEL;
    }

    /**
     * 
     * @param m1AUTOCANCEL
     *     The M1_AUTO_CANCEL
     */
    @JsonProperty("M1_AUTO_CANCEL")
    public void setM1AUTOCANCEL(String m1AUTOCANCEL) {
        this.m1AUTOCANCEL = m1AUTOCANCEL;
    }

    /**
     * 
     * @return
     *     The m1ESTOUTOFSVCDUR
     */
    @JsonProperty("M1_EST_OUT_OF_SVC_DUR")
    public String getM1ESTOUTOFSVCDUR() {
        return m1ESTOUTOFSVCDUR;
    }

    /**
     * 
     * @param m1ESTOUTOFSVCDUR
     *     The M1_EST_OUT_OF_SVC_DUR
     */
    @JsonProperty("M1_EST_OUT_OF_SVC_DUR")
    public void setM1ESTOUTOFSVCDUR(String m1ESTOUTOFSVCDUR) {
        this.m1ESTOUTOFSVCDUR = m1ESTOUTOFSVCDUR;
    }

    /**
     * 
     * @return
     *     The m1MDTMAPHOVERTEXT
     */
    @JsonProperty("M1_MDT_MAP_HOVER_TEXT")
    public String getM1MDTMAPHOVERTEXT() {
        return m1MDTMAPHOVERTEXT;
    }

    /**
     * 
     * @param m1MDTMAPHOVERTEXT
     *     The M1_MDT_MAP_HOVER_TEXT
     */
    @JsonProperty("M1_MDT_MAP_HOVER_TEXT")
    public void setM1MDTMAPHOVERTEXT(String m1MDTMAPHOVERTEXT) {
        this.m1MDTMAPHOVERTEXT = m1MDTMAPHOVERTEXT;
    }

    /**
     * 
     * @return
     *     The mESSAGEPARMCNT
     */
    @JsonProperty("MESSAGE_PARM_CNT")
    public String getMESSAGEPARMCNT() {
        return mESSAGEPARMCNT;
    }

    /**
     * 
     * @param mESSAGEPARMCNT
     *     The MESSAGE_PARM_CNT
     */
    @JsonProperty("MESSAGE_PARM_CNT")
    public void setMESSAGEPARMCNT(String mESSAGEPARMCNT) {
        this.mESSAGEPARMCNT = mESSAGEPARMCNT;
    }

    /**
     * 
     * @return
     *     The m1BELONGSTOPKGLBL
     */
    @JsonProperty("M1_BELONGS_TO_PKG_LBL")
    public String getM1BELONGSTOPKGLBL() {
        return m1BELONGSTOPKGLBL;
    }

    /**
     * 
     * @param m1BELONGSTOPKGLBL
     *     The M1_BELONGS_TO_PKG_LBL
     */
    @JsonProperty("M1_BELONGS_TO_PKG_LBL")
    public void setM1BELONGSTOPKGLBL(String m1BELONGSTOPKGLBL) {
        this.m1BELONGSTOPKGLBL = m1BELONGSTOPKGLBL;
    }

    /**
     * 
     * @return
     *     The m1THEMEORACLELBL
     */
    @JsonProperty("M1_THEME_ORACLE_LBL")
    public String getM1THEMEORACLELBL() {
        return m1THEMEORACLELBL;
    }

    /**
     * 
     * @param m1THEMEORACLELBL
     *     The M1_THEME_ORACLE_LBL
     */
    @JsonProperty("M1_THEME_ORACLE_LBL")
    public void setM1THEMEORACLELBL(String m1THEMEORACLELBL) {
        this.m1THEMEORACLELBL = m1THEMEORACLELBL;
    }

    /**
     * 
     * @return
     *     The m1PENDINGCANCELSW
     */
    @JsonProperty("M1_PENDING_CANCEL_SW")
    public String getM1PENDINGCANCELSW() {
        return m1PENDINGCANCELSW;
    }

    /**
     * 
     * @param m1PENDINGCANCELSW
     *     The M1_PENDING_CANCEL_SW
     */
    @JsonProperty("M1_PENDING_CANCEL_SW")
    public void setM1PENDINGCANCELSW(String m1PENDINGCANCELSW) {
        this.m1PENDINGCANCELSW = m1PENDINGCANCELSW;
    }

    /**
     * 
     * @return
     *     The tASKBUSOBJCD
     */
    @JsonProperty("TASK_BUS_OBJ_CD")
    public String getTASKBUSOBJCD() {
        return tASKBUSOBJCD;
    }

    /**
     * 
     * @param tASKBUSOBJCD
     *     The TASK_BUS_OBJ_CD
     */
    @JsonProperty("TASK_BUS_OBJ_CD")
    public void setTASKBUSOBJCD(String tASKBUSOBJCD) {
        this.tASKBUSOBJCD = tASKBUSOBJCD;
    }

    /**
     * 
     * @return
     *     The m1SHIFTLBL
     */
    @JsonProperty("M1_SHIFT_LBL")
    public String getM1SHIFTLBL() {
        return m1SHIFTLBL;
    }

    /**
     * 
     * @param m1SHIFTLBL
     *     The M1_SHIFT_LBL
     */
    @JsonProperty("M1_SHIFT_LBL")
    public void setM1SHIFTLBL(String m1SHIFTLBL) {
        this.m1SHIFTLBL = m1SHIFTLBL;
    }

    /**
     * 
     * @return
     *     The m1AVGDUR
     */
    @JsonProperty("M1_AVG_DUR")
    public String getM1AVGDUR() {
        return m1AVGDUR;
    }

    /**
     * 
     * @param m1AVGDUR
     *     The M1_AVG_DUR
     */
    @JsonProperty("M1_AVG_DUR")
    public void setM1AVGDUR(String m1AVGDUR) {
        this.m1AVGDUR = m1AVGDUR;
    }

    /**
     * 
     * @return
     *     The m1OVERRIDEDURATION
     */
    @JsonProperty("M1_OVERRIDE_DURATION")
    public String getM1OVERRIDEDURATION() {
        return m1OVERRIDEDURATION;
    }

    /**
     * 
     * @param m1OVERRIDEDURATION
     *     The M1_OVERRIDE_DURATION
     */
    @JsonProperty("M1_OVERRIDE_DURATION")
    public void setM1OVERRIDEDURATION(String m1OVERRIDEDURATION) {
        this.m1OVERRIDEDURATION = m1OVERRIDEDURATION;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKASSIGNMENTLBL
     */
    @JsonProperty("M1_DEPOT_TASK_ASSIGNMENT_LBL")
    public String getM1DEPOTTASKASSIGNMENTLBL() {
        return m1DEPOTTASKASSIGNMENTLBL;
    }

    /**
     * 
     * @param m1DEPOTTASKASSIGNMENTLBL
     *     The M1_DEPOT_TASK_ASSIGNMENT_LBL
     */
    @JsonProperty("M1_DEPOT_TASK_ASSIGNMENT_LBL")
    public void setM1DEPOTTASKASSIGNMENTLBL(String m1DEPOTTASKASSIGNMENTLBL) {
        this.m1DEPOTTASKASSIGNMENTLBL = m1DEPOTTASKASSIGNMENTLBL;
    }

    /**
     * 
     * @return
     *     The m1EMBEDDEDVIEWER
     */
    @JsonProperty("M1_EMBEDDEDVIEWER")
    public String getM1EMBEDDEDVIEWER() {
        return m1EMBEDDEDVIEWER;
    }

    /**
     * 
     * @param m1EMBEDDEDVIEWER
     *     The M1_EMBEDDEDVIEWER
     */
    @JsonProperty("M1_EMBEDDEDVIEWER")
    public void setM1EMBEDDEDVIEWER(String m1EMBEDDEDVIEWER) {
        this.m1EMBEDDEDVIEWER = m1EMBEDDEDVIEWER;
    }

    /**
     * 
     * @return
     *     The m1SENTFROMUSER
     */
    @JsonProperty("M1_SENT_FROM_USER")
    public String getM1SENTFROMUSER() {
        return m1SENTFROMUSER;
    }

    /**
     * 
     * @param m1SENTFROMUSER
     *     The M1_SENT_FROM_USER
     */
    @JsonProperty("M1_SENT_FROM_USER")
    public void setM1SENTFROMUSER(String m1SENTFROMUSER) {
        this.m1SENTFROMUSER = m1SENTFROMUSER;
    }

    /**
     * 
     * @return
     *     The aLLOCATIONRULEFLG
     */
    @JsonProperty("ALLOCATION_RULE_FLG")
    public String getALLOCATIONRULEFLG() {
        return aLLOCATIONRULEFLG;
    }

    /**
     * 
     * @param aLLOCATIONRULEFLG
     *     The ALLOCATION_RULE_FLG
     */
    @JsonProperty("ALLOCATION_RULE_FLG")
    public void setALLOCATIONRULEFLG(String aLLOCATIONRULEFLG) {
        this.aLLOCATIONRULEFLG = aLLOCATIONRULEFLG;
    }

    /**
     * 
     * @return
     *     The m1CONSOLEAPPENDERLBL
     */
    @JsonProperty("M1_CONSOLE_APPENDER_LBL")
    public String getM1CONSOLEAPPENDERLBL() {
        return m1CONSOLEAPPENDERLBL;
    }

    /**
     * 
     * @param m1CONSOLEAPPENDERLBL
     *     The M1_CONSOLE_APPENDER_LBL
     */
    @JsonProperty("M1_CONSOLE_APPENDER_LBL")
    public void setM1CONSOLEAPPENDERLBL(String m1CONSOLEAPPENDERLBL) {
        this.m1CONSOLEAPPENDERLBL = m1CONSOLEAPPENDERLBL;
    }

    /**
     * 
     * @return
     *     The m1LOGAPPENDERLBL
     */
    @JsonProperty("M1_LOG_APPENDER_LBL")
    public String getM1LOGAPPENDERLBL() {
        return m1LOGAPPENDERLBL;
    }

    /**
     * 
     * @param m1LOGAPPENDERLBL
     *     The M1_LOG_APPENDER_LBL
     */
    @JsonProperty("M1_LOG_APPENDER_LBL")
    public void setM1LOGAPPENDERLBL(String m1LOGAPPENDERLBL) {
        this.m1LOGAPPENDERLBL = m1LOGAPPENDERLBL;
    }

    /**
     * 
     * @return
     *     The m1SENDNOWUPDATESW
     */
    @JsonProperty("M1_SEND_NOW_UPDATE_SW")
    public String getM1SENDNOWUPDATESW() {
        return m1SENDNOWUPDATESW;
    }

    /**
     * 
     * @param m1SENDNOWUPDATESW
     *     The M1_SEND_NOW_UPDATE_SW
     */
    @JsonProperty("M1_SEND_NOW_UPDATE_SW")
    public void setM1SENDNOWUPDATESW(String m1SENDNOWUPDATESW) {
        this.m1SENDNOWUPDATESW = m1SENDNOWUPDATESW;
    }

    /**
     * 
     * @return
     *     The m1OVRDFLG
     */
    @JsonProperty("M1_OVRD_FLG")
    public String getM1OVRDFLG() {
        return m1OVRDFLG;
    }

    /**
     * 
     * @param m1OVRDFLG
     *     The M1_OVRD_FLG
     */
    @JsonProperty("M1_OVRD_FLG")
    public void setM1OVRDFLG(String m1OVRDFLG) {
        this.m1OVRDFLG = m1OVRDFLG;
    }

    /**
     * 
     * @return
     *     The aDDR3AVAIL
     */
    @JsonProperty("ADDR3_AVAIL")
    public String getADDR3AVAIL() {
        return aDDR3AVAIL;
    }

    /**
     * 
     * @param aDDR3AVAIL
     *     The ADDR3_AVAIL
     */
    @JsonProperty("ADDR3_AVAIL")
    public void setADDR3AVAIL(String aDDR3AVAIL) {
        this.aDDR3AVAIL = aDDR3AVAIL;
    }

    /**
     * 
     * @return
     *     The m1VEHSTRTODOMTR
     */
    @JsonProperty("M1_VEH_STRT_ODO_MTR")
    public String getM1VEHSTRTODOMTR() {
        return m1VEHSTRTODOMTR;
    }

    /**
     * 
     * @param m1VEHSTRTODOMTR
     *     The M1_VEH_STRT_ODO_MTR
     */
    @JsonProperty("M1_VEH_STRT_ODO_MTR")
    public void setM1VEHSTRTODOMTR(String m1VEHSTRTODOMTR) {
        this.m1VEHSTRTODOMTR = m1VEHSTRTODOMTR;
    }

    /**
     * 
     * @return
     *     The tEXTANSWER
     */
    @JsonProperty("TEXT_ANSWER")
    public String getTEXTANSWER() {
        return tEXTANSWER;
    }

    /**
     * 
     * @param tEXTANSWER
     *     The TEXT_ANSWER
     */
    @JsonProperty("TEXT_ANSWER")
    public void setTEXTANSWER(String tEXTANSWER) {
        this.tEXTANSWER = tEXTANSWER;
    }

    /**
     * 
     * @return
     *     The oRIGPLANNEDENDDTTM
     */
    @JsonProperty("ORIG_PLANNED_END_DTTM")
    public String getORIGPLANNEDENDDTTM() {
        return oRIGPLANNEDENDDTTM;
    }

    /**
     * 
     * @param oRIGPLANNEDENDDTTM
     *     The ORIG_PLANNED_END_DTTM
     */
    @JsonProperty("ORIG_PLANNED_END_DTTM")
    public void setORIGPLANNEDENDDTTM(String oRIGPLANNEDENDDTTM) {
        this.oRIGPLANNEDENDDTTM = oRIGPLANNEDENDDTTM;
    }

    /**
     * 
     * @return
     *     The sUBSCRIPTIONID
     */
    @JsonProperty("SUBSCRIPTION_ID")
    public String getSUBSCRIPTIONID() {
        return sUBSCRIPTIONID;
    }

    /**
     * 
     * @param sUBSCRIPTIONID
     *     The SUBSCRIPTION_ID
     */
    @JsonProperty("SUBSCRIPTION_ID")
    public void setSUBSCRIPTIONID(String sUBSCRIPTIONID) {
        this.sUBSCRIPTIONID = sUBSCRIPTIONID;
    }

    /**
     * 
     * @return
     *     The m1COMMENT
     */
    @JsonProperty("M1_COMMENT")
    public String getM1COMMENT() {
        return m1COMMENT;
    }

    /**
     * 
     * @param m1COMMENT
     *     The M1_COMMENT
     */
    @JsonProperty("M1_COMMENT")
    public void setM1COMMENT(String m1COMMENT) {
        this.m1COMMENT = m1COMMENT;
    }

    /**
     * 
     * @return
     *     The m1DELVRNOWFLG
     */
    @JsonProperty("M1_DELVR_NOW_FLG")
    public String getM1DELVRNOWFLG() {
        return m1DELVRNOWFLG;
    }

    /**
     * 
     * @param m1DELVRNOWFLG
     *     The M1_DELVR_NOW_FLG
     */
    @JsonProperty("M1_DELVR_NOW_FLG")
    public void setM1DELVRNOWFLG(String m1DELVRNOWFLG) {
        this.m1DELVRNOWFLG = m1DELVRNOWFLG;
    }

    /**
     * 
     * @return
     *     The cALCTRVLDIST
     */
    @JsonProperty("CALC_TRVL_DIST")
    public String getCALCTRVLDIST() {
        return cALCTRVLDIST;
    }

    /**
     * 
     * @param cALCTRVLDIST
     *     The CALC_TRVL_DIST
     */
    @JsonProperty("CALC_TRVL_DIST")
    public void setCALCTRVLDIST(String cALCTRVLDIST) {
        this.cALCTRVLDIST = cALCTRVLDIST;
    }

    /**
     * 
     * @return
     *     The m1POUTASKTYPE
     */
    @JsonProperty("M1_POU_TASK_TYPE")
    public String getM1POUTASKTYPE() {
        return m1POUTASKTYPE;
    }

    /**
     * 
     * @param m1POUTASKTYPE
     *     The M1_POU_TASK_TYPE
     */
    @JsonProperty("M1_POU_TASK_TYPE")
    public void setM1POUTASKTYPE(String m1POUTASKTYPE) {
        this.m1POUTASKTYPE = m1POUTASKTYPE;
    }

    /**
     * 
     * @return
     *     The m1ASSIGNEDTOCAPACITYSW
     */
    @JsonProperty("M1_ASSIGNED_TO_CAPACITY_SW")
    public String getM1ASSIGNEDTOCAPACITYSW() {
        return m1ASSIGNEDTOCAPACITYSW;
    }

    /**
     * 
     * @param m1ASSIGNEDTOCAPACITYSW
     *     The M1_ASSIGNED_TO_CAPACITY_SW
     */
    @JsonProperty("M1_ASSIGNED_TO_CAPACITY_SW")
    public void setM1ASSIGNEDTOCAPACITYSW(String m1ASSIGNEDTOCAPACITYSW) {
        this.m1ASSIGNEDTOCAPACITYSW = m1ASSIGNEDTOCAPACITYSW;
    }

    /**
     * 
     * @return
     *     The m1GENERALLBL
     */
    @JsonProperty("M1_GENERAL_LBL")
    public String getM1GENERALLBL() {
        return m1GENERALLBL;
    }

    /**
     * 
     * @param m1GENERALLBL
     *     The M1_GENERAL_LBL
     */
    @JsonProperty("M1_GENERAL_LBL")
    public void setM1GENERALLBL(String m1GENERALLBL) {
        this.m1GENERALLBL = m1GENERALLBL;
    }

    /**
     * 
     * @return
     *     The m1REPLYLBL
     */
    @JsonProperty("M1_REPLY_LBL")
    public String getM1REPLYLBL() {
        return m1REPLYLBL;
    }

    /**
     * 
     * @param m1REPLYLBL
     *     The M1_REPLY_LBL
     */
    @JsonProperty("M1_REPLY_LBL")
    public void setM1REPLYLBL(String m1REPLYLBL) {
        this.m1REPLYLBL = m1REPLYLBL;
    }

    /**
     * 
     * @return
     *     The m1CLOSEBTNLBL
     */
    @JsonProperty("M1_CLOSE_BTN_LBL")
    public String getM1CLOSEBTNLBL() {
        return m1CLOSEBTNLBL;
    }

    /**
     * 
     * @param m1CLOSEBTNLBL
     *     The M1_CLOSE_BTN_LBL
     */
    @JsonProperty("M1_CLOSE_BTN_LBL")
    public void setM1CLOSEBTNLBL(String m1CLOSEBTNLBL) {
        this.m1CLOSEBTNLBL = m1CLOSEBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1SERVERPROXYHOST
     */
    @JsonProperty("M1_SERVER_PROXY_HOST")
    public String getM1SERVERPROXYHOST() {
        return m1SERVERPROXYHOST;
    }

    /**
     * 
     * @param m1SERVERPROXYHOST
     *     The M1_SERVER_PROXY_HOST
     */
    @JsonProperty("M1_SERVER_PROXY_HOST")
    public void setM1SERVERPROXYHOST(String m1SERVERPROXYHOST) {
        this.m1SERVERPROXYHOST = m1SERVERPROXYHOST;
    }

    /**
     * 
     * @return
     *     The tASKTYPECD
     */
    @JsonProperty("TASK_TYPE_CD")
    public String getTASKTYPECD() {
        return tASKTYPECD;
    }

    /**
     * 
     * @param tASKTYPECD
     *     The TASK_TYPE_CD
     */
    @JsonProperty("TASK_TYPE_CD")
    public void setTASKTYPECD(String tASKTYPECD) {
        this.tASKTYPECD = tASKTYPECD;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYBO
     */
    @JsonProperty("M1_ACTIVITY_BO")
    public String getM1ACTIVITYBO() {
        return m1ACTIVITYBO;
    }

    /**
     * 
     * @param m1ACTIVITYBO
     *     The M1_ACTIVITY_BO
     */
    @JsonProperty("M1_ACTIVITY_BO")
    public void setM1ACTIVITYBO(String m1ACTIVITYBO) {
        this.m1ACTIVITYBO = m1ACTIVITYBO;
    }

    /**
     * 
     * @return
     *     The tIMESHEETTMTYPECD
     */
    @JsonProperty("TIMESHEET_TM_TYPE_CD")
    public String getTIMESHEETTMTYPECD() {
        return tIMESHEETTMTYPECD;
    }

    /**
     * 
     * @param tIMESHEETTMTYPECD
     *     The TIMESHEET_TM_TYPE_CD
     */
    @JsonProperty("TIMESHEET_TM_TYPE_CD")
    public void setTIMESHEETTMTYPECD(String tIMESHEETTMTYPECD) {
        this.tIMESHEETTMTYPECD = tIMESHEETTMTYPECD;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEWITHINDAYS
     */
    @JsonProperty("M1_COMPLETE_WITHIN_DAYS")
    public String getM1COMPLETEWITHINDAYS() {
        return m1COMPLETEWITHINDAYS;
    }

    /**
     * 
     * @param m1COMPLETEWITHINDAYS
     *     The M1_COMPLETE_WITHIN_DAYS
     */
    @JsonProperty("M1_COMPLETE_WITHIN_DAYS")
    public void setM1COMPLETEWITHINDAYS(String m1COMPLETEWITHINDAYS) {
        this.m1COMPLETEWITHINDAYS = m1COMPLETEWITHINDAYS;
    }

    /**
     * 
     * @return
     *     The m1TODOMESSAGE
     */
    @JsonProperty("M1_TO_DO_MESSAGE")
    public String getM1TODOMESSAGE() {
        return m1TODOMESSAGE;
    }

    /**
     * 
     * @param m1TODOMESSAGE
     *     The M1_TO_DO_MESSAGE
     */
    @JsonProperty("M1_TO_DO_MESSAGE")
    public void setM1TODOMESSAGE(String m1TODOMESSAGE) {
        this.m1TODOMESSAGE = m1TODOMESSAGE;
    }

    /**
     * 
     * @return
     *     The m1WORKPROFILECD
     */
    @JsonProperty("M1_WORK_PROFILE_CD")
    public String getM1WORKPROFILECD() {
        return m1WORKPROFILECD;
    }

    /**
     * 
     * @param m1WORKPROFILECD
     *     The M1_WORK_PROFILE_CD
     */
    @JsonProperty("M1_WORK_PROFILE_CD")
    public void setM1WORKPROFILECD(String m1WORKPROFILECD) {
        this.m1WORKPROFILECD = m1WORKPROFILECD;
    }

    /**
     * 
     * @return
     *     The mSGPARMTYPFLG
     */
    @JsonProperty("MSG_PARM_TYP_FLG")
    public String getMSGPARMTYPFLG() {
        return mSGPARMTYPFLG;
    }

    /**
     * 
     * @param mSGPARMTYPFLG
     *     The MSG_PARM_TYP_FLG
     */
    @JsonProperty("MSG_PARM_TYP_FLG")
    public void setMSGPARMTYPFLG(String mSGPARMTYPFLG) {
        this.mSGPARMTYPFLG = mSGPARMTYPFLG;
    }

    /**
     * 
     * @return
     *     The m1SITEADDRESS
     */
    @JsonProperty("M1_SITE_ADDRESS")
    public String getM1SITEADDRESS() {
        return m1SITEADDRESS;
    }

    /**
     * 
     * @param m1SITEADDRESS
     *     The M1_SITE_ADDRESS
     */
    @JsonProperty("M1_SITE_ADDRESS")
    public void setM1SITEADDRESS(String m1SITEADDRESS) {
        this.m1SITEADDRESS = m1SITEADDRESS;
    }

    /**
     * 
     * @return
     *     The mDTID
     */
    @JsonProperty("MDT_ID")
    public String getMDTID() {
        return mDTID;
    }

    /**
     * 
     * @param mDTID
     *     The MDT_ID
     */
    @JsonProperty("MDT_ID")
    public void setMDTID(String mDTID) {
        this.mDTID = mDTID;
    }

    /**
     * 
     * @return
     *     The m1MCPMEACTIVITYINFOLBL
     */
    @JsonProperty("M1_MCPME_ACTIVITY_INFO_LBL")
    public String getM1MCPMEACTIVITYINFOLBL() {
        return m1MCPMEACTIVITYINFOLBL;
    }

    /**
     * 
     * @param m1MCPMEACTIVITYINFOLBL
     *     The M1_MCPME_ACTIVITY_INFO_LBL
     */
    @JsonProperty("M1_MCPME_ACTIVITY_INFO_LBL")
    public void setM1MCPMEACTIVITYINFOLBL(String m1MCPMEACTIVITYINFOLBL) {
        this.m1MCPMEACTIVITYINFOLBL = m1MCPMEACTIVITYINFOLBL;
    }

    /**
     * 
     * @return
     *     The m1UNDISPATCHOPTIONFLG
     */
    @JsonProperty("M1_UNDISPATCH_OPTION_FLG")
    public String getM1UNDISPATCHOPTIONFLG() {
        return m1UNDISPATCHOPTIONFLG;
    }

    /**
     * 
     * @param m1UNDISPATCHOPTIONFLG
     *     The M1_UNDISPATCH_OPTION_FLG
     */
    @JsonProperty("M1_UNDISPATCH_OPTION_FLG")
    public void setM1UNDISPATCHOPTIONFLG(String m1UNDISPATCHOPTIONFLG) {
        this.m1UNDISPATCHOPTIONFLG = m1UNDISPATCHOPTIONFLG;
    }

    /**
     * 
     * @return
     *     The m1PACKAGEITEMSLBL
     */
    @JsonProperty("M1_PACKAGE_ITEMS_LBL")
    public String getM1PACKAGEITEMSLBL() {
        return m1PACKAGEITEMSLBL;
    }

    /**
     * 
     * @param m1PACKAGEITEMSLBL
     *     The M1_PACKAGE_ITEMS_LBL
     */
    @JsonProperty("M1_PACKAGE_ITEMS_LBL")
    public void setM1PACKAGEITEMSLBL(String m1PACKAGEITEMSLBL) {
        this.m1PACKAGEITEMSLBL = m1PACKAGEITEMSLBL;
    }

    /**
     * 
     * @return
     *     The m1WORKSEQ
     */
    @JsonProperty("M1_WORK_SEQ")
    public String getM1WORKSEQ() {
        return m1WORKSEQ;
    }

    /**
     * 
     * @param m1WORKSEQ
     *     The M1_WORK_SEQ
     */
    @JsonProperty("M1_WORK_SEQ")
    public void setM1WORKSEQ(String m1WORKSEQ) {
        this.m1WORKSEQ = m1WORKSEQ;
    }

    /**
     * 
     * @return
     *     The hOSTREFCD
     */
    @JsonProperty("HOST_REF_CD")
    public String getHOSTREFCD() {
        return hOSTREFCD;
    }

    /**
     * 
     * @param hOSTREFCD
     *     The HOST_REF_CD
     */
    @JsonProperty("HOST_REF_CD")
    public void setHOSTREFCD(String hOSTREFCD) {
        this.hOSTREFCD = hOSTREFCD;
    }

    /**
     * 
     * @return
     *     The m1DEPOTDELAY
     */
    @JsonProperty("M1_DEPOT_DELAY")
    public String getM1DEPOTDELAY() {
        return m1DEPOTDELAY;
    }

    /**
     * 
     * @param m1DEPOTDELAY
     *     The M1_DEPOT_DELAY
     */
    @JsonProperty("M1_DEPOT_DELAY")
    public void setM1DEPOTDELAY(String m1DEPOTDELAY) {
        this.m1DEPOTDELAY = m1DEPOTDELAY;
    }

    /**
     * 
     * @return
     *     The m1TIMEWINDOWSOURCEFLG
     */
    @JsonProperty("M1_TIME_WINDOW_SOURCE_FLG")
    public String getM1TIMEWINDOWSOURCEFLG() {
        return m1TIMEWINDOWSOURCEFLG;
    }

    /**
     * 
     * @param m1TIMEWINDOWSOURCEFLG
     *     The M1_TIME_WINDOW_SOURCE_FLG
     */
    @JsonProperty("M1_TIME_WINDOW_SOURCE_FLG")
    public void setM1TIMEWINDOWSOURCEFLG(String m1TIMEWINDOWSOURCEFLG) {
        this.m1TIMEWINDOWSOURCEFLG = m1TIMEWINDOWSOURCEFLG;
    }

    /**
     * 
     * @return
     *     The m1PREVIEWSHFTLBL
     */
    @JsonProperty("M1_PREVIEW_SHFT_LBL")
    public String getM1PREVIEWSHFTLBL() {
        return m1PREVIEWSHFTLBL;
    }

    /**
     * 
     * @param m1PREVIEWSHFTLBL
     *     The M1_PREVIEW_SHFT_LBL
     */
    @JsonProperty("M1_PREVIEW_SHFT_LBL")
    public void setM1PREVIEWSHFTLBL(String m1PREVIEWSHFTLBL) {
        this.m1PREVIEWSHFTLBL = m1PREVIEWSHFTLBL;
    }

    /**
     * 
     * @return
     *     The m1MSGTEXT
     */
    @JsonProperty("M1_MSG_TEXT")
    public String getM1MSGTEXT() {
        return m1MSGTEXT;
    }

    /**
     * 
     * @param m1MSGTEXT
     *     The M1_MSG_TEXT
     */
    @JsonProperty("M1_MSG_TEXT")
    public void setM1MSGTEXT(String m1MSGTEXT) {
        this.m1MSGTEXT = m1MSGTEXT;
    }

    /**
     * 
     * @return
     *     The qUEUEFLG
     */
    @JsonProperty("QUEUE_FLG")
    public String getQUEUEFLG() {
        return qUEUEFLG;
    }

    /**
     * 
     * @param qUEUEFLG
     *     The QUEUE_FLG
     */
    @JsonProperty("QUEUE_FLG")
    public void setQUEUEFLG(String qUEUEFLG) {
        this.qUEUEFLG = qUEUEFLG;
    }

    /**
     * 
     * @return
     *     The m1SELECTLOGLEVELLBL
     */
    @JsonProperty("M1_SELECT_LOGLEVEL_LBL")
    public String getM1SELECTLOGLEVELLBL() {
        return m1SELECTLOGLEVELLBL;
    }

    /**
     * 
     * @param m1SELECTLOGLEVELLBL
     *     The M1_SELECT_LOGLEVEL_LBL
     */
    @JsonProperty("M1_SELECT_LOGLEVEL_LBL")
    public void setM1SELECTLOGLEVELLBL(String m1SELECTLOGLEVELLBL) {
        this.m1SELECTLOGLEVELLBL = m1SELECTLOGLEVELLBL;
    }

    /**
     * 
     * @return
     *     The m1EXPIRATIONTDROLE
     */
    @JsonProperty("M1_EXPIRATION_TD_ROLE")
    public String getM1EXPIRATIONTDROLE() {
        return m1EXPIRATIONTDROLE;
    }

    /**
     * 
     * @param m1EXPIRATIONTDROLE
     *     The M1_EXPIRATION_TD_ROLE
     */
    @JsonProperty("M1_EXPIRATION_TD_ROLE")
    public void setM1EXPIRATIONTDROLE(String m1EXPIRATIONTDROLE) {
        this.m1EXPIRATIONTDROLE = m1EXPIRATIONTDROLE;
    }

    /**
     * 
     * @return
     *     The m1NUMBERACTIVITIES
     */
    @JsonProperty("M1_NUMBER_ACTIVITIES")
    public String getM1NUMBERACTIVITIES() {
        return m1NUMBERACTIVITIES;
    }

    /**
     * 
     * @param m1NUMBERACTIVITIES
     *     The M1_NUMBER_ACTIVITIES
     */
    @JsonProperty("M1_NUMBER_ACTIVITIES")
    public void setM1NUMBERACTIVITIES(String m1NUMBERACTIVITIES) {
        this.m1NUMBERACTIVITIES = m1NUMBERACTIVITIES;
    }

    /**
     * 
     * @return
     *     The m1DEBUGLBL
     */
    @JsonProperty("M1_DEBUG_LBL")
    public String getM1DEBUGLBL() {
        return m1DEBUGLBL;
    }

    /**
     * 
     * @param m1DEBUGLBL
     *     The M1_DEBUG_LBL
     */
    @JsonProperty("M1_DEBUG_LBL")
    public void setM1DEBUGLBL(String m1DEBUGLBL) {
        this.m1DEBUGLBL = m1DEBUGLBL;
    }

    /**
     * 
     * @return
     *     The m1SELECTPICKUPACTTYPELBL
     */
    @JsonProperty("M1_SELECT_PICKUP_ACTTYPE_LBL")
    public String getM1SELECTPICKUPACTTYPELBL() {
        return m1SELECTPICKUPACTTYPELBL;
    }

    /**
     * 
     * @param m1SELECTPICKUPACTTYPELBL
     *     The M1_SELECT_PICKUP_ACTTYPE_LBL
     */
    @JsonProperty("M1_SELECT_PICKUP_ACTTYPE_LBL")
    public void setM1SELECTPICKUPACTTYPELBL(String m1SELECTPICKUPACTTYPELBL) {
        this.m1SELECTPICKUPACTTYPELBL = m1SELECTPICKUPACTTYPELBL;
    }

    /**
     * 
     * @return
     *     The iNCITYLIMAVAIL
     */
    @JsonProperty("IN_CITY_LIM_AVAIL")
    public String getINCITYLIMAVAIL() {
        return iNCITYLIMAVAIL;
    }

    /**
     * 
     * @param iNCITYLIMAVAIL
     *     The IN_CITY_LIM_AVAIL
     */
    @JsonProperty("IN_CITY_LIM_AVAIL")
    public void setINCITYLIMAVAIL(String iNCITYLIMAVAIL) {
        this.iNCITYLIMAVAIL = iNCITYLIMAVAIL;
    }

    /**
     * 
     * @return
     *     The oUTMSGTYPECD
     */
    @JsonProperty("OUTMSG_TYPE_CD")
    public String getOUTMSGTYPECD() {
        return oUTMSGTYPECD;
    }

    /**
     * 
     * @param oUTMSGTYPECD
     *     The OUTMSG_TYPE_CD
     */
    @JsonProperty("OUTMSG_TYPE_CD")
    public void setOUTMSGTYPECD(String oUTMSGTYPECD) {
        this.oUTMSGTYPECD = oUTMSGTYPECD;
    }

    /**
     * 
     * @return
     *     The cOUNTYLBL
     */
    @JsonProperty("COUNTY_LBL")
    public String getCOUNTYLBL() {
        return cOUNTYLBL;
    }

    /**
     * 
     * @param cOUNTYLBL
     *     The COUNTY_LBL
     */
    @JsonProperty("COUNTY_LBL")
    public void setCOUNTYLBL(String cOUNTYLBL) {
        this.cOUNTYLBL = cOUNTYLBL;
    }

    /**
     * 
     * @return
     *     The m1BREAKID
     */
    @JsonProperty("M1_BREAK_ID")
    public String getM1BREAKID() {
        return m1BREAKID;
    }

    /**
     * 
     * @param m1BREAKID
     *     The M1_BREAK_ID
     */
    @JsonProperty("M1_BREAK_ID")
    public void setM1BREAKID(String m1BREAKID) {
        this.m1BREAKID = m1BREAKID;
    }

    /**
     * 
     * @return
     *     The tAKEATTENDANCEFLG
     */
    @JsonProperty("TAKE_ATTENDANCE_FLG")
    public String getTAKEATTENDANCEFLG() {
        return tAKEATTENDANCEFLG;
    }

    /**
     * 
     * @param tAKEATTENDANCEFLG
     *     The TAKE_ATTENDANCE_FLG
     */
    @JsonProperty("TAKE_ATTENDANCE_FLG")
    public void setTAKEATTENDANCEFLG(String tAKEATTENDANCEFLG) {
        this.tAKEATTENDANCEFLG = tAKEATTENDANCEFLG;
    }

    /**
     * 
     * @return
     *     The f1MSGPARMVLONG
     */
    @JsonProperty("F1_MSG_PARM_VLONG")
    public String getF1MSGPARMVLONG() {
        return f1MSGPARMVLONG;
    }

    /**
     * 
     * @param f1MSGPARMVLONG
     *     The F1_MSG_PARM_VLONG
     */
    @JsonProperty("F1_MSG_PARM_VLONG")
    public void setF1MSGPARMVLONG(String f1MSGPARMVLONG) {
        this.f1MSGPARMVLONG = f1MSGPARMVLONG;
    }

    /**
     * 
     * @return
     *     The m1WORKBYDATE
     */
    @JsonProperty("M1_WORK_BY_DATE")
    public String getM1WORKBYDATE() {
        return m1WORKBYDATE;
    }

    /**
     * 
     * @param m1WORKBYDATE
     *     The M1_WORK_BY_DATE
     */
    @JsonProperty("M1_WORK_BY_DATE")
    public void setM1WORKBYDATE(String m1WORKBYDATE) {
        this.m1WORKBYDATE = m1WORKBYDATE;
    }

    /**
     * 
     * @return
     *     The m1ESTIMATEDDURATION
     */
    @JsonProperty("M1_ESTIMATED_DURATION")
    public String getM1ESTIMATEDDURATION() {
        return m1ESTIMATEDDURATION;
    }

    /**
     * 
     * @param m1ESTIMATEDDURATION
     *     The M1_ESTIMATED_DURATION
     */
    @JsonProperty("M1_ESTIMATED_DURATION")
    public void setM1ESTIMATEDDURATION(String m1ESTIMATEDDURATION) {
        this.m1ESTIMATEDDURATION = m1ESTIMATEDDURATION;
    }

    /**
     * 
     * @return
     *     The cOUNTRY
     */
    @JsonProperty("COUNTRY")
    public String getCOUNTRY() {
        return cOUNTRY;
    }

    /**
     * 
     * @param cOUNTRY
     *     The COUNTRY
     */
    @JsonProperty("COUNTRY")
    public void setCOUNTRY(String cOUNTRY) {
        this.cOUNTRY = cOUNTRY;
    }

    /**
     * 
     * @return
     *     The sTEPLOWERLIMIT
     */
    @JsonProperty("STEP_LOWER_LIMIT")
    public String getSTEPLOWERLIMIT() {
        return sTEPLOWERLIMIT;
    }

    /**
     * 
     * @param sTEPLOWERLIMIT
     *     The STEP_LOWER_LIMIT
     */
    @JsonProperty("STEP_LOWER_LIMIT")
    public void setSTEPLOWERLIMIT(String sTEPLOWERLIMIT) {
        this.sTEPLOWERLIMIT = sTEPLOWERLIMIT;
    }

    /**
     * 
     * @return
     *     The m1CUSTOMERCONTACTCOMMENTS
     */
    @JsonProperty("M1_CUSTOMER_CONTACT_COMMENTS")
    public String getM1CUSTOMERCONTACTCOMMENTS() {
        return m1CUSTOMERCONTACTCOMMENTS;
    }

    /**
     * 
     * @param m1CUSTOMERCONTACTCOMMENTS
     *     The M1_CUSTOMER_CONTACT_COMMENTS
     */
    @JsonProperty("M1_CUSTOMER_CONTACT_COMMENTS")
    public void setM1CUSTOMERCONTACTCOMMENTS(String m1CUSTOMERCONTACTCOMMENTS) {
        this.m1CUSTOMERCONTACTCOMMENTS = m1CUSTOMERCONTACTCOMMENTS;
    }

    /**
     * 
     * @return
     *     The m1OFFLINELBL
     */
    @JsonProperty("M1_OFFLINE_LBL")
    public String getM1OFFLINELBL() {
        return m1OFFLINELBL;
    }

    /**
     * 
     * @param m1OFFLINELBL
     *     The M1_OFFLINE_LBL
     */
    @JsonProperty("M1_OFFLINE_LBL")
    public void setM1OFFLINELBL(String m1OFFLINELBL) {
        this.m1OFFLINELBL = m1OFFLINELBL;
    }

    /**
     * 
     * @return
     *     The m1CONCURRENTTASKID
     */
    @JsonProperty("M1_CONCURRENT_TASK_ID")
    public String getM1CONCURRENTTASKID() {
        return m1CONCURRENTTASKID;
    }

    /**
     * 
     * @param m1CONCURRENTTASKID
     *     The M1_CONCURRENT_TASK_ID
     */
    @JsonProperty("M1_CONCURRENT_TASK_ID")
    public void setM1CONCURRENTTASKID(String m1CONCURRENTTASKID) {
        this.m1CONCURRENTTASKID = m1CONCURRENTTASKID;
    }

    /**
     * 
     * @return
     *     The m1LOGONDELAY
     */
    @JsonProperty("M1_LOGON_DELAY")
    public String getM1LOGONDELAY() {
        return m1LOGONDELAY;
    }

    /**
     * 
     * @param m1LOGONDELAY
     *     The M1_LOGON_DELAY
     */
    @JsonProperty("M1_LOGON_DELAY")
    public void setM1LOGONDELAY(String m1LOGONDELAY) {
        this.m1LOGONDELAY = m1LOGONDELAY;
    }

    /**
     * 
     * @return
     *     The m1MOBAPPLBL
     */
    @JsonProperty("M1_MOB_APP_LBL")
    public String getM1MOBAPPLBL() {
        return m1MOBAPPLBL;
    }

    /**
     * 
     * @param m1MOBAPPLBL
     *     The M1_MOB_APP_LBL
     */
    @JsonProperty("M1_MOB_APP_LBL")
    public void setM1MOBAPPLBL(String m1MOBAPPLBL) {
        this.m1MOBAPPLBL = m1MOBAPPLBL;
    }

    /**
     * 
     * @return
     *     The m1CONTRACTORLBL
     */
    @JsonProperty("M1_CONTRACTOR_LBL")
    public String getM1CONTRACTORLBL() {
        return m1CONTRACTORLBL;
    }

    /**
     * 
     * @param m1CONTRACTORLBL
     *     The M1_CONTRACTOR_LBL
     */
    @JsonProperty("M1_CONTRACTOR_LBL")
    public void setM1CONTRACTORLBL(String m1CONTRACTORLBL) {
        this.m1CONTRACTORLBL = m1CONTRACTORLBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMATTRVALUE
     */
    @JsonProperty("M1_ITEM_ATTR_VALUE")
    public String getM1ITEMATTRVALUE() {
        return m1ITEMATTRVALUE;
    }

    /**
     * 
     * @param m1ITEMATTRVALUE
     *     The M1_ITEM_ATTR_VALUE
     */
    @JsonProperty("M1_ITEM_ATTR_VALUE")
    public void setM1ITEMATTRVALUE(String m1ITEMATTRVALUE) {
        this.m1ITEMATTRVALUE = m1ITEMATTRVALUE;
    }

    /**
     * 
     * @return
     *     The m1NONPRDTASKBO
     */
    @JsonProperty("M1_NON_PRD_TASK_BO")
    public String getM1NONPRDTASKBO() {
        return m1NONPRDTASKBO;
    }

    /**
     * 
     * @param m1NONPRDTASKBO
     *     The M1_NON_PRD_TASK_BO
     */
    @JsonProperty("M1_NON_PRD_TASK_BO")
    public void setM1NONPRDTASKBO(String m1NONPRDTASKBO) {
        this.m1NONPRDTASKBO = m1NONPRDTASKBO;
    }

    /**
     * 
     * @return
     *     The m1DELIVERYCOMPLETE
     */
    @JsonProperty("M1_DELIVERY_COMPLETE")
    public String getM1DELIVERYCOMPLETE() {
        return m1DELIVERYCOMPLETE;
    }

    /**
     * 
     * @param m1DELIVERYCOMPLETE
     *     The M1_DELIVERY_COMPLETE
     */
    @JsonProperty("M1_DELIVERY_COMPLETE")
    public void setM1DELIVERYCOMPLETE(String m1DELIVERYCOMPLETE) {
        this.m1DELIVERYCOMPLETE = m1DELIVERYCOMPLETE;
    }

    /**
     * 
     * @return
     *     The m1TIMESHEETLBL
     */
    @JsonProperty("M1_TIMESHEET_LBL")
    public String getM1TIMESHEETLBL() {
        return m1TIMESHEETLBL;
    }

    /**
     * 
     * @param m1TIMESHEETLBL
     *     The M1_TIMESHEET_LBL
     */
    @JsonProperty("M1_TIMESHEET_LBL")
    public void setM1TIMESHEETLBL(String m1TIMESHEETLBL) {
        this.m1TIMESHEETLBL = m1TIMESHEETLBL;
    }

    /**
     * 
     * @return
     *     The m1APPENDERSLBL
     */
    @JsonProperty("M1_APPENDERS_LBL")
    public String getM1APPENDERSLBL() {
        return m1APPENDERSLBL;
    }

    /**
     * 
     * @param m1APPENDERSLBL
     *     The M1_APPENDERS_LBL
     */
    @JsonProperty("M1_APPENDERS_LBL")
    public void setM1APPENDERSLBL(String m1APPENDERSLBL) {
        this.m1APPENDERSLBL = m1APPENDERSLBL;
    }

    /**
     * 
     * @return
     *     The m1BREAKBO
     */
    @JsonProperty("M1_BREAK_BO")
    public String getM1BREAKBO() {
        return m1BREAKBO;
    }

    /**
     * 
     * @param m1BREAKBO
     *     The M1_BREAK_BO
     */
    @JsonProperty("M1_BREAK_BO")
    public void setM1BREAKBO(String m1BREAKBO) {
        this.m1BREAKBO = m1BREAKBO;
    }

    /**
     * 
     * @return
     *     The m1COMMONCOMPLETIONLBL
     */
    @JsonProperty("M1_COMMON_COMPLETION_LBL")
    public String getM1COMMONCOMPLETIONLBL() {
        return m1COMMONCOMPLETIONLBL;
    }

    /**
     * 
     * @param m1COMMONCOMPLETIONLBL
     *     The M1_COMMON_COMPLETION_LBL
     */
    @JsonProperty("M1_COMMON_COMPLETION_LBL")
    public void setM1COMMONCOMPLETIONLBL(String m1COMMONCOMPLETIONLBL) {
        this.m1COMMONCOMPLETIONLBL = m1COMMONCOMPLETIONLBL;
    }

    /**
     * 
     * @return
     *     The m1CREWTIMUGGDIMMAINLBL
     */
    @JsonProperty("M1_CREW_TIM_UGG_DIM_MAIN_LBL")
    public String getM1CREWTIMUGGDIMMAINLBL() {
        return m1CREWTIMUGGDIMMAINLBL;
    }

    /**
     * 
     * @param m1CREWTIMUGGDIMMAINLBL
     *     The M1_CREW_TIM_UGG_DIM_MAIN_LBL
     */
    @JsonProperty("M1_CREW_TIM_UGG_DIM_MAIN_LBL")
    public void setM1CREWTIMUGGDIMMAINLBL(String m1CREWTIMUGGDIMMAINLBL) {
        this.m1CREWTIMUGGDIMMAINLBL = m1CREWTIMUGGDIMMAINLBL;
    }

    /**
     * 
     * @return
     *     The nUM1LBL
     */
    @JsonProperty("NUM1_LBL")
    public String getNUM1LBL() {
        return nUM1LBL;
    }

    /**
     * 
     * @param nUM1LBL
     *     The NUM1_LBL
     */
    @JsonProperty("NUM1_LBL")
    public void setNUM1LBL(String nUM1LBL) {
        this.nUM1LBL = nUM1LBL;
    }

    /**
     * 
     * @return
     *     The m1ACTSTELBL
     */
    @JsonProperty("M1_ACT_STE_LBL")
    public String getM1ACTSTELBL() {
        return m1ACTSTELBL;
    }

    /**
     * 
     * @param m1ACTSTELBL
     *     The M1_ACT_STE_LBL
     */
    @JsonProperty("M1_ACT_STE_LBL")
    public void setM1ACTSTELBL(String m1ACTSTELBL) {
        this.m1ACTSTELBL = m1ACTSTELBL;
    }

    /**
     * 
     * @return
     *     The m1TRAVELTIMEDURATION
     */
    @JsonProperty("M1_TRAVELTIME_DURATION")
    public String getM1TRAVELTIMEDURATION() {
        return m1TRAVELTIMEDURATION;
    }

    /**
     * 
     * @param m1TRAVELTIMEDURATION
     *     The M1_TRAVELTIME_DURATION
     */
    @JsonProperty("M1_TRAVELTIME_DURATION")
    public void setM1TRAVELTIMEDURATION(String m1TRAVELTIMEDURATION) {
        this.m1TRAVELTIMEDURATION = m1TRAVELTIMEDURATION;
    }

    /**
     * 
     * @return
     *     The m1COMPLETEWITHINTIME
     */
    @JsonProperty("M1_COMPLETE_WITHIN_TIME")
    public String getM1COMPLETEWITHINTIME() {
        return m1COMPLETEWITHINTIME;
    }

    /**
     * 
     * @param m1COMPLETEWITHINTIME
     *     The M1_COMPLETE_WITHIN_TIME
     */
    @JsonProperty("M1_COMPLETE_WITHIN_TIME")
    public void setM1COMPLETEWITHINTIME(String m1COMPLETEWITHINTIME) {
        this.m1COMPLETEWITHINTIME = m1COMPLETEWITHINTIME;
    }

    /**
     * 
     * @return
     *     The lOGENTRYTYPEFLG
     */
    @JsonProperty("LOG_ENTRY_TYPE_FLG")
    public String getLOGENTRYTYPEFLG() {
        return lOGENTRYTYPEFLG;
    }

    /**
     * 
     * @param lOGENTRYTYPEFLG
     *     The LOG_ENTRY_TYPE_FLG
     */
    @JsonProperty("LOG_ENTRY_TYPE_FLG")
    public void setLOGENTRYTYPEFLG(String lOGENTRYTYPEFLG) {
        this.lOGENTRYTYPEFLG = lOGENTRYTYPEFLG;
    }

    /**
     * 
     * @return
     *     The m1ATTENDANCELBL
     */
    @JsonProperty("M1_ATTENDANCE_LBL")
    public String getM1ATTENDANCELBL() {
        return m1ATTENDANCELBL;
    }

    /**
     * 
     * @param m1ATTENDANCELBL
     *     The M1_ATTENDANCE_LBL
     */
    @JsonProperty("M1_ATTENDANCE_LBL")
    public void setM1ATTENDANCELBL(String m1ATTENDANCELBL) {
        this.m1ATTENDANCELBL = m1ATTENDANCELBL;
    }

    /**
     * 
     * @return
     *     The aDDR4LBL
     */
    @JsonProperty("ADDR4_LBL")
    public String getADDR4LBL() {
        return aDDR4LBL;
    }

    /**
     * 
     * @param aDDR4LBL
     *     The ADDR4_LBL
     */
    @JsonProperty("ADDR4_LBL")
    public void setADDR4LBL(String aDDR4LBL) {
        this.aDDR4LBL = aDDR4LBL;
    }

    /**
     * 
     * @return
     *     The f1ATTACHMENTRECORD
     */
    @JsonProperty("F1_ATTACHMENT_RECORD")
    public String getF1ATTACHMENTRECORD() {
        return f1ATTACHMENTRECORD;
    }

    /**
     * 
     * @param f1ATTACHMENTRECORD
     *     The F1_ATTACHMENT_RECORD
     */
    @JsonProperty("F1_ATTACHMENT_RECORD")
    public void setF1ATTACHMENTRECORD(String f1ATTACHMENTRECORD) {
        this.f1ATTACHMENTRECORD = f1ATTACHMENTRECORD;
    }

    /**
     * 
     * @return
     *     The m1DEPOTTASKDECLINEREASON
     */
    @JsonProperty("M1_DEPOT_TASK_DECLINE_REASON")
    public String getM1DEPOTTASKDECLINEREASON() {
        return m1DEPOTTASKDECLINEREASON;
    }

    /**
     * 
     * @param m1DEPOTTASKDECLINEREASON
     *     The M1_DEPOT_TASK_DECLINE_REASON
     */
    @JsonProperty("M1_DEPOT_TASK_DECLINE_REASON")
    public void setM1DEPOTTASKDECLINEREASON(String m1DEPOTTASKDECLINEREASON) {
        this.m1DEPOTTASKDECLINEREASON = m1DEPOTTASKDECLINEREASON;
    }

    /**
     * 
     * @return
     *     The m1THEMEELBL
     */
    @JsonProperty("M1_THEME_E_LBL")
    public String getM1THEMEELBL() {
        return m1THEMEELBL;
    }

    /**
     * 
     * @param m1THEMEELBL
     *     The M1_THEME_E_LBL
     */
    @JsonProperty("M1_THEME_E_LBL")
    public void setM1THEMEELBL(String m1THEMEELBL) {
        this.m1THEMEELBL = m1THEMEELBL;
    }

    /**
     * 
     * @return
     *     The dRIPMODEFLG
     */
    @JsonProperty("DRIP_MODE_FLG")
    public String getDRIPMODEFLG() {
        return dRIPMODEFLG;
    }

    /**
     * 
     * @param dRIPMODEFLG
     *     The DRIP_MODE_FLG
     */
    @JsonProperty("DRIP_MODE_FLG")
    public void setDRIPMODEFLG(String dRIPMODEFLG) {
        this.dRIPMODEFLG = dRIPMODEFLG;
    }

    /**
     * 
     * @return
     *     The sTEPSTATEFLG
     */
    @JsonProperty("STEP_STATE_FLG")
    public String getSTEPSTATEFLG() {
        return sTEPSTATEFLG;
    }

    /**
     * 
     * @param sTEPSTATEFLG
     *     The STEP_STATE_FLG
     */
    @JsonProperty("STEP_STATE_FLG")
    public void setSTEPSTATEFLG(String sTEPSTATEFLG) {
        this.sTEPSTATEFLG = sTEPSTATEFLG;
    }

    /**
     * 
     * @return
     *     The m1ADDNEWLBL
     */
    @JsonProperty("M1_ADD_NEW_LBL")
    public String getM1ADDNEWLBL() {
        return m1ADDNEWLBL;
    }

    /**
     * 
     * @param m1ADDNEWLBL
     *     The M1_ADD_NEW_LBL
     */
    @JsonProperty("M1_ADD_NEW_LBL")
    public void setM1ADDNEWLBL(String m1ADDNEWLBL) {
        this.m1ADDNEWLBL = m1ADDNEWLBL;
    }

    /**
     * 
     * @return
     *     The cREDTTM
     */
    @JsonProperty("CRE_DTTM")
    public String getCREDTTM() {
        return cREDTTM;
    }

    /**
     * 
     * @param cREDTTM
     *     The CRE_DTTM
     */
    @JsonProperty("CRE_DTTM")
    public void setCREDTTM(String cREDTTM) {
        this.cREDTTM = cREDTTM;
    }

    /**
     * 
     * @return
     *     The vARIABLESHIFTFLG
     */
    @JsonProperty("VARIABLE_SHIFT_FLG")
    public String getVARIABLESHIFTFLG() {
        return vARIABLESHIFTFLG;
    }

    /**
     * 
     * @param vARIABLESHIFTFLG
     *     The VARIABLE_SHIFT_FLG
     */
    @JsonProperty("VARIABLE_SHIFT_FLG")
    public void setVARIABLESHIFTFLG(String vARIABLESHIFTFLG) {
        this.vARIABLESHIFTFLG = vARIABLESHIFTFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTIVITYCOMPLETEFLG
     */
    @JsonProperty("M1_ACTIVITY_COMPLETE_FLG")
    public String getM1ACTIVITYCOMPLETEFLG() {
        return m1ACTIVITYCOMPLETEFLG;
    }

    /**
     * 
     * @param m1ACTIVITYCOMPLETEFLG
     *     The M1_ACTIVITY_COMPLETE_FLG
     */
    @JsonProperty("M1_ACTIVITY_COMPLETE_FLG")
    public void setM1ACTIVITYCOMPLETEFLG(String m1ACTIVITYCOMPLETEFLG) {
        this.m1ACTIVITYCOMPLETEFLG = m1ACTIVITYCOMPLETEFLG;
    }

    /**
     * 
     * @return
     *     The aLLLBL
     */
    @JsonProperty("ALL_LBL")
    public String getALLLBL() {
        return aLLLBL;
    }

    /**
     * 
     * @param aLLLBL
     *     The ALL_LBL
     */
    @JsonProperty("ALL_LBL")
    public void setALLLBL(String aLLLBL) {
        this.aLLLBL = aLLLBL;
    }

    /**
     * 
     * @return
     *     The m1UNDELIVEREDLBL
     */
    @JsonProperty("M1_UNDELIVERED_LBL")
    public String getM1UNDELIVEREDLBL() {
        return m1UNDELIVEREDLBL;
    }

    /**
     * 
     * @param m1UNDELIVEREDLBL
     *     The M1_UNDELIVERED_LBL
     */
    @JsonProperty("M1_UNDELIVERED_LBL")
    public void setM1UNDELIVEREDLBL(String m1UNDELIVEREDLBL) {
        this.m1UNDELIVEREDLBL = m1UNDELIVEREDLBL;
    }

    /**
     * 
     * @return
     *     The m1STRTSHIFTLBL
     */
    @JsonProperty("M1_STRT_SHIFT_LBL")
    public String getM1STRTSHIFTLBL() {
        return m1STRTSHIFTLBL;
    }

    /**
     * 
     * @param m1STRTSHIFTLBL
     *     The M1_STRT_SHIFT_LBL
     */
    @JsonProperty("M1_STRT_SHIFT_LBL")
    public void setM1STRTSHIFTLBL(String m1STRTSHIFTLBL) {
        this.m1STRTSHIFTLBL = m1STRTSHIFTLBL;
    }

    /**
     * 
     * @return
     *     The m1ADDREMARKTYPLBL
     */
    @JsonProperty("M1_ADD_REMARK_TYP_LBL")
    public String getM1ADDREMARKTYPLBL() {
        return m1ADDREMARKTYPLBL;
    }

    /**
     * 
     * @param m1ADDREMARKTYPLBL
     *     The M1_ADD_REMARK_TYP_LBL
     */
    @JsonProperty("M1_ADD_REMARK_TYP_LBL")
    public void setM1ADDREMARKTYPLBL(String m1ADDREMARKTYPLBL) {
        this.m1ADDREMARKTYPLBL = m1ADDREMARKTYPLBL;
    }

    /**
     * 
     * @return
     *     The pROCEDURECLEARANCEREQFLG
     */
    @JsonProperty("PROCEDURE_CLEARANCE_REQ_FLG")
    public String getPROCEDURECLEARANCEREQFLG() {
        return pROCEDURECLEARANCEREQFLG;
    }

    /**
     * 
     * @param pROCEDURECLEARANCEREQFLG
     *     The PROCEDURE_CLEARANCE_REQ_FLG
     */
    @JsonProperty("PROCEDURE_CLEARANCE_REQ_FLG")
    public void setPROCEDURECLEARANCEREQFLG(String pROCEDURECLEARANCEREQFLG) {
        this.pROCEDURECLEARANCEREQFLG = pROCEDURECLEARANCEREQFLG;
    }

    /**
     * 
     * @return
     *     The hOSTEXTERNALID
     */
    @JsonProperty("HOST_EXTERNAL_ID")
    public String getHOSTEXTERNALID() {
        return hOSTEXTERNALID;
    }

    /**
     * 
     * @param hOSTEXTERNALID
     *     The HOST_EXTERNAL_ID
     */
    @JsonProperty("HOST_EXTERNAL_ID")
    public void setHOSTEXTERNALID(String hOSTEXTERNALID) {
        this.hOSTEXTERNALID = hOSTEXTERNALID;
    }

    /**
     * 
     * @return
     *     The m1LISTLBL
     */
    @JsonProperty("M1_LIST_LBL")
    public String getM1LISTLBL() {
        return m1LISTLBL;
    }

    /**
     * 
     * @param m1LISTLBL
     *     The M1_LIST_LBL
     */
    @JsonProperty("M1_LIST_LBL")
    public void setM1LISTLBL(String m1LISTLBL) {
        this.m1LISTLBL = m1LISTLBL;
    }

    /**
     * 
     * @return
     *     The m1DEPENDENCYRSNFLG
     */
    @JsonProperty("M1_DEPENDENCY_RSN_FLG")
    public String getM1DEPENDENCYRSNFLG() {
        return m1DEPENDENCYRSNFLG;
    }

    /**
     * 
     * @param m1DEPENDENCYRSNFLG
     *     The M1_DEPENDENCY_RSN_FLG
     */
    @JsonProperty("M1_DEPENDENCY_RSN_FLG")
    public void setM1DEPENDENCYRSNFLG(String m1DEPENDENCYRSNFLG) {
        this.m1DEPENDENCYRSNFLG = m1DEPENDENCYRSNFLG;
    }

    /**
     * 
     * @return
     *     The sUBURB
     */
    @JsonProperty("SUBURB")
    public String getSUBURB() {
        return sUBURB;
    }

    /**
     * 
     * @param sUBURB
     *     The SUBURB
     */
    @JsonProperty("SUBURB")
    public void setSUBURB(String sUBURB) {
        this.sUBURB = sUBURB;
    }

    /**
     * 
     * @return
     *     The m1DEPOTLBL
     */
    @JsonProperty("M1_DEPOT_LBL")
    public String getM1DEPOTLBL() {
        return m1DEPOTLBL;
    }

    /**
     * 
     * @param m1DEPOTLBL
     *     The M1_DEPOT_LBL
     */
    @JsonProperty("M1_DEPOT_LBL")
    public void setM1DEPOTLBL(String m1DEPOTLBL) {
        this.m1DEPOTLBL = m1DEPOTLBL;
    }

    /**
     * 
     * @return
     *     The dESCR100
     */
    @JsonProperty("DESCR100")
    public String getDESCR100() {
        return dESCR100;
    }

    /**
     * 
     * @param dESCR100
     *     The DESCR100
     */
    @JsonProperty("DESCR100")
    public void setDESCR100(String dESCR100) {
        this.dESCR100 = dESCR100;
    }

    /**
     * 
     * @return
     *     The m1COUNT
     */
    @JsonProperty("M1_COUNT")
    public String getM1COUNT() {
        return m1COUNT;
    }

    /**
     * 
     * @param m1COUNT
     *     The M1_COUNT
     */
    @JsonProperty("M1_COUNT")
    public void setM1COUNT(String m1COUNT) {
        this.m1COUNT = m1COUNT;
    }

    /**
     * 
     * @return
     *     The m1LOGLEVELLBL
     */
    @JsonProperty("M1_LOG_LEVEL_LBL")
    public String getM1LOGLEVELLBL() {
        return m1LOGLEVELLBL;
    }

    /**
     * 
     * @param m1LOGLEVELLBL
     *     The M1_LOG_LEVEL_LBL
     */
    @JsonProperty("M1_LOG_LEVEL_LBL")
    public void setM1LOGLEVELLBL(String m1LOGLEVELLBL) {
        this.m1LOGLEVELLBL = m1LOGLEVELLBL;
    }

    /**
     * 
     * @return
     *     The m1LIFESPAN
     */
    @JsonProperty("M1_LIFE_SPAN")
    public String getM1LIFESPAN() {
        return m1LIFESPAN;
    }

    /**
     * 
     * @param m1LIFESPAN
     *     The M1_LIFE_SPAN
     */
    @JsonProperty("M1_LIFE_SPAN")
    public void setM1LIFESPAN(String m1LIFESPAN) {
        this.m1LIFESPAN = m1LIFESPAN;
    }

    /**
     * 
     * @return
     *     The m1CREATEDBYCREWSW
     */
    @JsonProperty("M1_CREATED_BY_CREW_SW")
    public String getM1CREATEDBYCREWSW() {
        return m1CREATEDBYCREWSW;
    }

    /**
     * 
     * @param m1CREATEDBYCREWSW
     *     The M1_CREATED_BY_CREW_SW
     */
    @JsonProperty("M1_CREATED_BY_CREW_SW")
    public void setM1CREATEDBYCREWSW(String m1CREATEDBYCREWSW) {
        this.m1CREATEDBYCREWSW = m1CREATEDBYCREWSW;
    }

    /**
     * 
     * @return
     *     The m1NONCUMCAPACITYFLG
     */
    @JsonProperty("M1_NONCUM_CAPACITY_FLG")
    public String getM1NONCUMCAPACITYFLG() {
        return m1NONCUMCAPACITYFLG;
    }

    /**
     * 
     * @param m1NONCUMCAPACITYFLG
     *     The M1_NONCUM_CAPACITY_FLG
     */
    @JsonProperty("M1_NONCUM_CAPACITY_FLG")
    public void setM1NONCUMCAPACITYFLG(String m1NONCUMCAPACITYFLG) {
        this.m1NONCUMCAPACITYFLG = m1NONCUMCAPACITYFLG;
    }

    /**
     * 
     * @return
     *     The m1ACTUALARRDTTM
     */
    @JsonProperty("M1_ACTUAL_ARR_DTTM")
    public String getM1ACTUALARRDTTM() {
        return m1ACTUALARRDTTM;
    }

    /**
     * 
     * @param m1ACTUALARRDTTM
     *     The M1_ACTUAL_ARR_DTTM
     */
    @JsonProperty("M1_ACTUAL_ARR_DTTM")
    public void setM1ACTUALARRDTTM(String m1ACTUALARRDTTM) {
        this.m1ACTUALARRDTTM = m1ACTUALARRDTTM;
    }

    /**
     * 
     * @return
     *     The m1CANCELCHGSBTNLBL
     */
    @JsonProperty("M1_CANCEL_CHGS_BTN_LBL")
    public String getM1CANCELCHGSBTNLBL() {
        return m1CANCELCHGSBTNLBL;
    }

    /**
     * 
     * @param m1CANCELCHGSBTNLBL
     *     The M1_CANCEL_CHGS_BTN_LBL
     */
    @JsonProperty("M1_CANCEL_CHGS_BTN_LBL")
    public void setM1CANCELCHGSBTNLBL(String m1CANCELCHGSBTNLBL) {
        this.m1CANCELCHGSBTNLBL = m1CANCELCHGSBTNLBL;
    }

    /**
     * 
     * @return
     *     The m1DATASENTATDTTM
     */
    @JsonProperty("M1_DATA_SENT_AT_DTTM")
    public String getM1DATASENTATDTTM() {
        return m1DATASENTATDTTM;
    }

    /**
     * 
     * @param m1DATASENTATDTTM
     *     The M1_DATA_SENT_AT_DTTM
     */
    @JsonProperty("M1_DATA_SENT_AT_DTTM")
    public void setM1DATASENTATDTTM(String m1DATASENTATDTTM) {
        this.m1DATASENTATDTTM = m1DATASENTATDTTM;
    }

    /**
     * 
     * @return
     *     The m1MAILMSGCLSFLG
     */
    @JsonProperty("M1_MAIL_MSG_CLS_FLG")
    public String getM1MAILMSGCLSFLG() {
        return m1MAILMSGCLSFLG;
    }

    /**
     * 
     * @param m1MAILMSGCLSFLG
     *     The M1_MAIL_MSG_CLS_FLG
     */
    @JsonProperty("M1_MAIL_MSG_CLS_FLG")
    public void setM1MAILMSGCLSFLG(String m1MAILMSGCLSFLG) {
        this.m1MAILMSGCLSFLG = m1MAILMSGCLSFLG;
    }

    /**
     * 
     * @return
     *     The pARMSEQ
     */
    @JsonProperty("PARM_SEQ")
    public String getPARMSEQ() {
        return pARMSEQ;
    }

    /**
     * 
     * @param pARMSEQ
     *     The PARM_SEQ
     */
    @JsonProperty("PARM_SEQ")
    public void setPARMSEQ(String pARMSEQ) {
        this.pARMSEQ = pARMSEQ;
    }

    /**
     * 
     * @return
     *     The m1CLOSEDBYADVDISPFLG
     */
    @JsonProperty("M1_CLOSEDBY_ADV_DISP_FLG")
    public String getM1CLOSEDBYADVDISPFLG() {
        return m1CLOSEDBYADVDISPFLG;
    }

    /**
     * 
     * @param m1CLOSEDBYADVDISPFLG
     *     The M1_CLOSEDBY_ADV_DISP_FLG
     */
    @JsonProperty("M1_CLOSEDBY_ADV_DISP_FLG")
    public void setM1CLOSEDBYADVDISPFLG(String m1CLOSEDBYADVDISPFLG) {
        this.m1CLOSEDBYADVDISPFLG = m1CLOSEDBYADVDISPFLG;
    }

    /**
     * 
     * @return
     *     The hOUSETYPELBL
     */
    @JsonProperty("HOUSE_TYPE_LBL")
    public String getHOUSETYPELBL() {
        return hOUSETYPELBL;
    }

    /**
     * 
     * @param hOUSETYPELBL
     *     The HOUSE_TYPE_LBL
     */
    @JsonProperty("HOUSE_TYPE_LBL")
    public void setHOUSETYPELBL(String hOUSETYPELBL) {
        this.hOUSETYPELBL = hOUSETYPELBL;
    }

    /**
     * 
     * @return
     *     The rMKTYPECD
     */
    @JsonProperty("RMK_TYPE_CD")
    public String getRMKTYPECD() {
        return rMKTYPECD;
    }

    /**
     * 
     * @param rMKTYPECD
     *     The RMK_TYPE_CD
     */
    @JsonProperty("RMK_TYPE_CD")
    public void setRMKTYPECD(String rMKTYPECD) {
        this.rMKTYPECD = rMKTYPECD;
    }

    /**
     * 
     * @return
     *     The m1PICKUPACTIVITYLBL
     */
    @JsonProperty("M1_PICKUP_ACTIVITY_LBL")
    public String getM1PICKUPACTIVITYLBL() {
        return m1PICKUPACTIVITYLBL;
    }

    /**
     * 
     * @param m1PICKUPACTIVITYLBL
     *     The M1_PICKUP_ACTIVITY_LBL
     */
    @JsonProperty("M1_PICKUP_ACTIVITY_LBL")
    public void setM1PICKUPACTIVITYLBL(String m1PICKUPACTIVITYLBL) {
        this.m1PICKUPACTIVITYLBL = m1PICKUPACTIVITYLBL;
    }

    /**
     * 
     * @return
     *     The m1ITEMLOADDCLNRSNFLG
     */
    @JsonProperty("M1_ITEM_LOAD_DCLN_RSN_FLG")
    public String getM1ITEMLOADDCLNRSNFLG() {
        return m1ITEMLOADDCLNRSNFLG;
    }

    /**
     * 
     * @param m1ITEMLOADDCLNRSNFLG
     *     The M1_ITEM_LOAD_DCLN_RSN_FLG
     */
    @JsonProperty("M1_ITEM_LOAD_DCLN_RSN_FLG")
    public void setM1ITEMLOADDCLNRSNFLG(String m1ITEMLOADDCLNRSNFLG) {
        this.m1ITEMLOADDCLNRSNFLG = m1ITEMLOADDCLNRSNFLG;
    }

    /**
     * 
     * @return
     *     The m1RESENDMAILLBL
     */
    @JsonProperty("M1_RESEND_MAIL_LBL")
    public String getM1RESENDMAILLBL() {
        return m1RESENDMAILLBL;
    }

    /**
     * 
     * @param m1RESENDMAILLBL
     *     The M1_RESEND_MAIL_LBL
     */
    @JsonProperty("M1_RESEND_MAIL_LBL")
    public void setM1RESENDMAILLBL(String m1RESENDMAILLBL) {
        this.m1RESENDMAILLBL = m1RESENDMAILLBL;
    }

    /**
     * 
     * @return
     *     The m1CONTRELIGID
     */
    @JsonProperty("M1_CONTR_ELIG_ID")
    public String getM1CONTRELIGID() {
        return m1CONTRELIGID;
    }

    /**
     * 
     * @param m1CONTRELIGID
     *     The M1_CONTR_ELIG_ID
     */
    @JsonProperty("M1_CONTR_ELIG_ID")
    public void setM1CONTRELIGID(String m1CONTRELIGID) {
        this.m1CONTRELIGID = m1CONTRELIGID;
    }

    /**
     * 
     * @return
     *     The m1ENDSHIFTLBL
     */
    @JsonProperty("M1_END_SHIFT_LBL")
    public String getM1ENDSHIFTLBL() {
        return m1ENDSHIFTLBL;
    }

    /**
     * 
     * @param m1ENDSHIFTLBL
     *     The M1_END_SHIFT_LBL
     */
    @JsonProperty("M1_END_SHIFT_LBL")
    public void setM1ENDSHIFTLBL(String m1ENDSHIFTLBL) {
        this.m1ENDSHIFTLBL = m1ENDSHIFTLBL;
    }

    /**
     * 
     * @return
     *     The m1RVWTMSHDEVLBL
     */
    @JsonProperty("M1_RVW_TMSH_DEV_LBL")
    public String getM1RVWTMSHDEVLBL() {
        return m1RVWTMSHDEVLBL;
    }

    /**
     * 
     * @param m1RVWTMSHDEVLBL
     *     The M1_RVW_TMSH_DEV_LBL
     */
    @JsonProperty("M1_RVW_TMSH_DEV_LBL")
    public void setM1RVWTMSHDEVLBL(String m1RVWTMSHDEVLBL) {
        this.m1RVWTMSHDEVLBL = m1RVWTMSHDEVLBL;
    }

    /**
     * 
     * @return
     *     The m1CUSTOMERACCEPTANCELBL
     */
    @JsonProperty("M1_CUSTOMER_ACCEPTANCE_LBL")
    public String getM1CUSTOMERACCEPTANCELBL() {
        return m1CUSTOMERACCEPTANCELBL;
    }

    /**
     * 
     * @param m1CUSTOMERACCEPTANCELBL
     *     The M1_CUSTOMER_ACCEPTANCE_LBL
     */
    @JsonProperty("M1_CUSTOMER_ACCEPTANCE_LBL")
    public void setM1CUSTOMERACCEPTANCELBL(String m1CUSTOMERACCEPTANCELBL) {
        this.m1CUSTOMERACCEPTANCELBL = m1CUSTOMERACCEPTANCELBL;
    }

    /**
     * 
     * @return
     *     The m1KEEPWITHCREWLBL
     */
    @JsonProperty("M1_KEEP_WITH_CREW_LBL")
    public String getM1KEEPWITHCREWLBL() {
        return m1KEEPWITHCREWLBL;
    }

    /**
     * 
     * @param m1KEEPWITHCREWLBL
     *     The M1_KEEP_WITH_CREW_LBL
     */
    @JsonProperty("M1_KEEP_WITH_CREW_LBL")
    public void setM1KEEPWITHCREWLBL(String m1KEEPWITHCREWLBL) {
        this.m1KEEPWITHCREWLBL = m1KEEPWITHCREWLBL;
    }

    /**
     * 
     * @return
     *     The m1MEETINGINFORMATIONLBL
     */
    @JsonProperty("M1_MEETING_INFORMATION_LBL")
    public String getM1MEETINGINFORMATIONLBL() {
        return m1MEETINGINFORMATIONLBL;
    }

    /**
     * 
     * @param m1MEETINGINFORMATIONLBL
     *     The M1_MEETING_INFORMATION_LBL
     */
    @JsonProperty("M1_MEETING_INFORMATION_LBL")
    public void setM1MEETINGINFORMATIONLBL(String m1MEETINGINFORMATIONLBL) {
        this.m1MEETINGINFORMATIONLBL = m1MEETINGINFORMATIONLBL;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "COUNTRY":
                if (value instanceof String) {
                    setCOUNTRY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"COUNTRY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR1_AVAIL":
                if (value instanceof String) {
                    setADDR1AVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR1_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR2_AVAIL":
                if (value instanceof String) {
                    setADDR2AVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR2_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR3_AVAIL":
                if (value instanceof String) {
                    setADDR3AVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR3_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR4_AVAIL":
                if (value instanceof String) {
                    setADDR4AVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR4_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CITY_AVAIL":
                if (value instanceof String) {
                    setCITYAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CITY_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "VERSION":
                if (value instanceof String) {
                    setVERSION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"VERSION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "NUM1_AVAIL":
                if (value instanceof String) {
                    setNUM1AVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"NUM1_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "NUM2_AVAIL":
                if (value instanceof String) {
                    setNUM2AVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"NUM2_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "HOUSE_TYPE_AVAIL":
                if (value instanceof String) {
                    setHOUSETYPEAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"HOUSE_TYPE_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "COUNTY_AVAIL":
                if (value instanceof String) {
                    setCOUNTYAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"COUNTY_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATE_AVAIL":
                if (value instanceof String) {
                    setSTATEAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATE_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "POSTAL_AVAIL":
                if (value instanceof String) {
                    setPOSTALAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"POSTAL_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "IN_CITY_LIM_AVAIL":
                if (value instanceof String) {
                    setINCITYLIMAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"IN_CITY_LIM_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "GEO_CODE_AVAIL":
                if (value instanceof String) {
                    setGEOCODEAVAIL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"GEO_CODE_AVAIL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DESCR":
                if (value instanceof String) {
                    setDESCR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DESCR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR1_LBL":
                if (value instanceof String) {
                    setADDR1LBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR1_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR2_LBL":
                if (value instanceof String) {
                    setADDR2LBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR2_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR3_LBL":
                if (value instanceof String) {
                    setADDR3LBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR3_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDR4_LBL":
                if (value instanceof String) {
                    setADDR4LBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDR4_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CITY_LBL":
                if (value instanceof String) {
                    setCITYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CITY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "NUM1_LBL":
                if (value instanceof String) {
                    setNUM1LBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"NUM1_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "NUM2_LBL":
                if (value instanceof String) {
                    setNUM2LBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"NUM2_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "HOUSE_TYPE_LBL":
                if (value instanceof String) {
                    setHOUSETYPELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"HOUSE_TYPE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "COUNTY_LBL":
                if (value instanceof String) {
                    setCOUNTYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"COUNTY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATE_LBL":
                if (value instanceof String) {
                    setSTATELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "POSTAL_LBL":
                if (value instanceof String) {
                    setPOSTALLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"POSTAL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "IN_CITY_LIM_LBL":
                if (value instanceof String) {
                    setINCITYLIMLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"IN_CITY_LIM_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "GEO_CODE_LBL":
                if (value instanceof String) {
                    setGEOCODELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"GEO_CODE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATE":
                if (value instanceof String) {
                    setSTATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BUS_OBJ_CD":
                if (value instanceof String) {
                    setBUSOBJCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BUS_OBJ_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BO_STATUS_BO_CD":
                if (value instanceof String) {
                    setBOSTATUSBOCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BO_STATUS_BO_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BO_STATUS_CD":
                if (value instanceof String) {
                    setBOSTATUSCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BO_STATUS_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BO_STATUS_REASON_CD":
                if (value instanceof String) {
                    setBOSTATUSREASONCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BO_STATUS_REASON_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATUS_REASON_SELECT_FLG":
                if (value instanceof String) {
                    setSTATUSREASONSELECTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATUS_REASON_SELECT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STATUS_REASON_USAGE_FLG":
                if (value instanceof String) {
                    setM1STATUSREASONUSAGEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STATUS_REASON_USAGE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADHOC_CHAR_VAL":
                if (value instanceof String) {
                    setADHOCCHARVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADHOC_CHAR_VAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATUS_RSN_USAGE":
                if (value instanceof String) {
                    setSTATUSRSNUSAGE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATUS_RSN_USAGE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_VAL":
                if (value instanceof String) {
                    setCHARVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_VAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RMK_TYPE_CD":
                if (value instanceof String) {
                    setRMKTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"RMK_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SVC_CLS_CD":
                if (value instanceof String) {
                    setSVCCLSCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SVC_CLS_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_TYPE":
                if (value instanceof String) {
                    setM1ACTIVITYTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TASK_TYPE_CD":
                if (value instanceof String) {
                    setTASKTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TASK_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_TYPE_CD":
                if (value instanceof String) {
                    setCHARTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_TYPE_CD":
                if (value instanceof String) {
                    setPROCEDURETYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_VAL_FK1":
                if (value instanceof String) {
                    setCHARVALFK1(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_VAL_FK1\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SEQ_NUM":
                if (value instanceof String) {
                    setSEQNUM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SEQ_NUM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIMESHEET_TYPE_CD":
                if (value instanceof String) {
                    setTIMESHEETTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TIMESHEET_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TMSHEET_BO_CD":
                if (value instanceof String) {
                    setTMSHEETBOCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TMSHEET_BO_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PERCENTAGE_DEVIATION":
                if (value instanceof String) {
                    setM1PERCENTAGEDEVIATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PERCENTAGE_DEVIATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BO_DATA_AREA":
                if (value instanceof String) {
                    setBODATAAREA(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BO_DATA_AREA\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATUS_FLG":
                if (value instanceof String) {
                    setSTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_BO":
                if (value instanceof String) {
                    setM1ACTIVITYBO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_BO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TASK_BUS_OBJ_CD":
                if (value instanceof String) {
                    setTASKBUSOBJCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TASK_BUS_OBJ_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TASK_CLS_FLG":
                if (value instanceof String) {
                    setTASKCLSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TASK_CLS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "HOST_SYSTEM_CD":
                if (value instanceof String) {
                    setHOSTSYSTEMCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"HOST_SYSTEM_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "HOST_REF_CD":
                if (value instanceof String) {
                    setHOSTREFCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"HOST_REF_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AVG_DUR":
                if (value instanceof String) {
                    setM1AVGDUR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AVG_DUR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "AVG_DUR":
                if (value instanceof String) {
                    setAVGDUR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"AVG_DUR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EFF_DUR_IMPACT":
                if (value instanceof String) {
                    setM1EFFDURIMPACT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EFF_DUR_IMPACT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_ALLOCATION_FLG":
                if (value instanceof String) {
                    setM1AUTOALLOCATIONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AUTO_ALLOCATION_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_ALLOCATION_DAYS":
                if (value instanceof String) {
                    setM1AUTOALLOCATIONDAYS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AUTO_ALLOCATION_DAYS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_ALLOCATION_DUR":
                if (value instanceof String) {
                    setM1AUTOALLOCATIONDUR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AUTO_ALLOCATION_DUR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "AUTO_DISPATCH_FLG":
                if (value instanceof String) {
                    setAUTODISPATCHFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"AUTO_DISPATCH_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ELIGIBLE_ASSIST_FLG":
                if (value instanceof String) {
                    setM1ELIGIBLEASSISTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ELIGIBLE_ASSIST_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ELGB_CONTRACTING_FLG":
                if (value instanceof String) {
                    setM1ELGBCONTRACTINGFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ELGB_CONTRACTING_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ACKNOWLEDGEMENT_REQ_FLG":
                if (value instanceof String) {
                    setACKNOWLEDGEMENTREQFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ACKNOWLEDGEMENT_REQ_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_IGNORE_SEQ_LOCK_FLG":
                if (value instanceof String) {
                    setM1IGNORESEQLOCKFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_IGNORE_SEQ_LOCK_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "QUEUE_FLG":
                if (value instanceof String) {
                    setQUEUEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"QUEUE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PRI_PROF_CD":
                if (value instanceof String) {
                    setPRIPROFCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PRI_PROF_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DFL_APPT_BOOK_GRP":
                if (value instanceof String) {
                    setDFLAPPTBOOKGRP(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DFL_APPT_BOOK_GRP\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WORK_PROFILE_CD":
                if (value instanceof String) {
                    setM1WORKPROFILECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WORK_PROFILE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_TYPE_WORK_CALENDAR":
                if (value instanceof String) {
                    setM1ACTIVITYTYPEWORKCALENDAR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_TYPE_WORK_CALENDAR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CALENDAR_CD":
                if (value instanceof String) {
                    setCALENDARCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CALENDAR_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETE_OPTION_FLG":
                if (value instanceof String) {
                    setM1COMPLETEOPTIONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETE_OPTION_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETE_WITHIN_DAYS":
                if (value instanceof String) {
                    setM1COMPLETEWITHINDAYS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETE_WITHIN_DAYS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETE_WITHIN_TIME":
                if (value instanceof String) {
                    setM1COMPLETEWITHINTIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETE_WITHIN_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_SIZE":
                if (value instanceof String) {
                    setM1CREWSIZE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_SIZE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PRE_TIME_FAC":
                if (value instanceof String) {
                    setM1PRETIMEFAC(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PRE_TIME_FAC\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCHED_PRIORITY":
                if (value instanceof String) {
                    setM1SCHEDPRIORITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCHED_PRIORITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_CLASS_FLG":
                if (value instanceof String) {
                    setM1ACTIVITYCLASSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_CLASS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_BREAKS_FLG":
                if (value instanceof String) {
                    setM1ALLOWBREAKSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALLOW_BREAKS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_CREW_TIME_FLG":
                if (value instanceof String) {
                    setM1ALLOWCREWTIMEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALLOW_CREW_TIME_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_EARNING_TIME_FLG":
                if (value instanceof String) {
                    setM1ALLOWEARNINGTIMEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALLOW_EARNING_TIME_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CAP_TYPE_CD":
                if (value instanceof String) {
                    setCAPTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CAP_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COUNT":
                if (value instanceof String) {
                    setM1COUNT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COUNT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAP_TYPE_USAGE_FLG":
                if (value instanceof String) {
                    setM1CAPTYPEUSAGEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAP_TYPE_USAGE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VALID_REMARK_TYPES":
                if (value instanceof String) {
                    setM1VALIDREMARKTYPES(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VALID_REMARK_TYPES\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REMARK_TYPE":
                if (value instanceof String) {
                    setM1REMARKTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REMARK_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SORT_SEQUENCE":
                if (value instanceof String) {
                    setM1SORTSEQUENCE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SORT_SEQUENCE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_EXP_LBL":
                if (value instanceof String) {
                    setM1ACTIVITYEXPLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_EXP_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_EXTENSION":
                if (value instanceof String) {
                    setM1AUTOEXTENSION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AUTO_EXTENSION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXTENSION_DAYS":
                if (value instanceof String) {
                    setM1EXTENSIONDAYS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXTENSION_DAYS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXTENSION_DURATION":
                if (value instanceof String) {
                    setM1EXTENSIONDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXTENSION_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXTENSION_LIMIT":
                if (value instanceof String) {
                    setM1EXTENSIONLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXTENSION_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_CANCEL":
                if (value instanceof String) {
                    setM1AUTOCANCEL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AUTO_CANCEL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AFTER_DAYS":
                if (value instanceof String) {
                    setM1AFTERDAYS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AFTER_DAYS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AFTER_DURATION":
                if (value instanceof String) {
                    setM1AFTERDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AFTER_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_TYPE_TODO":
                if (value instanceof String) {
                    setM1ACTIVITYTYPETODO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_TYPE_TODO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ISSUE_DETECTED_TODO_TYPE":
                if (value instanceof String) {
                    setM1ISSUEDETECTEDTODOTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ISSUE_DETECTED_TODO_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ISSUE_DETECTED_TODO_ROLE":
                if (value instanceof String) {
                    setM1ISSUEDETECTEDTODOROLE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ISSUE_DETECTED_TODO_ROLE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COLLISION_DETECTED_TODO_TYP":
                if (value instanceof String) {
                    setM1COLLISIONDETECTEDTODOTYP(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COLLISION_DETECTED_TODO_TYP\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COLLISION_DETECTED_TODO_ROL":
                if (value instanceof String) {
                    setM1COLLISIONDETECTEDTODOROL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COLLISION_DETECTED_TODO_ROL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXPIRATION_TD_TYPE":
                if (value instanceof String) {
                    setM1EXPIRATIONTDTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXPIRATION_TD_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXPIRATION_TD_ROLE":
                if (value instanceof String) {
                    setM1EXPIRATIONTDROLE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXPIRATION_TD_ROLE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SVC_CATEGORY_CD":
                if (value instanceof String) {
                    setM1SVCCATEGORYCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SVC_CATEGORY_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SVC_TYPE_FLG":
                if (value instanceof String) {
                    setM1SVCTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SVC_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESPONSE_TIME_SLA":
                if (value instanceof String) {
                    setM1RESPONSETIMESLA(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESPONSE_TIME_SLA\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TRAVEL_TIMESHEET_TYPE":
                if (value instanceof String) {
                    setTRAVELTIMESHEETTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TRAVEL_TIMESHEET_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIMESHEET_TM_TYPE_CD":
                if (value instanceof String) {
                    setTIMESHEETTMTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TIMESHEET_TM_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_EXT_LOOKUP_VALUE":
                if (value instanceof String) {
                    setF1EXTLOOKUPVALUE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_EXT_LOOKUP_VALUE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DESCR_OVRD":
                if (value instanceof String) {
                    setDESCROVRD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DESCR_OVRD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DESCRLONG":
                if (value instanceof String) {
                    setDESCRLONG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DESCRLONG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_EXT_LOOKUP_USAGE_FLG":
                if (value instanceof String) {
                    setF1EXTLOOKUPUSAGEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_EXT_LOOKUP_USAGE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OWNER_FLG":
                if (value instanceof String) {
                    setOWNERFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"OWNER_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "WORK_TIMESHEET_TYPE":
                if (value instanceof String) {
                    setWORKTIMESHEETTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"WORK_TIMESHEET_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_CLEARANCE_REQ_FLG":
                if (value instanceof String) {
                    setPROCEDURECLEARANCEREQFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_CLEARANCE_REQ_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UPTO_BUS_PRI_VAL":
                if (value instanceof String) {
                    setM1UPTOBUSPRIVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UPTO_BUS_PRI_VAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCHED_PRIORITY_VAL":
                if (value instanceof String) {
                    setM1SCHEDPRIORITYVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCHED_PRIORITY_VAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREATE_BY_CREW_FLG":
                if (value instanceof String) {
                    setM1CREATEBYCREWFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREATE_BY_CREW_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALLOW_RELATED_ACTIVITIES":
                if (value instanceof String) {
                    setM1ALLOWRELATEDACTIVITIES(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALLOW_RELATED_ACTIVITIES\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RELATED_ACTIVITY_TYPES":
                if (value instanceof String) {
                    setM1RELATEDACTIVITYTYPES(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RELATED_ACTIVITY_TYPES\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GANTT_DISPLAY_ICON_LBL":
                if (value instanceof String) {
                    setM1GANTTDISPLAYICONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GANTT_DISPLAY_ICON_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREWINQUIRY_TYPE":
                if (value instanceof String) {
                    setM1CREWINQUIRYTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREWINQUIRY_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_ACT_CLASS_FLG":
                if (value instanceof String) {
                    setM1DEPOTACTCLASSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_ACT_CLASS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POU_TASK_TYPE":
                if (value instanceof String) {
                    setM1POUTASKTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POU_TASK_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POU_TASK_BO":
                if (value instanceof String) {
                    setM1POUTASKBO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POU_TASK_BO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "POU_TIMESHEET_TYPE":
                if (value instanceof String) {
                    setPOUTIMESHEETTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"POU_TIMESHEET_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LATE_COST":
                if (value instanceof String) {
                    setM1LATECOST(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LATE_COST\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_TYPE":
                if (value instanceof String) {
                    setM1DEPOTTASKTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_BO":
                if (value instanceof String) {
                    setM1DEPOTTASKBO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_BO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DEPOT_TIMESHEET_TYPE":
                if (value instanceof String) {
                    setDEPOTTIMESHEETTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DEPOT_TIMESHEET_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_LOAD_ORDER_FLG":
                if (value instanceof String) {
                    setM1DEPOTTASKLOADORDERFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_LOAD_ORDER_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SAME_CREW_FLG":
                if (value instanceof String) {
                    setM1SAMECREWFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SAME_CREW_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MIN_VISIT_DURATION":
                if (value instanceof String) {
                    setM1MINVISITDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MIN_VISIT_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AVG_VISIT_DURATION":
                if (value instanceof String) {
                    setM1AVGVISITDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AVG_VISIT_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DUR_EXTENSION_LIMIT":
                if (value instanceof String) {
                    setM1DUREXTENSIONLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DUR_EXTENSION_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BRK_TYPE":
                if (value instanceof String) {
                    setM1BRKTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BRK_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BRK_WINDOW_DUR":
                if (value instanceof String) {
                    setM1BRKWINDOWDUR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BRK_WINDOW_DUR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BRK_DUR":
                if (value instanceof String) {
                    setM1BRKDUR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BRK_DUR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BREAK_TIMESHEET_TYPE":
                if (value instanceof String) {
                    setBREAKTIMESHEETTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BREAK_TIMESHEET_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STRICT_TIME_FLG":
                if (value instanceof String) {
                    setM1STRICTTIMEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STRICT_TIME_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BREAK_BO":
                if (value instanceof String) {
                    setM1BREAKBO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BREAK_BO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NON_PRD_TASK_BO":
                if (value instanceof String) {
                    setM1NONPRDTASKBO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NON_PRD_TASK_BO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WINDOW_DURATION":
                if (value instanceof String) {
                    setM1WINDOWDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WINDOW_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DURATION":
                if (value instanceof String) {
                    setM1DURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOC_OPT_FLG":
                if (value instanceof String) {
                    setM1LOCOPTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOC_OPT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "NPT_TIMESHEET_TYPE":
                if (value instanceof String) {
                    setNPTTIMESHEETTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"NPT_TIMESHEET_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "EXT_SYS_TYP_FLG":
                if (value instanceof String) {
                    setEXTSYSTYPFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"EXT_SYS_TYP_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "WFM_NAME":
                if (value instanceof String) {
                    setWFMNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"WFM_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MESSAGE_NBR":
                if (value instanceof String) {
                    setMESSAGENBR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MESSAGE_NBR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MESSAGE_CAT_NBR":
                if (value instanceof String) {
                    setMESSAGECATNBR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MESSAGE_CAT_NBR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "WFM_MSG_CD":
                if (value instanceof String) {
                    setWFMMSGCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"WFM_MSG_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "WFM_MSG_CAT_FLG":
                if (value instanceof String) {
                    setWFMMSGCATFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"WFM_MSG_CAT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "EXT_OPT_TYPE":
                if (value instanceof String) {
                    setEXTOPTTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"EXT_OPT_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "WFM_OPT_VAL":
                if (value instanceof String) {
                    setWFMOPTVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"WFM_OPT_VAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OUTMSG_TYPE_CD":
                if (value instanceof String) {
                    setOUTMSGTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"OUTMSG_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OUTMSG_PRIOR_FLG":
                if (value instanceof String) {
                    setOUTMSGPRIORFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"OUTMSG_PRIOR_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_ID":
                if (value instanceof String) {
                    setM1ACTIVITYID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TASK_ID":
                if (value instanceof String) {
                    setTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BUS_PRI_NBR":
                if (value instanceof String) {
                    setM1BUSPRINBR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BUS_PRI_NBR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OVERRIDE_ALLOCATION_RULE":
                if (value instanceof String) {
                    setOVERRIDEALLOCATIONRULE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"OVERRIDE_ALLOCATION_RULE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ALLOCATION_RULE_FLG":
                if (value instanceof String) {
                    setALLOCATIONRULEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ALLOCATION_RULE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STATUS_UPD_DTTM":
                if (value instanceof String) {
                    setSTATUSUPDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STATUS_UPD_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ESTIMATED_DURATION":
                if (value instanceof String) {
                    setM1ESTIMATEDDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ESTIMATED_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ESTIMATED_DURATION":
                if (value instanceof String) {
                    setESTIMATEDDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ESTIMATED_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TASK_ALT_ID":
                if (value instanceof String) {
                    setTASKALTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TASK_ALT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MAN_ALLOC_TO_SHIFT":
                if (value instanceof String) {
                    setMANALLOCTOSHIFT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MAN_ALLOC_TO_SHIFT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAPACITY_PREFERRED_FLG":
                if (value instanceof String) {
                    setM1CAPACITYPREFERREDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAPACITY_PREFERRED_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONTR_ELIG_ID":
                if (value instanceof String) {
                    setM1CONTRELIGID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONTR_ELIG_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONTR_ELIG_VERSION":
                if (value instanceof String) {
                    setM1CONTRELIGVERSION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONTR_ELIG_VERSION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONTRACTOR_ID":
                if (value instanceof String) {
                    setM1CONTRACTORID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONTRACTOR_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "HOST_EXTERNAL_ID":
                if (value instanceof String) {
                    setHOSTEXTERNALID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"HOST_EXTERNAL_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "HOST_TASK_ID":
                if (value instanceof String) {
                    setHOSTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"HOST_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_COMMENTS":
                if (value instanceof String) {
                    setM1ACTIVITYCOMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CUST_NAME":
                if (value instanceof String) {
                    setCUSTNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CUST_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONTACT_NAME":
                if (value instanceof String) {
                    setM1CONTACTNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONTACT_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAIN_PHONE":
                if (value instanceof String) {
                    setM1MAINPHONE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAIN_PHONE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CELL_PHONE":
                if (value instanceof String) {
                    setM1CELLPHONE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CELL_PHONE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACCOUNT_ID":
                if (value instanceof String) {
                    setM1ACCOUNTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACCOUNT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PERSON_ID":
                if (value instanceof String) {
                    setM1PERSONID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PERSON_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SITE_ID":
                if (value instanceof String) {
                    setM1SITEID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SITE_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_1":
                if (value instanceof String) {
                    setM1ADDRESS1(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_1\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDRESS1":
                if (value instanceof String) {
                    setADDRESS1(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDRESS1\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDRESS2":
                if (value instanceof String) {
                    setADDRESS2(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDRESS2\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDRESS3":
                if (value instanceof String) {
                    setADDRESS3(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDRESS3\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADDRESS4":
                if (value instanceof String) {
                    setADDRESS4(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADDRESS4\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CROSS_STREET":
                if (value instanceof String) {
                    setCROSSSTREET(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CROSS_STREET\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SUBURB":
                if (value instanceof String) {
                    setSUBURB(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SUBURB\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_CITY":
                if (value instanceof String) {
                    setM1ADDRESSCITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_CITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CITY":
                if (value instanceof String) {
                    setCITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_COUNTY":
                if (value instanceof String) {
                    setM1ADDRESSCOUNTY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_COUNTY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "COUNTY":
                if (value instanceof String) {
                    setCOUNTY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"COUNTY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "POSTAL":
                if (value instanceof String) {
                    setPOSTAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"POSTAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "GEO_LAT":
                if (value instanceof String) {
                    setGEOLAT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"GEO_LAT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "GEO_LONG":
                if (value instanceof String) {
                    setGEOLONG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"GEO_LONG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "INSTR":
                if (value instanceof String) {
                    setINSTR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"INSTR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SVC_AREA_CD":
                if (value instanceof String) {
                    setSVCAREACD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SVC_AREA_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIME_ZONE_CD":
                if (value instanceof String) {
                    setTIMEZONECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TIME_ZONE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "APPOINTMENT_FLG":
                if (value instanceof String) {
                    setAPPOINTMENTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"APPOINTMENT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TAKEN_BY":
                if (value instanceof String) {
                    setM1TAKENBY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TAKEN_BY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TAKEN_DATE":
                if (value instanceof String) {
                    setM1TAKENDATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TAKEN_DATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMMENT":
                if (value instanceof String) {
                    setM1COMMENT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMMENT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPT_REQ_FLG":
                if (value instanceof String) {
                    setM1APPTREQFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_APPT_REQ_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_KEY_ID":
                if (value instanceof String) {
                    setM1KEYID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_KEY_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OR_TASK_CAPABILITY_FLG":
                if (value instanceof String) {
                    setM1ORTASKCAPABILITYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OR_TASK_CAPABILITY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "EXT_CAP_TYPE_CD":
                if (value instanceof String) {
                    setEXTCAPTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"EXT_CAP_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TRANSPORT_RESTRICTION_FLG":
                if (value instanceof String) {
                    setM1TRANSPORTRESTRICTIONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TRANSPORT_RESTRICTION_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LIFE_SPAN":
                if (value instanceof String) {
                    setM1LIFESPAN(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LIFE_SPAN\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_DELAY":
                if (value instanceof String) {
                    setM1DEPOTDELAY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_DELAY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUMULATIVE_CAPACITY_FLG":
                if (value instanceof String) {
                    setM1CUMULATIVECAPACITYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUMULATIVE_CAPACITY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TRANSFER_TYPE_FLG":
                if (value instanceof String) {
                    setM1TRANSFERTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TRANSFER_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAPACITY_VAL":
                if (value instanceof String) {
                    setM1CAPACITYVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAPACITY_VAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NONCUM_CAPACITY_FLG":
                if (value instanceof String) {
                    setM1NONCUMCAPACITYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NONCUM_CAPACITY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOCKED_TO_DEPOT_TASK_ID":
                if (value instanceof String) {
                    setM1LOCKEDTODEPOTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOCKED_TO_DEPOT_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_ATTRIBUTE":
                if (value instanceof String) {
                    setM1ACTIVITYATTRIBUTE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_ATTRIBUTE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_ATTRIB_USAGE_FLG":
                if (value instanceof String) {
                    setM1ACTIVITYATTRIBUSAGEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_ATTRIB_USAGE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_CD":
                if (value instanceof String) {
                    setM1DEPOTCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOAD_INSTR":
                if (value instanceof String) {
                    setM1LOADINSTR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOAD_INSTR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SITE_DELAY":
                if (value instanceof String) {
                    setM1SITEDELAY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SITE_DELAY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SEQNO":
                if (value instanceof String) {
                    setSEQNO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SEQNO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TSK_TM_WIND_START_DTTM":
                if (value instanceof String) {
                    setTSKTMWINDSTARTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TSK_TM_WIND_START_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TSK_TM_WIND_END_DTTM":
                if (value instanceof String) {
                    setTSKTMWINDENDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TSK_TM_WIND_END_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIME_WINDOW_USAGE_FLG":
                if (value instanceof String) {
                    setTIMEWINDOWUSAGEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TIME_WINDOW_USAGE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIME_WINDOW_SOURCE_FLG":
                if (value instanceof String) {
                    setM1TIMEWINDOWSOURCEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIME_WINDOW_SOURCE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WINDOW_MODE_FLG":
                if (value instanceof String) {
                    setM1WINDOWMODEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WINDOW_MODE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_LATE":
                if (value instanceof String) {
                    setM1MAXLATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAX_LATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WINDOW_COST":
                if (value instanceof String) {
                    setM1WINDOWCOST(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WINDOW_COST\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SLA_FLEXIBILITY":
                if (value instanceof String) {
                    setM1SLAFLEXIBILITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SLA_FLEXIBILITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NUM_OF_EXTENSIONS":
                if (value instanceof String) {
                    setM1NUMOFEXTENSIONS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NUM_OF_EXTENSIONS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEFERMENT_REASON_FLG":
                if (value instanceof String) {
                    setM1DEFERMENTREASONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEFERMENT_REASON_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEFERMENT_COMMENTS":
                if (value instanceof String) {
                    setM1DEFERMENTCOMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEFERMENT_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SEQ_NUM_WRK":
                if (value instanceof String) {
                    setM1SEQNUMWRK(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SEQ_NUM_WRK\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ELEM_XPATH":
                if (value instanceof String) {
                    setM1ELEMXPATH(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ELEM_XPATH\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ELEM_INDEX":
                if (value instanceof String) {
                    setM1ELEMINDEX(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ELEM_INDEX\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MESSAGE_PARM_CNT":
                if (value instanceof String) {
                    setMESSAGEPARMCNT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MESSAGE_PARM_CNT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MSG_PARM_TYP_FLG":
                if (value instanceof String) {
                    setMSGPARMTYPFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MSG_PARM_TYP_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_MSG_PARM_VLONG":
                if (value instanceof String) {
                    setF1MSGPARMVLONG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_MSG_PARM_VLONG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETED_BY_ASSIGNMENT_ID":
                if (value instanceof String) {
                    setM1COMPLETEDBYASSIGNMENTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETED_BY_ASSIGNMENT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREATION_DTTM":
                if (value instanceof String) {
                    setM1CREATIONDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREATION_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CRE_DTTM":
                if (value instanceof String) {
                    setCREDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CRE_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FINALIZED_DTTM":
                if (value instanceof String) {
                    setM1FINALIZEDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FINALIZED_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FINAL_DTTM":
                if (value instanceof String) {
                    setM1FINALDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FINAL_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PENDING_CANCEL_SW":
                if (value instanceof String) {
                    setM1PENDINGCANCELSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PENDING_CANCEL_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PENDING_DISPATCH_APPROVAL":
                if (value instanceof String) {
                    setM1PENDINGDISPATCHAPPROVAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PENDING_DISPATCH_APPROVAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREATED_BY_CREW_SW":
                if (value instanceof String) {
                    setM1CREATEDBYCREWSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREATED_BY_CREW_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_HOST_JOB_EXTERNAL_ID":
                if (value instanceof String) {
                    setM1HOSTJOBEXTERNALID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_HOST_JOB_EXTERNAL_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_JOB_ID":
                if (value instanceof String) {
                    setM1JOBID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_JOB_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCHEDULING_ORDER":
                if (value instanceof String) {
                    setM1SCHEDULINGORDER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCHEDULING_ORDER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPENDENCY_TYPE_FLG":
                if (value instanceof String) {
                    setM1DEPENDENCYTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPENDENCY_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_HOST_PARENT_EXT_ID":
                if (value instanceof String) {
                    setM1HOSTPARENTEXTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_HOST_PARENT_EXT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_HOST_CHAIN_EXT_ID":
                if (value instanceof String) {
                    setM1HOSTCHAINEXTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_HOST_CHAIN_EXT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPENDENT_ON":
                if (value instanceof String) {
                    setM1DEPENDENTON(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPENDENT_ON\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PARENT_TASK_ID":
                if (value instanceof String) {
                    setPARENTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PARENT_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIMING_OPTION_FLG":
                if (value instanceof String) {
                    setM1TIMINGOPTIONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIMING_OPTION_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MIN_OFFSET":
                if (value instanceof String) {
                    setM1MINOFFSET(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MIN_OFFSET\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_OFFSET":
                if (value instanceof String) {
                    setM1MAXOFFSET(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAX_OFFSET\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESOURCE_OPTION_FLG":
                if (value instanceof String) {
                    setM1RESOURCEOPTIONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESOURCE_OPTION_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPENDENCY_RSN_FLG":
                if (value instanceof String) {
                    setM1DEPENDENCYRSNFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPENDENCY_RSN_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESTRICTION_TYPE_FLG":
                if (value instanceof String) {
                    setM1RESTRICTIONTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESTRICTION_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESTRICTION_VALUE":
                if (value instanceof String) {
                    setM1RESTRICTIONVALUE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESTRICTION_VALUE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RANK":
                if (value instanceof String) {
                    setM1RANK(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RANK\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DATA_SRC_IND":
                if (value instanceof String) {
                    setM1DATASRCIND(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DATA_SRC_IND\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXT_ENTITY_NAME":
                if (value instanceof String) {
                    setM1EXTENTITYNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXT_ENTITY_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EXT_ENTITY_VALUE":
                if (value instanceof String) {
                    setM1EXTENTITYVALUE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EXT_ENTITY_VALUE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "FIXED_CREW":
                if (value instanceof String) {
                    setFIXEDCREW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"FIXED_CREW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ORGJB_LBL":
                if (value instanceof String) {
                    setM1ORGJBLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ORGJB_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NOTIFY_HOST_OF_DISPATCH":
                if (value instanceof String) {
                    setM1NOTIFYHOSTOFDISPATCH(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NOTIFY_HOST_OF_DISPATCH\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NOTIFY_HOST_OF_STATUS":
                if (value instanceof String) {
                    setM1NOTIFYHOSTOFSTATUS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NOTIFY_HOST_OF_STATUS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NOTIFY_HOST_COMPLETION_ONLY":
                if (value instanceof String) {
                    setM1NOTIFYHOSTCOMPLETIONONLY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NOTIFY_HOST_COMPLETION_ONLY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ASSIGNMENT_ID":
                if (value instanceof String) {
                    setM1ASSIGNMENTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ASSIGNMENT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "BUS_STATUS_DTTM":
                if (value instanceof String) {
                    setBUSSTATUSDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"BUS_STATUS_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PARENT_TASK_ID":
                if (value instanceof String) {
                    setM1PARENTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PARENT_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_ALTERNATE_ID":
                if (value instanceof String) {
                    setM1ACTIVITYALTERNATEID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_ALTERNATE_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PARENT_TASK_ALT_ID":
                if (value instanceof String) {
                    setPARENTTASKALTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PARENT_TASK_ALT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SHIFT_ID":
                if (value instanceof String) {
                    setM1SHIFTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SHIFT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ASSIGNED_ENGINEER":
                if (value instanceof String) {
                    setM1ASSIGNEDENGINEER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ASSIGNED_ENGINEER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTUAL_ARR_DTTM":
                if (value instanceof String) {
                    setM1ACTUALARRDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTUAL_ARR_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTUAL_START_TIME":
                if (value instanceof String) {
                    setM1ACTUALSTARTTIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTUAL_START_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTUAL_COMPLETION_TIME":
                if (value instanceof String) {
                    setM1ACTUALCOMPLETIONTIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTUAL_COMPLETION_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TRAVELTIME_DURATION":
                if (value instanceof String) {
                    setM1TRAVELTIMEDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TRAVELTIME_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TRAVEL_DISTANCE":
                if (value instanceof String) {
                    setM1TRAVELDISTANCE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TRAVEL_DISTANCE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RT_DST_UNIT_FLG":
                if (value instanceof String) {
                    setM1RTDSTUNITFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RT_DST_UNIT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BREAK_TIME":
                if (value instanceof String) {
                    setM1BREAKTIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BREAK_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TAG":
                if (value instanceof String) {
                    setM1TAG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TAG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPROVAL_DTTM_LBL":
                if (value instanceof String) {
                    setM1APPROVALDTTMLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_APPROVAL_DTTM_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPT_ST_DTTM":
                if (value instanceof String) {
                    setM1APPTSTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_APPT_ST_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPT_END_DTTM":
                if (value instanceof String) {
                    setM1APPTENDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_APPT_END_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WORK_SEQ":
                if (value instanceof String) {
                    setM1WORKSEQ(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WORK_SEQ\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CALC_TRVL_TM":
                if (value instanceof String) {
                    setM1CALCTRVLTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CALC_TRVL_TM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CALC_TRVL_DIST":
                if (value instanceof String) {
                    setM1CALCTRVLDIST(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CALC_TRVL_DIST\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTUAL_ST_DTTM":
                if (value instanceof String) {
                    setM1ACTUALSTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTUAL_ST_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTUAL_COM_DTTM":
                if (value instanceof String) {
                    setM1ACTUALCOMDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTUAL_COM_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_ID":
                if (value instanceof String) {
                    setM1DEPOTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RT_DST_UNIT_ABBR_FLG":
                if (value instanceof String) {
                    setM1RTDSTUNITABBRFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RT_DST_UNIT_ABBR_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UPDATED_ETA":
                if (value instanceof String) {
                    setM1UPDATEDETA(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UPDATED_ETA\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAC_REMAINING_DURATION":
                if (value instanceof String) {
                    setM1CACREMAININGDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAC_REMAINING_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAC_EXTENSION_LOW_LIMIT":
                if (value instanceof String) {
                    setM1CACEXTENSIONLOWLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAC_EXTENSION_LOW_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAC_EXTENSION_HIGH_LIMIT":
                if (value instanceof String) {
                    setM1CACEXTENSIONHIGHLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAC_EXTENSION_HIGH_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POSTPONE_DTTM_NO_DEFAULT_SW":
                if (value instanceof String) {
                    setM1POSTPONEDTTMNODEFAULTSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POSTPONE_DTTM_NO_DEFAULT_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POSTPONE_DTTM":
                if (value instanceof String) {
                    setM1POSTPONEDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POSTPONE_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EST_REMAINING_DURATION":
                if (value instanceof String) {
                    setM1ESTREMAININGDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EST_REMAINING_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMMENTS":
                if (value instanceof String) {
                    setM1COMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DISPATCH_DTTM":
                if (value instanceof String) {
                    setM1DISPATCHDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DISPATCH_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ENROUTE_DTTM":
                if (value instanceof String) {
                    setENROUTEDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ENROUTE_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ARRD_DTTM":
                if (value instanceof String) {
                    setARRDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ARRD_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ON_SITE_DATE":
                if (value instanceof String) {
                    setM1ONSITEDATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ON_SITE_DATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUSTOMER_CONTACT_TYPE_CD":
                if (value instanceof String) {
                    setM1CUSTOMERCONTACTTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUSTOMER_CONTACT_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUST_CONTACT_TYPE_MAIN_LBL":
                if (value instanceof String) {
                    setM1CUSTCONTACTTYPEMAINLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUST_CONTACT_TYPE_MAIN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUSTOMER_CONTACT_COMMENTS":
                if (value instanceof String) {
                    setM1CUSTOMERCONTACTCOMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUSTOMER_CONTACT_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TO_DO_MESSAGE":
                if (value instanceof String) {
                    setM1TODOMESSAGE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TO_DO_MESSAGE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_TM_USG_CD":
                if (value instanceof String) {
                    setM1CREWTMUSGCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_TM_USG_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_TIM_UGG_DIM_MAIN_LBL":
                if (value instanceof String) {
                    setM1CREWTIMUGGDIMMAINLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_TIM_UGG_DIM_MAIN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_TM_USG_CLS_FLG":
                if (value instanceof String) {
                    setM1CREWTMUSGCLSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_TM_USG_CLS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CALC_DURATION":
                if (value instanceof String) {
                    setM1CALCDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CALC_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADJUSTED_DURATION":
                if (value instanceof String) {
                    setM1ADJUSTEDDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADJUSTED_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EARNING_TYPE":
                if (value instanceof String) {
                    setM1EARNINGTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EARNING_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EARNING_TYPE_EXT_ID":
                if (value instanceof String) {
                    setM1EARNINGTYPEEXTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EARNING_TYPE_EXT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVERTIME_TYPE_EXT_ID":
                if (value instanceof String) {
                    setM1OVERTIMETYPEEXTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVERTIME_TYPE_EXT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CREW_SHFT_TYPE_CD":
                if (value instanceof String) {
                    setCREWSHFTTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CREW_SHFT_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RESRC_ID":
                if (value instanceof String) {
                    setRESRCID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"RESRC_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RESRC_CLASS_FLG":
                if (value instanceof String) {
                    setRESRCCLASSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"RESRC_CLASS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONTRACTOR_LBL":
                if (value instanceof String) {
                    setM1CONTRACTORLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONTRACTOR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PARENT_ASSIGNMENT_ID":
                if (value instanceof String) {
                    setM1PARENTASSIGNMENTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PARENT_ASSIGNMENT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PICKUP_SEQUENCE_NUMBER":
                if (value instanceof String) {
                    setM1PICKUPSEQUENCENUMBER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PICKUP_SEQUENCE_NUMBER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WORK_BY_DATE":
                if (value instanceof String) {
                    setM1WORKBYDATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WORK_BY_DATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PICKUP_STATUS_FLG":
                if (value instanceof String) {
                    setM1PICKUPSTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PICKUP_STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIME_REMAINING":
                if (value instanceof String) {
                    setM1TIMEREMAINING(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIME_REMAINING\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIME_REMAINING_AS_OF_DTTM":
                if (value instanceof String) {
                    setM1TIMEREMAININGASOFDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIME_REMAINING_AS_OF_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_KEEP_WITH_CREW_LBL":
                if (value instanceof String) {
                    setM1KEEPWITHCREWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_KEEP_WITH_CREW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_COMPLETE_FLG":
                if (value instanceof String) {
                    setM1ACTIVITYCOMPLETEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_COMPLETE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVERRIDE_DURATION":
                if (value instanceof String) {
                    setM1OVERRIDEDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVERRIDE_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVRD_EXTENSION_LIMIT_FLG":
                if (value instanceof String) {
                    setM1OVRDEXTENSIONLIMITFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVRD_EXTENSION_LIMIT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WORK_DURATION":
                if (value instanceof String) {
                    setM1WORKDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WORK_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "LOG_ENTRY_TYPE_FLG":
                if (value instanceof String) {
                    setLOGENTRYTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"LOG_ENTRY_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MOB_LOG_DTTM":
                if (value instanceof String) {
                    setMOBLOGDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MOB_LOG_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_VAL_FK2":
                if (value instanceof String) {
                    setCHARVALFK2(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_VAL_FK2\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_VAL_FK3":
                if (value instanceof String) {
                    setCHARVALFK3(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_VAL_FK3\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_VAL_FK4":
                if (value instanceof String) {
                    setCHARVALFK4(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_VAL_FK4\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CHAR_VAL_FK5":
                if (value instanceof String) {
                    setCHARVALFK5(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CHAR_VAL_FK5\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "USER_ID":
                if (value instanceof String) {
                    setUSERID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"USER_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PARM_SEQ":
                if (value instanceof String) {
                    setPARMSEQ(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PARM_SEQ\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TASK_STATUS_FLG":
                if (value instanceof String) {
                    setM1TASKSTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TASK_STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_IS_DECLINE_ALLOWED_SW":
                if (value instanceof String) {
                    setM1ISDECLINEALLOWEDSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_IS_DECLINE_ALLOWED_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_HAS_ATTACHMENTS_SW":
                if (value instanceof String) {
                    setM1HASATTACHMENTSSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_HAS_ATTACHMENTS_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_TASKLIST_LINE":
                if (value instanceof String) {
                    setM1MDTTASKLISTLINE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_TASKLIST_LINE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OVERRIDE_CLEARANCE_FLG":
                if (value instanceof String) {
                    setOVERRIDECLEARANCEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"OVERRIDE_CLEARANCE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_STATUS_FLG":
                if (value instanceof String) {
                    setPROCEDURESTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_ID":
                if (value instanceof String) {
                    setPROCEDUREID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_CLASS_FLG":
                if (value instanceof String) {
                    setM1DEPOTCLASSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_CLASS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SITE_ADDRESS":
                if (value instanceof String) {
                    setM1SITEADDRESS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SITE_ADDRESS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SERVICE_ADDRESS":
                if (value instanceof String) {
                    setM1SERVICEADDRESS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SERVICE_ADDRESS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STATUSCLASS_AND_SHIFTID":
                if (value instanceof String) {
                    setM1STATUSCLASSANDSHIFTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STATUSCLASS_AND_SHIFTID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RELATED_PICKUPS_EXIST_SW":
                if (value instanceof String) {
                    setM1RELATEDPICKUPSEXISTSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RELATED_PICKUPS_EXIST_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ASSIGNED_TO_CAPACITY_SW":
                if (value instanceof String) {
                    setM1ASSIGNEDTOCAPACITYSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ASSIGNED_TO_CAPACITY_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_MAP_HOVER_TEXT":
                if (value instanceof String) {
                    setM1MDTMAPHOVERTEXT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_MAP_HOVER_TEXT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SEND_NOW_UPDATE_SW":
                if (value instanceof String) {
                    setM1SENDNOWUPDATESW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SEND_NOW_UPDATE_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DATA_SENT_AT_DTTM":
                if (value instanceof String) {
                    setM1DATASENTATDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DATA_SENT_AT_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DECLINE_COMMENTS":
                if (value instanceof String) {
                    setM1DECLINECOMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DECLINE_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BREAK_ID":
                if (value instanceof String) {
                    setM1BREAKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BREAK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BREAK_TYPE":
                if (value instanceof String) {
                    setM1BREAKTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BREAK_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WIND_ST_DTTM":
                if (value instanceof String) {
                    setM1WINDSTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WIND_ST_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BRK_CRE_DTTM":
                if (value instanceof String) {
                    setM1BRKCREDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BRK_CRE_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONCURRENT_TASK_ID":
                if (value instanceof String) {
                    setM1CONCURRENTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONCURRENT_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTACHMENT_NAME_LBL":
                if (value instanceof String) {
                    setATTACHMENTNAMELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ATTACHMENT_NAME_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTACHMENT_ID":
                if (value instanceof String) {
                    setATTACHMENTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ATTACHMENT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CREATE_USER_LBL":
                if (value instanceof String) {
                    setCREATEUSERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CREATE_USER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MAINT_OBJ_CD":
                if (value instanceof String) {
                    setMAINTOBJCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MAINT_OBJ_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VAL1":
                if (value instanceof String) {
                    setPKVAL1(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VAL1\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VAL2":
                if (value instanceof String) {
                    setPKVAL2(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VAL2\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VAL3":
                if (value instanceof String) {
                    setPKVAL3(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VAL3\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VAL4":
                if (value instanceof String) {
                    setPKVAL4(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VAL4\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VAL5":
                if (value instanceof String) {
                    setPKVAL5(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VAL5\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ATTACHMENT_FILE_NAME":
                if (value instanceof String) {
                    setM1ATTACHMENTFILENAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ATTACHMENT_FILE_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTACHMENT_FILE_NAME":
                if (value instanceof String) {
                    setATTACHMENTFILENAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ATTACHMENT_FILE_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTACHMENT_DATA":
                if (value instanceof String) {
                    setATTACHMENTDATA(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ATTACHMENT_DATA\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_ATTACHMENT_FILE_SIZE":
                if (value instanceof String) {
                    setF1ATTACHMENTFILESIZE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_ATTACHMENT_FILE_SIZE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_FILE_UPLOAD_DTTM":
                if (value instanceof String) {
                    setF1FILEUPLOADDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_FILE_UPLOAD_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT":
                if (value instanceof String) {
                    setM1MDT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FILE_DESC":
                if (value instanceof String) {
                    setM1FILEDESC(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FILE_DESC\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_ATTCH_ID":
                if (value instanceof String) {
                    setM1MDTATTCHID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_ATTCH_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SENDTOCREW":
                if (value instanceof String) {
                    setM1SENDTOCREW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SENDTOCREW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DOWNLOADED":
                if (value instanceof String) {
                    setM1DOWNLOADED(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DOWNLOADED\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SERVERSYNC":
                if (value instanceof String) {
                    setM1SERVERSYNC(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SERVERSYNC\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EMBEDDEDVIEWER":
                if (value instanceof String) {
                    setM1EMBEDDEDVIEWER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EMBEDDEDVIEWER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDTOWNED":
                if (value instanceof String) {
                    setM1MDTOWNED(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDTOWNED\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CREW_SHFT_ID":
                if (value instanceof String) {
                    setCREWSHFTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CREW_SHFT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_CAPABILITY_TYPE":
                if (value instanceof String) {
                    setMDTCAPABILITYTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_CAPABILITY_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CAP_DTTM":
                if (value instanceof String) {
                    setCAPDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CAP_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SEND_TO_HOST":
                if (value instanceof String) {
                    setM1SENDTOHOST(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SEND_TO_HOST\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RELATED_ENTITY_LBL":
                if (value instanceof String) {
                    setM1RELATEDENTITYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RELATED_ENTITY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1-ATTACHIDLBL":
                if (value instanceof String) {
                    setF1ATTACHIDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1-ATTACHIDLBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_ATTACHMENT_RECORD":
                if (value instanceof String) {
                    setF1ATTACHMENTRECORD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_ATTACHMENT_RECORD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STARTED_DTTM":
                if (value instanceof String) {
                    setSTARTEDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STARTED_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SHFT_COPRF_CD":
                if (value instanceof String) {
                    setSHFTCOPRFCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SHFT_COPRF_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DRIP_MODE_FLG":
                if (value instanceof String) {
                    setDRIPMODEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DRIP_MODE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UNDISPATCH_OPTION_FLG":
                if (value instanceof String) {
                    setM1UNDISPATCHOPTIONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UNDISPATCH_OPTION_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CHANGE_SEQUENCE_FLG":
                if (value instanceof String) {
                    setM1CHANGESEQUENCEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CHANGE_SEQUENCE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DRIP_HORIZON":
                if (value instanceof String) {
                    setDRIPHORIZON(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DRIP_HORIZON\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGON_LOCATION_TYPE":
                if (value instanceof String) {
                    setM1LOGONLOCATIONTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGON_LOCATION_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "LOC_TYPE_FLG":
                if (value instanceof String) {
                    setLOCTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"LOC_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGON_LOCATION":
                if (value instanceof String) {
                    setM1LOGONLOCATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGON_LOCATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "LOCATION_CD":
                if (value instanceof String) {
                    setLOCATIONCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"LOCATION_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGON_DELAY":
                if (value instanceof String) {
                    setM1LOGONDELAY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGON_DELAY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_STRT_TRVL":
                if (value instanceof String) {
                    setM1MAXSTRTTRVL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAX_STRT_TRVL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGOFF_LOCATION_TYPE":
                if (value instanceof String) {
                    setM1LOGOFFLOCATIONTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGOFF_LOCATION_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGOFF_LOCATION":
                if (value instanceof String) {
                    setM1LOGOFFLOCATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGOFF_LOCATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGOFF_DELAY":
                if (value instanceof String) {
                    setM1LOGOFFDELAY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGOFF_DELAY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_FINSH_TRVL":
                if (value instanceof String) {
                    setM1MAXFINSHTRVL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAX_FINSH_TRVL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SVC_AREA_USAGE":
                if (value instanceof String) {
                    setM1SVCAREAUSAGE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SVC_AREA_USAGE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SVC_AREA_USG_FLG":
                if (value instanceof String) {
                    setSVCAREAUSGFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SVC_AREA_USG_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SVC_CLS_USG_FLG":
                if (value instanceof String) {
                    setSVCCLSUSGFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SVC_CLS_USG_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESRV_CAPACITY_BY_FLG":
                if (value instanceof String) {
                    setM1RESRVCAPACITYBYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESRV_CAPACITY_BY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESERVE_CAP_TYPE":
                if (value instanceof String) {
                    setM1RESERVECAPTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESERVE_CAP_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESRV_CAPACITY_LEAD_OPT_FLG":
                if (value instanceof String) {
                    setM1RESRVCAPACITYLEADOPTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESRV_CAPACITY_LEAD_OPT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESERVE_CAP_LEAD_TM":
                if (value instanceof String) {
                    setM1RESERVECAPLEADTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESERVE_CAP_LEAD_TM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESERVE_CAP_PERCENT":
                if (value instanceof String) {
                    setM1RESERVECAPPERCENT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESERVE_CAP_PERCENT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESERVE_CAP_MAX_PERCENT":
                if (value instanceof String) {
                    setM1RESERVECAPMAXPERCENT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESERVE_CAP_MAX_PERCENT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "GPS_DATA_ENABLED_FLG":
                if (value instanceof String) {
                    setGPSDATAENABLEDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"GPS_DATA_ENABLED_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADVANCED_DISPATCH_OFFSET":
                if (value instanceof String) {
                    setM1ADVANCEDDISPATCHOFFSET(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADVANCED_DISPATCH_OFFSET\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADV_DISPATCH_MODE_FLG":
                if (value instanceof String) {
                    setM1ADVDISPATCHMODEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADV_DISPATCH_MODE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADVANCED_DISPATCH_TASKS":
                if (value instanceof String) {
                    setM1ADVANCEDDISPATCHTASKS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADVANCED_DISPATCH_TASKS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NUMBER_ACTIVITIES":
                if (value instanceof String) {
                    setM1NUMBERACTIVITIES(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NUMBER_ACTIVITIES\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "VARIABLE_SHIFT_FLG":
                if (value instanceof String) {
                    setVARIABLESHIFTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"VARIABLE_SHIFT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SHIFT_DURATION":
                if (value instanceof String) {
                    setSHIFTDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SHIFT_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ROUND_START_TIME_OPT_FLG":
                if (value instanceof String) {
                    setROUNDSTARTTIMEOPTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ROUND_START_TIME_OPT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AUTO_COMP_FLG":
                if (value instanceof String) {
                    setM1AUTOCOMPFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AUTO_COMP_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_ID":
                if (value instanceof String) {
                    setM1CREWID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SHFT_USAGE_FLG":
                if (value instanceof String) {
                    setSHFTUSAGEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SHFT_USAGE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PLAN_START_DTTM":
                if (value instanceof String) {
                    setPLANSTARTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PLAN_START_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PLAN_END_DTTM":
                if (value instanceof String) {
                    setPLANENDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PLAN_END_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ORIG_PLANNED_START_DTTM":
                if (value instanceof String) {
                    setORIGPLANNEDSTARTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ORIG_PLANNED_START_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ORIG_PLANNED_END_DTTM":
                if (value instanceof String) {
                    setORIGPLANNEDENDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ORIG_PLANNED_END_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_NAME":
                if (value instanceof String) {
                    setM1CREWNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SMS_CURRENT_TASK_ID":
                if (value instanceof String) {
                    setM1SMSCURRENTTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SMS_CURRENT_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCHED_OPT_FLG":
                if (value instanceof String) {
                    setM1SCHEDOPTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCHED_OPT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REQ_BY_FLG":
                if (value instanceof String) {
                    setM1REQBYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REQ_BY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CLOSEDBY_ADV_DISP_FLG":
                if (value instanceof String) {
                    setM1CLOSEDBYADVDISPFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CLOSEDBY_ADV_DISP_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "EFF_DTTM":
                if (value instanceof String) {
                    setEFFDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"EFF_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "EXP_DTTM":
                if (value instanceof String) {
                    setEXPDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"EXP_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VEH_STRT_ODO_MTR":
                if (value instanceof String) {
                    setM1VEHSTRTODOMTR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VEH_STRT_ODO_MTR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VEH_END_ODO_MTR":
                if (value instanceof String) {
                    setM1VEHENDODOMTR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VEH_END_ODO_MTR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESRC_NAME":
                if (value instanceof String) {
                    setM1RESRCNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESRC_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGON_USER":
                if (value instanceof String) {
                    setM1LOGONUSER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGON_USER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_ID":
                if (value instanceof String) {
                    setMDTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MOBILE_PHONE_NUMBER":
                if (value instanceof String) {
                    setM1MOBILEPHONENUMBER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MOBILE_PHONE_NUMBER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "LOGON_MOBILE_PHONE":
                if (value instanceof String) {
                    setLOGONMOBILEPHONE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"LOGON_MOBILE_PHONE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FORCED_LOG_OFF_SW":
                if (value instanceof String) {
                    setM1FORCEDLOGOFFSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FORCED_LOG_OFF_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FORCE_LOGOFF_REASON_FLG":
                if (value instanceof String) {
                    setM1FORCELOGOFFREASONFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FORCE_LOGOFF_REASON_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GPS_RESRC_ID":
                if (value instanceof String) {
                    setM1GPSRESRCID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GPS_RESRC_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TEMPLATE_SHIFT":
                if (value instanceof String) {
                    setM1TEMPLATESHIFT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TEMPLATE_SHIFT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SHFT_TMPL_ID":
                if (value instanceof String) {
                    setSHFTTMPLID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SHFT_TMPL_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SUBSCRIPTION_ID":
                if (value instanceof String) {
                    setSUBSCRIPTIONID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SUBSCRIPTION_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVRD_FLG":
                if (value instanceof String) {
                    setM1OVRDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVRD_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EST_OUT_OF_SVC_DUR":
                if (value instanceof String) {
                    setM1ESTOUTOFSVCDUR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EST_OUT_OF_SVC_DUR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIMED_EVENT_EXP_DTTM":
                if (value instanceof String) {
                    setM1TIMEDEVENTEXPDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIMED_EVENT_EXP_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REVW_ON_DEV_FLG":
                if (value instanceof String) {
                    setM1REVWONDEVFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REVW_ON_DEV_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIMESHEET_ID":
                if (value instanceof String) {
                    setTIMESHEETID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TIMESHEET_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RESRC_ID_TYPE_FLG":
                if (value instanceof String) {
                    setRESRCIDTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"RESRC_ID_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OFFLINE_FLG":
                if (value instanceof String) {
                    setM1OFFLINEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OFFLINE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "START_DTTM":
                if (value instanceof String) {
                    setSTARTDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"START_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "END_DTTM":
                if (value instanceof String) {
                    setENDDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"END_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_CUST_ACCEPT_REQ_FLG":
                if (value instanceof String) {
                    setM1ITEMCUSTACCEPTREQFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_CUST_ACCEPT_REQ_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_ITEM_ID":
                if (value instanceof String) {
                    setM1DEPOTTASKITEMID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_ITEM_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DESC_LBL":
                if (value instanceof String) {
                    setM1DESCLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DESC_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_QUANTITY":
                if (value instanceof String) {
                    setM1ITEMQUANTITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_QUANTITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_BARCODE_TYPE":
                if (value instanceof String) {
                    setM1ITEMBARCODETYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_BARCODE_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_BARCODE":
                if (value instanceof String) {
                    setM1ITEMBARCODE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_BARCODE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_ADDITIONAL_DETAILS":
                if (value instanceof String) {
                    setM1ITEMADDITIONALDETAILS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_ADDITIONAL_DETAILS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_ATTR_NAME":
                if (value instanceof String) {
                    setM1ITEMATTRNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_ATTR_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_ATTR_VALUE":
                if (value instanceof String) {
                    setM1ITEMATTRVALUE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_ATTR_VALUE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_PACKAGE_ITEMS":
                if (value instanceof String) {
                    setM1ITEMPACKAGEITEMS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_PACKAGE_ITEMS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_CUST_ACCEPTED_FLG":
                if (value instanceof String) {
                    setM1ITEMCUSTACCEPTEDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_CUST_ACCEPTED_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ASIGN_CMPL_RECEIPT_OPT_FLG":
                if (value instanceof String) {
                    setM1ASIGNCMPLRECEIPTOPTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ASIGN_CMPL_RECEIPT_OPT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_PROVIDED_QUANTITY":
                if (value instanceof String) {
                    setM1ITEMPROVIDEDQUANTITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_PROVIDED_QUANTITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_LOAD_STATUS_FLG":
                if (value instanceof String) {
                    setM1ITEMLOADSTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_LOAD_STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_LOAD_DCLN_RSN_FLG":
                if (value instanceof String) {
                    setM1ITEMLOADDCLNRSNFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_LOAD_DCLN_RSN_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_DELIVERY_STATUS_FLG":
                if (value instanceof String) {
                    setM1ITEMDELIVERYSTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_DELIVERY_STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_DELI_DCLN_RSN_FLG":
                if (value instanceof String) {
                    setM1ITEMDELIDCLNRSNFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_DELI_DCLN_RSN_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_COMPLETION_COMMENTS":
                if (value instanceof String) {
                    setM1ITEMCOMPLETIONCOMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_COMPLETION_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_DECLINE_REASON":
                if (value instanceof String) {
                    setM1DEPOTTASKDECLINEREASON(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_DECLINE_REASON\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_CAPACITY_FLG":
                if (value instanceof String) {
                    setM1MAXCAPACITYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAX_CAPACITY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAX_NONCUM_CAPACITY_FLG":
                if (value instanceof String) {
                    setM1MAXNONCUMCAPACITYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAX_NONCUM_CAPACITY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_RUN_CLOSED_FLG":
                if (value instanceof String) {
                    setM1DEPOTRUNCLOSEDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_RUN_CLOSED_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUTOFF_DTTM":
                if (value instanceof String) {
                    setM1CUTOFFDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUTOFF_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PREV_CUTOFF_DTTM":
                if (value instanceof String) {
                    setM1PREVCUTOFFDTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PREV_CUTOFF_DTTM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1DEPTSK_AN_LBL":
                if (value instanceof String) {
                    setM1DEPTSKANLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1DEPTSK_AN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREATED_BY_ASSIGNMENT_ID":
                if (value instanceof String) {
                    setM1CREATEDBYASSIGNMENTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREATED_BY_ASSIGNMENT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GENERAL_LBL":
                if (value instanceof String) {
                    setM1GENERALLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GENERAL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_START_DAY_OF_WEEK":
                if (value instanceof String) {
                    setM1STARTDAYOFWEEK(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_START_DAY_OF_WEEK\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MST_CONFIG_DATA":
                if (value instanceof String) {
                    setMSTCONFIGDATA(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MST_CONFIG_DATA\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PLAN_HORIZON":
                if (value instanceof String) {
                    setM1PLANHORIZON(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PLAN_HORIZON\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALERTS_LBL":
                if (value instanceof String) {
                    setM1ALERTSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALERTS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SYNC_ALERT_TYPE":
                if (value instanceof String) {
                    setM1SYNCALERTTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SYNC_ALERT_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CANCEL_ALERT_ACT_TYPE":
                if (value instanceof String) {
                    setM1CANCELALERTACTTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CANCEL_ALERT_ACT_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UNACKN_EMERG_ALERT_TYPE":
                if (value instanceof String) {
                    setM1UNACKNEMERGALERTTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UNACKN_EMERG_ALERT_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PANIC_ALERT_TYPE":
                if (value instanceof String) {
                    setM1PANICALERTTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PANIC_ALERT_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIMED_EVENT_ALERT_TYPE":
                if (value instanceof String) {
                    setM1TIMEDEVENTALERTTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIMED_EVENT_ALERT_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALERT_SOUND":
                if (value instanceof String) {
                    setM1ALERTSOUND(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALERT_SOUND\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SOUND_DURATION":
                if (value instanceof String) {
                    setM1SOUNDDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SOUND_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SOUND_PAUSE":
                if (value instanceof String) {
                    setM1SOUNDPAUSE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SOUND_PAUSE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MOB_APP_LBL":
                if (value instanceof String) {
                    setM1MOBAPPLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MOB_APP_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SYNC_ALERT_THRESHOLD":
                if (value instanceof String) {
                    setM1SYNCALERTTHRESHOLD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SYNC_ALERT_THRESHOLD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_LOG_LOC":
                if (value instanceof String) {
                    setM1MDTLOGLOC(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_LOG_LOC\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SERVER_PROXY_HOST":
                if (value instanceof String) {
                    setM1SERVERPROXYHOST(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SERVER_PROXY_HOST\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SERVER_PROXY_PORT":
                if (value instanceof String) {
                    setM1SERVERPROXYPORT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SERVER_PROXY_PORT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DISCONNECT_THRESHOLD":
                if (value instanceof String) {
                    setM1DISCONNECTTHRESHOLD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DISCONNECT_THRESHOLD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REAL_GPS_THRESHOLD":
                if (value instanceof String) {
                    setM1REALGPSTHRESHOLD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REAL_GPS_THRESHOLD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PANIC_ALERT_COUNT_DOWN":
                if (value instanceof String) {
                    setM1PANICALERTCOUNTDOWN(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PANIC_ALERT_COUNT_DOWN\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_SOUND_DURATION":
                if (value instanceof String) {
                    setM1MDTSOUNDDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_SOUND_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_SOUND_PAUSE":
                if (value instanceof String) {
                    setM1MDTSOUNDPAUSE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_SOUND_PAUSE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DATA_ENCRYPTION_GC_FLG":
                if (value instanceof String) {
                    setM1DATAENCRYPTIONGCFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DATA_ENCRYPTION_GC_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESRC_MNGT_LBL":
                if (value instanceof String) {
                    setM1RESRCMNGTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESRC_MNGT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TASK_TYPE_FOR_POU":
                if (value instanceof String) {
                    setM1TASKTYPEFORPOU(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TASK_TYPE_FOR_POU\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TIMESHEET_PROCESS_TYPE_CD":
                if (value instanceof String) {
                    setTIMESHEETPROCESSTYPECD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TIMESHEET_PROCESS_TYPE_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TMSHEET_CORR_FLG":
                if (value instanceof String) {
                    setM1TMSHEETCORRFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TMSHEET_CORR_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_LBL":
                if (value instanceof String) {
                    setM1DEPOTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RT_PARMS_LBL":
                if (value instanceof String) {
                    setM1RTPARMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RT_PARMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MAIL_ID":
                if (value instanceof String) {
                    setMAILID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MAIL_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAIL_ID":
                if (value instanceof String) {
                    setM1MAILID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAIL_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SUBJECT":
                if (value instanceof String) {
                    setM1SUBJECT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SUBJECT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MSG_TEXT":
                if (value instanceof String) {
                    setM1MSGTEXT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MSG_TEXT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DELVR_NOW_FLG":
                if (value instanceof String) {
                    setM1DELVRNOWFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DELVR_NOW_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIME_LIMIT":
                if (value instanceof String) {
                    setM1TIMELIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIME_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAIL_MSG_CLS_FLG":
                if (value instanceof String) {
                    setM1MAILMSGCLSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAIL_MSG_CLS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FOLDER_FLG":
                if (value instanceof String) {
                    setM1FOLDERFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FOLDER_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ERROR_MSG":
                if (value instanceof String) {
                    setERRORMSG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ERROR_MSG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAILING_LIST_CD":
                if (value instanceof String) {
                    setM1MAILINGLISTCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAILING_LIST_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PRDF_SNDTO_FLG":
                if (value instanceof String) {
                    setM1PRDFSNDTOFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PRDF_SNDTO_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NON_PROD_TASK_ID":
                if (value instanceof String) {
                    setM1NONPRODTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NON_PROD_TASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_2":
                if (value instanceof String) {
                    setM1ADDRESS2(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_2\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_3":
                if (value instanceof String) {
                    setM1ADDRESS3(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_3\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_4":
                if (value instanceof String) {
                    setM1ADDRESS4(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_4\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CROSS_STREET":
                if (value instanceof String) {
                    setM1CROSSSTREET(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CROSS_STREET\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SUBURB":
                if (value instanceof String) {
                    setM1SUBURB(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SUBURB\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CITY":
                if (value instanceof String) {
                    setM1CITY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CITY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COUNTY":
                if (value instanceof String) {
                    setM1COUNTY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COUNTY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POSTAL":
                if (value instanceof String) {
                    setM1POSTAL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POSTAL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COUNTRY":
                if (value instanceof String) {
                    setM1COUNTRY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COUNTRY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STATE":
                if (value instanceof String) {
                    setM1STATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GEOCODE_LATITUDE":
                if (value instanceof String) {
                    setM1GEOCODELATITUDE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GEOCODE_LATITUDE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GEOCODE_LONGITUDE":
                if (value instanceof String) {
                    setM1GEOCODELONGITUDE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GEOCODE_LONGITUDE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POUTASK_ID":
                if (value instanceof String) {
                    setM1POUTASKID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POUTASK_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "POU_ID":
                if (value instanceof String) {
                    setPOUID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"POU_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POU_TYPE":
                if (value instanceof String) {
                    setM1POUTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POU_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POU_SHIFT_ID":
                if (value instanceof String) {
                    setM1POUSHIFTID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POU_SHIFT_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOCATION":
                if (value instanceof String) {
                    setM1LOCATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOCATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PLAN_START_TIME":
                if (value instanceof String) {
                    setM1PLANSTARTTIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PLAN_START_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PLAN_END_TIME":
                if (value instanceof String) {
                    setM1PLANENDTIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PLAN_END_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_BUS_OBJ_CD":
                if (value instanceof String) {
                    setPROCEDUREBUSOBJCD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_BUS_OBJ_CD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RELATED_ENTITY_FLG":
                if (value instanceof String) {
                    setRELATEDENTITYFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"RELATED_ENTITY_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_EFF_DT":
                if (value instanceof String) {
                    setPROCEDUREEFFDT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_EFF_DT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_EXP_DT":
                if (value instanceof String) {
                    setPROCEDUREEXPDT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_EXP_DT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ALLOW_OVERRIDE_FLG":
                if (value instanceof String) {
                    setALLOWOVERRIDEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ALLOW_OVERRIDE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TAKE_ATTENDANCE_FLG":
                if (value instanceof String) {
                    setTAKEATTENDANCEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TAKE_ATTENDANCE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_STEP_SEQ_NO":
                if (value instanceof String) {
                    setPROCEDURESTEPSEQNO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_STEP_SEQ_NO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PROCEDURE_MESSAGE_NBR":
                if (value instanceof String) {
                    setM1PROCEDUREMESSAGENBR(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PROCEDURE_MESSAGE_NBR\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_STEP_TEXT":
                if (value instanceof String) {
                    setPROCEDURESTEPTEXT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_STEP_TEXT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_REQUIRED_FLG":
                if (value instanceof String) {
                    setSTEPREQUIREDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STEP_REQUIRED_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ANSWER_TYPE_FLG":
                if (value instanceof String) {
                    setANSWERTYPEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ANSWER_TYPE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "YES_NO_ANSWER_FLG":
                if (value instanceof String) {
                    setYESNOANSWERFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"YES_NO_ANSWER_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_PASS_VALUE":
                if (value instanceof String) {
                    setSTEPPASSVALUE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STEP_PASS_VALUE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_LOWER_LIMIT":
                if (value instanceof String) {
                    setSTEPLOWERLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STEP_LOWER_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_UPPER_LIMIT":
                if (value instanceof String) {
                    setSTEPUPPERLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STEP_UPPER_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MLRD_STATUS_FLG":
                if (value instanceof String) {
                    setM1MLRDSTATUSFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MLRD_STATUS_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SENT_BY_MAIL_ID":
                if (value instanceof String) {
                    setM1SENTBYMAILID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SENT_BY_MAIL_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SENT_FROM_USER":
                if (value instanceof String) {
                    setM1SENTFROMUSER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SENT_FROM_USER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SENT_FROM_CREW_SHFT":
                if (value instanceof String) {
                    setM1SENTFROMCREWSHFT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SENT_FROM_CREW_SHFT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "FIRST_NAME":
                if (value instanceof String) {
                    setFIRSTNAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"FIRST_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FROM_LBL":
                if (value instanceof String) {
                    setM1FROMLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FROM_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_SHFT_LBL":
                if (value instanceof String) {
                    setM1CREWSHFTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_SHFT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESOURCE_LBL":
                if (value instanceof String) {
                    setM1RESOURCELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESOURCE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CREATED_BY_LBL":
                if (value instanceof String) {
                    setCREATEDBYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CREATED_BY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TMSHT_OVRD_FLG":
                if (value instanceof String) {
                    setM1TMSHTOVRDFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TMSHT_OVRD_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_HIGH_CORR_LIMIT":
                if (value instanceof String) {
                    setM1HIGHCORRLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_HIGH_CORR_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOW_CORR_LIMIT":
                if (value instanceof String) {
                    setM1LOWCORRLIMIT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOW_CORR_LIMIT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CALC_ERROR_SW":
                if (value instanceof String) {
                    setM1CALCERRORSW(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CALC_ERROR_SW\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CALC_DURATION":
                if (value instanceof String) {
                    setCALCDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CALC_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ADJ_DURATION":
                if (value instanceof String) {
                    setADJDURATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ADJ_DURATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SYSTEM_GEN_FLG":
                if (value instanceof String) {
                    setM1SYSTEMGENFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SYSTEM_GEN_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_STATE_FLG":
                if (value instanceof String) {
                    setPROCEDURESTATEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_STATE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VALUE1":
                if (value instanceof String) {
                    setPKVALUE1(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VALUE1\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VALUE2":
                if (value instanceof String) {
                    setPKVALUE2(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VALUE2\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VALUE3":
                if (value instanceof String) {
                    setPKVALUE3(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VALUE3\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VALUE4":
                if (value instanceof String) {
                    setPKVALUE4(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VALUE4\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PK_VALUE5":
                if (value instanceof String) {
                    setPKVALUE5(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PK_VALUE5\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ENTITY_INFORMATION":
                if (value instanceof String) {
                    setENTITYINFORMATION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ENTITY_INFORMATION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "OVERRIDE_FAILURE_FLG":
                if (value instanceof String) {
                    setOVERRIDEFAILUREFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"OVERRIDE_FAILURE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "PROCEDURE_COMMENTS":
                if (value instanceof String) {
                    setPROCEDURECOMMENTS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"PROCEDURE_COMMENTS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TEXT_ANSWER":
                if (value instanceof String) {
                    setTEXTANSWER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TEXT_ANSWER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "NUMBER_ANSWER":
                if (value instanceof String) {
                    setNUMBERANSWER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"NUMBER_ANSWER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "STEP_STATE_FLG":
                if (value instanceof String) {
                    setSTEPSTATEFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"STEP_STATE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MOBILE_WORKER":
                if (value instanceof String) {
                    setM1MOBILEWORKER(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MOBILE_WORKER\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTENDED_PROCEDURE_FLG":
                if (value instanceof String) {
                    setATTENDEDPROCEDUREFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ATTENDED_PROCEDURE_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ACCEPT_LBL":
                if (value instanceof String) {
                    setACCEPTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ACCEPT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ALL_LBL":
                if (value instanceof String) {
                    setALLLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ALL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ATTACH_LBL":
                if (value instanceof String) {
                    setATTACHLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ATTACH_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CALC_TRVL_DIST":
                if (value instanceof String) {
                    setCALCTRVLDIST(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CALC_TRVL_DIST\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "CANCEL_LBL":
                if (value instanceof String) {
                    setCANCELLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"CANCEL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DELETE_BTN":
                if (value instanceof String) {
                    setDELETEBTN(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DELETE_BTN\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DESCR100":
                if (value instanceof String) {
                    setDESCR100(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DESCR100\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "DIRECTIONS_LBL":
                if (value instanceof String) {
                    setDIRECTIONSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"DIRECTIONS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ERROR_LBL":
                if (value instanceof String) {
                    setERRORLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"ERROR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "F1_CONFIRM_DEL_LBL":
                if (value instanceof String) {
                    setF1CONFIRMDELLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"F1_CONFIRM_DEL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "KEY_LBL":
                if (value instanceof String) {
                    setKEYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"KEY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1-MCPMEPOSTPONED":
                if (value instanceof String) {
                    setM1MCPMEPOSTPONED(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1-MCPMEPOSTPONED\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITIES_FOR_DEPOT_LBL":
                if (value instanceof String) {
                    setM1ACTIVITIESFORDEPOTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITIES_FOR_DEPOT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_INFO_LBL":
                if (value instanceof String) {
                    setM1ACTIVITYINFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_LBL":
                if (value instanceof String) {
                    setM1ACTIVITYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_PROCEDURES_LBL":
                if (value instanceof String) {
                    setM1ACTIVITYPROCEDURESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_PROCEDURES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACTIVITY_TYPE_LBL":
                if (value instanceof String) {
                    setM1ACTIVITYTYPELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACTIVITY_TYPE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACT_AFRA_LBL":
                if (value instanceof String) {
                    setM1ACTAFRALBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACT_AFRA_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACT_CAL_LBL":
                if (value instanceof String) {
                    setM1ACTCALLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACT_CAL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACT_CHG_SHFST_LBL":
                if (value instanceof String) {
                    setM1ACTCHGSHFSTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACT_CHG_SHFST_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACT_CPF_LBL":
                if (value instanceof String) {
                    setM1ACTCPFLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACT_CPF_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACT_EOS_LBL":
                if (value instanceof String) {
                    setM1ACTEOSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACT_EOS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ACT_STE_LBL":
                if (value instanceof String) {
                    setM1ACTSTELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ACT_STE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADDRESS_LBL":
                if (value instanceof String) {
                    setM1ADDRESSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADDRESS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADD_ANOTHER_BTN_LBL":
                if (value instanceof String) {
                    setM1ADDANOTHERBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADD_ANOTHER_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADD_BTN_LBL":
                if (value instanceof String) {
                    setM1ADDBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADD_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADD_NEW_LBL":
                if (value instanceof String) {
                    setM1ADDNEWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADD_NEW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADD_REMARK_TYP_LBL":
                if (value instanceof String) {
                    setM1ADDREMARKTYPLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADD_REMARK_TYP_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADD_VEHICLE_LBL":
                if (value instanceof String) {
                    setM1ADDVEHICLELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADD_VEHICLE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ADD_WORKER_LBL":
                if (value instanceof String) {
                    setM1ADDWORKERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ADD_WORKER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALERT_MESSAGE":
                if (value instanceof String) {
                    setM1ALERTMESSAGE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALERT_MESSAGE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ALERT_SENT_LBL":
                if (value instanceof String) {
                    setM1ALERTSENTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ALERT_SENT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPENDERS_LBL":
                if (value instanceof String) {
                    setM1APPENDERSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_APPENDERS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_APPOINTMENT_WINDOW_LBL":
                if (value instanceof String) {
                    setM1APPOINTMENTWINDOWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_APPOINTMENT_WINDOW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ARRIVED_ASSIGNMENT_LBL":
                if (value instanceof String) {
                    setM1ARRIVEDASSIGNMENTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ARRIVED_ASSIGNMENT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ARR_TM":
                if (value instanceof String) {
                    setM1ARRTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ARR_TM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ASSIGNMENT_REMKSEC_LBL":
                if (value instanceof String) {
                    setM1ASSIGNMENTREMKSECLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ASSIGNMENT_REMKSEC_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ATTACHMENT":
                if (value instanceof String) {
                    setM1ATTACHMENT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ATTACHMENT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ATTACHMENT_DETAILS_LBL":
                if (value instanceof String) {
                    setM1ATTACHMENTDETAILSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ATTACHMENT_DETAILS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ATTENDANCE_LBL":
                if (value instanceof String) {
                    setM1ATTENDANCELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ATTENDANCE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AT_DEPOT_LBL":
                if (value instanceof String) {
                    setM1ATDEPOTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AT_DEPOT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_AT_LBL":
                if (value instanceof String) {
                    setM1ATLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_AT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BACK_BTN_LBL":
                if (value instanceof String) {
                    setM1BACKBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BACK_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BELONGS_TO_PKG_LBL":
                if (value instanceof String) {
                    setM1BELONGSTOPKGLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BELONGS_TO_PKG_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_BREAK_TASK_LBL":
                if (value instanceof String) {
                    setM1BREAKTASKLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_BREAK_TASK_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CALCADJ_DURATION_LBL":
                if (value instanceof String) {
                    setM1CALCADJDURATIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CALCADJ_DURATION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAMERA_LBL":
                if (value instanceof String) {
                    setM1CAMERALBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAMERA_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CANCEL_CHGS_BTN_LBL":
                if (value instanceof String) {
                    setM1CANCELCHGSBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CANCEL_CHGS_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CANCEL_OFFLINE_LBL":
                if (value instanceof String) {
                    setM1CANCELOFFLINELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CANCEL_OFFLINE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAPACITY_CNT_CMPL_LBL":
                if (value instanceof String) {
                    setM1CAPACITYCNTCMPLLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAPACITY_CNT_CMPL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAPTURE_SIGNATURE_LBL":
                if (value instanceof String) {
                    setM1CAPTURESIGNATURELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAPTURE_SIGNATURE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CHOOSE_AN_ACTION_LBL":
                if (value instanceof String) {
                    setM1CHOOSEANACTIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CHOOSE_AN_ACTION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CLOSE_BTN_LBL":
                if (value instanceof String) {
                    setM1CLOSEBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CLOSE_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMMON_ATTACHMENT":
                if (value instanceof String) {
                    setM1COMMONATTACHMENT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMMON_ATTACHMENT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMMON_COMPLETION_LBL":
                if (value instanceof String) {
                    setM1COMMONCOMPLETIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMMON_COMPLETION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETED_LBL":
                if (value instanceof String) {
                    setM1COMPLETEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETE_ACT_LBL":
                if (value instanceof String) {
                    setM1COMPLETEACTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETE_ACT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETE_BTN_LBL":
                if (value instanceof String) {
                    setM1COMPLETEBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETE_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLETION_TM":
                if (value instanceof String) {
                    setM1COMPLETIONTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLETION_TM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPLEX_ACT_CMPL_LBL":
                if (value instanceof String) {
                    setM1COMPLEXACTCMPLLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPLEX_ACT_CMPL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_COMPOSE_MAIL_LBL":
                if (value instanceof String) {
                    setM1COMPOSEMAILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_COMPOSE_MAIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CONSOLE_APPENDER_LBL":
                if (value instanceof String) {
                    setM1CONSOLEAPPENDERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CONSOLE_APPENDER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CORRECT_LBL":
                if (value instanceof String) {
                    setM1CORRECTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CORRECT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREWINQUIRY_LBL":
                if (value instanceof String) {
                    setM1CREWINQUIRYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREWINQUIRY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CREW_TIME_USAGE_CMPL_LBL":
                if (value instanceof String) {
                    setM1CREWTIMEUSAGECMPLLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CREW_TIME_USAGE_CMPL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CRSHT_ROUTE_LBL":
                if (value instanceof String) {
                    setM1CRSHTROUTELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CRSHT_ROUTE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CRW_LBL":
                if (value instanceof String) {
                    setM1CRWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CRW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUSTOMER_ACCEPTANCE_LBL":
                if (value instanceof String) {
                    setM1CUSTOMERACCEPTANCELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUSTOMER_ACCEPTANCE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CUSTOMER_INFO_LBL":
                if (value instanceof String) {
                    setM1CUSTOMERINFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CUSTOMER_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEBUG_LBL":
                if (value instanceof String) {
                    setM1DEBUGLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEBUG_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DECLINED_LBL":
                if (value instanceof String) {
                    setM1DECLINEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DECLINED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DECLINE_ACT_LBL":
                if (value instanceof String) {
                    setM1DECLINEACTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DECLINE_ACT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DECLINE_ALL_ITEMS_LBL":
                if (value instanceof String) {
                    setM1DECLINEALLITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DECLINE_ALL_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DELIVERED_LBL":
                if (value instanceof String) {
                    setM1DELIVEREDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DELIVERED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DELIVERY_COMPLETE":
                if (value instanceof String) {
                    setM1DELIVERYCOMPLETE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DELIVERY_COMPLETE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DELIVER_ALL_ITEMS_LBL":
                if (value instanceof String) {
                    setM1DELIVERALLITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DELIVER_ALL_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPLOYMENT_ID_LBL":
                if (value instanceof String) {
                    setM1DEPLOYMENTIDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPLOYMENT_ID_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_ADDRESS":
                if (value instanceof String) {
                    setM1DEPOTADDRESS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_ADDRESS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_INFORMATION_LBL":
                if (value instanceof String) {
                    setM1DEPOTINFORMATIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_INFORMATION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_REL_ASSIGNMENT_LBL":
                if (value instanceof String) {
                    setM1DEPOTRELASSIGNMENTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_REL_ASSIGNMENT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DEPOT_TASK_ASSIGNMENT_LBL":
                if (value instanceof String) {
                    setM1DEPOTTASKASSIGNMENTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DEPOT_TASK_ASSIGNMENT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DOWNLOAD":
                if (value instanceof String) {
                    setM1DOWNLOAD(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DOWNLOAD\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DOWNLOAD_ALL":
                if (value instanceof String) {
                    setM1DOWNLOADALL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DOWNLOAD_ALL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DOWNLOAD_IN_PROGRESS_LBL":
                if (value instanceof String) {
                    setM1DOWNLOADINPROGRESSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DOWNLOAD_IN_PROGRESS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_DURATION_LBL":
                if (value instanceof String) {
                    setM1DURATIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_DURATION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EARNING_TIME_CMPL_LBL":
                if (value instanceof String) {
                    setM1EARNINGTIMECMPLLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EARNING_TIME_CMPL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_EMPLOYEE_ID":
                if (value instanceof String) {
                    setM1EMPLOYEEID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_EMPLOYEE_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ENDS_LBL":
                if (value instanceof String) {
                    setM1ENDSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ENDS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_END_SHIFT_LBL":
                if (value instanceof String) {
                    setM1ENDSHIFTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_END_SHIFT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_END_TM":
                if (value instanceof String) {
                    setM1ENDTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_END_TM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ENROUTE_TO_LBL":
                if (value instanceof String) {
                    setM1ENROUTETOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ENROUTE_TO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ERROR_LBL":
                if (value instanceof String) {
                    setM1ERRORLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ERROR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ETA_LBL":
                if (value instanceof String) {
                    setM1ETALBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ETA_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FATAL_LBL":
                if (value instanceof String) {
                    setM1FATALLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FATAL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FILE_APPENDER_LBL":
                if (value instanceof String) {
                    setM1FILEAPPENDERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FILE_APPENDER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_FILTER_ITEMS_LBL":
                if (value instanceof String) {
                    setM1FILTERITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_FILTER_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GALLERY_LBL":
                if (value instanceof String) {
                    setM1GALLERYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GALLERY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GO_OUT_SVC_LBL":
                if (value instanceof String) {
                    setM1GOOUTSVCLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GO_OUT_SVC_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GROUP_LBL":
                if (value instanceof String) {
                    setM1GROUPLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GROUP_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_GUAR_DEL_LBL":
                if (value instanceof String) {
                    setM1GUARDELLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_GUAR_DEL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_HH_LBL":
                if (value instanceof String) {
                    setM1HHLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_HH_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_INBOX_LBL":
                if (value instanceof String) {
                    setM1INBOXLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_INBOX_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_INFO_LBL":
                if (value instanceof String) {
                    setM1INFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_INQUIRY_HISTORY":
                if (value instanceof String) {
                    setM1INQUIRYHISTORY(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_INQUIRY_HISTORY\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_INQUIRY_HISTORY_LBL":
                if (value instanceof String) {
                    setM1INQUIRYHISTORYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_INQUIRY_HISTORY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_DETAILS_LBL":
                if (value instanceof String) {
                    setM1ITEMDETAILSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_DETAILS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ITEM_INFORMATION_LBL":
                if (value instanceof String) {
                    setM1ITEMINFORMATIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ITEM_INFORMATION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LEFT_AT_LBL":
                if (value instanceof String) {
                    setM1LEFTATLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LEFT_AT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LEGEND_LBL":
                if (value instanceof String) {
                    setM1LEGENDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LEGEND_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LIST_LBL":
                if (value instanceof String) {
                    setM1LISTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LIST_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOADED_LBL":
                if (value instanceof String) {
                    setM1LOADEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOADED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOAD_ALL_ITEMS_LBL":
                if (value instanceof String) {
                    setM1LOADALLITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOAD_ALL_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOAD_TASK_BUTTON_LBL":
                if (value instanceof String) {
                    setM1LOADTASKBUTTONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOAD_TASK_BUTTON_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOAD_TASK_COMPLETE_LBL":
                if (value instanceof String) {
                    setM1LOADTASKCOMPLETELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOAD_TASK_COMPLETE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGGING_LBL":
                if (value instanceof String) {
                    setM1LOGGINGLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGGING_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOGOFF_BTN_LBL":
                if (value instanceof String) {
                    setM1LOGOFFBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOGOFF_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOG_APPENDER_LBL":
                if (value instanceof String) {
                    setM1LOGAPPENDERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOG_APPENDER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_LOG_LEVEL_LBL":
                if (value instanceof String) {
                    setM1LOGLEVELLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_LOG_LEVEL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAIL_LBL":
                if (value instanceof String) {
                    setM1MAILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MAP_LBL":
                if (value instanceof String) {
                    setM1MAPLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MAP_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MARK_ALL_AS_LOADED_LBL":
                if (value instanceof String) {
                    setM1MARKALLASLOADEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MARK_ALL_AS_LOADED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MARK_ALL_AS_UNLOADED_LBL":
                if (value instanceof String) {
                    setM1MARKALLASUNLOADEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MARK_ALL_AS_UNLOADED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MBL_WKR_LBL":
                if (value instanceof String) {
                    setM1MBLWKRLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MBL_WKR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCPME_ACTIVITY_INFO_LBL":
                if (value instanceof String) {
                    setM1MCPMEACTIVITYINFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCPME_ACTIVITY_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCPME_CUSTOMER_INFO_LBL":
                if (value instanceof String) {
                    setM1MCPMECUSTOMERINFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCPME_CUSTOMER_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCPME_SCHEDULING_INFO_LBL":
                if (value instanceof String) {
                    setM1MCPMESCHEDULINGINFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCPME_SCHEDULING_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCP_LAYERS":
                if (value instanceof String) {
                    setM1MCPLAYERS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCP_LAYERS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCP_MARKERS":
                if (value instanceof String) {
                    setM1MCPMARKERS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCP_MARKERS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MDT_DEBUG_LBL":
                if (value instanceof String) {
                    setM1MDTDEBUGLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MDT_DEBUG_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MEETING_INFORMATION_LBL":
                if (value instanceof String) {
                    setM1MEETINGINFORMATIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MEETING_INFORMATION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MESSAGES_LBL":
                if (value instanceof String) {
                    setM1MESSAGESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MESSAGES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ML_POU_TASK_LBL":
                if (value instanceof String) {
                    setM1MLPOUTASKLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ML_POU_TASK_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MM_LBL":
                if (value instanceof String) {
                    setM1MMLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MM_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MORE_ELLIPSIS_LBL":
                if (value instanceof String) {
                    setM1MOREELLIPSISLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MORE_ELLIPSIS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NAME":
                if (value instanceof String) {
                    setM1NAME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NAME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NATIVE_MAPS_LBL":
                if (value instanceof String) {
                    setM1NATIVEMAPSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NATIVE_MAPS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NETWORK_COMMUNICATION_LBL":
                if (value instanceof String) {
                    setM1NETWORKCOMMUNICATIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NETWORK_COMMUNICATION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NEW_FUNCTION_LBL":
                if (value instanceof String) {
                    setM1NEWFUNCTIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NEW_FUNCTION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NON_FINAL_SHIFT_WARN_LBL":
                if (value instanceof String) {
                    setM1NONFINALSHIFTWARNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NON_FINAL_SHIFT_WARN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NON_PROD_TASK_LBL":
                if (value instanceof String) {
                    setM1NONPRODTASKLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NON_PROD_TASK_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NOT_LOADED_LBL":
                if (value instanceof String) {
                    setM1NOTLOADEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NOT_LOADED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NO_LBL":
                if (value instanceof String) {
                    setM1NOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_NPT_LBL":
                if (value instanceof String) {
                    setM1NPTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_NPT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OFFLINE_BTN_LBL":
                if (value instanceof String) {
                    setM1OFFLINEBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OFFLINE_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OFFLINE_LBL":
                if (value instanceof String) {
                    setM1OFFLINELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OFFLINE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OK_BTN_LBL":
                if (value instanceof String) {
                    setM1OKBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OK_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ONLINE_BTN_LBL":
                if (value instanceof String) {
                    setM1ONLINEBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ONLINE_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_ONLINE_LBL":
                if (value instanceof String) {
                    setM1ONLINELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_ONLINE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OPEN_LBL":
                if (value instanceof String) {
                    setM1OPENLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OPEN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVERRIDDEN_FLIPSW_LBL":
                if (value instanceof String) {
                    setM1OVERRIDDENFLIPSWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVERRIDDEN_FLIPSW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVERRIDE_FLIPSW_LBL":
                if (value instanceof String) {
                    setM1OVERRIDEFLIPSWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVERRIDE_FLIPSW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_OVERRIDE_PRCDR_CLEAR_LBL":
                if (value instanceof String) {
                    setM1OVERRIDEPRCDRCLEARLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_OVERRIDE_PRCDR_CLEAR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PACKAGE_ITEMS_LBL":
                if (value instanceof String) {
                    setM1PACKAGEITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PACKAGE_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PANIC_HEADER_LBL":
                if (value instanceof String) {
                    setM1PANICHEADERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PANIC_HEADER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PENDING_LBL":
                if (value instanceof String) {
                    setM1PENDINGLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PENDING_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PERF_LBL":
                if (value instanceof String) {
                    setM1PERFLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PERF_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PICKUP_ACTIVITY_LBL":
                if (value instanceof String) {
                    setM1PICKUPACTIVITYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PICKUP_ACTIVITY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POSTPONE_DATE":
                if (value instanceof String) {
                    setM1POSTPONEDATE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POSTPONE_DATE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POSTPONE_TIME":
                if (value instanceof String) {
                    setM1POSTPONETIME(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POSTPONE_TIME\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POSTPONE_UNTIL_LBL":
                if (value instanceof String) {
                    setM1POSTPONEUNTILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POSTPONE_UNTIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_POUABB_LBL":
                if (value instanceof String) {
                    setM1POUABBLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_POUABB_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PREVIEW_BTN_LBL":
                if (value instanceof String) {
                    setM1PREVIEWBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PREVIEW_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PREVIEW_SHFT_LBL":
                if (value instanceof String) {
                    setM1PREVIEWSHFTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PREVIEW_SHFT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PREVIEW_TASK_LIST_LBL":
                if (value instanceof String) {
                    setM1PREVIEWTASKLISTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PREVIEW_TASK_LIST_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PRIMARY_FUNCTION":
                if (value instanceof String) {
                    setM1PRIMARYFUNCTION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PRIMARY_FUNCTION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_PROCEDURES_LBL":
                if (value instanceof String) {
                    setM1PROCEDURESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_PROCEDURES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_QUESTIONNAIRE_LBL":
                if (value instanceof String) {
                    setM1QUESTIONNAIRELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_QUESTIONNAIRE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REACH_DEST_LBL":
                if (value instanceof String) {
                    setM1REACHDESTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REACH_DEST_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RECEIVED_LBL":
                if (value instanceof String) {
                    setM1RECEIVEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RECEIVED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REF_DELPOY_LBL":
                if (value instanceof String) {
                    setM1REFDELPOYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REF_DELPOY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REMOTE_APPENDER_LBL":
                if (value instanceof String) {
                    setM1REMOTEAPPENDERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REMOTE_APPENDER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REMOVE_FROM_SHIFT_LBL":
                if (value instanceof String) {
                    setM1REMOVEFROMSHIFTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REMOVE_FROM_SHIFT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REPLY_LBL":
                if (value instanceof String) {
                    setM1REPLYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REPLY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REQUEST_HELP_LBL":
                if (value instanceof String) {
                    setM1REQUESTHELPLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REQUEST_HELP_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REQUIRED_FIELDS_LBL":
                if (value instanceof String) {
                    setM1REQUIREDFIELDSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REQUIRED_FIELDS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESEND_MAIL_LBL":
                if (value instanceof String) {
                    setM1RESENDMAILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESEND_MAIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RESET_SIGNATURE_LBL":
                if (value instanceof String) {
                    setM1RESETSIGNATURELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RESET_SIGNATURE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RETURNED_LBL":
                if (value instanceof String) {
                    setM1RETURNEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RETURNED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RETURN_ALL_ITEMS_LBL":
                if (value instanceof String) {
                    setM1RETURNALLITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RETURN_ALL_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REVIEWED_LBL":
                if (value instanceof String) {
                    setM1REVIEWEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REVIEWED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REVIEW_LBL":
                if (value instanceof String) {
                    setM1REVIEWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REVIEW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_REVIEW_RQD_LBL":
                if (value instanceof String) {
                    setM1REVIEWRQDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_REVIEW_RQD_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RE_LBL":
                if (value instanceof String) {
                    setM1RELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RTN_SVC_PRPT":
                if (value instanceof String) {
                    setM1RTNSVCPRPT(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RTN_SVC_PRPT\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RTN_TO_SVC_LBL":
                if (value instanceof String) {
                    setM1RTNTOSVCLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RTN_TO_SVC_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RVE_TM_WAIT_LBL":
                if (value instanceof String) {
                    setM1RVETMWAITLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RVE_TM_WAIT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RVW_TMSH_DEV_LBL":
                if (value instanceof String) {
                    setM1RVWTMSHDEVLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RVW_TMSH_DEV_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_RVW_TM_SH_LBL":
                if (value instanceof String) {
                    setM1RVWTMSHLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_RVW_TM_SH_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SAVE_BTN_LBL":
                if (value instanceof String) {
                    setM1SAVEBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SAVE_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCAN_ALL_ITEMS_LBL":
                if (value instanceof String) {
                    setM1SCANALLITEMSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCAN_ALL_ITEMS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCAN_ANY_LBL":
                if (value instanceof String) {
                    setM1SCANANYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCAN_ANY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCAN_BARCODE_LBL":
                if (value instanceof String) {
                    setM1SCANBARCODELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCAN_BARCODE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCAN_LBL":
                if (value instanceof String) {
                    setM1SCANLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCAN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCAN_NEXT_LBL":
                if (value instanceof String) {
                    setM1SCANNEXTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCAN_NEXT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SCHEDULING_INFO_LBL":
                if (value instanceof String) {
                    setM1SCHEDULINGINFOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SCHEDULING_INFO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SECONDS_LBL":
                if (value instanceof String) {
                    setM1SECONDSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SECONDS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SELECT_LOGLEVEL_LBL":
                if (value instanceof String) {
                    setM1SELECTLOGLEVELLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SELECT_LOGLEVEL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SELECT_ONE_LBL":
                if (value instanceof String) {
                    setM1SELECTONELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SELECT_ONE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SELECT_PICKUP_ACTTYPE_LBL":
                if (value instanceof String) {
                    setM1SELECTPICKUPACTTYPELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SELECT_PICKUP_ACTTYPE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SELECT_THEME_LBL":
                if (value instanceof String) {
                    setM1SELECTTHEMELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SELECT_THEME_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SEL_PRI_FUNCTION_LBL":
                if (value instanceof String) {
                    setM1SELPRIFUNCTIONLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SEL_PRI_FUNCTION_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SEND_MAIL_LBL":
                if (value instanceof String) {
                    setM1SENDMAILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SEND_MAIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SEND_NOW_LBL":
                if (value instanceof String) {
                    setM1SENDNOWLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SEND_NOW_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SENT_LBL":
                if (value instanceof String) {
                    setM1SENTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SENT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SENT_MAIL_LBL":
                if (value instanceof String) {
                    setM1SENTMAILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SENT_MAIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SERVICE_INSTRUCTIONS":
                if (value instanceof String) {
                    setM1SERVICEINSTRUCTIONS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SERVICE_INSTRUCTIONS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SETTINGS_LBL":
                if (value instanceof String) {
                    setM1SETTINGSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SETTINGS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SHF_DTL_LBL":
                if (value instanceof String) {
                    setM1SHFDTLLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SHF_DTL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SHIFT_ACTIONS_LBL":
                if (value instanceof String) {
                    setM1SHIFTACTIONSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SHIFT_ACTIONS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SHIFT_LBL":
                if (value instanceof String) {
                    setM1SHIFTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SHIFT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SHIFT_PROCEDURES_LBL":
                if (value instanceof String) {
                    setM1SHIFTPROCEDURESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SHIFT_PROCEDURES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SHOW_MORE_LBL":
                if (value instanceof String) {
                    setM1SHOWMORELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SHOW_MORE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SIGNATURE_LBL":
                if (value instanceof String) {
                    setM1SIGNATURELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SIGNATURE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SITE_INSTRUCTIONS":
                if (value instanceof String) {
                    setM1SITEINSTRUCTIONS(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SITE_INSTRUCTIONS\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SND_TO_LBL":
                if (value instanceof String) {
                    setM1SNDTOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SND_TO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SS_LBL":
                if (value instanceof String) {
                    setM1SSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STARTEND_ODOMETER_LBL":
                if (value instanceof String) {
                    setM1STARTENDODOMETERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STARTEND_ODOMETER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_START_BTN_LBL":
                if (value instanceof String) {
                    setM1STARTBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_START_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_START_ODOMTR_LBL":
                if (value instanceof String) {
                    setM1STARTODOMTRLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_START_ODOMTR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STATUS_RSN_LBL":
                if (value instanceof String) {
                    setM1STATUSRSNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STATUS_RSN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STOP_BTN_LBL":
                if (value instanceof String) {
                    setM1STOPBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STOP_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_STRT_SHIFT_LBL":
                if (value instanceof String) {
                    setM1STRTSHIFTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_STRT_SHIFT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SUMMARY_LBL":
                if (value instanceof String) {
                    setM1SUMMARYLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SUMMARY_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SVC_STATE_LBL":
                if (value instanceof String) {
                    setM1SVCSTATELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SVC_STATE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_SYNC_LOG_FILES_LBL":
                if (value instanceof String) {
                    setM1SYNCLOGFILESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_SYNC_LOG_FILES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TARGET_TASK_TYPE":
                if (value instanceof String) {
                    setM1TARGETTASKTYPE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TARGET_TASK_TYPE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TASKS_LBL":
                if (value instanceof String) {
                    setM1TASKSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TASKS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TASK_DETAILS_LBL":
                if (value instanceof String) {
                    setM1TASKDETAILSLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TASK_DETAILS_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TASK_LIST_LBL":
                if (value instanceof String) {
                    setM1TASKLISTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TASK_LIST_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TBD_LBL":
                if (value instanceof String) {
                    setM1TBDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TBD_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_A_LBL":
                if (value instanceof String) {
                    setM1THEMEALBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_A_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_B_LBL":
                if (value instanceof String) {
                    setM1THEMEBLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_B_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_C_LBL":
                if (value instanceof String) {
                    setM1THEMECLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_C_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_D_LBL":
                if (value instanceof String) {
                    setM1THEMEDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_D_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_E_LBL":
                if (value instanceof String) {
                    setM1THEMEELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_E_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_LBL":
                if (value instanceof String) {
                    setM1THEMELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_THEME_ORACLE_LBL":
                if (value instanceof String) {
                    setM1THEMEORACLELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_THEME_ORACLE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIMED_EVENT_ALERT_LBL":
                if (value instanceof String) {
                    setM1TIMEDEVENTALERTLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIMED_EVENT_ALERT_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TIMESHEET_LBL":
                if (value instanceof String) {
                    setM1TIMESHEETLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TIMESHEET_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_TO_LBL":
                if (value instanceof String) {
                    setM1TOLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_TO_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UNDELIVERED_LBL":
                if (value instanceof String) {
                    setM1UNDELIVEREDLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UNDELIVERED_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UPDATE_LBL":
                if (value instanceof String) {
                    setM1UPDATELBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UPDATE_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_UPLOADED_IMAGES_LBL":
                if (value instanceof String) {
                    setM1UPLOADEDIMAGESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_UPLOADED_IMAGES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_USED_UNTIL_LBL":
                if (value instanceof String) {
                    setM1USEDUNTILLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_USED_UNTIL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_USER_ID":
                if (value instanceof String) {
                    setM1USERID(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_USER_ID\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VEHICLES_LBL":
                if (value instanceof String) {
                    setM1VEHICLESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VEHICLES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VEHICLE_TAG":
                if (value instanceof String) {
                    setM1VEHICLETAG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VEHICLE_TAG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VIEW_ACT_PRCDR_LBL":
                if (value instanceof String) {
                    setM1VIEWACTPRCDRLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VIEW_ACT_PRCDR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_VIEW_SHF_PRCDR_LBL":
                if (value instanceof String) {
                    setM1VIEWSHFPRCDRLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_VIEW_SHF_PRCDR_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WARNING_LBL":
                if (value instanceof String) {
                    setM1WARNINGLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WARNING_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WARN_LBL":
                if (value instanceof String) {
                    setM1WARNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WARN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WINDOW_APPENDER_LBL":
                if (value instanceof String) {
                    setM1WINDOWAPPENDERLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WINDOW_APPENDER_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_WORK_SEQ_LBL":
                if (value instanceof String) {
                    setM1WORKSEQLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_WORK_SEQ_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_YES_LBL":
                if (value instanceof String) {
                    setM1YESLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_YES_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "RESET_LBL":
                if (value instanceof String) {
                    setRESETLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"RESET_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "SEND_BTN_LBL":
                if (value instanceof String) {
                    setSENDBTNLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"SEND_BTN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "START_TM":
                if (value instanceof String) {
                    setSTARTTM(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"START_TM\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "TOTAL_LBL":
                if (value instanceof String) {
                    setTOTALLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"TOTAL_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCP_INDICATOR_MAIN_LBL":
                if (value instanceof String) {
                    setM1MCPINDICATORMAINLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCP_INDICATOR_MAIN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_INDICATOR_CODE":
                if (value instanceof String) {
                    setMDTINDICATORCODE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_INDICATOR_CODE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_INDICATOR_IMAGE":
                if (value instanceof String) {
                    setMDTINDICATORIMAGE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_INDICATOR_IMAGE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_INDICATOR_POSITION":
                if (value instanceof String) {
                    setMDTINDICATORPOSITION(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_INDICATOR_POSITION\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_MCP_CAPABILITY_TYP_MAIN_LBL":
                if (value instanceof String) {
                    setM1MCPCAPABILITYTYPMAINLBL(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_MCP_CAPABILITY_TYP_MAIN_LBL\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "M1_CAP_SYS_EVENT_FLG":
                if (value instanceof String) {
                    setM1CAPSYSEVENTFLG(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"M1_CAP_SYS_EVENT_FLG\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_CAPABILITY_IMAGE":
                if (value instanceof String) {
                    setMDTCAPABILITYIMAGE(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_CAPABILITY_IMAGE\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "MDT_CAPABILITY_ATTACHMENT_BO":
                if (value instanceof String) {
                    setMDTCAPABILITYATTACHMENTBO(((String) value));
                } else {
                    throw new IllegalArgumentException(value.getClass().toString());
					//throw new IllegalArgumentException(("property \"MDT_CAPABILITY_ATTACHMENT_BO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "NUM2_LBL":
                return getNUM2LBL();
            case "M1_RELATED_ENTITY_LBL":
                return getM1RELATEDENTITYLBL();
            case "M1_COMPLETE_OPTION_FLG":
                return getM1COMPLETEOPTIONFLG();
            case "M1_PERF_LBL":
                return getM1PERFLBL();
            case "M1_ATTACHMENT":
                return getM1ATTACHMENT();
            case "M1_MAX_STRT_TRVL":
                return getM1MAXSTRTTRVL();
            case "TASK_ID":
                return getTASKID();
            case "M1_VALID_REMARK_TYPES":
                return getM1VALIDREMARKTYPES();
            case "ATTACH_LBL":
                return getATTACHLBL();
            case "OVERRIDE_CLEARANCE_FLG":
                return getOVERRIDECLEARANCEFLG();
            case "ADDRESS2":
                return getADDRESS2();
            case "M1_LOGOFF_LOCATION_TYPE":
                return getM1LOGOFFLOCATIONTYPE();
            case "ADDRESS3":
                return getADDRESS3();
            case "ADDRESS1":
                return getADDRESS1();
            case "M1_WINDOW_MODE_FLG":
                return getM1WINDOWMODEFLG();
            case "M1_REVIEWED_LBL":
                return getM1REVIEWEDLBL();
            case "EXT_CAP_TYPE_CD":
                return getEXTCAPTYPECD();
            case "M1_POUABB_LBL":
                return getM1POUABBLBL();
            case "M1_NUM_OF_EXTENSIONS":
                return getM1NUMOFEXTENSIONS();
            case "M1_STATUS_REASON_USAGE_FLG":
                return getM1STATUSREASONUSAGEFLG();
            case "M1_COMMON_ATTACHMENT":
                return getM1COMMONATTACHMENT();
            case "M1_RESPONSE_TIME_SLA":
                return getM1RESPONSETIMESLA();
            case "ADDRESS4":
                return getADDRESS4();
            case "M1_RESRC_NAME":
                return getM1RESRCNAME();
            case "M1_CITY":
                return getM1CITY();
            case "M1_RESERVE_CAP_PERCENT":
                return getM1RESERVECAPPERCENT();
            case "M1_POSTPONE_TIME":
                return getM1POSTPONETIME();
            case "M1_CRSHT_ROUTE_LBL":
                return getM1CRSHTROUTELBL();
            case "M1_TIME_LIMIT":
                return getM1TIMELIMIT();
            case "EXT_SYS_TYP_FLG":
                return getEXTSYSTYPFLG();
            case "M1_SCAN_ANY_LBL":
                return getM1SCANANYLBL();
            case "M1_RETURNED_LBL":
                return getM1RETURNEDLBL();
            case "M1_MAX_OFFSET":
                return getM1MAXOFFSET();
            case "CHAR_VAL":
                return getCHARVAL();
            case "M1_POSTAL":
                return getM1POSTAL();
            case "M1_UPTO_BUS_PRI_VAL":
                return getM1UPTOBUSPRIVAL();
            case "M1_PREVIEW_TASK_LIST_LBL":
                return getM1PREVIEWTASKLISTLBL();
            case "M1_ALLOW_EARNING_TIME_FLG":
                return getM1ALLOWEARNINGTIMEFLG();
            case "ERROR_MSG":
                return getERRORMSG();
            case "SHFT_COPRF_CD":
                return getSHFTCOPRFCD();
            case "M1_SORT_SEQUENCE":
                return getM1SORTSEQUENCE();
            case "M1_ACTIVITY_COMMENTS":
                return getM1ACTIVITYCOMMENTS();
            case "ENROUTE_DTTM":
                return getENROUTEDTTM();
            case "M1_AUTO_ALLOCATION_FLG":
                return getM1AUTOALLOCATIONFLG();
            case "TIME_WINDOW_USAGE_FLG":
                return getTIMEWINDOWUSAGEFLG();
            case "M1_LOGON_LOCATION":
                return getM1LOGONLOCATION();
            case "M1_MDT_SOUND_DURATION":
                return getM1MDTSOUNDDURATION();
            case "BUS_OBJ_CD":
                return getBUSOBJCD();
            case "M1_REMOVE_FROM_SHIFT_LBL":
                return getM1REMOVEFROMSHIFTLBL();
            case "M1_TIMING_OPTION_FLG":
                return getM1TIMINGOPTIONFLG();
            case "M1_COUNTY":
                return getM1COUNTY();
            case "ARRD_DTTM":
                return getARRDDTTM();
            case "M1_COMPLETION_TM":
                return getM1COMPLETIONTM();
            case "M1_SEQ_NUM_WRK":
                return getM1SEQNUMWRK();
            case "M1_STATUSCLASS_AND_SHIFTID":
                return getM1STATUSCLASSANDSHIFTID();
            case "M1_DEPOT_TASK_LOAD_ORDER_FLG":
                return getM1DEPOTTASKLOADORDERFLG();
            case "M1_STARTEND_ODOMETER_LBL":
                return getM1STARTENDODOMETERLBL();
            case "STEP_PASS_VALUE":
                return getSTEPPASSVALUE();
            case "M1_SCHED_PRIORITY":
                return getM1SCHEDPRIORITY();
            case "AUTO_DISPATCH_FLG":
                return getAUTODISPATCHFLG();
            case "MESSAGE_NBR":
                return getMESSAGENBR();
            case "M1_INQUIRY_HISTORY_LBL":
                return getM1INQUIRYHISTORYLBL();
            case "M1_SENT_LBL":
                return getM1SENTLBL();
            case "M1_ACTUAL_COM_DTTM":
                return getM1ACTUALCOMDTTM();
            case "M1_APPT_REQ_FLG":
                return getM1APPTREQFLG();
            case "M1_SOUND_PAUSE":
                return getM1SOUNDPAUSE();
            case "M1_RELATED_PICKUPS_EXIST_SW":
                return getM1RELATEDPICKUPSEXISTSW();
            case "M1_AFTER_DURATION":
                return getM1AFTERDURATION();
            case "M1_MARK_ALL_AS_LOADED_LBL":
                return getM1MARKALLASLOADEDLBL();
            case "M1_NOT_LOADED_LBL":
                return getM1NOTLOADEDLBL();
            case "M1_MAX_CAPACITY_FLG":
                return getM1MAXCAPACITYFLG();
            case "M1_ALERT_SENT_LBL":
                return getM1ALERTSENTLBL();
            case "MDT_CAPABILITY_IMAGE":
                return getMDTCAPABILITYIMAGE();
            case "INSTR":
                return getINSTR();
            case "F1_EXT_LOOKUP_USAGE_FLG":
                return getF1EXTLOOKUPUSAGEFLG();
            case "COUNTY":
                return getCOUNTY();
            case "M1_POU_TASK_BO":
                return getM1POUTASKBO();
            case "M1_WIND_ST_DTTM":
                return getM1WINDSTDTTM();
            case "M1_OVERRIDDEN_FLIPSW_LBL":
                return getM1OVERRIDDENFLIPSWLBL();
            case "MAIL_ID":
                return getMAILID();
            case "M1_PARENT_ASSIGNMENT_ID":
                return getM1PARENTASSIGNMENTID();
            case "M1_FILTER_ITEMS_LBL":
                return getM1FILTERITEMSLBL();
            case "ROUND_START_TIME_OPT_FLG":
                return getROUNDSTARTTIMEOPTFLG();
            case "M1_VIEW_ACT_PRCDR_LBL":
                return getM1VIEWACTPRCDRLBL();
            case "M1_SAVE_BTN_LBL":
                return getM1SAVEBTNLBL();
            case "M1_FILE_APPENDER_LBL":
                return getM1FILEAPPENDERLBL();
            case "M1_SITE_INSTRUCTIONS":
                return getM1SITEINSTRUCTIONS();
            case "M1_BRK_WINDOW_DUR":
                return getM1BRKWINDOWDUR();
            case "STARTED_DTTM":
                return getSTARTEDDTTM();
            case "M1_ACTIVITIES_FOR_DEPOT_LBL":
                return getM1ACTIVITIESFORDEPOTLBL();
            case "M1_FINALIZED_DTTM":
                return getM1FINALIZEDDTTM();
            case "M1_DEPENDENCY_TYPE_FLG":
                return getM1DEPENDENCYTYPEFLG();
            case "M1_ITEM_COMPLETION_COMMENTS":
                return getM1ITEMCOMPLETIONCOMMENTS();
            case "M1_PANIC_ALERT_COUNT_DOWN":
                return getM1PANICALERTCOUNTDOWN();
            case "M1_SLA_FLEXIBILITY":
                return getM1SLAFLEXIBILITY();
            case "M1_SERVER_PROXY_PORT":
                return getM1SERVERPROXYPORT();
            case "M1_HIGH_CORR_LIMIT":
                return getM1HIGHCORRLIMIT();
            case "M1_NO_LBL":
                return getM1NOLBL();
            case "M1_IGNORE_SEQ_LOCK_FLG":
                return getM1IGNORESEQLOCKFLG();
            case "M1_OVRD_EXTENSION_LIMIT_FLG":
                return getM1OVRDEXTENSIONLIMITFLG();
            case "M1_GANTT_DISPLAY_ICON_LBL":
                return getM1GANTTDISPLAYICONLBL();
            case "M1_VEHICLE_TAG":
                return getM1VEHICLETAG();
            case "M1_STATE":
                return getM1STATE();
            case "OWNER_FLG":
                return getOWNERFLG();
            case "M1_STOP_BTN_LBL":
                return getM1STOPBTNLBL();
            case "START_TM":
                return getSTARTTM();
            case "M1_ASSIGNMENT_REMKSEC_LBL":
                return getM1ASSIGNMENTREMKSECLBL();
            case "M1_NON_FINAL_SHIFT_WARN_LBL":
                return getM1NONFINALSHIFTWARNLBL();
            case "M1_VEHICLES_LBL":
                return getM1VEHICLESLBL();
            case "M1_ITEM_PACKAGE_ITEMS":
                return getM1ITEMPACKAGEITEMS();
            case "RESRC_CLASS_FLG":
                return getRESRCCLASSFLG();
            case "M1_NATIVE_MAPS_LBL":
                return getM1NATIVEMAPSLBL();
            case "M1_NON_PROD_TASK_LBL":
                return getM1NONPRODTASKLBL();
            case "M1_RESTRICTION_VALUE":
                return getM1RESTRICTIONVALUE();
            case "M1_TAKEN_BY":
                return getM1TAKENBY();
            case "CALENDAR_CD":
                return getCALENDARCD();
            case "M1DEPTSK_AN_LBL":
                return getM1DEPTSKANLBL();
            case "ADHOC_CHAR_VAL":
                return getADHOCCHARVAL();
            case "M1_DATA_SRC_IND":
                return getM1DATASRCIND();
            case "M1_DEPOT_ACT_CLASS_FLG":
                return getM1DEPOTACTCLASSFLG();
            case "M1_ENDS_LBL":
                return getM1ENDSLBL();
            case "M1_LOGGING_LBL":
                return getM1LOGGINGLBL();
            case "M1_IS_DECLINE_ALLOWED_SW":
                return getM1ISDECLINEALLOWEDSW();
            case "M1_REVIEW_LBL":
                return getM1REVIEWLBL();
            case "M1_MDT_ATTCH_ID":
                return getM1MDTATTCHID();
            case "END_DTTM":
                return getENDDTTM();
            case "M1_CREATED_BY_ASSIGNMENT_ID":
                return getM1CREATEDBYASSIGNMENTID();
            case "TIME_ZONE_CD":
                return getTIMEZONECD();
            case "M1_BRK_CRE_DTTM":
                return getM1BRKCREDTTM();
            case "CHAR_VAL_FK2":
                return getCHARVALFK2();
            case "M1_MOBILE_PHONE_NUMBER":
                return getM1MOBILEPHONENUMBER();
            case "CHAR_VAL_FK3":
                return getCHARVALFK3();
            case "CREW_SHFT_TYPE_CD":
                return getCREWSHFTTYPECD();
            case "CHAR_VAL_FK1":
                return getCHARVALFK1();
            case "CHAR_VAL_FK4":
                return getCHARVALFK4();
            case "CHAR_VAL_FK5":
                return getCHARVALFK5();
            case "M1_APPOINTMENT_WINDOW_LBL":
                return getM1APPOINTMENTWINDOWLBL();
            case "M1_PENDING_DISPATCH_APPROVAL":
                return getM1PENDINGDISPATCHAPPROVAL();
            case "M1_CAPACITY_CNT_CMPL_LBL":
                return getM1CAPACITYCNTCMPLLBL();
            case "M1_ACTIVITY_TYPE_WORK_CALENDAR":
                return getM1ACTIVITYTYPEWORKCALENDAR();
            case "M1_MCP_LAYERS":
                return getM1MCPLAYERS();
            case "M1_RT_DST_UNIT_FLG":
                return getM1RTDSTUNITFLG();
            case "SHFT_TMPL_ID":
                return getSHFTTMPLID();
            case "SHIFT_DURATION":
                return getSHIFTDURATION();
            case "M1_EFF_DUR_IMPACT":
                return getM1EFFDURIMPACT();
            case "PROCEDURE_STEP_TEXT":
                return getPROCEDURESTEPTEXT();
            case "M1_PICKUP_SEQUENCE_NUMBER":
                return getM1PICKUPSEQUENCENUMBER();
            case "SVC_AREA_CD":
                return getSVCAREACD();
            case "M1_EXTENSION_LIMIT":
                return getM1EXTENSIONLIMIT();
            case "PROCEDURE_TYPE_CD":
                return getPROCEDURETYPECD();
            case "M1_REF_DELPOY_LBL":
                return getM1REFDELPOYLBL();
            case "M1_RESOURCE_OPTION_FLG":
                return getM1RESOURCEOPTIONFLG();
            case "M1_EXTENSION_DURATION":
                return getM1EXTENSIONDURATION();
            case "M1_ADD_BTN_LBL":
                return getM1ADDBTNLBL();
            case "M1_SEND_MAIL_LBL":
                return getM1SENDMAILLBL();
            case "M1_OFFLINE_FLG":
                return getM1OFFLINEFLG();
            case "M1_PRDF_SNDTO_FLG":
                return getM1PRDFSNDTOFLG();
            case "M1_ACT_CHG_SHFST_LBL":
                return getM1ACTCHGSHFSTLBL();
            case "ADDR4_AVAIL":
                return getADDR4AVAIL();
            case "M1_CANCEL_OFFLINE_LBL":
                return getM1CANCELOFFLINELBL();
            case "ATTACHMENT_NAME_LBL":
                return getATTACHMENTNAMELBL();
            case "M1_WARNING_LBL":
                return getM1WARNINGLBL();
            case "M1_CREW_TM_USG_CD":
                return getM1CREWTMUSGCD();
            case "M1_CHOOSE_AN_ACTION_LBL":
                return getM1CHOOSEANACTIONLBL();
            case "STATUS_RSN_USAGE":
                return getSTATUSRSNUSAGE();
            case "M1_REQ_BY_FLG":
                return getM1REQBYFLG();
            case "M1_ADVANCED_DISPATCH_TASKS":
                return getM1ADVANCEDDISPATCHTASKS();
            case "M1_EARNING_TIME_CMPL_LBL":
                return getM1EARNINGTIMECMPLLBL();
            case "FIXED_CREW":
                return getFIXEDCREW();
            case "M1_TRANSFER_TYPE_FLG":
                return getM1TRANSFERTYPEFLG();
            case "M1_LOGOFF_LOCATION":
                return getM1LOGOFFLOCATION();
            case "M1_NOTIFY_HOST_COMPLETION_ONLY":
                return getM1NOTIFYHOSTCOMPLETIONONLY();
            case "M1_MDT_DEBUG_LBL":
                return getM1MDTDEBUGLBL();
            case "M1_BUS_PRI_NBR":
                return getM1BUSPRINBR();
            case "DELETE_BTN":
                return getDELETEBTN();
            case "M1_ENROUTE_TO_LBL":
                return getM1ENROUTETOLBL();
            case "TIMESHEET_PROCESS_TYPE_CD":
                return getTIMESHEETPROCESSTYPECD();
            case "M1_TBD_LBL":
                return getM1TBDLBL();
            case "GPS_DATA_ENABLED_FLG":
                return getGPSDATAENABLEDFLG();
            case "M1_SMS_CURRENT_TASK_ID":
                return getM1SMSCURRENTTASKID();
            case "M1_REQUEST_HELP_LBL":
                return getM1REQUESTHELPLBL();
            case "M1_ACTIVITY_INFO_LBL":
                return getM1ACTIVITYINFOLBL();
            case "PROCEDURE_STEP_SEQ_NO":
                return getPROCEDURESTEPSEQNO();
            case "M1_WINDOW_COST":
                return getM1WINDOWCOST();
            case "M1_RT_PARMS_LBL":
                return getM1RTPARMSLBL();
            case "M1_TAG":
                return getM1TAG();
            case "ENTITY_INFORMATION":
                return getENTITYINFORMATION();
            case "M1_ADDRESS_CITY":
                return getM1ADDRESSCITY();
            case "ATTENDED_PROCEDURE_FLG":
                return getATTENDEDPROCEDUREFLG();
            case "M1_MAX_FINSH_TRVL":
                return getM1MAXFINSHTRVL();
            case "M1_PARENT_TASK_ID":
                return getM1PARENTTASKID();
            case "M1_AT_DEPOT_LBL":
                return getM1ATDEPOTLBL();
            case "CUST_NAME":
                return getCUSTNAME();
            case "GEO_LONG":
                return getGEOLONG();
            case "STATE_AVAIL":
                return getSTATEAVAIL();
            case "CREATED_BY_LBL":
                return getCREATEDBYLBL();
            case "M1_CAC_EXTENSION_HIGH_LIMIT":
                return getM1CACEXTENSIONHIGHLIMIT();
            case "M1_SAME_CREW_FLG":
                return getM1SAMECREWFLG();
            case "M1_CAP_SYS_EVENT_FLG":
                return getM1CAPSYSEVENTFLG();
            case "M1_SVC_STATE_LBL":
                return getM1SVCSTATELBL();
            case "M1_SEND_NOW_LBL":
                return getM1SENDNOWLBL();
            case "M1_BRK_TYPE":
                return getM1BRKTYPE();
            case "M1_STRICT_TIME_FLG":
                return getM1STRICTTIMEFLG();
            case "M1_CAPACITY_VAL":
                return getM1CAPACITYVAL();
            case "M1_MAP_LBL":
                return getM1MAPLBL();
            case "M1_CREW_SIZE":
                return getM1CREWSIZE();
            case "M1_TIME_REMAINING":
                return getM1TIMEREMAINING();
            case "M1_SCHED_OPT_FLG":
                return getM1SCHEDOPTFLG();
            case "M1_SHIFT_PROCEDURES_LBL":
                return getM1SHIFTPROCEDURESLBL();
            case "M1_ORGJB_LBL":
                return getM1ORGJBLBL();
            case "M1_PLAN_START_TIME":
                return getM1PLANSTARTTIME();
            case "M1_CALC_TRVL_DIST":
                return getM1CALCTRVLDIST();
            case "M1_LOGON_USER":
                return getM1LOGONUSER();
            case "M1_LOGOFF_DELAY":
                return getM1LOGOFFDELAY();
            case "M1_THEME_D_LBL":
                return getM1THEMEDLBL();
            case "M1_FORCED_LOG_OFF_SW":
                return getM1FORCEDLOGOFFSW();
            case "ADJ_DURATION":
                return getADJDURATION();
            case "ATTACHMENT_DATA":
                return getATTACHMENTDATA();
            case "M1_WINDOW_DURATION":
                return getM1WINDOWDURATION();
            case "M1_PROCEDURES_LBL":
                return getM1PROCEDURESLBL();
            case "M1_CAP_TYPE_USAGE_FLG":
                return getM1CAPTYPEUSAGEFLG();
            case "CITY_AVAIL":
                return getCITYAVAIL();
            case "SVC_CLS_CD":
                return getSVCCLSCD();
            case "M1_RESRC_MNGT_LBL":
                return getM1RESRCMNGTLBL();
            case "M1_NOTIFY_HOST_OF_DISPATCH":
                return getM1NOTIFYHOSTOFDISPATCH();
            case "M1_BREAK_TYPE":
                return getM1BREAKTYPE();
            case "M1_EMPLOYEE_ID":
                return getM1EMPLOYEEID();
            case "M1_ELEM_XPATH":
                return getM1ELEMXPATH();
            case "M1_OPEN_LBL":
                return getM1OPENLBL();
            case "NUM1_AVAIL":
                return getNUM1AVAIL();
            case "M1_DURATION_LBL":
                return getM1DURATIONLBL();
            case "F1_CONFIRM_DEL_LBL":
                return getF1CONFIRMDELLBL();
            case "M1_ALERT_MESSAGE":
                return getM1ALERTMESSAGE();
            case "MDT_CAPABILITY_TYPE":
                return getMDTCAPABILITYTYPE();
            case "M1_ARR_TM":
                return getM1ARRTM();
            case "KEY_LBL":
                return getKEYLBL();
            case "M1_ATTACHMENT_DETAILS_LBL":
                return getM1ATTACHMENTDETAILSLBL();
            case "TRAVEL_TIMESHEET_TYPE":
                return getTRAVELTIMESHEETTYPE();
            case "DESCR_OVRD":
                return getDESCROVRD();
            case "RELATED_ENTITY_FLG":
                return getRELATEDENTITYFLG();
            case "M1_TASK_LIST_LBL":
                return getM1TASKLISTLBL();
            case "EXP_DTTM":
                return getEXPDTTM();
            case "ATTACHMENT_ID":
                return getATTACHMENTID();
            case "M1_AUTO_ALLOCATION_DUR":
                return getM1AUTOALLOCATIONDUR();
            case "M1_SCHEDULING_INFO_LBL":
                return getM1SCHEDULINGINFOLBL();
            case "M1_POU_TYPE":
                return getM1POUTYPE();
            case "M1_DELIVER_ALL_ITEMS_LBL":
                return getM1DELIVERALLITEMSLBL();
            case "M1_ADD_VEHICLE_LBL":
                return getM1ADDVEHICLELBL();
            case "DESCRLONG":
                return getDESCRLONG();
            case "M1_GPS_RESRC_ID":
                return getM1GPSRESRCID();
            case "M1_ML_POU_TASK_LBL":
                return getM1MLPOUTASKLBL();
            case "PLAN_END_DTTM":
                return getPLANENDDTTM();
            case "AVG_DUR":
                return getAVGDUR();
            case "M1_RESRV_CAPACITY_LEAD_OPT_FLG":
                return getM1RESRVCAPACITYLEADOPTFLG();
            case "M1_ADV_DISPATCH_MODE_FLG":
                return getM1ADVDISPATCHMODEFLG();
            case "M1_OFFLINE_BTN_LBL":
                return getM1OFFLINEBTNLBL();
            case "M1_THEME_B_LBL":
                return getM1THEMEBLBL();
            case "M1_RESERVE_CAP_LEAD_TM":
                return getM1RESERVECAPLEADTM();
            case "M1_COUNTRY":
                return getM1COUNTRY();
            case "M1_SIGNATURE_LBL":
                return getM1SIGNATURELBL();
            case "M1_DESC_LBL":
                return getM1DESCLBL();
            case "M1_DOWNLOAD":
                return getM1DOWNLOAD();
            case "BUS_STATUS_DTTM":
                return getBUSSTATUSDTTM();
            case "ALLOW_OVERRIDE_FLG":
                return getALLOWOVERRIDEFLG();
            case "M1_SENT_MAIL_LBL":
                return getM1SENTMAILLBL();
            case "M1_START_ODOMTR_LBL":
                return getM1STARTODOMTRLBL();
            case "M1_TO_LBL":
                return getM1TOLBL();
            case "M1_MDT":
                return getM1MDT();
            case "DEPOT_TIMESHEET_TYPE":
                return getDEPOTTIMESHEETTYPE();
            case "M1_MIN_OFFSET":
                return getM1MINOFFSET();
            case "M1_DEPOT_CLASS_FLG":
                return getM1DEPOTCLASSFLG();
            case "M1_SHF_DTL_LBL":
                return getM1SHFDTLLBL();
            case "M1_DEPOT_CD":
                return getM1DEPOTCD();
            case "M1_CALC_TRVL_TM":
                return getM1CALCTRVLTM();
            case "M1_CREWINQUIRY_LBL":
                return getM1CREWINQUIRYLBL();
            case "M1_ADD_ANOTHER_BTN_LBL":
                return getM1ADDANOTHERBTNLBL();
            case "M1_ITEM_DETAILS_LBL":
                return getM1ITEMDETAILSLBL();
            case "M1_POSTPONE_DTTM":
                return getM1POSTPONEDTTM();
            case "M1_NETWORK_COMMUNICATION_LBL":
                return getM1NETWORKCOMMUNICATIONLBL();
            case "M1_FATAL_LBL":
                return getM1FATALLBL();
            case "M1_APPT_END_DTTM":
                return getM1APPTENDDTTM();
            case "MOB_LOG_DTTM":
                return getMOBLOGDTTM();
            case "M1_CALCADJ_DURATION_LBL":
                return getM1CALCADJDURATIONLBL();
            case "MST_CONFIG_DATA":
                return getMSTCONFIGDATA();
            case "M1_TARGET_TASK_TYPE":
                return getM1TARGETTASKTYPE();
            case "M1_ACTIVITY_TYPE":
                return getM1ACTIVITYTYPE();
            case "M1_ADDRESS_4":
                return getM1ADDRESS4();
            case "M1_ADDRESS_2":
                return getM1ADDRESS2();
            case "M1_ADDRESS_3":
                return getM1ADDRESS3();
            case "PROCEDURE_STATE_FLG":
                return getPROCEDURESTATEFLG();
            case "M1_ADDRESS_1":
                return getM1ADDRESS1();
            case "EFF_DTTM":
                return getEFFDTTM();
            case "M1_USER_ID":
                return getM1USERID();
            case "F1_FILE_UPLOAD_DTTM":
                return getF1FILEUPLOADDTTM();
            case "M1_CANCEL_ALERT_ACT_TYPE":
                return getM1CANCELALERTACTTYPE();
            case "M1_TASK_TYPE_FOR_POU":
                return getM1TASKTYPEFORPOU();
            case "M1_DISCONNECT_THRESHOLD":
                return getM1DISCONNECTTHRESHOLD();
            case "PROCEDURE_ID":
                return getPROCEDUREID();
            case "M1_OK_BTN_LBL":
                return getM1OKBTNLBL();
            case "M1_TIMED_EVENT_ALERT_LBL":
                return getM1TIMEDEVENTALERTLBL();
            case "M1_WORK_DURATION":
                return getM1WORKDURATION();
            case "LOCATION_CD":
                return getLOCATIONCD();
            case "M1_KEY_ID":
                return getM1KEYID();
            case "M1_ASIGN_CMPL_RECEIPT_OPT_FLG":
                return getM1ASIGNCMPLRECEIPTOPTFLG();
            case "M1_ITEM_PROVIDED_QUANTITY":
                return getM1ITEMPROVIDEDQUANTITY();
            case "M1_ADDRESS_LBL":
                return getM1ADDRESSLBL();
            case "M1_TASK_STATUS_FLG":
                return getM1TASKSTATUSFLG();
            case "M1_ALLOW_CREW_TIME_FLG":
                return getM1ALLOWCREWTIMEFLG();
            case "HOUSE_TYPE_AVAIL":
                return getHOUSETYPEAVAIL();
            case "M1_ACT_AFRA_LBL":
                return getM1ACTAFRALBL();
            case "ADDR1_LBL":
                return getADDR1LBL();
            case "SHFT_USAGE_FLG":
                return getSHFTUSAGEFLG();
            case "M1_SYNC_ALERT_THRESHOLD":
                return getM1SYNCALERTTHRESHOLD();
            case "STATUS_FLG":
                return getSTATUSFLG();
            case "M1_YES_LBL":
                return getM1YESLBL();
            case "M1_NOTIFY_HOST_OF_STATUS":
                return getM1NOTIFYHOSTOFSTATUS();
            case "IN_CITY_LIM_LBL":
                return getINCITYLIMLBL();
            case "MAN_ALLOC_TO_SHIFT":
                return getMANALLOCTOSHIFT();
            case "PARENT_TASK_ALT_ID":
                return getPARENTTASKALTID();
            case "DRIP_HORIZON":
                return getDRIPHORIZON();
            case "M1_BACK_BTN_LBL":
                return getM1BACKBTNLBL();
            case "M1_DEPOT_TASK_ITEM_ID":
                return getM1DEPOTTASKITEMID();
            case "TSK_TM_WIND_END_DTTM":
                return getTSKTMWINDENDDTTM();
            case "M1_PLAN_HORIZON":
                return getM1PLANHORIZON();
            case "GEO_CODE_LBL":
                return getGEOCODELBL();
            case "M1_DEPOT_RUN_CLOSED_FLG":
                return getM1DEPOTRUNCLOSEDFLG();
            case "M1_FORCE_LOGOFF_REASON_FLG":
                return getM1FORCELOGOFFREASONFLG();
            case "M1_SCAN_ALL_ITEMS_LBL":
                return getM1SCANALLITEMSLBL();
            case "CREATE_USER_LBL":
                return getCREATEUSERLBL();
            case "ANSWER_TYPE_FLG":
                return getANSWERTYPEFLG();
            case "MDT_INDICATOR_IMAGE":
                return getMDTINDICATORIMAGE();
            case "RESRC_ID":
                return getRESRCID();
            case "M1_THEME_LBL":
                return getM1THEMELBL();
            case "M1_SITE_DELAY":
                return getM1SITEDELAY();
            case "M1_SCAN_LBL":
                return getM1SCANLBL();
            case "M1_ALERT_SOUND":
                return getM1ALERTSOUND();
            case "M1_SERVICE_ADDRESS":
                return getM1SERVICEADDRESS();
            case "M1_EARNING_TYPE":
                return getM1EARNINGTYPE();
            case "M1_CUTOFF_DTTM":
                return getM1CUTOFFDTTM();
            case "FIRST_NAME":
                return getFIRSTNAME();
            case "ADDR2_AVAIL":
                return getADDR2AVAIL();
            case "PROCEDURE_EXP_DT":
                return getPROCEDUREEXPDT();
            case "M1_VEH_END_ODO_MTR":
                return getM1VEHENDODOMTR();
            case "F1_ATTACHMENT_FILE_SIZE":
                return getF1ATTACHMENTFILESIZE();
            case "M1_RANK":
                return getM1RANK();
            case "CANCEL_LBL":
                return getCANCELLBL();
            case "M1_SEND_TO_HOST":
                return getM1SENDTOHOST();
            case "ORIG_PLANNED_START_DTTM":
                return getORIGPLANNEDSTARTDTTM();
            case "M1_ONLINE_LBL":
                return getM1ONLINELBL();
            case "M1_TMSHEET_CORR_FLG":
                return getM1TMSHEETCORRFLG();
            case "M1_ITEM_QUANTITY":
                return getM1ITEMQUANTITY();
            case "GEO_CODE_AVAIL":
                return getGEOCODEAVAIL();
            case "M1_SHIFT_ID":
                return getM1SHIFTID();
            case "M1_STATUS_RSN_LBL":
                return getM1STATUSRSNLBL();
            case "CAP_TYPE_CD":
                return getCAPTYPECD();
            case "M1_EXPIRATION_TD_TYPE":
                return getM1EXPIRATIONTDTYPE();
            case "OVERRIDE_FAILURE_FLG":
                return getOVERRIDEFAILUREFLG();
            case "M1_UPDATE_LBL":
                return getM1UPDATELBL();
            case "STATUS_UPD_DTTM":
                return getSTATUSUPDDTTM();
            case "M1_SENT_FROM_CREW_SHFT":
                return getM1SENTFROMCREWSHFT();
            case "HOST_SYSTEM_CD":
                return getHOSTSYSTEMCD();
            case "ESTIMATED_DURATION":
                return getESTIMATEDDURATION();
            case "M1_LOC_OPT_FLG":
                return getM1LOCOPTFLG();
            case "TIMESHEET_TYPE_CD":
                return getTIMESHEETTYPECD();
            case "M1_ACT_CPF_LBL":
                return getM1ACTCPFLBL();
            case "NUMBER_ANSWER":
                return getNUMBERANSWER();
            case "M1_SVC_CATEGORY_CD":
                return getM1SVCCATEGORYCD();
            case "M1_MESSAGES_LBL":
                return getM1MESSAGESLBL();
            case "F1-ATTACHIDLBL":
                return getF1ATTACHIDLBL();
            case "M1_PREVIEW_BTN_LBL":
                return getM1PREVIEWBTNLBL();
            case "M1_ELIGIBLE_ASSIST_FLG":
                return getM1ELIGIBLEASSISTFLG();
            case "START_DTTM":
                return getSTARTDTTM();
            case "STEP_UPPER_LIMIT":
                return getSTEPUPPERLIMIT();
            case "LOGON_MOBILE_PHONE":
                return getLOGONMOBILEPHONE();
            case "M1_RESOURCE_LBL":
                return getM1RESOURCELBL();
            case "M1_AUTO_EXTENSION":
                return getM1AUTOEXTENSION();
            case "COUNTY_AVAIL":
                return getCOUNTYAVAIL();
            case "M1_DATA_ENCRYPTION_GC_FLG":
                return getM1DATAENCRYPTIONGCFLG();
            case "M1_CAMERA_LBL":
                return getM1CAMERALBL();
            case "M1_REMOTE_APPENDER_LBL":
                return getM1REMOTEAPPENDERLBL();
            case "M1_BREAK_TASK_LBL":
                return getM1BREAKTASKLBL();
            case "BO_STATUS_CD":
                return getBOSTATUSCD();
            case "EXT_OPT_TYPE":
                return getEXTOPTTYPE();
            case "M1_SUBURB":
                return getM1SUBURB();
            case "M1_ITEM_LOAD_STATUS_FLG":
                return getM1ITEMLOADSTATUSFLG();
            case "PROCEDURE_COMMENTS":
                return getPROCEDURECOMMENTS();
            case "M1_SHIFT_ACTIONS_LBL":
                return getM1SHIFTACTIONSLBL();
            case "M1_CONTACT_NAME":
                return getM1CONTACTNAME();
            case "M1_GALLERY_LBL":
                return getM1GALLERYLBL();
            case "M1_SYNC_ALERT_TYPE":
                return getM1SYNCALERTTYPE();
            case "M1_SCHED_PRIORITY_VAL":
                return getM1SCHEDPRIORITYVAL();
            case "M1_LEFT_AT_LBL":
                return getM1LEFTATLBL();
            case "M1_LATE_COST":
                return getM1LATECOST();
            case "M1_POU_SHIFT_ID":
                return getM1POUSHIFTID();
            case "M1_SERVERSYNC":
                return getM1SERVERSYNC();
            case "M1_ELGB_CONTRACTING_FLG":
                return getM1ELGBCONTRACTINGFLG();
            case "BO_DATA_AREA":
                return getBODATAAREA();
            case "M1_ACTIVITY_ALTERNATE_ID":
                return getM1ACTIVITYALTERNATEID();
            case "WFM_MSG_CD":
                return getWFMMSGCD();
            case "M1_INBOX_LBL":
                return getM1INBOXLBL();
            case "M1_INFO_LBL":
                return getM1INFOLBL();
            case "M1_LOADED_LBL":
                return getM1LOADEDLBL();
            case "M1_HOST_CHAIN_EXT_ID":
                return getM1HOSTCHAINEXTID();
            case "M1_CONTR_ELIG_VERSION":
                return getM1CONTRELIGVERSION();
            case "M1_MDTOWNED":
                return getM1MDTOWNED();
            case "M1_OVERRIDE_FLIPSW_LBL":
                return getM1OVERRIDEFLIPSWLBL();
            case "M1_PLAN_END_TIME":
                return getM1PLANENDTIME();
            case "M1_PRIMARY_FUNCTION":
                return getM1PRIMARYFUNCTION();
            case "M1_PERSON_ID":
                return getM1PERSONID();
            case "M1_MAIL_LBL":
                return getM1MAILLBL();
            case "CHAR_TYPE_CD":
                return getCHARTYPECD();
            case "M1_ADVANCED_DISPATCH_OFFSET":
                return getM1ADVANCEDDISPATCHOFFSET();
            case "ERROR_LBL":
                return getERRORLBL();
            case "M1_CRW_LBL":
                return getM1CRWLBL();
            case "PK_VALUE2":
                return getPKVALUE2();
            case "PK_VALUE1":
                return getPKVALUE1();
            case "PK_VALUE4":
                return getPKVALUE4();
            case "PK_VALUE3":
                return getPKVALUE3();
            case "M1_LOGON_LOCATION_TYPE":
                return getM1LOGONLOCATIONTYPE();
            case "PK_VALUE5":
                return getPKVALUE5();
            case "M1_VIEW_SHF_PRCDR_LBL":
                return getM1VIEWSHFPRCDRLBL();
            case "M1_SYSTEM_GEN_FLG":
                return getM1SYSTEMGENFLG();
            case "M1_GEOCODE_LATITUDE":
                return getM1GEOCODELATITUDE();
            case "M1_ELEM_INDEX":
                return getM1ELEMINDEX();
            case "M1_ITEM_DELIVERY_STATUS_FLG":
                return getM1ITEMDELIVERYSTATUSFLG();
            case "M1_ACTIVITY_LBL":
                return getM1ACTIVITYLBL();
            case "M1_DEPOT_REL_ASSIGNMENT_LBL":
                return getM1DEPOTRELASSIGNMENTLBL();
            case "M1_DEFERMENT_COMMENTS":
                return getM1DEFERMENTCOMMENTS();
            case "M1_CREW_NAME":
                return getM1CREWNAME();
            case "M1_ACTIVITY_PROCEDURES_LBL":
                return getM1ACTIVITYPROCEDURESLBL();
            case "OUTMSG_PRIOR_FLG":
                return getOUTMSGPRIORFLG();
            case "M1_AUTO_COMP_FLG":
                return getM1AUTOCOMPFLG();
            case "M1_DOWNLOAD_ALL":
                return getM1DOWNLOADALL();
            case "M1_COLLISION_DETECTED_TODO_TYP":
                return getM1COLLISIONDETECTEDTODOTYP();
            case "M1_GUAR_DEL_LBL":
                return getM1GUARDELLBL();
            case "M1_ADDRESS_COUNTY":
                return getM1ADDRESSCOUNTY();
            case "M1_DEFERMENT_REASON_FLG":
                return getM1DEFERMENTREASONFLG();
            case "M1_SUBJECT":
                return getM1SUBJECT();
            case "M1_PANIC_HEADER_LBL":
                return getM1PANICHEADERLBL();
            case "TASK_ALT_ID":
                return getTASKALTID();
            case "SEQ_NUM":
                return getSEQNUM();
            case "M1_LOAD_ALL_ITEMS_LBL":
                return getM1LOADALLITEMSLBL();
            case "M1_SHOW_MORE_LBL":
                return getM1SHOWMORELBL();
            case "M1_UPDATED_ETA":
                return getM1UPDATEDETA();
            case "M1_RESET_SIGNATURE_LBL":
                return getM1RESETSIGNATURELBL();
            case "M1_DELIVERED_LBL":
                return getM1DELIVEREDLBL();
            case "M1_REMARK_TYPE":
                return getM1REMARKTYPE();
            case "M1_LOCKED_TO_DEPOT_TASK_ID":
                return getM1LOCKEDTODEPOTTASKID();
            case "M1_DEPOT_TASK_BO":
                return getM1DEPOTTASKBO();
            case "M1_SVC_TYPE_FLG":
                return getM1SVCTYPEFLG();
            case "M1_MBL_WKR_LBL":
                return getM1MBLWKRLBL();
            case "M1_REACH_DEST_LBL":
                return getM1REACHDESTLBL();
            case "WFM_MSG_CAT_FLG":
                return getWFMMSGCATFLG();
            case "M1_SENT_BY_MAIL_ID":
                return getM1SENTBYMAILID();
            case "M1_LOGOFF_BTN_LBL":
                return getM1LOGOFFBTNLBL();
            case "M1_CHANGE_SEQUENCE_FLG":
                return getM1CHANGESEQUENCEFLG();
            case "TSK_TM_WIND_START_DTTM":
                return getTSKTMWINDSTARTDTTM();
            case "M1_DEPOT_TASK_TYPE":
                return getM1DEPOTTASKTYPE();
            case "MDT_INDICATOR_POSITION":
                return getMDTINDICATORPOSITION();
            case "M1_RTN_TO_SVC_LBL":
                return getM1RTNTOSVCLBL();
            case "M1_OVERTIME_TYPE_EXT_ID":
                return getM1OVERTIMETYPEEXTID();
            case "M1_NEW_FUNCTION_LBL":
                return getM1NEWFUNCTIONLBL();
            case "M1_CORRECT_LBL":
                return getM1CORRECTLBL();
            case "M1_BREAK_TIME":
                return getM1BREAKTIME();
            case "M1_RTN_SVC_PRPT":
                return getM1RTNSVCPRPT();
            case "M1_MCP_CAPABILITY_TYP_MAIN_LBL":
                return getM1MCPCAPABILITYTYPMAINLBL();
            case "M1_CREWINQUIRY_TYPE":
                return getM1CREWINQUIRYTYPE();
            case "ADDR1_AVAIL":
                return getADDR1AVAIL();
            case "M1_SCAN_NEXT_LBL":
                return getM1SCANNEXTLBL();
            case "OVERRIDE_ALLOCATION_RULE":
                return getOVERRIDEALLOCATIONRULE();
            case "M1_SECONDS_LBL":
                return getM1SECONDSLBL();
            case "MDT_INDICATOR_CODE":
                return getMDTINDICATORCODE();
            case "M1_ACTIVITY_CLASS_FLG":
                return getM1ACTIVITYCLASSFLG();
            case "M1_DURATION":
                return getM1DURATION();
            case "M1_SS_LBL":
                return getM1SSLBL();
            case "M1_PROCEDURE_MESSAGE_NBR":
                return getM1PROCEDUREMESSAGENBR();
            case "M1_ACTUAL_COMPLETION_TIME":
                return getM1ACTUALCOMPLETIONTIME();
            case "F1_EXT_LOOKUP_VALUE":
                return getF1EXTLOOKUPVALUE();
            case "M1_DECLINE_ALL_ITEMS_LBL":
                return getM1DECLINEALLITEMSLBL();
            case "M1_POUTASK_ID":
                return getM1POUTASKID();
            case "M1_ONLINE_BTN_LBL":
                return getM1ONLINEBTNLBL();
            case "BO_STATUS_REASON_CD":
                return getBOSTATUSREASONCD();
            case "M1_ACTIVITY_ID":
                return getM1ACTIVITYID();
            case "LOC_TYPE_FLG":
                return getLOCTYPEFLG();
            case "M1_PICKUP_STATUS_FLG":
                return getM1PICKUPSTATUSFLG();
            case "M1_WARN_LBL":
                return getM1WARNLBL();
            case "M1_ISSUE_DETECTED_TODO_TYPE":
                return getM1ISSUEDETECTEDTODOTYPE();
            case "M1_COMPLETED_LBL":
                return getM1COMPLETEDLBL();
            case "M1_HOST_JOB_EXTERNAL_ID":
                return getM1HOSTJOBEXTERNALID();
            case "M1_MARK_ALL_AS_UNLOADED_LBL":
                return getM1MARKALLASUNLOADEDLBL();
            case "TOTAL_LBL":
                return getTOTALLBL();
            case "BREAK_TIMESHEET_TYPE":
                return getBREAKTIMESHEETTYPE();
            case "M1_PREV_CUTOFF_DTTM":
                return getM1PREVCUTOFFDTTM();
            case "M1_SENDTOCREW":
                return getM1SENDTOCREW();
            case "M1_CELL_PHONE":
                return getM1CELLPHONE();
            case "M1_CAPTURE_SIGNATURE_LBL":
                return getM1CAPTURESIGNATURELBL();
            case "VERSION":
                return getVERSION();
            case "M1_MCP_MARKERS":
                return getM1MCPMARKERS();
            case "M1_RVE_TM_WAIT_LBL":
                return getM1RVETMWAITLBL();
            case "M1_ERROR_LBL":
                return getM1ERRORLBL();
            case "M1_COMPLETED_BY_ASSIGNMENT_ID":
                return getM1COMPLETEDBYASSIGNMENTID();
            case "WFM_OPT_VAL":
                return getWFMOPTVAL();
            case "M1_CAPACITY_PREFERRED_FLG":
                return getM1CAPACITYPREFERREDFLG();
            case "PARENT_TASK_ID":
                return getPARENTTASKID();
            case "M1_PRE_TIME_FAC":
                return getM1PRETIMEFAC();
            case "M1_COMPLEX_ACT_CMPL_LBL":
                return getM1COMPLEXACTCMPLLBL();
            case "M1_THEME_A_LBL":
                return getM1THEMEALBL();
            case "M1_ATTACHMENT_FILE_NAME":
                return getM1ATTACHMENTFILENAME();
            case "NUM2_AVAIL":
                return getNUM2AVAIL();
            case "GEO_LAT":
                return getGEOLAT();
            case "M1_DOWNLOAD_IN_PROGRESS_LBL":
                return getM1DOWNLOADINPROGRESSLBL();
            case "M1_POSTPONE_DTTM_NO_DEFAULT_SW":
                return getM1POSTPONEDTTMNODEFAULTSW();
            case "M1_SND_TO_LBL":
                return getM1SNDTOLBL();
            case "M1_HAS_ATTACHMENTS_SW":
                return getM1HASATTACHMENTSSW();
            case "M1_LEGEND_LBL":
                return getM1LEGENDLBL();
            case "M1_TASK_DETAILS_LBL":
                return getM1TASKDETAILSLBL();
            case "M1_HH_LBL":
                return getM1HHLBL();
            case "M1_COMPOSE_MAIL_LBL":
                return getM1COMPOSEMAILLBL();
            case "M1_MOBILE_WORKER":
                return getM1MOBILEWORKER();
            case "TASK_CLS_FLG":
                return getTASKCLSFLG();
            case "PROCEDURE_BUS_OBJ_CD":
                return getPROCEDUREBUSOBJCD();
            case "CALC_DURATION":
                return getCALCDURATION();
            case "M1_PANIC_ALERT_TYPE":
                return getM1PANICALERTTYPE();
            case "M1_MDT_SOUND_PAUSE":
                return getM1MDTSOUNDPAUSE();
            case "M1_CUST_CONTACT_TYPE_MAIN_LBL":
                return getM1CUSTCONTACTTYPEMAINLBL();
            case "M1_MAX_NONCUM_CAPACITY_FLG":
                return getM1MAXNONCUMCAPACITYFLG();
            case "M1_CREW_TM_USG_CLS_FLG":
                return getM1CREWTMUSGCLSFLG();
            case "M1_CAC_EXTENSION_LOW_LIMIT":
                return getM1CACEXTENSIONLOWLIMIT();
            case "WFM_NAME":
                return getWFMNAME();
            case "PLAN_START_DTTM":
                return getPLANSTARTDTTM();
            case "M1_EST_REMAINING_DURATION":
                return getM1ESTREMAININGDURATION();
            case "M1_TMSHT_OVRD_FLG":
                return getM1TMSHTOVRDFLG();
            case "M1_INQUIRY_HISTORY":
                return getM1INQUIRYHISTORY();
            case "M1_CALC_DURATION":
                return getM1CALCDURATION();
            case "PROCEDURE_EFF_DT":
                return getPROCEDUREEFFDT();
            case "M1_UPLOADED_IMAGES_LBL":
                return getM1UPLOADEDIMAGESLBL();
            case "M1_ADD_WORKER_LBL":
                return getM1ADDWORKERLBL();
            case "M1_SITE_ID":
                return getM1SITEID();
            case "STATE_LBL":
                return getSTATELBL();
            case "USER_ID":
                return getUSERID();
            case "M1_ASSIGNED_ENGINEER":
                return getM1ASSIGNEDENGINEER();
            case "TMSHEET_BO_CD":
                return getTMSHEETBOCD();
            case "M1_ACT_CAL_LBL":
                return getM1ACTCALLBL();
            case "M1_TIME_REMAINING_AS_OF_DTTM":
                return getM1TIMEREMAININGASOFDTTM();
            case "M1_POSTPONE_UNTIL_LBL":
                return getM1POSTPONEUNTILLBL();
            case "M1_SOUND_DURATION":
                return getM1SOUNDDURATION();
            case "M1_MDT_TASKLIST_LINE":
                return getM1MDTTASKLISTLINE();
            case "POSTAL":
                return getPOSTAL();
            case "ADDR2_LBL":
                return getADDR2LBL();
            case "M1_CREW_TIME_USAGE_CMPL_LBL":
                return getM1CREWTIMEUSAGECMPLLBL();
            case "M1_ACTIVITY_TYPE_LBL":
                return getM1ACTIVITYTYPELBL();
            case "M1_MCPME_SCHEDULING_INFO_LBL":
                return getM1MCPMESCHEDULINGINFOLBL();
            case "M1_LOW_CORR_LIMIT":
                return getM1LOWCORRLIMIT();
            case "M1_ARRIVED_ASSIGNMENT_LBL":
                return getM1ARRIVEDASSIGNMENTLBL();
            case "M1_MM_LBL":
                return getM1MMLBL();
            case "M1_DEPOT_ADDRESS":
                return getM1DEPOTADDRESS();
            case "M1_ASSIGNMENT_ID":
                return getM1ASSIGNMENTID();
            case "M1_TIMED_EVENT_EXP_DTTM":
                return getM1TIMEDEVENTEXPDTTM();
            case "M1_QUESTIONNAIRE_LBL":
                return getM1QUESTIONNAIRELBL();
            case "M1_COMMENTS":
                return getM1COMMENTS();
            case "M1_RESERVE_CAP_MAX_PERCENT":
                return getM1RESERVECAPMAXPERCENT();
            case "M1_DUR_EXTENSION_LIMIT":
                return getM1DUREXTENSIONLIMIT();
            case "YES_NO_ANSWER_FLG":
                return getYESNOANSWERFLG();
            case "M1_DEPLOYMENT_ID_LBL":
                return getM1DEPLOYMENTIDLBL();
            case "M1_SCAN_BARCODE_LBL":
                return getM1SCANBARCODELBL();
            case "TIMESHEET_ID":
                return getTIMESHEETID();
            case "M1_SYNC_LOG_FILES_LBL":
                return getM1SYNCLOGFILESLBL();
            case "M1_LOAD_INSTR":
                return getM1LOADINSTR();
            case "M1_SUMMARY_LBL":
                return getM1SUMMARYLBL();
            case "M1_DECLINE_COMMENTS":
                return getM1DECLINECOMMENTS();
            case "PK_VAL5":
                return getPKVAL5();
            case "M1_APPROVAL_DTTM_LBL":
                return getM1APPROVALDTTMLBL();
            case "M1_MAX_LATE":
                return getM1MAXLATE();
            case "M1_TASKS_LBL":
                return getM1TASKSLBL();
            case "PK_VAL1":
                return getPKVAL1();
            case "PK_VAL2":
                return getPKVAL2();
            case "M1_PENDING_LBL":
                return getM1PENDINGLBL();
            case "PK_VAL3":
                return getPKVAL3();
            case "M1_ITEM_CUST_ACCEPTED_FLG":
                return getM1ITEMCUSTACCEPTEDFLG();
            case "PK_VAL4":
                return getPKVAL4();
            case "CROSS_STREET":
                return getCROSSSTREET();
            case "M1_OVERRIDE_PRCDR_CLEAR_LBL":
                return getM1OVERRIDEPRCDRCLEARLBL();
            case "POU_ID":
                return getPOUID();
            case "M1_CREW_SHFT_LBL":
                return getM1CREWSHFTLBL();
            case "M1_RE_LBL":
                return getM1RELBL();
            case "M1_ACTIVITY_EXP_LBL":
                return getM1ACTIVITYEXPLBL();
            case "M1_FROM_LBL":
                return getM1FROMLBL();
            case "M1_JOB_ID":
                return getM1JOBID();
            case "CITY_LBL":
                return getCITYLBL();
            case "APPOINTMENT_FLG":
                return getAPPOINTMENTFLG();
            case "M1_ACTIVITY_ATTRIBUTE":
                return getM1ACTIVITYATTRIBUTE();
            case "M1_LOAD_TASK_BUTTON_LBL":
                return getM1LOADTASKBUTTONLBL();
            case "M1_SELECT_THEME_LBL":
                return getM1SELECTTHEMELBL();
            case "M1_MORE_ELLIPSIS_LBL":
                return getM1MOREELLIPSISLBL();
            case "M1_WORK_SEQ_LBL":
                return getM1WORKSEQLBL();
            case "M1_ACTUAL_START_TIME":
                return getM1ACTUALSTARTTIME();
            case "M1_SETTINGS_LBL":
                return getM1SETTINGSLBL();
            case "M1_EXTENSION_DAYS":
                return getM1EXTENSIONDAYS();
            case "HOST_TASK_ID":
                return getHOSTTASKID();
            case "M1_ALLOW_BREAKS_FLG":
                return getM1ALLOWBREAKSFLG();
            case "M1_MCP_INDICATOR_MAIN_LBL":
                return getM1MCPINDICATORMAINLBL();
            case "M1_COLLISION_DETECTED_TODO_ROL":
                return getM1COLLISIONDETECTEDTODOROL();
            case "M1_CREATE_BY_CREW_FLG":
                return getM1CREATEBYCREWFLG();
            case "M1_SVC_AREA_USAGE":
                return getM1SVCAREAUSAGE();
            case "M1_USED_UNTIL_LBL":
                return getM1USEDUNTILLBL();
            case "M1_CROSS_STREET":
                return getM1CROSSSTREET();
            case "M1_ETA_LBL":
                return getM1ETALBL();
            case "M1_SERVICE_INSTRUCTIONS":
                return getM1SERVICEINSTRUCTIONS();
            case "M1_RESTRICTION_TYPE_FLG":
                return getM1RESTRICTIONTYPEFLG();
            case "M1_SCHEDULING_ORDER":
                return getM1SCHEDULINGORDER();
            case "M1_TEMPLATE_SHIFT":
                return getM1TEMPLATESHIFT();
            case "STATUS_REASON_SELECT_FLG":
                return getSTATUSREASONSELECTFLG();
            case "M1_AFTER_DAYS":
                return getM1AFTERDAYS();
            case "DIRECTIONS_LBL":
                return getDIRECTIONSLBL();
            case "M1_CUSTOMER_INFO_LBL":
                return getM1CUSTOMERINFOLBL();
            case "DESCR":
                return getDESCR();
            case "CREW_SHFT_ID":
                return getCREWSHFTID();
            case "M1_SEL_PRI_FUNCTION_LBL":
                return getM1SELPRIFUNCTIONLBL();
            case "M1_ADJUSTED_DURATION":
                return getM1ADJUSTEDDURATION();
            case "M1_CALC_ERROR_SW":
                return getM1CALCERRORSW();
            case "M1_AT_LBL":
                return getM1ATLBL();
            case "M1_APPT_ST_DTTM":
                return getM1APPTSTDTTM();
            case "M1_LOAD_TASK_COMPLETE_LBL":
                return getM1LOADTASKCOMPLETELBL();
            case "M1_EXT_ENTITY_NAME":
                return getM1EXTENTITYNAME();
            case "M1_DOWNLOADED":
                return getM1DOWNLOADED();
            case "M1_DEPOT_INFORMATION_LBL":
                return getM1DEPOTINFORMATIONLBL();
            case "M1_FOLDER_FLG":
                return getM1FOLDERFLG();
            case "POSTAL_AVAIL":
                return getPOSTALAVAIL();
            case "M1_MAIL_ID":
                return getM1MAILID();
            case "M1_BRK_DUR":
                return getM1BRKDUR();
            case "M1_ITEM_BARCODE_TYPE":
                return getM1ITEMBARCODETYPE();
            case "M1_NPT_LBL":
                return getM1NPTLBL();
            case "M1_SELECT_ONE_LBL":
                return getM1SELECTONELBL();
            case "M1_ITEM_BARCODE":
                return getM1ITEMBARCODE();
            case "M1_UNACKN_EMERG_ALERT_TYPE":
                return getM1UNACKNEMERGALERTTYPE();
            case "M1-MCPMEPOSTPONED":
                return getM1MCPMEPOSTPONED();
            case "M1_ITEM_ADDITIONAL_DETAILS":
                return getM1ITEMADDITIONALDETAILS();
            case "ACCEPT_LBL":
                return getACCEPTLBL();
            case "WORK_TIMESHEET_TYPE":
                return getWORKTIMESHEETTYPE();
            case "M1_RECEIVED_LBL":
                return getM1RECEIVEDLBL();
            case "M1_RETURN_ALL_ITEMS_LBL":
                return getM1RETURNALLITEMSLBL();
            case "M1_CUMULATIVE_CAPACITY_FLG":
                return getM1CUMULATIVECAPACITYFLG();
            case "M1_MAIN_PHONE":
                return getM1MAINPHONE();
            case "M1_MAILING_LIST_CD":
                return getM1MAILINGLISTCD();
            case "M1_EARNING_TYPE_EXT_ID":
                return getM1EARNINGTYPEEXTID();
            case "M1_FINAL_DTTM":
                return getM1FINALDTTM();
            case "M1_DEPOT_TASK_ID":
                return getM1DEPOTTASKID();
            case "M1_POSTPONE_DATE":
                return getM1POSTPONEDATE();
            case "M1_ACTIVITY_ATTRIB_USAGE_FLG":
                return getM1ACTIVITYATTRIBUSAGEFLG();
            case "SEND_BTN_LBL":
                return getSENDBTNLBL();
            case "M1_GEOCODE_LONGITUDE":
                return getM1GEOCODELONGITUDE();
            case "RESRC_ID_TYPE_FLG":
                return getRESRCIDTYPEFLG();
            case "SEQNO":
                return getSEQNO();
            case "M1_CREATION_DTTM":
                return getM1CREATIONDTTM();
            case "M1_START_BTN_LBL":
                return getM1STARTBTNLBL();
            case "M1_NON_PROD_TASK_ID":
                return getM1NONPRODTASKID();
            case "M1_THEME_C_LBL":
                return getM1THEMECLBL();
            case "M1_ON_SITE_DATE":
                return getM1ONSITEDATE();
            case "M1_ALERTS_LBL":
                return getM1ALERTSLBL();
            case "M1_REQUIRED_FIELDS_LBL":
                return getM1REQUIREDFIELDSLBL();
            case "M1_MIN_VISIT_DURATION":
                return getM1MINVISITDURATION();
            case "M1_ACTIVITY_TYPE_TODO":
                return getM1ACTIVITYTYPETODO();
            case "M1_NAME":
                return getM1NAME();
            case "M1_ACCOUNT_ID":
                return getM1ACCOUNTID();
            case "ATTACHMENT_FILE_NAME":
                return getATTACHMENTFILENAME();
            case "M1_EXT_ENTITY_VALUE":
                return getM1EXTENTITYVALUE();
            case "SVC_AREA_USG_FLG":
                return getSVCAREAUSGFLG();
            case "POU_TIMESHEET_TYPE":
                return getPOUTIMESHEETTYPE();
            case "PRI_PROF_CD":
                return getPRIPROFCD();
            case "M1_REVW_ON_DEV_FLG":
                return getM1REVWONDEVFLG();
            case "PROCEDURE_STATUS_FLG":
                return getPROCEDURESTATUSFLG();
            case "M1_AUTO_ALLOCATION_DAYS":
                return getM1AUTOALLOCATIONDAYS();
            case "SVC_CLS_USG_FLG":
                return getSVCCLSUSGFLG();
            case "M1_TRAVEL_DISTANCE":
                return getM1TRAVELDISTANCE();
            case "M1_CAC_REMAINING_DURATION":
                return getM1CACREMAININGDURATION();
            case "M1_COMPLETE_BTN_LBL":
                return getM1COMPLETEBTNLBL();
            case "M1_GROUP_LBL":
                return getM1GROUPLBL();
            case "STEP_REQUIRED_FLG":
                return getSTEPREQUIREDFLG();
            case "M1_CUSTOMER_CONTACT_TYPE_CD":
                return getM1CUSTOMERCONTACTTYPECD();
            case "MDT_CAPABILITY_ATTACHMENT_BO":
                return getMDTCAPABILITYATTACHMENTBO();
            case "M1_PERCENTAGE_DEVIATION":
                return getM1PERCENTAGEDEVIATION();
            case "M1_OR_TASK_CAPABILITY_FLG":
                return getM1ORTASKCAPABILITYFLG();
            case "M1_ITEM_ATTR_NAME":
                return getM1ITEMATTRNAME();
            case "M1_MLRD_STATUS_FLG":
                return getM1MLRDSTATUSFLG();
            case "M1_RELATED_ACTIVITY_TYPES":
                return getM1RELATEDACTIVITYTYPES();
            case "M1_AVG_VISIT_DURATION":
                return getM1AVGVISITDURATION();
            case "M1_CONTRACTOR_ID":
                return getM1CONTRACTORID();
            case "M1_GO_OUT_SVC_LBL":
                return getM1GOOUTSVCLBL();
            case "M1_DECLINED_LBL":
                return getM1DECLINEDLBL();
            case "NPT_TIMESHEET_TYPE":
                return getNPTTIMESHEETTYPE();
            case "M1_ALLOW_RELATED_ACTIVITIES":
                return getM1ALLOWRELATEDACTIVITIES();
            case "M1_WINDOW_APPENDER_LBL":
                return getM1WINDOWAPPENDERLBL();
            case "DFL_APPT_BOOK_GRP":
                return getDFLAPPTBOOKGRP();
            case "M1_ISSUE_DETECTED_TODO_ROLE":
                return getM1ISSUEDETECTEDTODOROLE();
            case "M1_END_TM":
                return getM1ENDTM();
            case "M1_REVIEW_RQD_LBL":
                return getM1REVIEWRQDLBL();
            case "M1_ITEM_INFORMATION_LBL":
                return getM1ITEMINFORMATIONLBL();
            case "CAP_DTTM":
                return getCAPDTTM();
            case "M1_TRANSPORT_RESTRICTION_FLG":
                return getM1TRANSPORTRESTRICTIONFLG();
            case "MAINT_OBJ_CD":
                return getMAINTOBJCD();
            case "M1_TIMED_EVENT_ALERT_TYPE":
                return getM1TIMEDEVENTALERTTYPE();
            case "POSTAL_LBL":
                return getPOSTALLBL();
            case "M1_RESRV_CAPACITY_BY_FLG":
                return getM1RESRVCAPACITYBYFLG();
            case "M1_ITEM_DELI_DCLN_RSN_FLG":
                return getM1ITEMDELIDCLNRSNFLG();
            case "M1_START_DAY_OF_WEEK":
                return getM1STARTDAYOFWEEK();
            case "M1_RT_DST_UNIT_ABBR_FLG":
                return getM1RTDSTUNITABBRFLG();
            case "M1_REAL_GPS_THRESHOLD":
                return getM1REALGPSTHRESHOLD();
            case "RESET_LBL":
                return getRESETLBL();
            case "ADDR3_LBL":
                return getADDR3LBL();
            case "ACKNOWLEDGEMENT_REQ_FLG":
                return getACKNOWLEDGEMENTREQFLG();
            case "M1_FILE_DESC":
                return getM1FILEDESC();
            case "M1_COMPLETE_ACT_LBL":
                return getM1COMPLETEACTLBL();
            case "M1_RESERVE_CAP_TYPE":
                return getM1RESERVECAPTYPE();
            case "BO_STATUS_BO_CD":
                return getBOSTATUSBOCD();
            case "M1_HOST_PARENT_EXT_ID":
                return getM1HOSTPARENTEXTID();
            case "M1_RVW_TM_SH_LBL":
                return getM1RVWTMSHLBL();
            case "M1_ITEM_CUST_ACCEPT_REQ_FLG":
                return getM1ITEMCUSTACCEPTREQFLG();
            case "M1_MDT_LOG_LOC":
                return getM1MDTLOGLOC();
            case "M1_DEPENDENT_ON":
                return getM1DEPENDENTON();
            case "CITY":
                return getCITY();
            case "M1_LOCATION":
                return getM1LOCATION();
            case "MESSAGE_CAT_NBR":
                return getMESSAGECATNBR();
            case "M1_DECLINE_ACT_LBL":
                return getM1DECLINEACTLBL();
            case "M1_MCPME_CUSTOMER_INFO_LBL":
                return getM1MCPMECUSTOMERINFOLBL();
            case "STATE":
                return getSTATE();
            case "M1_CREW_ID":
                return getM1CREWID();
            case "M1_ACT_EOS_LBL":
                return getM1ACTEOSLBL();
            case "M1_ACTUAL_ST_DTTM":
                return getM1ACTUALSTDTTM();
            case "M1_DISPATCH_DTTM":
                return getM1DISPATCHDTTM();
            case "M1_TAKEN_DATE":
                return getM1TAKENDATE();
            case "M1_AUTO_CANCEL":
                return getM1AUTOCANCEL();
            case "M1_EST_OUT_OF_SVC_DUR":
                return getM1ESTOUTOFSVCDUR();
            case "M1_MDT_MAP_HOVER_TEXT":
                return getM1MDTMAPHOVERTEXT();
            case "MESSAGE_PARM_CNT":
                return getMESSAGEPARMCNT();
            case "M1_BELONGS_TO_PKG_LBL":
                return getM1BELONGSTOPKGLBL();
            case "M1_THEME_ORACLE_LBL":
                return getM1THEMEORACLELBL();
            case "M1_PENDING_CANCEL_SW":
                return getM1PENDINGCANCELSW();
            case "TASK_BUS_OBJ_CD":
                return getTASKBUSOBJCD();
            case "M1_SHIFT_LBL":
                return getM1SHIFTLBL();
            case "M1_AVG_DUR":
                return getM1AVGDUR();
            case "M1_OVERRIDE_DURATION":
                return getM1OVERRIDEDURATION();
            case "M1_DEPOT_TASK_ASSIGNMENT_LBL":
                return getM1DEPOTTASKASSIGNMENTLBL();
            case "M1_EMBEDDEDVIEWER":
                return getM1EMBEDDEDVIEWER();
            case "M1_SENT_FROM_USER":
                return getM1SENTFROMUSER();
            case "ALLOCATION_RULE_FLG":
                return getALLOCATIONRULEFLG();
            case "M1_CONSOLE_APPENDER_LBL":
                return getM1CONSOLEAPPENDERLBL();
            case "M1_LOG_APPENDER_LBL":
                return getM1LOGAPPENDERLBL();
            case "M1_SEND_NOW_UPDATE_SW":
                return getM1SENDNOWUPDATESW();
            case "M1_OVRD_FLG":
                return getM1OVRDFLG();
            case "ADDR3_AVAIL":
                return getADDR3AVAIL();
            case "M1_VEH_STRT_ODO_MTR":
                return getM1VEHSTRTODOMTR();
            case "TEXT_ANSWER":
                return getTEXTANSWER();
            case "ORIG_PLANNED_END_DTTM":
                return getORIGPLANNEDENDDTTM();
            case "SUBSCRIPTION_ID":
                return getSUBSCRIPTIONID();
            case "M1_COMMENT":
                return getM1COMMENT();
            case "M1_DELVR_NOW_FLG":
                return getM1DELVRNOWFLG();
            case "CALC_TRVL_DIST":
                return getCALCTRVLDIST();
            case "M1_POU_TASK_TYPE":
                return getM1POUTASKTYPE();
            case "M1_ASSIGNED_TO_CAPACITY_SW":
                return getM1ASSIGNEDTOCAPACITYSW();
            case "M1_GENERAL_LBL":
                return getM1GENERALLBL();
            case "M1_REPLY_LBL":
                return getM1REPLYLBL();
            case "M1_CLOSE_BTN_LBL":
                return getM1CLOSEBTNLBL();
            case "M1_SERVER_PROXY_HOST":
                return getM1SERVERPROXYHOST();
            case "TASK_TYPE_CD":
                return getTASKTYPECD();
            case "M1_ACTIVITY_BO":
                return getM1ACTIVITYBO();
            case "TIMESHEET_TM_TYPE_CD":
                return getTIMESHEETTMTYPECD();
            case "M1_COMPLETE_WITHIN_DAYS":
                return getM1COMPLETEWITHINDAYS();
            case "M1_TO_DO_MESSAGE":
                return getM1TODOMESSAGE();
            case "M1_WORK_PROFILE_CD":
                return getM1WORKPROFILECD();
            case "MSG_PARM_TYP_FLG":
                return getMSGPARMTYPFLG();
            case "M1_SITE_ADDRESS":
                return getM1SITEADDRESS();
            case "MDT_ID":
                return getMDTID();
            case "M1_MCPME_ACTIVITY_INFO_LBL":
                return getM1MCPMEACTIVITYINFOLBL();
            case "M1_UNDISPATCH_OPTION_FLG":
                return getM1UNDISPATCHOPTIONFLG();
            case "M1_PACKAGE_ITEMS_LBL":
                return getM1PACKAGEITEMSLBL();
            case "M1_WORK_SEQ":
                return getM1WORKSEQ();
            case "HOST_REF_CD":
                return getHOSTREFCD();
            case "M1_DEPOT_DELAY":
                return getM1DEPOTDELAY();
            case "M1_TIME_WINDOW_SOURCE_FLG":
                return getM1TIMEWINDOWSOURCEFLG();
            case "M1_PREVIEW_SHFT_LBL":
                return getM1PREVIEWSHFTLBL();
            case "M1_MSG_TEXT":
                return getM1MSGTEXT();
            case "QUEUE_FLG":
                return getQUEUEFLG();
            case "M1_SELECT_LOGLEVEL_LBL":
                return getM1SELECTLOGLEVELLBL();
            case "M1_EXPIRATION_TD_ROLE":
                return getM1EXPIRATIONTDROLE();
            case "M1_NUMBER_ACTIVITIES":
                return getM1NUMBERACTIVITIES();
            case "M1_DEBUG_LBL":
                return getM1DEBUGLBL();
            case "M1_SELECT_PICKUP_ACTTYPE_LBL":
                return getM1SELECTPICKUPACTTYPELBL();
            case "IN_CITY_LIM_AVAIL":
                return getINCITYLIMAVAIL();
            case "OUTMSG_TYPE_CD":
                return getOUTMSGTYPECD();
            case "COUNTY_LBL":
                return getCOUNTYLBL();
            case "M1_BREAK_ID":
                return getM1BREAKID();
            case "TAKE_ATTENDANCE_FLG":
                return getTAKEATTENDANCEFLG();
            case "F1_MSG_PARM_VLONG":
                return getF1MSGPARMVLONG();
            case "M1_WORK_BY_DATE":
                return getM1WORKBYDATE();
            case "M1_ESTIMATED_DURATION":
                return getM1ESTIMATEDDURATION();
            case "COUNTRY":
                return getCOUNTRY();
            case "STEP_LOWER_LIMIT":
                return getSTEPLOWERLIMIT();
            case "M1_CUSTOMER_CONTACT_COMMENTS":
                return getM1CUSTOMERCONTACTCOMMENTS();
            case "M1_OFFLINE_LBL":
                return getM1OFFLINELBL();
            case "M1_CONCURRENT_TASK_ID":
                return getM1CONCURRENTTASKID();
            case "M1_LOGON_DELAY":
                return getM1LOGONDELAY();
            case "M1_MOB_APP_LBL":
                return getM1MOBAPPLBL();
            case "M1_CONTRACTOR_LBL":
                return getM1CONTRACTORLBL();
            case "M1_ITEM_ATTR_VALUE":
                return getM1ITEMATTRVALUE();
            case "M1_NON_PRD_TASK_BO":
                return getM1NONPRDTASKBO();
            case "M1_DELIVERY_COMPLETE":
                return getM1DELIVERYCOMPLETE();
            case "M1_TIMESHEET_LBL":
                return getM1TIMESHEETLBL();
            case "M1_APPENDERS_LBL":
                return getM1APPENDERSLBL();
            case "M1_BREAK_BO":
                return getM1BREAKBO();
            case "M1_COMMON_COMPLETION_LBL":
                return getM1COMMONCOMPLETIONLBL();
            case "M1_CREW_TIM_UGG_DIM_MAIN_LBL":
                return getM1CREWTIMUGGDIMMAINLBL();
            case "NUM1_LBL":
                return getNUM1LBL();
            case "M1_ACT_STE_LBL":
                return getM1ACTSTELBL();
            case "M1_TRAVELTIME_DURATION":
                return getM1TRAVELTIMEDURATION();
            case "M1_COMPLETE_WITHIN_TIME":
                return getM1COMPLETEWITHINTIME();
            case "LOG_ENTRY_TYPE_FLG":
                return getLOGENTRYTYPEFLG();
            case "M1_ATTENDANCE_LBL":
                return getM1ATTENDANCELBL();
            case "ADDR4_LBL":
                return getADDR4LBL();
            case "F1_ATTACHMENT_RECORD":
                return getF1ATTACHMENTRECORD();
            case "M1_DEPOT_TASK_DECLINE_REASON":
                return getM1DEPOTTASKDECLINEREASON();
            case "M1_THEME_E_LBL":
                return getM1THEMEELBL();
            case "DRIP_MODE_FLG":
                return getDRIPMODEFLG();
            case "STEP_STATE_FLG":
                return getSTEPSTATEFLG();
            case "M1_ADD_NEW_LBL":
                return getM1ADDNEWLBL();
            case "CRE_DTTM":
                return getCREDTTM();
            case "VARIABLE_SHIFT_FLG":
                return getVARIABLESHIFTFLG();
            case "M1_ACTIVITY_COMPLETE_FLG":
                return getM1ACTIVITYCOMPLETEFLG();
            case "ALL_LBL":
                return getALLLBL();
            case "M1_UNDELIVERED_LBL":
                return getM1UNDELIVEREDLBL();
            case "M1_STRT_SHIFT_LBL":
                return getM1STRTSHIFTLBL();
            case "M1_ADD_REMARK_TYP_LBL":
                return getM1ADDREMARKTYPLBL();
            case "PROCEDURE_CLEARANCE_REQ_FLG":
                return getPROCEDURECLEARANCEREQFLG();
            case "HOST_EXTERNAL_ID":
                return getHOSTEXTERNALID();
            case "M1_LIST_LBL":
                return getM1LISTLBL();
            case "M1_DEPENDENCY_RSN_FLG":
                return getM1DEPENDENCYRSNFLG();
            case "SUBURB":
                return getSUBURB();
            case "M1_DEPOT_LBL":
                return getM1DEPOTLBL();
            case "DESCR100":
                return getDESCR100();
            case "M1_COUNT":
                return getM1COUNT();
            case "M1_LOG_LEVEL_LBL":
                return getM1LOGLEVELLBL();
            case "M1_LIFE_SPAN":
                return getM1LIFESPAN();
            case "M1_CREATED_BY_CREW_SW":
                return getM1CREATEDBYCREWSW();
            case "M1_NONCUM_CAPACITY_FLG":
                return getM1NONCUMCAPACITYFLG();
            case "M1_ACTUAL_ARR_DTTM":
                return getM1ACTUALARRDTTM();
            case "M1_CANCEL_CHGS_BTN_LBL":
                return getM1CANCELCHGSBTNLBL();
            case "M1_DATA_SENT_AT_DTTM":
                return getM1DATASENTATDTTM();
            case "M1_MAIL_MSG_CLS_FLG":
                return getM1MAILMSGCLSFLG();
            case "PARM_SEQ":
                return getPARMSEQ();
            case "M1_CLOSEDBY_ADV_DISP_FLG":
                return getM1CLOSEDBYADVDISPFLG();
            case "HOUSE_TYPE_LBL":
                return getHOUSETYPELBL();
            case "RMK_TYPE_CD":
                return getRMKTYPECD();
            case "M1_PICKUP_ACTIVITY_LBL":
                return getM1PICKUPACTIVITYLBL();
            case "M1_ITEM_LOAD_DCLN_RSN_FLG":
                return getM1ITEMLOADDCLNRSNFLG();
            case "M1_RESEND_MAIL_LBL":
                return getM1RESENDMAILLBL();
            case "M1_CONTR_ELIG_ID":
                return getM1CONTRELIGID();
            case "M1_END_SHIFT_LBL":
                return getM1ENDSHIFTLBL();
            case "M1_RVW_TMSH_DEV_LBL":
                return getM1RVWTMSHDEVLBL();
            case "M1_CUSTOMER_ACCEPTANCE_LBL":
                return getM1CUSTOMERACCEPTANCELBL();
            case "M1_KEEP_WITH_CREW_LBL":
                return getM1KEEPWITHCREWLBL();
            case "M1_MEETING_INFORMATION_LBL":
                return getM1MEETINGINFORMATIONLBL();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, Labels.NOT_FOUND_VALUE);
        if (Labels.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

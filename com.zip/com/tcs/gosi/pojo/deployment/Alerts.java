
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "alertSound",
    "soundPause",
    "cancelActivityAlertType",
    "soundDuration",
    "synchronizationAlertType",
    "timedEventAlertType",
    "unacknowledgedEmergencyAlertType",
    "panicAlertType"
})
public class Alerts {

    @JsonProperty("alertSound")
    private String alertSound;
    @JsonProperty("soundPause")
    private String soundPause;
    @JsonProperty("cancelActivityAlertType")
    private String cancelActivityAlertType;
    @JsonProperty("soundDuration")
    private String soundDuration;
    @JsonProperty("synchronizationAlertType")
    private String synchronizationAlertType;
    @JsonProperty("timedEventAlertType")
    private String timedEventAlertType;
    @JsonProperty("unacknowledgedEmergencyAlertType")
    private String unacknowledgedEmergencyAlertType;
    @JsonProperty("panicAlertType")
    private String panicAlertType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The alertSound
     */
    @JsonProperty("alertSound")
    public String getAlertSound() {
        return alertSound;
    }

    /**
     * 
     * @param alertSound
     *     The alertSound
     */
    @JsonProperty("alertSound")
    public void setAlertSound(String alertSound) {
        this.alertSound = alertSound;
    }

    /**
     * 
     * @return
     *     The soundPause
     */
    @JsonProperty("soundPause")
    public String getSoundPause() {
        return soundPause;
    }

    /**
     * 
     * @param soundPause
     *     The soundPause
     */
    @JsonProperty("soundPause")
    public void setSoundPause(String soundPause) {
        this.soundPause = soundPause;
    }

    /**
     * 
     * @return
     *     The cancelActivityAlertType
     */
    @JsonProperty("cancelActivityAlertType")
    public String getCancelActivityAlertType() {
        return cancelActivityAlertType;
    }

    /**
     * 
     * @param cancelActivityAlertType
     *     The cancelActivityAlertType
     */
    @JsonProperty("cancelActivityAlertType")
    public void setCancelActivityAlertType(String cancelActivityAlertType) {
        this.cancelActivityAlertType = cancelActivityAlertType;
    }

    /**
     * 
     * @return
     *     The soundDuration
     */
    @JsonProperty("soundDuration")
    public String getSoundDuration() {
        return soundDuration;
    }

    /**
     * 
     * @param soundDuration
     *     The soundDuration
     */
    @JsonProperty("soundDuration")
    public void setSoundDuration(String soundDuration) {
        this.soundDuration = soundDuration;
    }

    /**
     * 
     * @return
     *     The synchronizationAlertType
     */
    @JsonProperty("synchronizationAlertType")
    public String getSynchronizationAlertType() {
        return synchronizationAlertType;
    }

    /**
     * 
     * @param synchronizationAlertType
     *     The synchronizationAlertType
     */
    @JsonProperty("synchronizationAlertType")
    public void setSynchronizationAlertType(String synchronizationAlertType) {
        this.synchronizationAlertType = synchronizationAlertType;
    }

    /**
     * 
     * @return
     *     The timedEventAlertType
     */
    @JsonProperty("timedEventAlertType")
    public String getTimedEventAlertType() {
        return timedEventAlertType;
    }

    /**
     * 
     * @param timedEventAlertType
     *     The timedEventAlertType
     */
    @JsonProperty("timedEventAlertType")
    public void setTimedEventAlertType(String timedEventAlertType) {
        this.timedEventAlertType = timedEventAlertType;
    }

    /**
     * 
     * @return
     *     The unacknowledgedEmergencyAlertType
     */
    @JsonProperty("unacknowledgedEmergencyAlertType")
    public String getUnacknowledgedEmergencyAlertType() {
        return unacknowledgedEmergencyAlertType;
    }

    /**
     * 
     * @param unacknowledgedEmergencyAlertType
     *     The unacknowledgedEmergencyAlertType
     */
    @JsonProperty("unacknowledgedEmergencyAlertType")
    public void setUnacknowledgedEmergencyAlertType(String unacknowledgedEmergencyAlertType) {
        this.unacknowledgedEmergencyAlertType = unacknowledgedEmergencyAlertType;
    }

    /**
     * 
     * @return
     *     The panicAlertType
     */
    @JsonProperty("panicAlertType")
    public String getPanicAlertType() {
        return panicAlertType;
    }

    /**
     * 
     * @param panicAlertType
     *     The panicAlertType
     */
    @JsonProperty("panicAlertType")
    public void setPanicAlertType(String panicAlertType) {
        this.panicAlertType = panicAlertType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "alertSound":
                if (value instanceof String) {
                    setAlertSound(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"alertSound\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "soundPause":
                if (value instanceof String) {
                    setSoundPause(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"soundPause\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "cancelActivityAlertType":
                if (value instanceof String) {
                    setCancelActivityAlertType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"cancelActivityAlertType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "soundDuration":
                if (value instanceof String) {
                    setSoundDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"soundDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "synchronizationAlertType":
                if (value instanceof String) {
                    setSynchronizationAlertType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"synchronizationAlertType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "timedEventAlertType":
                if (value instanceof String) {
                    setTimedEventAlertType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"timedEventAlertType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "unacknowledgedEmergencyAlertType":
                if (value instanceof String) {
                    setUnacknowledgedEmergencyAlertType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"unacknowledgedEmergencyAlertType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "panicAlertType":
                if (value instanceof String) {
                    setPanicAlertType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"panicAlertType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "alertSound":
                return getAlertSound();
            case "soundPause":
                return getSoundPause();
            case "cancelActivityAlertType":
                return getCancelActivityAlertType();
            case "soundDuration":
                return getSoundDuration();
            case "synchronizationAlertType":
                return getSynchronizationAlertType();
            case "timedEventAlertType":
                return getTimedEventAlertType();
            case "unacknowledgedEmergencyAlertType":
                return getUnacknowledgedEmergencyAlertType();
            case "panicAlertType":
                return getPanicAlertType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, Alerts.NOT_FOUND_VALUE);
        if (Alerts.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

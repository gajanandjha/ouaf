
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bo",
    "description",
    "boStatus",
    "boStatusReason",
    "usage",
    "boStatusBO",
    "selection",
    "version"
})
public class F1BOStatusReason {

    @JsonProperty("bo")
    private String bo;
    @JsonProperty("description")
    private String description;
    @JsonProperty("boStatus")
    private String boStatus;
    @JsonProperty("boStatusReason")
    private String boStatusReason;
    @JsonProperty("usage")
    private String usage;
    @JsonProperty("boStatusBO")
    private String boStatusBO;
    @JsonProperty("selection")
    private String selection;
    @JsonProperty("version")
    private String version;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The boStatus
     */
    @JsonProperty("boStatus")
    public String getBoStatus() {
        return boStatus;
    }

    /**
     * 
     * @param boStatus
     *     The boStatus
     */
    @JsonProperty("boStatus")
    public void setBoStatus(String boStatus) {
        this.boStatus = boStatus;
    }

    /**
     * 
     * @return
     *     The boStatusReason
     */
    @JsonProperty("boStatusReason")
    public String getBoStatusReason() {
        return boStatusReason;
    }

    /**
     * 
     * @param boStatusReason
     *     The boStatusReason
     */
    @JsonProperty("boStatusReason")
    public void setBoStatusReason(String boStatusReason) {
        this.boStatusReason = boStatusReason;
    }

    /**
     * 
     * @return
     *     The usage
     */
    @JsonProperty("usage")
    public String getUsage() {
        return usage;
    }

    /**
     * 
     * @param usage
     *     The usage
     */
    @JsonProperty("usage")
    public void setUsage(String usage) {
        this.usage = usage;
    }

    /**
     * 
     * @return
     *     The boStatusBO
     */
    @JsonProperty("boStatusBO")
    public String getBoStatusBO() {
        return boStatusBO;
    }

    /**
     * 
     * @param boStatusBO
     *     The boStatusBO
     */
    @JsonProperty("boStatusBO")
    public void setBoStatusBO(String boStatusBO) {
        this.boStatusBO = boStatusBO;
    }

    /**
     * 
     * @return
     *     The selection
     */
    @JsonProperty("selection")
    public String getSelection() {
        return selection;
    }

    /**
     * 
     * @param selection
     *     The selection
     */
    @JsonProperty("selection")
    public void setSelection(String selection) {
        this.selection = selection;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "boStatus":
                if (value instanceof String) {
                    setBoStatus(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"boStatus\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "boStatusReason":
                if (value instanceof String) {
                    setBoStatusReason(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"boStatusReason\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "usage":
                if (value instanceof String) {
                    setUsage(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"usage\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "boStatusBO":
                if (value instanceof String) {
                    setBoStatusBO(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"boStatusBO\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "selection":
                if (value instanceof String) {
                    setSelection(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"selection\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "bo":
                return getBo();
            case "description":
                return getDescription();
            case "boStatus":
                return getBoStatus();
            case "boStatusReason":
                return getBoStatusReason();
            case "usage":
                return getUsage();
            case "boStatusBO":
                return getBoStatusBO();
            case "selection":
                return getSelection();
            case "version":
                return getVersion();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, F1BOStatusReason.NOT_FOUND_VALUE);
        if (F1BOStatusReason.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "breakWindowDuration",
    "queue",
    "bo",
    "breakDuration",
    "autoDispatch",
    "taskClass",
    "status",
    "acknowledgementRequired",
    "breakBo",
    "breakTimesheetTimeType",
    "description",
    "taskType",
    "version",
    "strictTime"
})
public class M1BreakTaskType {

    @JsonProperty("breakWindowDuration")
    private String breakWindowDuration;
    @JsonProperty("queue")
    private String queue;
    @JsonProperty("bo")
    private String bo;
    @JsonProperty("breakDuration")
    private String breakDuration;
    @JsonProperty("autoDispatch")
    private String autoDispatch;
    @JsonProperty("taskClass")
    private String taskClass;
    @JsonProperty("status")
    private String status;
    @JsonProperty("acknowledgementRequired")
    private String acknowledgementRequired;
    @JsonProperty("breakBo")
    private String breakBo;
    @JsonProperty("breakTimesheetTimeType")
    private String breakTimesheetTimeType;
    @JsonProperty("description")
    private String description;
    @JsonProperty("taskType")
    private String taskType;
    @JsonProperty("version")
    private String version;
    @JsonProperty("strictTime")
    private String strictTime;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The breakWindowDuration
     */
    @JsonProperty("breakWindowDuration")
    public String getBreakWindowDuration() {
        return breakWindowDuration;
    }

    /**
     * 
     * @param breakWindowDuration
     *     The breakWindowDuration
     */
    @JsonProperty("breakWindowDuration")
    public void setBreakWindowDuration(String breakWindowDuration) {
        this.breakWindowDuration = breakWindowDuration;
    }

    /**
     * 
     * @return
     *     The queue
     */
    @JsonProperty("queue")
    public String getQueue() {
        return queue;
    }

    /**
     * 
     * @param queue
     *     The queue
     */
    @JsonProperty("queue")
    public void setQueue(String queue) {
        this.queue = queue;
    }

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The breakDuration
     */
    @JsonProperty("breakDuration")
    public String getBreakDuration() {
        return breakDuration;
    }

    /**
     * 
     * @param breakDuration
     *     The breakDuration
     */
    @JsonProperty("breakDuration")
    public void setBreakDuration(String breakDuration) {
        this.breakDuration = breakDuration;
    }

    /**
     * 
     * @return
     *     The autoDispatch
     */
    @JsonProperty("autoDispatch")
    public String getAutoDispatch() {
        return autoDispatch;
    }

    /**
     * 
     * @param autoDispatch
     *     The autoDispatch
     */
    @JsonProperty("autoDispatch")
    public void setAutoDispatch(String autoDispatch) {
        this.autoDispatch = autoDispatch;
    }

    /**
     * 
     * @return
     *     The taskClass
     */
    @JsonProperty("taskClass")
    public String getTaskClass() {
        return taskClass;
    }

    /**
     * 
     * @param taskClass
     *     The taskClass
     */
    @JsonProperty("taskClass")
    public void setTaskClass(String taskClass) {
        this.taskClass = taskClass;
    }

    /**
     * 
     * @return
     *     The status
     */
    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    /**
     * 
     * @param status
     *     The status
     */
    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * 
     * @return
     *     The acknowledgementRequired
     */
    @JsonProperty("acknowledgementRequired")
    public String getAcknowledgementRequired() {
        return acknowledgementRequired;
    }

    /**
     * 
     * @param acknowledgementRequired
     *     The acknowledgementRequired
     */
    @JsonProperty("acknowledgementRequired")
    public void setAcknowledgementRequired(String acknowledgementRequired) {
        this.acknowledgementRequired = acknowledgementRequired;
    }

    /**
     * 
     * @return
     *     The breakBo
     */
    @JsonProperty("breakBo")
    public String getBreakBo() {
        return breakBo;
    }

    /**
     * 
     * @param breakBo
     *     The breakBo
     */
    @JsonProperty("breakBo")
    public void setBreakBo(String breakBo) {
        this.breakBo = breakBo;
    }

    /**
     * 
     * @return
     *     The breakTimesheetTimeType
     */
    @JsonProperty("breakTimesheetTimeType")
    public String getBreakTimesheetTimeType() {
        return breakTimesheetTimeType;
    }

    /**
     * 
     * @param breakTimesheetTimeType
     *     The breakTimesheetTimeType
     */
    @JsonProperty("breakTimesheetTimeType")
    public void setBreakTimesheetTimeType(String breakTimesheetTimeType) {
        this.breakTimesheetTimeType = breakTimesheetTimeType;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The taskType
     */
    @JsonProperty("taskType")
    public String getTaskType() {
        return taskType;
    }

    /**
     * 
     * @param taskType
     *     The taskType
     */
    @JsonProperty("taskType")
    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * 
     * @return
     *     The strictTime
     */
    @JsonProperty("strictTime")
    public String getStrictTime() {
        return strictTime;
    }

    /**
     * 
     * @param strictTime
     *     The strictTime
     */
    @JsonProperty("strictTime")
    public void setStrictTime(String strictTime) {
        this.strictTime = strictTime;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "breakWindowDuration":
                if (value instanceof String) {
                    setBreakWindowDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"breakWindowDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "queue":
                if (value instanceof String) {
                    setQueue(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"queue\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "breakDuration":
                if (value instanceof String) {
                    setBreakDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"breakDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "autoDispatch":
                if (value instanceof String) {
                    setAutoDispatch(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"autoDispatch\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskClass":
                if (value instanceof String) {
                    setTaskClass(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskClass\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "status":
                if (value instanceof String) {
                    setStatus(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"status\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "acknowledgementRequired":
                if (value instanceof String) {
                    setAcknowledgementRequired(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"acknowledgementRequired\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "breakBo":
                if (value instanceof String) {
                    setBreakBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"breakBo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "breakTimesheetTimeType":
                if (value instanceof String) {
                    setBreakTimesheetTimeType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"breakTimesheetTimeType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskType":
                if (value instanceof String) {
                    setTaskType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "strictTime":
                if (value instanceof String) {
                    setStrictTime(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"strictTime\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "breakWindowDuration":
                return getBreakWindowDuration();
            case "queue":
                return getQueue();
            case "bo":
                return getBo();
            case "breakDuration":
                return getBreakDuration();
            case "autoDispatch":
                return getAutoDispatch();
            case "taskClass":
                return getTaskClass();
            case "status":
                return getStatus();
            case "acknowledgementRequired":
                return getAcknowledgementRequired();
            case "breakBo":
                return getBreakBo();
            case "breakTimesheetTimeType":
                return getBreakTimesheetTimeType();
            case "description":
                return getDescription();
            case "taskType":
                return getTaskType();
            case "version":
                return getVersion();
            case "strictTime":
                return getStrictTime();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1BreakTaskType.NOT_FOUND_VALUE);
        if (M1BreakTaskType.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "schedulingPriorityStep"
})
public class SchedulingPrioritySteps {

    @JsonProperty("schedulingPriorityStep")
    private List<SchedulingPriorityStep> schedulingPriorityStep = null;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The schedulingPriorityStep
     */
    @JsonProperty("schedulingPriorityStep")
    public List<SchedulingPriorityStep> getSchedulingPriorityStep() {
        return schedulingPriorityStep;
    }

    /**
     * 
     * @param schedulingPriorityStep
     *     The schedulingPriorityStep
     */
    @JsonProperty("schedulingPriorityStep")
    public void setSchedulingPriorityStep(List<SchedulingPriorityStep> schedulingPriorityStep) {
        this.schedulingPriorityStep = schedulingPriorityStep;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "schedulingPriorityStep":
                if (value instanceof List) {
                    setSchedulingPriorityStep(((List<SchedulingPriorityStep> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"schedulingPriorityStep\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.SchedulingPriorityStep>\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "schedulingPriorityStep":
                return getSchedulingPriorityStep();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, SchedulingPrioritySteps.NOT_FOUND_VALUE);
        if (SchedulingPrioritySteps.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

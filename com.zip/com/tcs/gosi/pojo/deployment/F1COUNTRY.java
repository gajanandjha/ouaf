
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "address4Label",
    "address4Available",
    "houseTypeAvailable",
    "postalLabel",
    "cityLabel",
    "states",
    "number1Available",
    "geoCodeAvailable",
    "number2Available",
    "countyLabel",
    "address3Available",
    "inCityLimitAvailable",
    "version",
    "address1Available",
    "description",
    "address2Label",
    "address1Label",
    "countyAvailable",
    "cityAvailable",
    "address2Available",
    "country",
    "stateLabel",
    "stateAvailable",
    "postalAvailable",
    "address3Label"
})
public class F1COUNTRY {

    @JsonProperty("address4Label")
    private String address4Label;
    @JsonProperty("address4Available")
    private String address4Available;
    @JsonProperty("houseTypeAvailable")
    private String houseTypeAvailable;
    @JsonProperty("postalLabel")
    private String postalLabel;
    @JsonProperty("cityLabel")
    private String cityLabel;
    @JsonProperty("states")
    private States states;
    @JsonProperty("number1Available")
    private String number1Available;
    @JsonProperty("geoCodeAvailable")
    private String geoCodeAvailable;
    @JsonProperty("number2Available")
    private String number2Available;
    @JsonProperty("countyLabel")
    private String countyLabel;
    @JsonProperty("address3Available")
    private String address3Available;
    @JsonProperty("inCityLimitAvailable")
    private String inCityLimitAvailable;
    @JsonProperty("version")
    private String version;
    @JsonProperty("address1Available")
    private String address1Available;
    @JsonProperty("description")
    private String description;
    @JsonProperty("address2Label")
    private String address2Label;
    @JsonProperty("address1Label")
    private String address1Label;
    @JsonProperty("countyAvailable")
    private String countyAvailable;
    @JsonProperty("cityAvailable")
    private String cityAvailable;
    @JsonProperty("address2Available")
    private String address2Available;
    @JsonProperty("country")
    private String country;
    @JsonProperty("stateLabel")
    private String stateLabel;
    @JsonProperty("stateAvailable")
    private String stateAvailable;
    @JsonProperty("postalAvailable")
    private String postalAvailable;
    @JsonProperty("address3Label")
    private String address3Label;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The address4Label
     */
    @JsonProperty("address4Label")
    public String getAddress4Label() {
        return address4Label;
    }

    /**
     * 
     * @param address4Label
     *     The address4Label
     */
    @JsonProperty("address4Label")
    public void setAddress4Label(String address4Label) {
        this.address4Label = address4Label;
    }

    /**
     * 
     * @return
     *     The address4Available
     */
    @JsonProperty("address4Available")
    public String getAddress4Available() {
        return address4Available;
    }

    /**
     * 
     * @param address4Available
     *     The address4Available
     */
    @JsonProperty("address4Available")
    public void setAddress4Available(String address4Available) {
        this.address4Available = address4Available;
    }

    /**
     * 
     * @return
     *     The houseTypeAvailable
     */
    @JsonProperty("houseTypeAvailable")
    public String getHouseTypeAvailable() {
        return houseTypeAvailable;
    }

    /**
     * 
     * @param houseTypeAvailable
     *     The houseTypeAvailable
     */
    @JsonProperty("houseTypeAvailable")
    public void setHouseTypeAvailable(String houseTypeAvailable) {
        this.houseTypeAvailable = houseTypeAvailable;
    }

    /**
     * 
     * @return
     *     The postalLabel
     */
    @JsonProperty("postalLabel")
    public String getPostalLabel() {
        return postalLabel;
    }

    /**
     * 
     * @param postalLabel
     *     The postalLabel
     */
    @JsonProperty("postalLabel")
    public void setPostalLabel(String postalLabel) {
        this.postalLabel = postalLabel;
    }

    /**
     * 
     * @return
     *     The cityLabel
     */
    @JsonProperty("cityLabel")
    public String getCityLabel() {
        return cityLabel;
    }

    /**
     * 
     * @param cityLabel
     *     The cityLabel
     */
    @JsonProperty("cityLabel")
    public void setCityLabel(String cityLabel) {
        this.cityLabel = cityLabel;
    }

    /**
     * 
     * @return
     *     The states
     */
    @JsonProperty("states")
    public States getStates() {
        return states;
    }

    /**
     * 
     * @param states
     *     The states
     */
    @JsonProperty("states")
    public void setStates(States states) {
        this.states = states;
    }

    /**
     * 
     * @return
     *     The number1Available
     */
    @JsonProperty("number1Available")
    public String getNumber1Available() {
        return number1Available;
    }

    /**
     * 
     * @param number1Available
     *     The number1Available
     */
    @JsonProperty("number1Available")
    public void setNumber1Available(String number1Available) {
        this.number1Available = number1Available;
    }

    /**
     * 
     * @return
     *     The geoCodeAvailable
     */
    @JsonProperty("geoCodeAvailable")
    public String getGeoCodeAvailable() {
        return geoCodeAvailable;
    }

    /**
     * 
     * @param geoCodeAvailable
     *     The geoCodeAvailable
     */
    @JsonProperty("geoCodeAvailable")
    public void setGeoCodeAvailable(String geoCodeAvailable) {
        this.geoCodeAvailable = geoCodeAvailable;
    }

    /**
     * 
     * @return
     *     The number2Available
     */
    @JsonProperty("number2Available")
    public String getNumber2Available() {
        return number2Available;
    }

    /**
     * 
     * @param number2Available
     *     The number2Available
     */
    @JsonProperty("number2Available")
    public void setNumber2Available(String number2Available) {
        this.number2Available = number2Available;
    }

    /**
     * 
     * @return
     *     The countyLabel
     */
    @JsonProperty("countyLabel")
    public String getCountyLabel() {
        return countyLabel;
    }

    /**
     * 
     * @param countyLabel
     *     The countyLabel
     */
    @JsonProperty("countyLabel")
    public void setCountyLabel(String countyLabel) {
        this.countyLabel = countyLabel;
    }

    /**
     * 
     * @return
     *     The address3Available
     */
    @JsonProperty("address3Available")
    public String getAddress3Available() {
        return address3Available;
    }

    /**
     * 
     * @param address3Available
     *     The address3Available
     */
    @JsonProperty("address3Available")
    public void setAddress3Available(String address3Available) {
        this.address3Available = address3Available;
    }

    /**
     * 
     * @return
     *     The inCityLimitAvailable
     */
    @JsonProperty("inCityLimitAvailable")
    public String getInCityLimitAvailable() {
        return inCityLimitAvailable;
    }

    /**
     * 
     * @param inCityLimitAvailable
     *     The inCityLimitAvailable
     */
    @JsonProperty("inCityLimitAvailable")
    public void setInCityLimitAvailable(String inCityLimitAvailable) {
        this.inCityLimitAvailable = inCityLimitAvailable;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * 
     * @return
     *     The address1Available
     */
    @JsonProperty("address1Available")
    public String getAddress1Available() {
        return address1Available;
    }

    /**
     * 
     * @param address1Available
     *     The address1Available
     */
    @JsonProperty("address1Available")
    public void setAddress1Available(String address1Available) {
        this.address1Available = address1Available;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The address2Label
     */
    @JsonProperty("address2Label")
    public String getAddress2Label() {
        return address2Label;
    }

    /**
     * 
     * @param address2Label
     *     The address2Label
     */
    @JsonProperty("address2Label")
    public void setAddress2Label(String address2Label) {
        this.address2Label = address2Label;
    }

    /**
     * 
     * @return
     *     The address1Label
     */
    @JsonProperty("address1Label")
    public String getAddress1Label() {
        return address1Label;
    }

    /**
     * 
     * @param address1Label
     *     The address1Label
     */
    @JsonProperty("address1Label")
    public void setAddress1Label(String address1Label) {
        this.address1Label = address1Label;
    }

    /**
     * 
     * @return
     *     The countyAvailable
     */
    @JsonProperty("countyAvailable")
    public String getCountyAvailable() {
        return countyAvailable;
    }

    /**
     * 
     * @param countyAvailable
     *     The countyAvailable
     */
    @JsonProperty("countyAvailable")
    public void setCountyAvailable(String countyAvailable) {
        this.countyAvailable = countyAvailable;
    }

    /**
     * 
     * @return
     *     The cityAvailable
     */
    @JsonProperty("cityAvailable")
    public String getCityAvailable() {
        return cityAvailable;
    }

    /**
     * 
     * @param cityAvailable
     *     The cityAvailable
     */
    @JsonProperty("cityAvailable")
    public void setCityAvailable(String cityAvailable) {
        this.cityAvailable = cityAvailable;
    }

    /**
     * 
     * @return
     *     The address2Available
     */
    @JsonProperty("address2Available")
    public String getAddress2Available() {
        return address2Available;
    }

    /**
     * 
     * @param address2Available
     *     The address2Available
     */
    @JsonProperty("address2Available")
    public void setAddress2Available(String address2Available) {
        this.address2Available = address2Available;
    }

    /**
     * 
     * @return
     *     The country
     */
    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    /**
     * 
     * @param country
     *     The country
     */
    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * 
     * @return
     *     The stateLabel
     */
    @JsonProperty("stateLabel")
    public String getStateLabel() {
        return stateLabel;
    }

    /**
     * 
     * @param stateLabel
     *     The stateLabel
     */
    @JsonProperty("stateLabel")
    public void setStateLabel(String stateLabel) {
        this.stateLabel = stateLabel;
    }

    /**
     * 
     * @return
     *     The stateAvailable
     */
    @JsonProperty("stateAvailable")
    public String getStateAvailable() {
        return stateAvailable;
    }

    /**
     * 
     * @param stateAvailable
     *     The stateAvailable
     */
    @JsonProperty("stateAvailable")
    public void setStateAvailable(String stateAvailable) {
        this.stateAvailable = stateAvailable;
    }

    /**
     * 
     * @return
     *     The postalAvailable
     */
    @JsonProperty("postalAvailable")
    public String getPostalAvailable() {
        return postalAvailable;
    }

    /**
     * 
     * @param postalAvailable
     *     The postalAvailable
     */
    @JsonProperty("postalAvailable")
    public void setPostalAvailable(String postalAvailable) {
        this.postalAvailable = postalAvailable;
    }

    /**
     * 
     * @return
     *     The address3Label
     */
    @JsonProperty("address3Label")
    public String getAddress3Label() {
        return address3Label;
    }

    /**
     * 
     * @param address3Label
     *     The address3Label
     */
    @JsonProperty("address3Label")
    public void setAddress3Label(String address3Label) {
        this.address3Label = address3Label;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "address4Label":
                if (value instanceof String) {
                    setAddress4Label(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address4Label\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address4Available":
                if (value instanceof String) {
                    setAddress4Available(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address4Available\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "houseTypeAvailable":
                if (value instanceof String) {
                    setHouseTypeAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"houseTypeAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "postalLabel":
                if (value instanceof String) {
                    setPostalLabel(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"postalLabel\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "cityLabel":
                if (value instanceof String) {
                    setCityLabel(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"cityLabel\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "states":
                if (value instanceof States) {
                    setStates(((States) value));
                } else {
                    throw new IllegalArgumentException(("property \"states\" is of type \"com.tcs.gosi.pojo.deployment.States\", but got "+ value.getClass().toString()));
                }
                return true;
            case "number1Available":
                if (value instanceof String) {
                    setNumber1Available(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"number1Available\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "geoCodeAvailable":
                if (value instanceof String) {
                    setGeoCodeAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"geoCodeAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "number2Available":
                if (value instanceof String) {
                    setNumber2Available(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"number2Available\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "countyLabel":
                if (value instanceof String) {
                    setCountyLabel(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"countyLabel\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address3Available":
                if (value instanceof String) {
                    setAddress3Available(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address3Available\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "inCityLimitAvailable":
                if (value instanceof String) {
                    setInCityLimitAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"inCityLimitAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address1Available":
                if (value instanceof String) {
                    setAddress1Available(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address1Available\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address2Label":
                if (value instanceof String) {
                    setAddress2Label(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address2Label\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address1Label":
                if (value instanceof String) {
                    setAddress1Label(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address1Label\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "countyAvailable":
                if (value instanceof String) {
                    setCountyAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"countyAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "cityAvailable":
                if (value instanceof String) {
                    setCityAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"cityAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address2Available":
                if (value instanceof String) {
                    setAddress2Available(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address2Available\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "country":
                if (value instanceof String) {
                    setCountry(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"country\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "stateLabel":
                if (value instanceof String) {
                    setStateLabel(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"stateLabel\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "stateAvailable":
                if (value instanceof String) {
                    setStateAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"stateAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "postalAvailable":
                if (value instanceof String) {
                    setPostalAvailable(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"postalAvailable\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "address3Label":
                if (value instanceof String) {
                    setAddress3Label(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"address3Label\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "address4Label":
                return getAddress4Label();
            case "address4Available":
                return getAddress4Available();
            case "houseTypeAvailable":
                return getHouseTypeAvailable();
            case "postalLabel":
                return getPostalLabel();
            case "cityLabel":
                return getCityLabel();
            case "states":
                return getStates();
            case "number1Available":
                return getNumber1Available();
            case "geoCodeAvailable":
                return getGeoCodeAvailable();
            case "number2Available":
                return getNumber2Available();
            case "countyLabel":
                return getCountyLabel();
            case "address3Available":
                return getAddress3Available();
            case "inCityLimitAvailable":
                return getInCityLimitAvailable();
            case "version":
                return getVersion();
            case "address1Available":
                return getAddress1Available();
            case "description":
                return getDescription();
            case "address2Label":
                return getAddress2Label();
            case "address1Label":
                return getAddress1Label();
            case "countyAvailable":
                return getCountyAvailable();
            case "cityAvailable":
                return getCityAvailable();
            case "address2Available":
                return getAddress2Available();
            case "country":
                return getCountry();
            case "stateLabel":
                return getStateLabel();
            case "stateAvailable":
                return getStateAvailable();
            case "postalAvailable":
                return getPostalAvailable();
            case "address3Label":
                return getAddress3Label();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, F1COUNTRY.NOT_FOUND_VALUE);
        if (F1COUNTRY.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sortSequence",
    "remarkType"
})
public class ValidRemarkTypeList {

    @JsonProperty("sortSequence")
    private String sortSequence;
    @JsonProperty("remarkType")
    private String remarkType;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The sortSequence
     */
    @JsonProperty("sortSequence")
    public String getSortSequence() {
        return sortSequence;
    }

    /**
     * 
     * @param sortSequence
     *     The sortSequence
     */
    @JsonProperty("sortSequence")
    public void setSortSequence(String sortSequence) {
        this.sortSequence = sortSequence;
    }

    /**
     * 
     * @return
     *     The remarkType
     */
    @JsonProperty("remarkType")
    public String getRemarkType() {
        return remarkType;
    }

    /**
     * 
     * @param remarkType
     *     The remarkType
     */
    @JsonProperty("remarkType")
    public void setRemarkType(String remarkType) {
        this.remarkType = remarkType;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "sortSequence":
                if (value instanceof String) {
                    setSortSequence(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"sortSequence\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "remarkType":
                if (value instanceof String) {
                    setRemarkType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"remarkType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "sortSequence":
                return getSortSequence();
            case "remarkType":
                return getRemarkType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ValidRemarkTypeList.NOT_FOUND_VALUE);
        if (ValidRemarkTypeList.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "attachmentList"
})
public class AttachmentList {

    @JsonProperty("attachmentList")
    private List<AttachmentList_> attachmentList = null;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The attachmentList
     */
    @JsonProperty("attachmentList")
    public List<AttachmentList_> getAttachmentList() {
        return attachmentList;
    }

    /**
     * 
     * @param attachmentList
     *     The attachmentList
     */
    @JsonProperty("attachmentList")
    public void setAttachmentList(List<AttachmentList_> attachmentList) {
        this.attachmentList = attachmentList;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "attachmentList":
                if (value instanceof List) {
                    setAttachmentList(((List<AttachmentList_> ) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentList\" is of type \"java.util.List<com.tcs.gosi.pojo.deployment.AttachmentList_>\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "attachmentList":
                return getAttachmentList();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, AttachmentList.NOT_FOUND_VALUE);
        if (AttachmentList.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "capabilitiesList"
})
public class Capabilities {

    @JsonProperty("capabilitiesList")
    private List<CapabilitiesList> capabilitiesList;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The capabilitiesList
     */
    @JsonProperty("capabilitiesList")
    public List<CapabilitiesList> getCapabilitiesList() {
        return capabilitiesList;
    }

    /**
     * 
     * @param capabilitiesList
     *     The capabilitiesList
     */
    @JsonProperty("capabilitiesList")
    public void setCapabilitiesList(List<CapabilitiesList> capabilitiesList) {
        this.capabilitiesList = capabilitiesList;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "capabilitiesList":
                if (value instanceof List) {
                    setCapabilitiesList(((List<CapabilitiesList>) value));
                } else {
                    throw new IllegalArgumentException(("property \"capabilitiesList\" is of type \"com.tcs.gosi.pojo.deployment.CapabilitiesList\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "capabilitiesList":
                return getCapabilitiesList();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, Capabilities.NOT_FOUND_VALUE);
        if (Capabilities.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bo",
    "description",
    "lookupUsage",
    "owner",
    "longDescription",
    "businessObjectDataArea",
    "mainSection",
    "lookupValue",
    "version"
})
public class M1MCPCapabilityType {

    @JsonProperty("bo")
    private String bo;
    @JsonProperty("description")
    private String description;
    @JsonProperty("lookupUsage")
    private String lookupUsage;
    @JsonProperty("owner")
    private String owner;
    @JsonProperty("longDescription")
    private String longDescription;
    @JsonProperty("businessObjectDataArea")
    private BusinessObjectDataArea businessObjectDataArea;
    @JsonProperty("mainSection")
    private String mainSection;
    @JsonProperty("lookupValue")
    private String lookupValue;
    @JsonProperty("version")
    private String version;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The lookupUsage
     */
    @JsonProperty("lookupUsage")
    public String getLookupUsage() {
        return lookupUsage;
    }

    /**
     * 
     * @param lookupUsage
     *     The lookupUsage
     */
    @JsonProperty("lookupUsage")
    public void setLookupUsage(String lookupUsage) {
        this.lookupUsage = lookupUsage;
    }

    /**
     * 
     * @return
     *     The owner
     */
    @JsonProperty("owner")
    public String getOwner() {
        return owner;
    }

    /**
     * 
     * @param owner
     *     The owner
     */
    @JsonProperty("owner")
    public void setOwner(String owner) {
        this.owner = owner;
    }

    /**
     * 
     * @return
     *     The longDescription
     */
    @JsonProperty("longDescription")
    public String getLongDescription() {
        return longDescription;
    }

    /**
     * 
     * @param longDescription
     *     The longDescription
     */
    @JsonProperty("longDescription")
    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    /**
     * 
     * @return
     *     The businessObjectDataArea
     */
    @JsonProperty("businessObjectDataArea")
    public BusinessObjectDataArea getBusinessObjectDataArea() {
        return businessObjectDataArea;
    }

    /**
     * 
     * @param businessObjectDataArea
     *     The businessObjectDataArea
     */
    @JsonProperty("businessObjectDataArea")
    public void setBusinessObjectDataArea(BusinessObjectDataArea businessObjectDataArea) {
        this.businessObjectDataArea = businessObjectDataArea;
    }

    /**
     * 
     * @return
     *     The mainSection
     */
    @JsonProperty("mainSection")
    public String getMainSection() {
        return mainSection;
    }

    /**
     * 
     * @param mainSection
     *     The mainSection
     */
    @JsonProperty("mainSection")
    public void setMainSection(String mainSection) {
        this.mainSection = mainSection;
    }

    /**
     * 
     * @return
     *     The lookupValue
     */
    @JsonProperty("lookupValue")
    public String getLookupValue() {
        return lookupValue;
    }

    /**
     * 
     * @param lookupValue
     *     The lookupValue
     */
    @JsonProperty("lookupValue")
    public void setLookupValue(String lookupValue) {
        this.lookupValue = lookupValue;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "lookupUsage":
                if (value instanceof String) {
                    setLookupUsage(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"lookupUsage\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "owner":
                if (value instanceof String) {
                    setOwner(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"owner\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "longDescription":
                if (value instanceof String) {
                    setLongDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"longDescription\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "businessObjectDataArea":
                if (value instanceof BusinessObjectDataArea) {
                    setBusinessObjectDataArea(((BusinessObjectDataArea) value));
                } else {
                    throw new IllegalArgumentException(("property \"businessObjectDataArea\" is of type \"com.tcs.gosi.pojo.deployment.BusinessObjectDataArea\", but got "+ value.getClass().toString()));
                }
                return true;
            case "mainSection":
                if (value instanceof String) {
                    setMainSection(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"mainSection\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "lookupValue":
                if (value instanceof String) {
                    setLookupValue(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"lookupValue\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "bo":
                return getBo();
            case "description":
                return getDescription();
            case "lookupUsage":
                return getLookupUsage();
            case "owner":
                return getOwner();
            case "longDescription":
                return getLongDescription();
            case "businessObjectDataArea":
                return getBusinessObjectDataArea();
            case "mainSection":
                return getMainSection();
            case "lookupValue":
                return getLookupValue();
            case "version":
                return getVersion();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1MCPCapabilityType.NOT_FOUND_VALUE);
        if (M1MCPCapabilityType.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

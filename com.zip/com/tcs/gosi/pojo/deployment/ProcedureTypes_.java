
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "procedureTypesList"
})
public class ProcedureTypes_ {

    @JsonProperty("procedureTypesList")
    private ProcedureTypesList_ procedureTypesList;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The procedureTypesList
     */
    @JsonProperty("procedureTypesList")
    public ProcedureTypesList_ getProcedureTypesList() {
        return procedureTypesList;
    }

    /**
     * 
     * @param procedureTypesList
     *     The procedureTypesList
     */
    @JsonProperty("procedureTypesList")
    public void setProcedureTypesList(ProcedureTypesList_ procedureTypesList) {
        this.procedureTypesList = procedureTypesList;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "procedureTypesList":
                if (value instanceof ProcedureTypesList_) {
                    setProcedureTypesList(((ProcedureTypesList_) value));
                } else {
                    throw new IllegalArgumentException(("property \"procedureTypesList\" is of type \"com.tcs.gosi.pojo.deployment.ProcedureTypesList_\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "procedureTypesList":
                return getProcedureTypesList();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ProcedureTypes_.NOT_FOUND_VALUE);
        if (ProcedureTypes_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

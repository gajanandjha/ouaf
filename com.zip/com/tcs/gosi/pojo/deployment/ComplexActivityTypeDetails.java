
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sameCrew",
    "minimumVisitDuration",
    "durationExtensionLimit",
    "averageVisitDuration"
})
public class ComplexActivityTypeDetails {

    @JsonProperty("sameCrew")
    private String sameCrew;
    @JsonProperty("minimumVisitDuration")
    private String minimumVisitDuration;
    @JsonProperty("durationExtensionLimit")
    private String durationExtensionLimit;
    @JsonProperty("averageVisitDuration")
    private String averageVisitDuration;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The sameCrew
     */
    @JsonProperty("sameCrew")
    public String getSameCrew() {
        return sameCrew;
    }

    /**
     * 
     * @param sameCrew
     *     The sameCrew
     */
    @JsonProperty("sameCrew")
    public void setSameCrew(String sameCrew) {
        this.sameCrew = sameCrew;
    }

    /**
     * 
     * @return
     *     The minimumVisitDuration
     */
    @JsonProperty("minimumVisitDuration")
    public String getMinimumVisitDuration() {
        return minimumVisitDuration;
    }

    /**
     * 
     * @param minimumVisitDuration
     *     The minimumVisitDuration
     */
    @JsonProperty("minimumVisitDuration")
    public void setMinimumVisitDuration(String minimumVisitDuration) {
        this.minimumVisitDuration = minimumVisitDuration;
    }

    /**
     * 
     * @return
     *     The durationExtensionLimit
     */
    @JsonProperty("durationExtensionLimit")
    public String getDurationExtensionLimit() {
        return durationExtensionLimit;
    }

    /**
     * 
     * @param durationExtensionLimit
     *     The durationExtensionLimit
     */
    @JsonProperty("durationExtensionLimit")
    public void setDurationExtensionLimit(String durationExtensionLimit) {
        this.durationExtensionLimit = durationExtensionLimit;
    }

    /**
     * 
     * @return
     *     The averageVisitDuration
     */
    @JsonProperty("averageVisitDuration")
    public String getAverageVisitDuration() {
        return averageVisitDuration;
    }

    /**
     * 
     * @param averageVisitDuration
     *     The averageVisitDuration
     */
    @JsonProperty("averageVisitDuration")
    public void setAverageVisitDuration(String averageVisitDuration) {
        this.averageVisitDuration = averageVisitDuration;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "sameCrew":
                if (value instanceof String) {
                    setSameCrew(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"sameCrew\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "minimumVisitDuration":
                if (value instanceof String) {
                    setMinimumVisitDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"minimumVisitDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "durationExtensionLimit":
                if (value instanceof String) {
                    setDurationExtensionLimit(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"durationExtensionLimit\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "averageVisitDuration":
                if (value instanceof String) {
                    setAverageVisitDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"averageVisitDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "sameCrew":
                return getSameCrew();
            case "minimumVisitDuration":
                return getMinimumVisitDuration();
            case "durationExtensionLimit":
                return getDurationExtensionLimit();
            case "averageVisitDuration":
                return getAverageVisitDuration();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, ComplexActivityTypeDetails.NOT_FOUND_VALUE);
        if (ComplexActivityTypeDetails.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

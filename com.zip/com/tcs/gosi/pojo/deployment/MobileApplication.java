
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "soundPause",
    "minutesForNoContact",
    "remoteScriptCallBackThreshold",
    "m1DataEncryptionGcFlg",
    "realGPSThreshold",
    "soundDuration",
    "panicAlertCountDown",
    "mdtsLogLocation"
})
public class MobileApplication {

    @JsonProperty("soundPause")
    private String soundPause;
    @JsonProperty("minutesForNoContact")
    private String minutesForNoContact;
    @JsonProperty("remoteScriptCallBackThreshold")
    private String remoteScriptCallBackThreshold;
    @JsonProperty("m1DataEncryptionGcFlg")
    private String m1DataEncryptionGcFlg;
    @JsonProperty("realGPSThreshold")
    private String realGPSThreshold;
    @JsonProperty("soundDuration")
    private String soundDuration;
    @JsonProperty("panicAlertCountDown")
    private String panicAlertCountDown;
    @JsonProperty("mdtsLogLocation")
    private String mdtsLogLocation;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The soundPause
     */
    @JsonProperty("soundPause")
    public String getSoundPause() {
        return soundPause;
    }

    /**
     * 
     * @param soundPause
     *     The soundPause
     */
    @JsonProperty("soundPause")
    public void setSoundPause(String soundPause) {
        this.soundPause = soundPause;
    }

    /**
     * 
     * @return
     *     The minutesForNoContact
     */
    @JsonProperty("minutesForNoContact")
    public String getMinutesForNoContact() {
        return minutesForNoContact;
    }

    /**
     * 
     * @param minutesForNoContact
     *     The minutesForNoContact
     */
    @JsonProperty("minutesForNoContact")
    public void setMinutesForNoContact(String minutesForNoContact) {
        this.minutesForNoContact = minutesForNoContact;
    }

    /**
     * 
     * @return
     *     The remoteScriptCallBackThreshold
     */
    @JsonProperty("remoteScriptCallBackThreshold")
    public String getRemoteScriptCallBackThreshold() {
        return remoteScriptCallBackThreshold;
    }

    /**
     * 
     * @param remoteScriptCallBackThreshold
     *     The remoteScriptCallBackThreshold
     */
    @JsonProperty("remoteScriptCallBackThreshold")
    public void setRemoteScriptCallBackThreshold(String remoteScriptCallBackThreshold) {
        this.remoteScriptCallBackThreshold = remoteScriptCallBackThreshold;
    }

    /**
     * 
     * @return
     *     The m1DataEncryptionGcFlg
     */
    @JsonProperty("m1DataEncryptionGcFlg")
    public String getM1DataEncryptionGcFlg() {
        return m1DataEncryptionGcFlg;
    }

    /**
     * 
     * @param m1DataEncryptionGcFlg
     *     The m1DataEncryptionGcFlg
     */
    @JsonProperty("m1DataEncryptionGcFlg")
    public void setM1DataEncryptionGcFlg(String m1DataEncryptionGcFlg) {
        this.m1DataEncryptionGcFlg = m1DataEncryptionGcFlg;
    }

    /**
     * 
     * @return
     *     The realGPSThreshold
     */
    @JsonProperty("realGPSThreshold")
    public String getRealGPSThreshold() {
        return realGPSThreshold;
    }

    /**
     * 
     * @param realGPSThreshold
     *     The realGPSThreshold
     */
    @JsonProperty("realGPSThreshold")
    public void setRealGPSThreshold(String realGPSThreshold) {
        this.realGPSThreshold = realGPSThreshold;
    }

    /**
     * 
     * @return
     *     The soundDuration
     */
    @JsonProperty("soundDuration")
    public String getSoundDuration() {
        return soundDuration;
    }

    /**
     * 
     * @param soundDuration
     *     The soundDuration
     */
    @JsonProperty("soundDuration")
    public void setSoundDuration(String soundDuration) {
        this.soundDuration = soundDuration;
    }

    /**
     * 
     * @return
     *     The panicAlertCountDown
     */
    @JsonProperty("panicAlertCountDown")
    public String getPanicAlertCountDown() {
        return panicAlertCountDown;
    }

    /**
     * 
     * @param panicAlertCountDown
     *     The panicAlertCountDown
     */
    @JsonProperty("panicAlertCountDown")
    public void setPanicAlertCountDown(String panicAlertCountDown) {
        this.panicAlertCountDown = panicAlertCountDown;
    }

    /**
     * 
     * @return
     *     The mdtsLogLocation
     */
    @JsonProperty("mdtsLogLocation")
    public String getMdtsLogLocation() {
        return mdtsLogLocation;
    }

    /**
     * 
     * @param mdtsLogLocation
     *     The mdtsLogLocation
     */
    @JsonProperty("mdtsLogLocation")
    public void setMdtsLogLocation(String mdtsLogLocation) {
        this.mdtsLogLocation = mdtsLogLocation;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "soundPause":
                if (value instanceof String) {
                    setSoundPause(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"soundPause\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "minutesForNoContact":
                if (value instanceof String) {
                    setMinutesForNoContact(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"minutesForNoContact\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "remoteScriptCallBackThreshold":
                if (value instanceof String) {
                    setRemoteScriptCallBackThreshold(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"remoteScriptCallBackThreshold\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "m1DataEncryptionGcFlg":
                if (value instanceof String) {
                    setM1DataEncryptionGcFlg(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"m1DataEncryptionGcFlg\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "realGPSThreshold":
                if (value instanceof String) {
                    setRealGPSThreshold(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"realGPSThreshold\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "soundDuration":
                if (value instanceof String) {
                    setSoundDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"soundDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "panicAlertCountDown":
                if (value instanceof String) {
                    setPanicAlertCountDown(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"panicAlertCountDown\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "mdtsLogLocation":
                if (value instanceof String) {
                    setMdtsLogLocation(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"mdtsLogLocation\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "soundPause":
                return getSoundPause();
            case "minutesForNoContact":
                return getMinutesForNoContact();
            case "remoteScriptCallBackThreshold":
                return getRemoteScriptCallBackThreshold();
            case "m1DataEncryptionGcFlg":
                return getM1DataEncryptionGcFlg();
            case "realGPSThreshold":
                return getRealGPSThreshold();
            case "soundDuration":
                return getSoundDuration();
            case "panicAlertCountDown":
                return getPanicAlertCountDown();
            case "mdtsLogLocation":
                return getMdtsLogLocation();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, MobileApplication.NOT_FOUND_VALUE);
        if (MobileApplication.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "attachmentId",
    "autodownload"
})
public class AttachmentList__ {

	@JsonProperty("seqNum")
	private String seqNum;
	@JsonProperty("attachmentId")
    private String attachmentId;
    @JsonProperty("charType")
    private String charType;

	protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The attachmentId
     */
    @JsonProperty("attachmentId")
    public String getAttachmentId() {
        return attachmentId;
    }

    /**
     * 
     * @param attachmentId
     *     The attachmentId
     */
    @JsonProperty("attachmentId")
    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }
    
    @JsonProperty("seqNum")
	public String getSeqNum() {
		return seqNum;
	}

    @JsonProperty("seqNum")
	public void setSeqNum(String seqNum) {
		this.seqNum = seqNum;
	}
    
    @JsonProperty("charType")
    public String getCharType() {
		return charType;
	}

    @JsonProperty("charType")
	public void setCharType(String charType) {
		this.charType = charType;
	}

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "attachmentId":
                if (value instanceof String) {
                    setAttachmentId(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentId\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "seqNum":
                if (value instanceof String) {
                    setSeqNum(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"autodownload\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "charType":
                if (value instanceof String) {
                    setSeqNum(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"autodownload\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "attachmentId":
                return getAttachmentId();
            case "seqNum":
                return getSeqNum();
            case "charType":
                return getCharType();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, AttachmentList_.NOT_FOUND_VALUE);
        if (AttachmentList_.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}


package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "content",
    "deploymentId"
})
public class DeploymentDetails {

    @JsonProperty("content")
    private Content content;
    @JsonProperty("deploymentId")
    private String deploymentId;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The content
     */
    @JsonProperty("content")
    public Content getContent() {
        return content;
    }

    /**
     * 
     * @param content
     *     The content
     */
    @JsonProperty("content")
    public void setContent(Content content) {
        this.content = content;
    }

    /**
     * 
     * @return
     *     The deploymentId
     */
    @JsonProperty("deploymentId")
    public String getDeploymentId() {
        return deploymentId;
    }

    /**
     * 
     * @param deploymentId
     *     The deploymentId
     */
    @JsonProperty("deploymentId")
    public void setDeploymentId(String deploymentId) {
        this.deploymentId = deploymentId;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "content":
                if (value instanceof Content) {
                    setContent(((Content) value));
                } else {
                    throw new IllegalArgumentException(("property \"content\" is of type \"com.tcs.gosi.pojo.deployment.Content\", but got "+ value.getClass().toString()));
                }
                return true;
            case "deploymentId":
                if (value instanceof String) {
                    setDeploymentId(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"deploymentId\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "content":
                return getContent();
            case "deploymentId":
                return getDeploymentId();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, DeploymentDetails.NOT_FOUND_VALUE);
        if (DeploymentDetails.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

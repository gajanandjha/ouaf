
package com.tcs.gosi.pojo.deployment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "queue",
    "schedulingPrioritySteps",
    "ignoreSequenceLocking",
    "taskBo",
    "completeWithinOption",
    "slaPriority",
    "taskType",
    "autoAllocationGroup",
    "hostExternalSystem",
    "version",
    "activityExpiration",
    "bo",
    "createByCrew",
    "priorityProfile",
    "toDoSetup",
    "workCalendar",
    "autoDispatch",
    "workProfile",
    "description",
    "crewSize",
    "completeWithinDays",
    "averageDuration",
    "taskClass",
    "status",
    "acknowledgementRequired",
    "shiftPromotion",
    "workTimesheetTimeType",
    "travelTimesheetTimeType",
    "ganttIcon",
    "eligibleforAssist",
    "allowCrewTime",
    "procedureTypes",
    "eligibleForContracting",
    "capabilities",
    "allowBreaks",
    "procedureClearanceRequired",
    "attachmentGroup",
    "efficiencyDurationImpact",
    "defaultAppointmentBookingGroup"
})
public class M1ActivityType {

    @JsonProperty("queue")
    private String queue;
    @JsonProperty("schedulingPrioritySteps")
    private SchedulingPrioritySteps schedulingPrioritySteps;
    @JsonProperty("ignoreSequenceLocking")
    private String ignoreSequenceLocking;
    @JsonProperty("taskBo")
    private String taskBo;
    @JsonProperty("completeWithinOption")
    private String completeWithinOption;
    @JsonProperty("slaPriority")
    private String slaPriority;
    @JsonProperty("taskType")
    private String taskType;
    @JsonProperty("autoAllocationGroup")
    private AutoAllocationGroup autoAllocationGroup;
    @JsonProperty("hostExternalSystem")
    private String hostExternalSystem;
    @JsonProperty("version")
    private String version;
    @JsonProperty("activityExpiration")
    private ActivityExpiration activityExpiration;
    @JsonProperty("bo")
    private String bo;
    @JsonProperty("createByCrew")
    private String createByCrew;
    @JsonProperty("priorityProfile")
    private String priorityProfile;
    @JsonProperty("toDoSetup")
    private ToDoSetup toDoSetup;
    @JsonProperty("workCalendar")
    private String workCalendar;
    @JsonProperty("autoDispatch")
    private String autoDispatch;
    @JsonProperty("workProfile")
    private String workProfile;
    @JsonProperty("description")
    private String description;
    @JsonProperty("crewSize")
    private String crewSize;
    @JsonProperty("completeWithinDays")
    private String completeWithinDays;
    @JsonProperty("averageDuration")
    private String averageDuration;
    @JsonProperty("taskClass")
    private String taskClass;
    @JsonProperty("status")
    private String status;
    @JsonProperty("acknowledgementRequired")
    private String acknowledgementRequired;
    @JsonProperty("shiftPromotion")
    private String shiftPromotion;
    @JsonProperty("workTimesheetTimeType")
    private String workTimesheetTimeType;
    @JsonProperty("travelTimesheetTimeType")
    private String travelTimesheetTimeType;
    @JsonProperty("ganttIcon")
    private String ganttIcon;
    @JsonProperty("eligibleforAssist")
    private String eligibleforAssist;
    @JsonProperty("allowCrewTime")
    private String allowCrewTime;
    @JsonProperty("procedureTypes")
    private ProcedureTypes_ procedureTypes;
    @JsonProperty("eligibleForContracting")
    private String eligibleForContracting;
    @JsonProperty("capabilities")
    private Capabilities capabilities;
    @JsonProperty("allowBreaks")
    private String allowBreaks;
    @JsonProperty("procedureClearanceRequired")
    private String procedureClearanceRequired;
    @JsonProperty("attachmentGroup")
    private AttachmentGroup attachmentGroup;
    @JsonProperty("efficiencyDurationImpact")
    private String efficiencyDurationImpact;
    @JsonProperty("defaultAppointmentBookingGroup")
    private String defaultAppointmentBookingGroup;
    protected final static Object NOT_FOUND_VALUE = new Object();

    /**
     * 
     * @return
     *     The queue
     */
    @JsonProperty("queue")
    public String getQueue() {
        return queue;
    }

    /**
     * 
     * @param queue
     *     The queue
     */
    @JsonProperty("queue")
    public void setQueue(String queue) {
        this.queue = queue;
    }

    /**
     * 
     * @return
     *     The schedulingPrioritySteps
     */
    @JsonProperty("schedulingPrioritySteps")
    public SchedulingPrioritySteps getSchedulingPrioritySteps() {
        return schedulingPrioritySteps;
    }

    /**
     * 
     * @param schedulingPrioritySteps
     *     The schedulingPrioritySteps
     */
    @JsonProperty("schedulingPrioritySteps")
    public void setSchedulingPrioritySteps(SchedulingPrioritySteps schedulingPrioritySteps) {
        this.schedulingPrioritySteps = schedulingPrioritySteps;
    }

    /**
     * 
     * @return
     *     The ignoreSequenceLocking
     */
    @JsonProperty("ignoreSequenceLocking")
    public String getIgnoreSequenceLocking() {
        return ignoreSequenceLocking;
    }

    /**
     * 
     * @param ignoreSequenceLocking
     *     The ignoreSequenceLocking
     */
    @JsonProperty("ignoreSequenceLocking")
    public void setIgnoreSequenceLocking(String ignoreSequenceLocking) {
        this.ignoreSequenceLocking = ignoreSequenceLocking;
    }

    /**
     * 
     * @return
     *     The taskBo
     */
    @JsonProperty("taskBo")
    public String getTaskBo() {
        return taskBo;
    }

    /**
     * 
     * @param taskBo
     *     The taskBo
     */
    @JsonProperty("taskBo")
    public void setTaskBo(String taskBo) {
        this.taskBo = taskBo;
    }

    /**
     * 
     * @return
     *     The completeWithinOption
     */
    @JsonProperty("completeWithinOption")
    public String getCompleteWithinOption() {
        return completeWithinOption;
    }

    /**
     * 
     * @param completeWithinOption
     *     The completeWithinOption
     */
    @JsonProperty("completeWithinOption")
    public void setCompleteWithinOption(String completeWithinOption) {
        this.completeWithinOption = completeWithinOption;
    }

    /**
     * 
     * @return
     *     The slaPriority
     */
    @JsonProperty("slaPriority")
    public String getSlaPriority() {
        return slaPriority;
    }

    /**
     * 
     * @param slaPriority
     *     The slaPriority
     */
    @JsonProperty("slaPriority")
    public void setSlaPriority(String slaPriority) {
        this.slaPriority = slaPriority;
    }

    /**
     * 
     * @return
     *     The taskType
     */
    @JsonProperty("taskType")
    public String getTaskType() {
        return taskType;
    }

    /**
     * 
     * @param taskType
     *     The taskType
     */
    @JsonProperty("taskType")
    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    /**
     * 
     * @return
     *     The autoAllocationGroup
     */
    @JsonProperty("autoAllocationGroup")
    public AutoAllocationGroup getAutoAllocationGroup() {
        return autoAllocationGroup;
    }

    /**
     * 
     * @param autoAllocationGroup
     *     The autoAllocationGroup
     */
    @JsonProperty("autoAllocationGroup")
    public void setAutoAllocationGroup(AutoAllocationGroup autoAllocationGroup) {
        this.autoAllocationGroup = autoAllocationGroup;
    }

    /**
     * 
     * @return
     *     The hostExternalSystem
     */
    @JsonProperty("hostExternalSystem")
    public String getHostExternalSystem() {
        return hostExternalSystem;
    }

    /**
     * 
     * @param hostExternalSystem
     *     The hostExternalSystem
     */
    @JsonProperty("hostExternalSystem")
    public void setHostExternalSystem(String hostExternalSystem) {
        this.hostExternalSystem = hostExternalSystem;
    }

    /**
     * 
     * @return
     *     The version
     */
    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    /**
     * 
     * @param version
     *     The version
     */
    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * 
     * @return
     *     The activityExpiration
     */
    @JsonProperty("activityExpiration")
    public ActivityExpiration getActivityExpiration() {
        return activityExpiration;
    }

    /**
     * 
     * @param activityExpiration
     *     The activityExpiration
     */
    @JsonProperty("activityExpiration")
    public void setActivityExpiration(ActivityExpiration activityExpiration) {
        this.activityExpiration = activityExpiration;
    }

    /**
     * 
     * @return
     *     The bo
     */
    @JsonProperty("bo")
    public String getBo() {
        return bo;
    }

    /**
     * 
     * @param bo
     *     The bo
     */
    @JsonProperty("bo")
    public void setBo(String bo) {
        this.bo = bo;
    }

    /**
     * 
     * @return
     *     The createByCrew
     */
    @JsonProperty("createByCrew")
    public String getCreateByCrew() {
        return createByCrew;
    }

    /**
     * 
     * @param createByCrew
     *     The createByCrew
     */
    @JsonProperty("createByCrew")
    public void setCreateByCrew(String createByCrew) {
        this.createByCrew = createByCrew;
    }

    /**
     * 
     * @return
     *     The priorityProfile
     */
    @JsonProperty("priorityProfile")
    public String getPriorityProfile() {
        return priorityProfile;
    }

    /**
     * 
     * @param priorityProfile
     *     The priorityProfile
     */
    @JsonProperty("priorityProfile")
    public void setPriorityProfile(String priorityProfile) {
        this.priorityProfile = priorityProfile;
    }

    /**
     * 
     * @return
     *     The toDoSetup
     */
    @JsonProperty("toDoSetup")
    public ToDoSetup getToDoSetup() {
        return toDoSetup;
    }

    /**
     * 
     * @param toDoSetup
     *     The toDoSetup
     */
    @JsonProperty("toDoSetup")
    public void setToDoSetup(ToDoSetup toDoSetup) {
        this.toDoSetup = toDoSetup;
    }

    /**
     * 
     * @return
     *     The workCalendar
     */
    @JsonProperty("workCalendar")
    public String getWorkCalendar() {
        return workCalendar;
    }

    /**
     * 
     * @param workCalendar
     *     The workCalendar
     */
    @JsonProperty("workCalendar")
    public void setWorkCalendar(String workCalendar) {
        this.workCalendar = workCalendar;
    }

    /**
     * 
     * @return
     *     The autoDispatch
     */
    @JsonProperty("autoDispatch")
    public String getAutoDispatch() {
        return autoDispatch;
    }

    /**
     * 
     * @param autoDispatch
     *     The autoDispatch
     */
    @JsonProperty("autoDispatch")
    public void setAutoDispatch(String autoDispatch) {
        this.autoDispatch = autoDispatch;
    }

    /**
     * 
     * @return
     *     The workProfile
     */
    @JsonProperty("workProfile")
    public String getWorkProfile() {
        return workProfile;
    }

    /**
     * 
     * @param workProfile
     *     The workProfile
     */
    @JsonProperty("workProfile")
    public void setWorkProfile(String workProfile) {
        this.workProfile = workProfile;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return
     *     The crewSize
     */
    @JsonProperty("crewSize")
    public String getCrewSize() {
        return crewSize;
    }

    /**
     * 
     * @param crewSize
     *     The crewSize
     */
    @JsonProperty("crewSize")
    public void setCrewSize(String crewSize) {
        this.crewSize = crewSize;
    }

    /**
     * 
     * @return
     *     The completeWithinDays
     */
    @JsonProperty("completeWithinDays")
    public String getCompleteWithinDays() {
        return completeWithinDays;
    }

    /**
     * 
     * @param completeWithinDays
     *     The completeWithinDays
     */
    @JsonProperty("completeWithinDays")
    public void setCompleteWithinDays(String completeWithinDays) {
        this.completeWithinDays = completeWithinDays;
    }

    /**
     * 
     * @return
     *     The averageDuration
     */
    @JsonProperty("averageDuration")
    public String getAverageDuration() {
        return averageDuration;
    }

    /**
     * 
     * @param averageDuration
     *     The averageDuration
     */
    @JsonProperty("averageDuration")
    public void setAverageDuration(String averageDuration) {
        this.averageDuration = averageDuration;
    }

    /**
     * 
     * @return
     *     The taskClass
     */
    @JsonProperty("taskClass")
    public String getTaskClass() {
        return taskClass;
    }

    /**
     * 
     * @param taskClass
     *     The taskClass
     */
    @JsonProperty("taskClass")
    public void setTaskClass(String taskClass) {
        this.taskClass = taskClass;
    }

    /**
     * 
     * @return
     *     The status
     */
    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    /**
     * 
     * @param status
     *     The status
     */
    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * 
     * @return
     *     The acknowledgementRequired
     */
    @JsonProperty("acknowledgementRequired")
    public String getAcknowledgementRequired() {
        return acknowledgementRequired;
    }

    /**
     * 
     * @param acknowledgementRequired
     *     The acknowledgementRequired
     */
    @JsonProperty("acknowledgementRequired")
    public void setAcknowledgementRequired(String acknowledgementRequired) {
        this.acknowledgementRequired = acknowledgementRequired;
    }

    /**
     * 
     * @return
     *     The shiftPromotion
     */
    @JsonProperty("shiftPromotion")
    public String getShiftPromotion() {
        return shiftPromotion;
    }

    /**
     * 
     * @param shiftPromotion
     *     The shiftPromotion
     */
    @JsonProperty("shiftPromotion")
    public void setShiftPromotion(String shiftPromotion) {
        this.shiftPromotion = shiftPromotion;
    }

    /**
     * 
     * @return
     *     The workTimesheetTimeType
     */
    @JsonProperty("workTimesheetTimeType")
    public String getWorkTimesheetTimeType() {
        return workTimesheetTimeType;
    }

    /**
     * 
     * @param workTimesheetTimeType
     *     The workTimesheetTimeType
     */
    @JsonProperty("workTimesheetTimeType")
    public void setWorkTimesheetTimeType(String workTimesheetTimeType) {
        this.workTimesheetTimeType = workTimesheetTimeType;
    }

    /**
     * 
     * @return
     *     The travelTimesheetTimeType
     */
    @JsonProperty("travelTimesheetTimeType")
    public String getTravelTimesheetTimeType() {
        return travelTimesheetTimeType;
    }

    /**
     * 
     * @param travelTimesheetTimeType
     *     The travelTimesheetTimeType
     */
    @JsonProperty("travelTimesheetTimeType")
    public void setTravelTimesheetTimeType(String travelTimesheetTimeType) {
        this.travelTimesheetTimeType = travelTimesheetTimeType;
    }

    /**
     * 
     * @return
     *     The ganttIcon
     */
    @JsonProperty("ganttIcon")
    public String getGanttIcon() {
        return ganttIcon;
    }

    /**
     * 
     * @param ganttIcon
     *     The ganttIcon
     */
    @JsonProperty("ganttIcon")
    public void setGanttIcon(String ganttIcon) {
        this.ganttIcon = ganttIcon;
    }

    /**
     * 
     * @return
     *     The eligibleforAssist
     */
    @JsonProperty("eligibleforAssist")
    public String getEligibleforAssist() {
        return eligibleforAssist;
    }

    /**
     * 
     * @param eligibleforAssist
     *     The eligibleforAssist
     */
    @JsonProperty("eligibleforAssist")
    public void setEligibleforAssist(String eligibleforAssist) {
        this.eligibleforAssist = eligibleforAssist;
    }

    /**
     * 
     * @return
     *     The allowCrewTime
     */
    @JsonProperty("allowCrewTime")
    public String getAllowCrewTime() {
        return allowCrewTime;
    }

    /**
     * 
     * @param allowCrewTime
     *     The allowCrewTime
     */
    @JsonProperty("allowCrewTime")
    public void setAllowCrewTime(String allowCrewTime) {
        this.allowCrewTime = allowCrewTime;
    }

    /**
     * 
     * @return
     *     The procedureTypes
     */
    @JsonProperty("procedureTypes")
    public ProcedureTypes_ getProcedureTypes() {
        return procedureTypes;
    }

    /**
     * 
     * @param procedureTypes
     *     The procedureTypes
     */
    @JsonProperty("procedureTypes")
    public void setProcedureTypes(ProcedureTypes_ procedureTypes) {
        this.procedureTypes = procedureTypes;
    }

    /**
     * 
     * @return
     *     The eligibleForContracting
     */
    @JsonProperty("eligibleForContracting")
    public String getEligibleForContracting() {
        return eligibleForContracting;
    }

    /**
     * 
     * @param eligibleForContracting
     *     The eligibleForContracting
     */
    @JsonProperty("eligibleForContracting")
    public void setEligibleForContracting(String eligibleForContracting) {
        this.eligibleForContracting = eligibleForContracting;
    }

    /**
     * 
     * @return
     *     The capabilities
     */
    @JsonProperty("capabilities")
    public Capabilities getCapabilities() {
        return capabilities;
    }

    /**
     * 
     * @param capabilities
     *     The capabilities
     */
    @JsonProperty("capabilities")
    public void setCapabilities(Capabilities capabilities) {
        this.capabilities = capabilities;
    }

    /**
     * 
     * @return
     *     The allowBreaks
     */
    @JsonProperty("allowBreaks")
    public String getAllowBreaks() {
        return allowBreaks;
    }

    /**
     * 
     * @param allowBreaks
     *     The allowBreaks
     */
    @JsonProperty("allowBreaks")
    public void setAllowBreaks(String allowBreaks) {
        this.allowBreaks = allowBreaks;
    }

    /**
     * 
     * @return
     *     The procedureClearanceRequired
     */
    @JsonProperty("procedureClearanceRequired")
    public String getProcedureClearanceRequired() {
        return procedureClearanceRequired;
    }

    /**
     * 
     * @param procedureClearanceRequired
     *     The procedureClearanceRequired
     */
    @JsonProperty("procedureClearanceRequired")
    public void setProcedureClearanceRequired(String procedureClearanceRequired) {
        this.procedureClearanceRequired = procedureClearanceRequired;
    }

    /**
     * 
     * @return
     *     The attachmentGroup
     */
    @JsonProperty("attachmentGroup")
    public AttachmentGroup getAttachmentGroup() {
        return attachmentGroup;
    }

    /**
     * 
     * @param attachmentGroup
     *     The attachmentGroup
     */
    @JsonProperty("attachmentGroup")
    public void setAttachmentGroup(AttachmentGroup attachmentGroup) {
        this.attachmentGroup = attachmentGroup;
    }

    /**
     * 
     * @return
     *     The efficiencyDurationImpact
     */
    @JsonProperty("efficiencyDurationImpact")
    public String getEfficiencyDurationImpact() {
        return efficiencyDurationImpact;
    }

    /**
     * 
     * @param efficiencyDurationImpact
     *     The efficiencyDurationImpact
     */
    @JsonProperty("efficiencyDurationImpact")
    public void setEfficiencyDurationImpact(String efficiencyDurationImpact) {
        this.efficiencyDurationImpact = efficiencyDurationImpact;
    }

    /**
     * 
     * @return
     *     The defaultAppointmentBookingGroup
     */
    @JsonProperty("defaultAppointmentBookingGroup")
    public String getDefaultAppointmentBookingGroup() {
        return defaultAppointmentBookingGroup;
    }

    /**
     * 
     * @param defaultAppointmentBookingGroup
     *     The defaultAppointmentBookingGroup
     */
    @JsonProperty("defaultAppointmentBookingGroup")
    public void setDefaultAppointmentBookingGroup(String defaultAppointmentBookingGroup) {
        this.defaultAppointmentBookingGroup = defaultAppointmentBookingGroup;
    }

    protected boolean declaredProperty(String name, Object value) {
        switch (name) {
            case "queue":
                if (value instanceof String) {
                    setQueue(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"queue\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "schedulingPrioritySteps":
                if (value instanceof SchedulingPrioritySteps) {
                    setSchedulingPrioritySteps(((SchedulingPrioritySteps) value));
                } else {
                    throw new IllegalArgumentException(("property \"schedulingPrioritySteps\" is of type \"com.tcs.gosi.pojo.deployment.SchedulingPrioritySteps\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ignoreSequenceLocking":
                if (value instanceof String) {
                    setIgnoreSequenceLocking(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"ignoreSequenceLocking\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskBo":
                if (value instanceof String) {
                    setTaskBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskBo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "completeWithinOption":
                if (value instanceof String) {
                    setCompleteWithinOption(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"completeWithinOption\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "slaPriority":
                if (value instanceof String) {
                    setSlaPriority(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"slaPriority\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskType":
                if (value instanceof String) {
                    setTaskType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "autoAllocationGroup":
                if (value instanceof AutoAllocationGroup) {
                    setAutoAllocationGroup(((AutoAllocationGroup) value));
                } else {
                    throw new IllegalArgumentException(("property \"autoAllocationGroup\" is of type \"com.tcs.gosi.pojo.deployment.AutoAllocationGroup\", but got "+ value.getClass().toString()));
                }
                return true;
            case "hostExternalSystem":
                if (value instanceof String) {
                    setHostExternalSystem(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"hostExternalSystem\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "version":
                if (value instanceof String) {
                    setVersion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"version\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "activityExpiration":
                if (value instanceof ActivityExpiration) {
                    setActivityExpiration(((ActivityExpiration) value));
                } else {
                    throw new IllegalArgumentException(("property \"activityExpiration\" is of type \"com.tcs.gosi.pojo.deployment.ActivityExpiration\", but got "+ value.getClass().toString()));
                }
                return true;
            case "bo":
                if (value instanceof String) {
                    setBo(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"bo\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "createByCrew":
                if (value instanceof String) {
                    setCreateByCrew(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"createByCrew\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "priorityProfile":
                if (value instanceof String) {
                    setPriorityProfile(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"priorityProfile\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "toDoSetup":
                if (value instanceof ToDoSetup) {
                    setToDoSetup(((ToDoSetup) value));
                } else {
                    throw new IllegalArgumentException(("property \"toDoSetup\" is of type \"com.tcs.gosi.pojo.deployment.ToDoSetup\", but got "+ value.getClass().toString()));
                }
                return true;
            case "workCalendar":
                if (value instanceof String) {
                    setWorkCalendar(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"workCalendar\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "autoDispatch":
                if (value instanceof String) {
                    setAutoDispatch(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"autoDispatch\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "workProfile":
                if (value instanceof String) {
                    setWorkProfile(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"workProfile\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "description":
                if (value instanceof String) {
                    setDescription(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"description\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "crewSize":
                if (value instanceof String) {
                    setCrewSize(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"crewSize\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "completeWithinDays":
                if (value instanceof String) {
                    setCompleteWithinDays(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"completeWithinDays\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "averageDuration":
                if (value instanceof String) {
                    setAverageDuration(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"averageDuration\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "taskClass":
                if (value instanceof String) {
                    setTaskClass(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"taskClass\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "status":
                if (value instanceof String) {
                    setStatus(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"status\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "acknowledgementRequired":
                if (value instanceof String) {
                    setAcknowledgementRequired(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"acknowledgementRequired\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "shiftPromotion":
                if (value instanceof String) {
                    setShiftPromotion(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"shiftPromotion\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "workTimesheetTimeType":
                if (value instanceof String) {
                    setWorkTimesheetTimeType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"workTimesheetTimeType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "travelTimesheetTimeType":
                if (value instanceof String) {
                    setTravelTimesheetTimeType(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"travelTimesheetTimeType\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "ganttIcon":
                if (value instanceof String) {
                    setGanttIcon(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"ganttIcon\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "eligibleforAssist":
                if (value instanceof String) {
                    setEligibleforAssist(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"eligibleforAssist\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "allowCrewTime":
                if (value instanceof String) {
                    setAllowCrewTime(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"allowCrewTime\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "procedureTypes":
                if (value instanceof ProcedureTypes_) {
                    setProcedureTypes(((ProcedureTypes_) value));
                } else {
                    throw new IllegalArgumentException(("property \"procedureTypes\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "eligibleForContracting":
                if (value instanceof String) {
                    setEligibleForContracting(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"eligibleForContracting\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "capabilities":
                if (value instanceof Capabilities) {
                    setCapabilities(((Capabilities) value));
                } else {
                    throw new IllegalArgumentException(("property \"capabilities\" is of type \"com.tcs.gosi.pojo.deployment.Capabilities\", but got "+ value.getClass().toString()));
                }
                return true;
            case "allowBreaks":
                if (value instanceof String) {
                    setAllowBreaks(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"allowBreaks\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "procedureClearanceRequired":
                if (value instanceof String) {
                    setProcedureClearanceRequired(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"procedureClearanceRequired\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "attachmentGroup":
                if (value instanceof AttachmentGroup) {
                    setAttachmentGroup(((AttachmentGroup) value));
                } else {
                    throw new IllegalArgumentException(("property \"attachmentGroup\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "efficiencyDurationImpact":
                if (value instanceof String) {
                    setEfficiencyDurationImpact(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"efficiencyDurationImpact\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            case "defaultAppointmentBookingGroup":
                if (value instanceof String) {
                    setDefaultAppointmentBookingGroup(((String) value));
                } else {
                    throw new IllegalArgumentException(("property \"defaultAppointmentBookingGroup\" is of type \"java.lang.String\", but got "+ value.getClass().toString()));
                }
                return true;
            default:
                return false;
        }
    }

    protected Object declaredPropertyOrNotFound(String name, Object notFoundValue) {
        switch (name) {
            case "queue":
                return getQueue();
            case "schedulingPrioritySteps":
                return getSchedulingPrioritySteps();
            case "ignoreSequenceLocking":
                return getIgnoreSequenceLocking();
            case "taskBo":
                return getTaskBo();
            case "completeWithinOption":
                return getCompleteWithinOption();
            case "slaPriority":
                return getSlaPriority();
            case "taskType":
                return getTaskType();
            case "autoAllocationGroup":
                return getAutoAllocationGroup();
            case "hostExternalSystem":
                return getHostExternalSystem();
            case "version":
                return getVersion();
            case "activityExpiration":
                return getActivityExpiration();
            case "bo":
                return getBo();
            case "createByCrew":
                return getCreateByCrew();
            case "priorityProfile":
                return getPriorityProfile();
            case "toDoSetup":
                return getToDoSetup();
            case "workCalendar":
                return getWorkCalendar();
            case "autoDispatch":
                return getAutoDispatch();
            case "workProfile":
                return getWorkProfile();
            case "description":
                return getDescription();
            case "crewSize":
                return getCrewSize();
            case "completeWithinDays":
                return getCompleteWithinDays();
            case "averageDuration":
                return getAverageDuration();
            case "taskClass":
                return getTaskClass();
            case "status":
                return getStatus();
            case "acknowledgementRequired":
                return getAcknowledgementRequired();
            case "shiftPromotion":
                return getShiftPromotion();
            case "workTimesheetTimeType":
                return getWorkTimesheetTimeType();
            case "travelTimesheetTimeType":
                return getTravelTimesheetTimeType();
            case "ganttIcon":
                return getGanttIcon();
            case "eligibleforAssist":
                return getEligibleforAssist();
            case "allowCrewTime":
                return getAllowCrewTime();
            case "procedureTypes":
                return getProcedureTypes();
            case "eligibleForContracting":
                return getEligibleForContracting();
            case "capabilities":
                return getCapabilities();
            case "allowBreaks":
                return getAllowBreaks();
            case "procedureClearanceRequired":
                return getProcedureClearanceRequired();
            case "attachmentGroup":
                return getAttachmentGroup();
            case "efficiencyDurationImpact":
                return getEfficiencyDurationImpact();
            case "defaultAppointmentBookingGroup":
                return getDefaultAppointmentBookingGroup();
            default:
                return notFoundValue;
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    public<T >T get(String name) {
        Object value = declaredPropertyOrNotFound(name, M1ActivityType.NOT_FOUND_VALUE);
        if (M1ActivityType.NOT_FOUND_VALUE!= value) {
            return ((T) value);
        } else {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

    public void set(String name, Object value) {
        if (!declaredProperty(name, value)) {
            throw new IllegalArgumentException((("property \""+ name)+"\" is not defined"));
        }
    }

}

package com.tcs.gosi.pojo;

public class input {

	private String mdtId;
	private String userId;
	String languageCode;
	String currentShiftId;
	
	public String getMdtId() {
		return mdtId;
	}
	public void setMdtId(String mdtId) {
		this.mdtId = mdtId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public String getCurrentShiftId() {
		return currentShiftId;
	}
	public void setCurrentShiftId(String currentShiftId) {
		this.currentShiftId = currentShiftId;
	}

}

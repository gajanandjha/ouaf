package com.tcs.gosi.pojo;

public class M1GetDeploymentListREST {

	public M1GetDeploymentListREST() {
		super();
		m1_GetDeploymentListREST = new M1_GetDeploymentListREST();
	}
	
	private M1_GetDeploymentListREST m1_GetDeploymentListREST;

	public M1_GetDeploymentListREST getM1_GetDeploymentListREST() {
		return m1_GetDeploymentListREST;
	}

	public void setM1_GetDeploymentListREST(M1_GetDeploymentListREST m1_GetDeploymentListREST) {
		this.m1_GetDeploymentListREST = m1_GetDeploymentListREST;
	}

}

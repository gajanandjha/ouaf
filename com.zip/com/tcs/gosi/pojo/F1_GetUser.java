package com.tcs.gosi.pojo;

public class F1_GetUser {
	
	private String user;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
}

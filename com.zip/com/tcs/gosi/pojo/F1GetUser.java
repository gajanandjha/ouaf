package com.tcs.gosi.pojo;

public class F1GetUser {

	private F1_GetUser F1_GetUser;
	
	public F1GetUser() {
		super();
		F1_GetUser = new F1_GetUser();
	}

	public F1_GetUser getF1_GetUser() {
		return F1_GetUser;
	}

	public void setF1_GetUser(F1_GetUser f1_GetUser) {
		F1_GetUser = f1_GetUser;
	}
}